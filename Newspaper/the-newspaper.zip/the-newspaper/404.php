<?php
/**
 * @package 	WordPress
 * @subpackage 	The Newspaper
 * @version 	1.0.0
 * 
 * 404 Error Page Template
 * Created by CMSMasters
 * 
 */


get_header();


get_template_part('theme-framework/theme-style' . CMSMASTERS_THEME_STYLE . '/template/404');


get_footer();

