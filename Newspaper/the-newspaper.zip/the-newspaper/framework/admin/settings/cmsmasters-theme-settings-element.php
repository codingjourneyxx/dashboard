<?php 
/**
 * @package 	WordPress
 * @subpackage 	The Newspaper
 * @version 	1.1.8
 * 
 * Admin Panel Element Options
 * Created by CMSMasters
 * 
 */


function the_newspaper_options_element_tabs() {
	$tabs = array();
	
	$tabs['sidebar'] = esc_attr__('Sidebars', 'the-newspaper');
	
	if (class_exists('Cmsmasters_Content_Composer')) {
		$tabs['icon'] = esc_attr__('Social Icons', 'the-newspaper');
	}
	
	$tabs['lightbox'] = esc_attr__('Lightbox', 'the-newspaper');
	$tabs['sitemap'] = esc_attr__('Sitemap', 'the-newspaper');
	$tabs['error'] = esc_attr__('404', 'the-newspaper');
	$tabs['code'] = esc_attr__('Custom Codes', 'the-newspaper');
	
	if (class_exists('Cmsmasters_Form_Builder')) {
		$tabs['recaptcha'] = esc_attr__('reCAPTCHA', 'the-newspaper');
	}
	
	return apply_filters('cmsmasters_options_element_tabs_filter', $tabs);
}


function the_newspaper_options_element_sections() {
	$tab = the_newspaper_get_the_tab();
	
	switch ($tab) {
	case 'sidebar':
		$sections = array();
		
		$sections['sidebar_section'] = esc_attr__('Custom Sidebars', 'the-newspaper');
		
		break;
	case 'icon':
		$sections = array();
		
		$sections['icon_section'] = esc_attr__('Social Icons', 'the-newspaper');
		
		break;
	case 'lightbox':
		$sections = array();
		
		$sections['lightbox_section'] = esc_attr__('Theme Lightbox Options', 'the-newspaper');
		
		break;
	case 'sitemap':
		$sections = array();
		
		$sections['sitemap_section'] = esc_attr__('Sitemap Page Options', 'the-newspaper');
		
		break;
	case 'error':
		$sections = array();
		
		$sections['error_section'] = esc_attr__('404 Error Page Options', 'the-newspaper');
		
		break;
	case 'code':
		$sections = array();
		
		$sections['code_section'] = esc_attr__('Custom Codes', 'the-newspaper');
		
		break;
	case 'recaptcha':
		$sections = array();
		
		$sections['recaptcha_section'] = esc_attr__('Form Builder Plugin reCAPTCHA Keys', 'the-newspaper');
		
		break;
	default:
		$sections = array();
		
		
		break;
	}
	
	return apply_filters('cmsmasters_options_element_sections_filter', $sections, $tab);	
} 


function the_newspaper_options_element_fields($set_tab = false) {
	if ($set_tab) {
		$tab = $set_tab;
	} else {
		$tab = the_newspaper_get_the_tab();
	}
	
	
	$options = array();
	
	
	$defaults = the_newspaper_settings_element_defaults();
	
	
	switch ($tab) {
	case 'sidebar':
		$options[] = array( 
			'section' => 'sidebar_section', 
			'id' => 'the-newspaper' . '_sidebar', 
			'title' => esc_html__('Custom Sidebars', 'the-newspaper'), 
			'desc' => '', 
			'type' => 'sidebar', 
			'std' => $defaults[$tab]['the-newspaper' . '_sidebar'] 
		);
		
		break;
	case 'icon':
		$options[] = array( 
			'section' => 'icon_section', 
			'id' => 'the-newspaper' . '_social_icons', 
			'title' => esc_html__('Social Icons', 'the-newspaper'), 
			'desc' => '', 
			'type' => 'social', 
			'std' => $defaults[$tab]['the-newspaper' . '_social_icons'] 
		);
		
		break;
	case 'lightbox':
		$options[] = array( 
			'section' => 'lightbox_section', 
			'id' => 'the-newspaper' . '_ilightbox_skin', 
			'title' => esc_html__('Skin', 'the-newspaper'), 
			'desc' => '', 
			'type' => 'select', 
			'std' => $defaults[$tab]['the-newspaper' . '_ilightbox_skin'], 
			'choices' => array( 
				esc_html__('Dark', 'the-newspaper') . '|dark', 
				esc_html__('Light', 'the-newspaper') . '|light', 
				esc_html__('Mac', 'the-newspaper') . '|mac', 
				esc_html__('Metro Black', 'the-newspaper') . '|metro-black', 
				esc_html__('Metro White', 'the-newspaper') . '|metro-white', 
				esc_html__('Parade', 'the-newspaper') . '|parade', 
				esc_html__('Smooth', 'the-newspaper') . '|smooth' 
			) 
		);
		
		$options[] = array( 
			'section' => 'lightbox_section', 
			'id' => 'the-newspaper' . '_ilightbox_path', 
			'title' => esc_html__('Path', 'the-newspaper'), 
			'desc' => esc_html__('Sets path for switching windows', 'the-newspaper'), 
			'type' => 'radio', 
			'std' => $defaults[$tab]['the-newspaper' . '_ilightbox_path'], 
			'choices' => array( 
				esc_html__('Vertical', 'the-newspaper') . '|vertical', 
				esc_html__('Horizontal', 'the-newspaper') . '|horizontal' 
			) 
		);
		
		$options[] = array( 
			'section' => 'lightbox_section', 
			'id' => 'the-newspaper' . '_ilightbox_infinite', 
			'title' => esc_html__('Infinite', 'the-newspaper'), 
			'desc' => esc_html__('Sets the ability to infinite the group', 'the-newspaper'), 
			'type' => 'checkbox', 
			'std' => $defaults[$tab]['the-newspaper' . '_ilightbox_infinite'] 
		);
		
		$options[] = array( 
			'section' => 'lightbox_section', 
			'id' => 'the-newspaper' . '_ilightbox_aspect_ratio', 
			'title' => esc_html__('Keep Aspect Ratio', 'the-newspaper'), 
			'desc' => esc_html__('Sets the resizing method used to keep aspect ratio within the viewport', 'the-newspaper'), 
			'type' => 'checkbox', 
			'std' => $defaults[$tab]['the-newspaper' . '_ilightbox_aspect_ratio'] 
		);
		
		$options[] = array( 
			'section' => 'lightbox_section', 
			'id' => 'the-newspaper' . '_ilightbox_mobile_optimizer', 
			'title' => esc_html__('Mobile Optimizer', 'the-newspaper'), 
			'desc' => esc_html__('Make lightboxes optimized for giving better experience with mobile devices', 'the-newspaper'), 
			'type' => 'checkbox', 
			'std' => $defaults[$tab]['the-newspaper' . '_ilightbox_mobile_optimizer'] 
		);
		
		$options[] = array( 
			'section' => 'lightbox_section', 
			'id' => 'the-newspaper' . '_ilightbox_max_scale', 
			'title' => esc_html__('Max Scale', 'the-newspaper'), 
			'desc' => esc_html__('Sets the maximum viewport scale of the content', 'the-newspaper'), 
			'type' => 'number', 
			'std' => $defaults[$tab]['the-newspaper' . '_ilightbox_max_scale'], 
			'min' => 0.1, 
			'max' => 2, 
			'step' => 0.05 
		);
		
		$options[] = array( 
			'section' => 'lightbox_section', 
			'id' => 'the-newspaper' . '_ilightbox_min_scale', 
			'title' => esc_html__('Min Scale', 'the-newspaper'), 
			'desc' => esc_html__('Sets the minimum viewport scale of the content', 'the-newspaper'), 
			'type' => 'number', 
			'std' => $defaults[$tab]['the-newspaper' . '_ilightbox_min_scale'], 
			'min' => 0.1, 
			'max' => 2, 
			'step' => 0.05 
		);
		
		$options[] = array( 
			'section' => 'lightbox_section', 
			'id' => 'the-newspaper' . '_ilightbox_inner_toolbar', 
			'title' => esc_html__('Inner Toolbar', 'the-newspaper'), 
			'desc' => esc_html__('Bring buttons into windows, or let them be over the overlay', 'the-newspaper'), 
			'type' => 'checkbox', 
			'std' => $defaults[$tab]['the-newspaper' . '_ilightbox_inner_toolbar'] 
		);
		
		$options[] = array( 
			'section' => 'lightbox_section', 
			'id' => 'the-newspaper' . '_ilightbox_smart_recognition', 
			'title' => esc_html__('Smart Recognition', 'the-newspaper'), 
			'desc' => esc_html__('Sets content auto recognize from web pages', 'the-newspaper'), 
			'type' => 'checkbox', 
			'std' => $defaults[$tab]['the-newspaper' . '_ilightbox_smart_recognition'] 
		);
		
		$options[] = array( 
			'section' => 'lightbox_section', 
			'id' => 'the-newspaper' . '_ilightbox_fullscreen_one_slide', 
			'title' => esc_html__('Fullscreen One Slide', 'the-newspaper'), 
			'desc' => esc_html__('Decide to fullscreen only one slide or hole gallery the fullscreen mode', 'the-newspaper'), 
			'type' => 'checkbox', 
			'std' => $defaults[$tab]['the-newspaper' . '_ilightbox_fullscreen_one_slide'] 
		);
		
		$options[] = array( 
			'section' => 'lightbox_section', 
			'id' => 'the-newspaper' . '_ilightbox_fullscreen_viewport', 
			'title' => esc_html__('Fullscreen Viewport', 'the-newspaper'), 
			'desc' => esc_html__('Sets the resizing method used to fit content within the fullscreen mode', 'the-newspaper'), 
			'type' => 'select', 
			'std' => $defaults[$tab]['the-newspaper' . '_ilightbox_fullscreen_viewport'], 
			'choices' => array( 
				esc_html__('Center', 'the-newspaper') . '|center', 
				esc_html__('Fit', 'the-newspaper') . '|fit', 
				esc_html__('Fill', 'the-newspaper') . '|fill', 
				esc_html__('Stretch', 'the-newspaper') . '|stretch' 
			) 
		);
		
		$options[] = array( 
			'section' => 'lightbox_section', 
			'id' => 'the-newspaper' . '_ilightbox_controls_toolbar', 
			'title' => esc_html__('Toolbar Controls', 'the-newspaper'), 
			'desc' => esc_html__('Sets buttons be available or not', 'the-newspaper'), 
			'type' => 'checkbox', 
			'std' => $defaults[$tab]['the-newspaper' . '_ilightbox_controls_toolbar'] 
		);
		
		$options[] = array( 
			'section' => 'lightbox_section', 
			'id' => 'the-newspaper' . '_ilightbox_controls_arrows', 
			'title' => esc_html__('Arrow Controls', 'the-newspaper'), 
			'desc' => esc_html__('Enable the arrow buttons', 'the-newspaper'), 
			'type' => 'checkbox', 
			'std' => $defaults[$tab]['the-newspaper' . '_ilightbox_controls_arrows'] 
		);
		
		$options[] = array( 
			'section' => 'lightbox_section', 
			'id' => 'the-newspaper' . '_ilightbox_controls_fullscreen', 
			'title' => esc_html__('Fullscreen Controls', 'the-newspaper'), 
			'desc' => esc_html__('Sets the fullscreen button', 'the-newspaper'), 
			'type' => 'checkbox', 
			'std' => $defaults[$tab]['the-newspaper' . '_ilightbox_controls_fullscreen'] 
		);
		
		$options[] = array( 
			'section' => 'lightbox_section', 
			'id' => 'the-newspaper' . '_ilightbox_controls_thumbnail', 
			'title' => esc_html__('Thumbnails Controls', 'the-newspaper'), 
			'desc' => esc_html__('Sets the thumbnail navigation', 'the-newspaper'), 
			'type' => 'checkbox', 
			'std' => $defaults[$tab]['the-newspaper' . '_ilightbox_controls_thumbnail'] 
		);
		
		$options[] = array( 
			'section' => 'lightbox_section', 
			'id' => 'the-newspaper' . '_ilightbox_controls_keyboard', 
			'title' => esc_html__('Keyboard Controls', 'the-newspaper'), 
			'desc' => esc_html__('Sets the keyboard navigation', 'the-newspaper'), 
			'type' => 'checkbox', 
			'std' => $defaults[$tab]['the-newspaper' . '_ilightbox_controls_keyboard'] 
		);
		
		$options[] = array( 
			'section' => 'lightbox_section', 
			'id' => 'the-newspaper' . '_ilightbox_controls_mousewheel', 
			'title' => esc_html__('Mouse Wheel Controls', 'the-newspaper'), 
			'desc' => esc_html__('Sets the mousewheel navigation', 'the-newspaper'), 
			'type' => 'checkbox', 
			'std' => $defaults[$tab]['the-newspaper' . '_ilightbox_controls_mousewheel'] 
		);
		
		$options[] = array( 
			'section' => 'lightbox_section', 
			'id' => 'the-newspaper' . '_ilightbox_controls_swipe', 
			'title' => esc_html__('Swipe Controls', 'the-newspaper'), 
			'desc' => esc_html__('Sets the swipe navigation', 'the-newspaper'), 
			'type' => 'checkbox', 
			'std' => $defaults[$tab]['the-newspaper' . '_ilightbox_controls_swipe'] 
		);
		
		$options[] = array( 
			'section' => 'lightbox_section', 
			'id' => 'the-newspaper' . '_ilightbox_controls_slideshow', 
			'title' => esc_html__('Slideshow Controls', 'the-newspaper'), 
			'desc' => esc_html__('Enable the slideshow feature and button', 'the-newspaper'), 
			'type' => 'checkbox', 
			'std' => $defaults[$tab]['the-newspaper' . '_ilightbox_controls_slideshow'] 
		);
		
		break;
	case 'sitemap':
		$options[] = array( 
			'section' => 'sitemap_section', 
			'id' => 'the-newspaper' . '_sitemap_nav', 
			'title' => esc_html__('Website Pages', 'the-newspaper'), 
			'desc' => esc_html__('show', 'the-newspaper'), 
			'type' => 'checkbox', 
			'std' => $defaults[$tab]['the-newspaper' . '_sitemap_nav'] 
		);
		
		$options[] = array( 
			'section' => 'sitemap_section', 
			'id' => 'the-newspaper' . '_sitemap_categs', 
			'title' => esc_html__('Blog Archives by Categories', 'the-newspaper'), 
			'desc' => esc_html__('show', 'the-newspaper'), 
			'type' => 'checkbox', 
			'std' => $defaults[$tab]['the-newspaper' . '_sitemap_categs'] 
		);
		
		$options[] = array( 
			'section' => 'sitemap_section', 
			'id' => 'the-newspaper' . '_sitemap_tags', 
			'title' => esc_html__('Blog Archives by Tags', 'the-newspaper'), 
			'desc' => esc_html__('show', 'the-newspaper'), 
			'type' => 'checkbox', 
			'std' => $defaults[$tab]['the-newspaper' . '_sitemap_tags'] 
		);
		
		$options[] = array( 
			'section' => 'sitemap_section', 
			'id' => 'the-newspaper' . '_sitemap_month', 
			'title' => esc_html__('Blog Archives by Month', 'the-newspaper'), 
			'desc' => esc_html__('show', 'the-newspaper'), 
			'type' => 'checkbox', 
			'std' => $defaults[$tab]['the-newspaper' . '_sitemap_month'] 
		);
		
		$options[] = array( 
			'section' => 'sitemap_section', 
			'id' => 'the-newspaper' . '_sitemap_pj_categs', 
			'title' => esc_html__('Portfolio Archives by Categories', 'the-newspaper'), 
			'desc' => esc_html__('show', 'the-newspaper'), 
			'type' => 'checkbox', 
			'std' => $defaults[$tab]['the-newspaper' . '_sitemap_pj_categs'] 
		);
		
		$options[] = array( 
			'section' => 'sitemap_section', 
			'id' => 'the-newspaper' . '_sitemap_pj_tags', 
			'title' => esc_html__('Portfolio Archives by Tags', 'the-newspaper'), 
			'desc' => esc_html__('show', 'the-newspaper'), 
			'type' => 'checkbox', 
			'std' => $defaults[$tab]['the-newspaper' . '_sitemap_pj_tags'] 
		);
		
		break;
	case 'error':
		$options[] = array( 
			'section' => 'error_section', 
			'id' => 'the-newspaper' . '_error_color', 
			'title' => esc_html__('Text Color', 'the-newspaper'), 
			'desc' => '', 
			'type' => 'rgba', 
			'std' => $defaults[$tab]['the-newspaper' . '_error_color'] 
		);
		
		$options[] = array( 
			'section' => 'error_section', 
			'id' => 'the-newspaper' . '_error_bg_color', 
			'title' => esc_html__('Background Color', 'the-newspaper'), 
			'desc' => '', 
			'type' => 'rgba', 
			'std' => $defaults[$tab]['the-newspaper' . '_error_bg_color'] 
		);
		
		$options[] = array( 
			'section' => 'error_section', 
			'id' => 'the-newspaper' . '_error_bg_img_enable', 
			'title' => esc_html__('Background Image Visibility', 'the-newspaper'), 
			'desc' => esc_html__('show', 'the-newspaper'), 
			'type' => 'checkbox', 
			'std' => $defaults[$tab]['the-newspaper' . '_error_bg_img_enable'] 
		);
		
		$options[] = array( 
			'section' => 'error_section', 
			'id' => 'the-newspaper' . '_error_bg_image', 
			'title' => esc_html__('Background Image', 'the-newspaper'), 
			'desc' => esc_html__('Choose your custom error page background image.', 'the-newspaper'), 
			'type' => 'upload', 
			'std' => $defaults[$tab]['the-newspaper' . '_error_bg_image'], 
			'frame' => 'select', 
			'multiple' => false 
		);
		
		$options[] = array( 
			'section' => 'error_section', 
			'id' => 'the-newspaper' . '_error_bg_rep', 
			'title' => esc_html__('Background Repeat', 'the-newspaper'), 
			'desc' => '', 
			'type' => 'radio', 
			'std' => $defaults[$tab]['the-newspaper' . '_error_bg_rep'], 
			'choices' => array( 
				esc_html__('No Repeat', 'the-newspaper') . '|no-repeat', 
				esc_html__('Repeat Horizontally', 'the-newspaper') . '|repeat-x', 
				esc_html__('Repeat Vertically', 'the-newspaper') . '|repeat-y', 
				esc_html__('Repeat', 'the-newspaper') . '|repeat' 
			) 
		);
		
		$options[] = array( 
			'section' => 'error_section', 
			'id' => 'the-newspaper' . '_error_bg_pos', 
			'title' => esc_html__('Background Position', 'the-newspaper'), 
			'desc' => '', 
			'type' => 'select', 
			'std' => $defaults[$tab]['the-newspaper' . '_error_bg_pos'], 
			'choices' => array( 
				esc_html__('Top Left', 'the-newspaper') . '|top left', 
				esc_html__('Top Center', 'the-newspaper') . '|top center', 
				esc_html__('Top Right', 'the-newspaper') . '|top right', 
				esc_html__('Center Left', 'the-newspaper') . '|center left', 
				esc_html__('Center Center', 'the-newspaper') . '|center center', 
				esc_html__('Center Right', 'the-newspaper') . '|center right', 
				esc_html__('Bottom Left', 'the-newspaper') . '|bottom left', 
				esc_html__('Bottom Center', 'the-newspaper') . '|bottom center', 
				esc_html__('Bottom Right', 'the-newspaper') . '|bottom right' 
			) 
		);
		
		$options[] = array( 
			'section' => 'error_section', 
			'id' => 'the-newspaper' . '_error_bg_att', 
			'title' => esc_html__('Background Attachment', 'the-newspaper'), 
			'desc' => '', 
			'type' => 'radio', 
			'std' => $defaults[$tab]['the-newspaper' . '_error_bg_att'], 
			'choices' => array( 
				esc_html__('Scroll', 'the-newspaper') . '|scroll', 
				esc_html__('Fixed', 'the-newspaper') . '|fixed' 
			) 
		);
		
		$options[] = array( 
			'section' => 'error_section', 
			'id' => 'the-newspaper' . '_error_bg_size', 
			'title' => esc_html__('Background Size', 'the-newspaper'), 
			'desc' => '', 
			'type' => 'radio', 
			'std' => $defaults[$tab]['the-newspaper' . '_error_bg_size'], 
			'choices' => array( 
				esc_html__('Auto', 'the-newspaper') . '|auto', 
				esc_html__('Cover', 'the-newspaper') . '|cover', 
				esc_html__('Contain', 'the-newspaper') . '|contain' 
			) 
		);
		
		$options[] = array( 
			'section' => 'error_section', 
			'id' => 'the-newspaper' . '_error_search', 
			'title' => esc_html__('Search Line', 'the-newspaper'), 
			'desc' => esc_html__('show', 'the-newspaper'), 
			'type' => 'checkbox', 
			'std' => $defaults[$tab]['the-newspaper' . '_error_search'] 
		);
		
		$options[] = array( 
			'section' => 'error_section', 
			'id' => 'the-newspaper' . '_error_sitemap_button', 
			'title' => esc_html__('Sitemap Button', 'the-newspaper'), 
			'desc' => esc_html__('show', 'the-newspaper'), 
			'type' => 'checkbox', 
			'std' => $defaults[$tab]['the-newspaper' . '_error_sitemap_button'] 
		);
		
		$options[] = array( 
			'section' => 'error_section', 
			'id' => 'the-newspaper' . '_error_sitemap_link', 
			'title' => esc_html__('Sitemap Page URL', 'the-newspaper'), 
			'desc' => '', 
			'type' => 'text', 
			'std' => $defaults[$tab]['the-newspaper' . '_error_sitemap_link'], 
			'class' => '' 
		);
		
		break;
	case 'code':
		$options[] = array( 
			'section' => 'code_section', 
			'id' => 'the-newspaper' . '_custom_css', 
			'title' => esc_html__('Custom CSS', 'the-newspaper'), 
			'desc' => '', 
			'type' => 'textarea', 
			'std' => $defaults[$tab]['the-newspaper' . '_custom_css'], 
			'class' => 'allowlinebreaks' 
		);
		
		$options[] = array( 
			'section' => 'code_section', 
			'id' => 'the-newspaper' . '_custom_js', 
			'title' => esc_html__('Custom JavaScript', 'the-newspaper'), 
			'desc' => '', 
			'type' => 'textarea', 
			'std' => $defaults[$tab]['the-newspaper' . '_custom_js'], 
			'class' => 'allowlinebreaks' 
		);
		
		$options[] = array( 
			'section' => 'code_section', 
			'id' => 'the-newspaper' . '_gmap_api_key', 
			'title' => esc_html__('Google Maps API key', 'the-newspaper'), 
			'desc' => '', 
			'type' => 'text', 
			'std' => $defaults[$tab]['the-newspaper' . '_gmap_api_key'], 
			'class' => '' 
		);
		
		$options[] = array( 
			'section' => 'code_section', 
			'id' => 'the-newspaper' . '_twitter_access_data', 
			'title' => esc_html__('Twitter Access Data', 'the-newspaper'), 
			'desc' => sprintf(
				/* translators: Twitter access data. %s: Link to twitter access data generator */
				esc_html__( 'Generate %s and paste access data to fields.', 'the-newspaper' ),
				'<a href="' . esc_url( 'https://api.cmsmasters.net/wp-json/cmsmasters-api/v1/twitter-request-token' ) . '" target="_blank">' .
					esc_html__( 'twitter access data', 'the-newspaper' ) .
				'</a>'
			), 
			'type' => 'multi-text', 
			'std' => $defaults[$tab]['the-newspaper' . '_twitter_access_data'], 
			'class' => 'regular-text', 
			'choices' => array( 
				esc_html__('Consumer Key', 'the-newspaper') . '|consumer_key', 
				esc_html__('Consumer Secret', 'the-newspaper') . '|consumer_secret', 
				esc_html__('Access Token', 'the-newspaper') . '|access_token', 
				esc_html__('Access Token Secret', 'the-newspaper') . '|access_token_secret' 
			) 
		);
		
		break;
	case 'recaptcha':
		$options[] = array( 
			'section' => 'recaptcha_section', 
			'id' => 'the-newspaper' . '_recaptcha_public_key', 
			'title' => esc_html__('reCAPTCHA Public Key', 'the-newspaper'), 
			'desc' => '', 
			'type' => 'text', 
			'std' => $defaults[$tab]['the-newspaper' . '_recaptcha_public_key'], 
			'class' => '' 
		);
		
		$options[] = array( 
			'section' => 'recaptcha_section', 
			'id' => 'the-newspaper' . '_recaptcha_private_key', 
			'title' => esc_html__('reCAPTCHA Private Key', 'the-newspaper'), 
			'desc' => '', 
			'type' => 'text', 
			'std' => $defaults[$tab]['the-newspaper' . '_recaptcha_private_key'], 
			'class' => '' 
		);
		
		break;
	}
	
	return apply_filters('cmsmasters_options_element_fields_filter', $options, $tab);	
}

