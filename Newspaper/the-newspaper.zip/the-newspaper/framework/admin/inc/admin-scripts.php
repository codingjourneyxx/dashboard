<?php
/**
 * @package 	WordPress
 * @subpackage 	The Newspaper
 * @version 	1.1.1
 * 
 * Admin Panel Scripts & Styles
 * Created by CMSMasters
 * 
 */


function the_newspaper_admin_register($hook) {
	global $pagenow;
	
	$screen = get_current_screen();
	
	
	wp_enqueue_style('wp-color-picker');
	
	wp_enqueue_script('wp-color-picker');

	wp_localize_script( 'wp-color-picker', 'wpColorPickerL10n', array(
		'clear' => 				esc_attr__('Clear', 'the-newspaper'),
		'clearAriaLabel' => 	esc_attr__('Clear color', 'the-newspaper'),
		'defaultLabel' => 		esc_attr__('Color value', 'the-newspaper'),
		'defaultString' => 		esc_attr__('Default', 'the-newspaper'),
		'defaultAriaLabel' => 	esc_attr__('Select default color', 'the-newspaper'),
		'pick' => 				esc_attr__('Select Color', 'the-newspaper'),
	) ); 
	
	wp_enqueue_script('wp-color-picker-alpha', get_template_directory_uri() . '/framework/admin/inc/js/wp-color-picker-alpha.js', array('jquery', 'wp-color-picker'), '2.1.4', true);
	
	
	wp_enqueue_style('the-newspaper-admin-icons-font', get_template_directory_uri() . '/framework/admin/inc/css/admin-icons-font.css', array(), '1.0.0', 'screen');
	
	wp_enqueue_style('the-newspaper-lightbox', get_template_directory_uri() . '/framework/admin/inc/css/jquery.cmsmastersLightbox.css', array(), '1.0.0', 'screen');
	
	if (is_rtl()) {
		wp_enqueue_style('the-newspaper-lightbox-rtl', get_template_directory_uri() . '/framework/admin/inc/css/jquery.cmsmastersLightbox-rtl.css', array(), '1.0.0', 'screen');
	}
	
	
	wp_enqueue_script('the-newspaper-uploader-js', get_template_directory_uri() . '/framework/admin/inc/js/jquery.cmsmastersUploader.js', array('jquery'), '1.0.0', true);
	
	wp_localize_script('the-newspaper-uploader-js', 'cmsmasters_admin_uploader', array( 
		'choose' => 				esc_attr__('Choose image', 'the-newspaper'), 
		'insert' => 				esc_attr__('Insert image', 'the-newspaper'), 
		'remove' => 				esc_attr__('Remove', 'the-newspaper'), 
		'edit_gallery' => 			esc_attr__('Edit gallery', 'the-newspaper') 
	));
	
	
	wp_enqueue_script('the-newspaper-lightbox-js', get_template_directory_uri() . '/framework/admin/inc/js/jquery.cmsmastersLightbox.js', array('jquery'), '1.0.0', true);
	
	wp_localize_script('the-newspaper-lightbox-js', 'cmsmasters_admin_lightbox', array( 
		'cancel' => 				esc_attr__('Cancel', 'the-newspaper'), 
		'insert' => 				esc_attr__('Insert', 'the-newspaper'), 
		'deselect' => 				esc_attr__('Deselect', 'the-newspaper'), 
		'choose_icon' => 			esc_attr__('Choose Icon', 'the-newspaper'), 
		'find_icons' => 			esc_attr__('Find icons', 'the-newspaper'), 
		'min_length' => 			esc_attr__('min 2 symbols', 'the-newspaper'), 
		'choose_font' => 			esc_attr__('Choose icons font', 'the-newspaper'), 
		'error_on_page' => 			esc_attr__("Error on page!\nReload page and try again.", 'the-newspaper') 
	));
	
	
	if ( 
		$hook == 'post.php' || 
		$hook == 'post-new.php' || 
		$hook == 'widgets.php' || 
		$hook == 'term.php' || 
		$hook == 'edit-tags.php' || 
		$hook == 'nav-menus.php' || 
		str_replace('cmsmasters-settings-element', '', $screen->id) != $screen->id 
	) {
		wp_enqueue_style('the-newspaper-icons', get_template_directory_uri() . '/css/fontello.css', array(), '1.0.0', 'screen');
		
		wp_enqueue_style('the-newspaper-icons-custom', get_template_directory_uri() . '/theme-vars/theme-style' . CMSMASTERS_THEME_STYLE . '/css/fontello-custom.css', array(), '1.0.0', 'screen');
	}
	
	
	if ( 
		$hook == 'widgets.php' || 
		$hook == 'nav-menus.php' 
	) {
		wp_enqueue_media();
	}
	
	
	wp_enqueue_style('the-newspaper-admin-styles', get_template_directory_uri() . '/framework/admin/inc/css/admin-theme-styles.css', array(), '1.0.0', 'screen');
	
	if (is_rtl()) {
		wp_enqueue_style('the-newspaper-admin-styles-rtl', get_template_directory_uri() . '/framework/admin/inc/css/admin-theme-styles-rtl.css', array(), '1.0.0', 'screen');
	}
	
	
	wp_enqueue_script('the-newspaper-admin-scripts', get_template_directory_uri() . '/framework/admin/inc/js/admin-theme-scripts.js', array('jquery'), '1.0.0', true);
	
	
	if ($hook == 'widgets.php') {
		wp_enqueue_style('the-newspaper-widgets-styles', get_template_directory_uri() . '/framework/admin/inc/css/widgets-styles.css', array(), '1.0.0', 'screen');
		
		wp_enqueue_script('the-newspaper-widgets-scripts', get_template_directory_uri() . '/framework/admin/inc/js/widgets-scripts.js', array('jquery'), '1.0.0', true);
	}
}

add_action('admin_enqueue_scripts', 'the_newspaper_admin_register');

add_action('admin_enqueue_scripts', 'cmsmasters_composer_icons');

