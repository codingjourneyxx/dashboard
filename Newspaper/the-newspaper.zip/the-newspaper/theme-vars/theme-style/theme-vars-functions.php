<?php
/**
 * @package 	WordPress
 * @subpackage 	The Newspaper
 * @version 	1.0.0
 * 
 * Theme Vars Functions
 * Created by CMSMasters
 * 
 */


/* Register CSS Styles */
function the_newspaper_vars_register_css_styles() {
	wp_enqueue_style('the-newspaper-theme-vars-style', get_template_directory_uri() . '/theme-vars/theme-style' . CMSMASTERS_THEME_STYLE . '/css/vars-style.css', array('the-newspaper-retina'), '1.0.0', 'screen, print');
}

add_action('wp_enqueue_scripts', 'the_newspaper_vars_register_css_styles');

