/**
 * @package 	WordPress
 * @subpackage 	The Newspaper
 * @version 	1.2.9
 * 
 * Theme Information
 * Created by CMSMasters
 * 
 */

To update your theme please use the files list from the FILE LOGS below and substitute/add the listed files on your server with the same files in the Updates folder.

Important: after you have updated the theme, in your admin panel please proceed to
Theme Settings - Fonts and click "Save" in any tab,
then proceed to 
Theme Settings - Colors and click "Save" in any tab here.
--------------------------------------
Version 1.2.9: files operations:

	Theme Files edited:
		the-newspaper\changelog.txt
		the-newspaper\readme.txt
		the-newspaper\style.css
		the-newspaper\theme-vars\plugin-activator.php
		the-newspaper\theme-vars\plugins\LayerSlider.zip
		the-newspaper\theme-vars\plugins\revslider.zip
		the-newspaper\theme-vars\theme-style\admin\demo-content-importer.php
		the-newspaper\theme-vars\theme-style\admin\demo-content\main\content.xml
		the-newspaper\theme-vars\theme-style\admin\demo-content\main\sliders\layerslider\LayerSlider.zip
		the-newspaper\theme-vars\theme-style\admin\demo-content\main\sliders\revslider\Shortcode Slider.zip
		the-newspaper\theme-vars\theme-style\admin\demo-content\main\theme-settings.txt
		the-newspaper\theme-vars\theme-style\admin\demo-content\modern\content.xml
		the-newspaper\theme-vars\theme-style\admin\demo-content\modern\sliders\layerslider\LayerSlider.zip
		the-newspaper\theme-vars\theme-style\admin\demo-content\modern\sliders\revslider\Posts Slider.zip
		the-newspaper\theme-vars\theme-style\admin\demo-content\modern\sliders\revslider\Shortcode Slider.zip
		the-newspaper\theme-vars\theme-style\admin\demo-content\modern\theme-settings.txt
		the-newspaper\theme-vars\theme-style\admin\demo-content\vintage\content.xml
		the-newspaper\theme-vars\theme-style\admin\demo-content\vintage\sliders\layerslider\LayerSlider.zip
		the-newspaper\theme-vars\theme-style\admin\demo-content\vintage\sliders\revslider\Shortcode Slider.zip
		the-newspaper\theme-vars\theme-style\admin\demo-content\vintage\theme-settings.txt
--------------------------------------
Version 1.2.8: files operations:

	Theme Files edited:
		the-newspaper\changelog.txt
		the-newspaper\readme.txt
		the-newspaper\style.css
		the-newspaper\theme-framework\theme-style\function\template-functions.php
		the-newspaper\theme-vars\plugin-activator.php
		the-newspaper\theme-vars\plugins\cmsmasters-content-composer.zip
		the-newspaper\theme-vars\plugins\LayerSlider.zip
		the-newspaper\theme-vars\plugins\revslider.zip
--------------------------------------
Version 1.2.7: files operations:

	Theme Files edited:
		the-newspaper\changelog.txt
		the-newspaper\readme.txt
		the-newspaper\style.css
		the-newspaper\theme-vars\plugin-activator.php
		the-newspaper\theme-vars\plugins\cmsmasters-content-composer.zip
		the-newspaper\theme-vars\plugins\LayerSlider.zip
		the-newspaper\theme-vars\plugins\revslider.zip
--------------------------------------
Version 1.2.6: files operations:

	Theme Files edited:
		the-newspaper\changelog.txt
		the-newspaper\framework\function\general-functions.php
		the-newspaper\readme.txt
		the-newspaper\style.css
		the-newspaper\theme-framework\theme-style\theme-functions.php
		the-newspaper\theme-vars\plugin-activator.php
		the-newspaper\theme-vars\plugins\cmsmasters-content-composer.zip
		the-newspaper\theme-vars\plugins\LayerSlider.zip
		the-newspaper\theme-vars\plugins\revslider.zip
--------------------------------------
Version 1.2.5: files operations:

	Theme Files edited:
		the-newspaper\changelog.txt
		the-newspaper\readme.txt
		the-newspaper\style.css
		the-newspaper\theme-vars\plugin-activator.php
		the-newspaper\theme-vars\plugins\LayerSlider.zip
		the-newspaper\theme-vars\plugins\revslider.zip
--------------------------------------
Version 1.2.4: files operations:

	Theme Files edited:
		the-newspaper\changelog.txt
		the-newspaper\framework\admin\inc\admin-scripts.php
		the-newspaper\framework\admin\inc\js\wp-color-picker-alpha.js
		the-newspaper\readme.txt
		the-newspaper\style.css
		the-newspaper\theme-vars\plugin-activator.php
		the-newspaper\theme-vars\plugins\revslider.zip
--------------------------------------
Version 1.2.3: files operations:

	Theme Files edited:
		the-newspaper\changelog.txt
		the-newspaper\readme.txt
		the-newspaper\style.css
		the-newspaper\theme-vars\plugin-activator.php
		the-newspaper\theme-vars\plugins\LayerSlider.zip
		the-newspaper\theme-vars\plugins\revslider.zip
--------------------------------------
Version 1.2.2: files operations:

	Theme Files edited:
		the-newspaper\changelog.txt
		the-newspaper\framework\admin\inc\admin-scripts.php
		the-newspaper\framework\admin\inc\js\wp-color-picker-alpha.js
		the-newspaper\framework\admin\options\cmsmasters-theme-options.php
		the-newspaper\framework\admin\settings\cmsmasters-theme-settings.php
		the-newspaper\framework\function\theme-colored-categories.php
		the-newspaper\readme.txt
		the-newspaper\style.css
		the-newspaper\theme-vars\plugin-activator.php
		the-newspaper\theme-vars\plugins\cmsmasters-content-composer.zip
		the-newspaper\theme-vars\plugins\LayerSlider.zip
		the-newspaper\theme-vars\plugins\revslider.zip
--------------------------------------
Version 1.2.1: files operations:

	Theme Files edited:
		the-newspaper\changelog.txt
		the-newspaper\readme.txt
		the-newspaper\style.css
		the-newspaper\theme-framework\theme-style\function\template-functions.php
		the-newspaper\theme-vars\plugin-activator.php
		the-newspaper\theme-vars\plugins\cmsmasters-importer.zip
		the-newspaper\theme-vars\plugins\LayerSlider.zip
		the-newspaper\theme-vars\plugins\revslider.zip
		the-newspaper\theme-vars\theme-style\admin\demo-content-importer.php
--------------------------------------
Version 1.2.0: files operations:

	Theme Files edited:
		the-newspaper\changelog.txt
		the-newspaper\readme.txt
		the-newspaper\style.css
		the-newspaper\theme-framework\theme-style\class\theme-widgets.php
		the-newspaper\theme-vars\plugin-activator.php
		the-newspaper\theme-vars\plugins\LayerSlider.zip
		the-newspaper\theme-vars\plugins\revslider.zip
--------------------------------------
Version 1.1.9: files operations:

	Theme Files edited:
		the-newspaper\changelog.txt
		the-newspaper\js\jquery.script.js
		the-newspaper\readme.txt
		the-newspaper\style.css
		the-newspaper\theme-vars\plugin-activator.php
		the-newspaper\theme-vars\plugins\LayerSlider.zip
		the-newspaper\theme-vars\plugins\revslider.zip
--------------------------------------
Version 1.1.8: files operations:

	Theme Files edited:
		the-newspaper\changelog.txt
		the-newspaper\framework\admin\settings\cmsmasters-theme-settings-element.php
		the-newspaper\framework\admin\settings\cmsmasters-theme-settings.php
		the-newspaper\framework\function\general-functions.php
		the-newspaper\framework\function\pagination.php
		the-newspaper\readme.txt
		the-newspaper\style.css
		the-newspaper\theme-framework\theme-style\class\theme-widgets.php
		the-newspaper\theme-framework\theme-style\cmsmasters-c-c\shortcodes\cmsmasters-portfolio.php
		the-newspaper\theme-framework\theme-style\css\less\style.less
		the-newspaper\theme-framework\theme-style\css\style.css
		the-newspaper\theme-framework\theme-style\function\template-functions.php
		the-newspaper\theme-vars\languages\the-newspaper.pot
		the-newspaper\theme-vars\plugin-activator.php
		the-newspaper\theme-vars\plugins\cmsmasters-content-composer.zip
		the-newspaper\theme-vars\plugins\LayerSlider.zip
		the-newspaper\theme-vars\plugins\revslider.zip
		the-newspaper\theme-vars\theme-style\admin\theme-settings-defaults.php
--------------------------------------
Version 1.1.7: files operations:

	Theme Files edited:
		the-newspaper\changelog.txt
		the-newspaper\readme.txt
		the-newspaper\style.css
		the-newspaper\theme-vars\plugin-activator.php
		the-newspaper\theme-vars\plugins\LayerSlider.zip
		the-newspaper\theme-vars\plugins\revslider.zip
--------------------------------------
Version 1.1.6: files operations:

	Theme Files edited:
		the-newspaper\changelog.txt
		the-newspaper\readme.txt
		the-newspaper\style.css
		the-newspaper\theme-vars\plugin-activator.php
		the-newspaper\theme-vars\plugins\cmsmasters-importer.zip
		the-newspaper\theme-vars\plugins\LayerSlider.zip
		the-newspaper\theme-vars\plugins\revslider.zip
--------------------------------------
Version 1.1.5: files operations:

	Theme Files edited:
		the-newspaper\framework\admin\settings\cmsmasters-theme-settings.php
		the-newspaper\framework\function\general-functions.php
		the-newspaper\js\jquery.iLightBox.min.js
		the-newspaper\readme.txt
		the-newspaper\style.css
		the-newspaper\theme-vars\languages\the-newspaper.pot
		the-newspaper\theme-vars\plugin-activator.php
		the-newspaper\theme-vars\plugins\LayerSlider.zip
		the-newspaper\theme-vars\plugins\revslider.zip
		the-newspaper\changelog.txt
--------------------------------------
Version 1.1.4: files operations:

	Theme Files edited:
		the-newspaper\framework\admin\settings\cmsmasters-theme-settings-element.php
		the-newspaper\framework\function\general-functions.php
		the-newspaper\js\cmsmasters-hover-slider.min.js
		the-newspaper\readme.txt
		the-newspaper\style.css
		the-newspaper\theme-framework\theme-style\css\less\style.less
		the-newspaper\theme-framework\theme-style\css\style.css
		the-newspaper\theme-framework\theme-style\post-type\blog\post-single.php
		the-newspaper\theme-vars\languages\the-newspaper.pot
		the-newspaper\theme-vars\plugin-activator.php
		the-newspaper\theme-vars\plugins\cmsmasters-content-composer.zip
		the-newspaper\theme-vars\plugins\LayerSlider.zip
		the-newspaper\theme-vars\plugins\revslider.zip
		the-newspaper\theme-vars\theme-style\admin\theme-settings-defaults.php
--------------------------------------
Version 1.1.3: files operations:

	Theme Files edited:
		the-newspaper\readme.txt
		the-newspaper\style.css
		the-newspaper\theme-vars\plugin-activator.php
		the-newspaper\theme-vars\plugins\cmsmasters-content-composer.zip
		the-newspaper\theme-vars\plugins\LayerSlider.zip
		the-newspaper\theme-vars\plugins\revslider.zip
--------------------------------------
Version 1.1.2: files operations:

	Theme Files edited:
		the-newspaper\readme.txt
		the-newspaper\style.css
		the-newspaper\theme-vars\languages\the-newspaper.pot
		the-newspaper\theme-vars\plugin-activator.php
		the-newspaper\theme-vars\plugins\cmsmasters-content-composer.zip
		the-newspaper\theme-vars\plugins\LayerSlider.zip
		the-newspaper\theme-vars\plugins\revslider.zip
		the-newspaper\theme-vars\theme-style\admin\demo-content-importer.php
		the-newspaper\theme-vars\theme-style\admin\demo-content\main\content.xml
		the-newspaper\theme-vars\theme-style\admin\demo-content\modern\content.xml
		the-newspaper\theme-vars\theme-style\admin\demo-content\vintage\content.xml
--------------------------------------
Version 1.1.1: files operations:

	Theme Files edited:
		the-newspaper\comments.php
		the-newspaper\framework\admin\inc\admin-scripts.php
		the-newspaper\framework\admin\inc\js\admin-theme-scripts.js
		the-newspaper\framework\admin\inc\js\jquery.cmsmastersLightbox.js
		the-newspaper\framework\admin\inc\js\wp-color-picker-alpha.js
		the-newspaper\framework\admin\options\cmsmasters-theme-options-post.php
		the-newspaper\framework\admin\options\js\cmsmasters-theme-options-toggle.js
		the-newspaper\framework\admin\settings\cmsmasters-theme-settings-general.php
		the-newspaper\framework\admin\settings\cmsmasters-theme-settings.php
		the-newspaper\framework\class\class-tgm-plugin-activation.php
		the-newspaper\framework\function\general-functions.php
		the-newspaper\functions.php
		the-newspaper\gutenberg\cmsmasters-framework\theme-style\cmsmasters-module-functions.php
		the-newspaper\gutenberg\cmsmasters-framework\theme-style\js\editor-options.js
		the-newspaper\header.php
		the-newspaper\index.php
		the-newspaper\js\jquery.iLightBox.min.js
		the-newspaper\js\jquery.isotope.min.js
		the-newspaper\js\jquery.script.js
		the-newspaper\js\modernizr.min.js
		the-newspaper\js\mousewheel.min.js
		the-newspaper\js\stellar.min.js
		the-newspaper\js\waypoints.min.js
		the-newspaper\page.php
		the-newspaper\single-profile.php
		the-newspaper\single-project.php
		the-newspaper\single.php
		the-newspaper\style.css
		the-newspaper\theme-framework\theme-style\class\theme-widgets.php
		the-newspaper\theme-framework\theme-style\css\adaptive.css
		the-newspaper\theme-framework\theme-style\css\less\adaptive.less
		the-newspaper\theme-framework\theme-style\css\less\style.less
		the-newspaper\theme-framework\theme-style\css\style.css
		the-newspaper\theme-framework\theme-style\function\template-functions.php
		the-newspaper\theme-framework\theme-style\js\jquery.isotope.mode.js
		the-newspaper\theme-framework\theme-style\js\jquery.theme-script.js
		the-newspaper\theme-vars\languages\the-newspaper.pot
		the-newspaper\theme-vars\plugin-activator.php
		the-newspaper\theme-vars\plugins\cmsmasters-content-composer.zip
		the-newspaper\theme-vars\plugins\cmsmasters-custom-fonts.zip
		the-newspaper\theme-vars\plugins\cmsmasters-importer.zip
		the-newspaper\theme-vars\plugins\cmsmasters-mega-menu.zip
		the-newspaper\theme-vars\plugins\LayerSlider.zip
		the-newspaper\theme-vars\plugins\revslider.zip
--------------------------------------
Version 1.1.0: files operations:

	Theme Files edited:
		the-newspaper\framework\admin\inc\js\jquery.cmsmastersLightbox.js
		the-newspaper\framework\admin\inc\js\wp-color-picker-alpha.js
		the-newspaper\framework\function\general-functions.php
		the-newspaper\js\jquery.iLightBox.min.js
		the-newspaper\readme.txt
		the-newspaper\style.css
		the-newspaper\theme-framework\theme-style\function\template-functions.php
		the-newspaper\theme-framework\theme-style\js\jquery.theme-script.js
		the-newspaper\theme-vars\plugin-activator.php
--------------------------------------
Version 1.0.7-1.0.9: files operations:

	Theme Files edited:
		the-newspaper\framework\admin\inc\admin-scripts.php
		the-newspaper\framework\admin\inc\js\wp-color-picker-alpha.js
		the-newspaper\framework\class\class-tgm-plugin-activation.php
		the-newspaper\gutenberg\cmsmasters-framework\theme-style\cmsmasters-module-functions.php
		the-newspaper\gutenberg\cmsmasters-framework\theme-style\css\editor-style.css
		the-newspaper\gutenberg\cmsmasters-framework\theme-style\css\frontend-style.css
		the-newspaper\gutenberg\cmsmasters-framework\theme-style\css\less\module-style.less
		the-newspaper\gutenberg\cmsmasters-framework\theme-style\function\module-colors.php
		the-newspaper\gutenberg\cmsmasters-framework\theme-style\function\module-fonts.php
		the-newspaper\header.php
		the-newspaper\readme.txt
		the-newspaper\style.css
		the-newspaper\theme-framework\theme-style\css\less\style.less
		the-newspaper\theme-framework\theme-style\css\style.css
		the-newspaper\theme-framework\theme-style\function\template-functions.php
		the-newspaper\theme-framework\theme-style\function\theme-fonts.php
		the-newspaper\theme-framework\theme-style\js\jquery.isotope.mode.js
		the-newspaper\theme-vars\plugin-activator.php
--------------------------------------
Version 1.0.6: files operations:

	Theme Files edited:
		the-newspaper\framework\admin\settings\css\cmsmasters-theme-settings.css
		the-newspaper\gutenberg\cmsmasters-framework\theme-style\css\editor-style.css
		the-newspaper\gutenberg\cmsmasters-framework\theme-style\css\frontend-style.css
		the-newspaper\gutenberg\cmsmasters-framework\theme-style\css\module-rtl.css
		the-newspaper\style.css
		the-newspaper\theme-framework\theme-style\css\style.css
		the-newspaper\theme-vars\theme-style\css\styles\the-newspaper.css
		the-newspaper\framework\admin\settings\js\cmsmasters-theme-settings.js
		the-newspaper\gutenberg\cmsmasters-framework\theme-style\js\editor-options.js
		the-newspaper\js\smooth-sticky.min.js
		the-newspaper\gutenberg\cmsmasters-framework\theme-style\css\less\module-style.less
		the-newspaper\theme-framework\theme-style\css\less\style.less
		the-newspaper\framework\admin\inc\config-functions.php
		the-newspaper\framework\admin\options\cmsmasters-theme-options-other.php
		the-newspaper\framework\admin\options\cmsmasters-theme-options-page.php
		the-newspaper\framework\admin\options\cmsmasters-theme-options-post.php
		the-newspaper\framework\admin\settings\cmsmasters-theme-settings.php
		the-newspaper\framework\admin\settings\cmsmasters-theme-settings-font.php
		the-newspaper\framework\admin\settings\cmsmasters-theme-settings-general.php
		the-newspaper\framework\admin\settings\inc\cmsmasters-helper-functions.php
		the-newspaper\framework\function\general-functions.php
		the-newspaper\functions.php
		the-newspaper\gutenberg\cmsmasters-framework\theme-style\cmsmasters-module-functions.php
		the-newspaper\gutenberg\cmsmasters-framework\theme-style\function\module-colors.php
		the-newspaper\gutenberg\cmsmasters-framework\theme-style\function\module-fonts.php
		the-newspaper\search.php
		the-newspaper\sidebar.php
		the-newspaper\theme-framework\theme-style\class\theme-widgets.php
		the-newspaper\theme-framework\theme-style\function\theme-fonts.php
		the-newspaper\theme-vars\plugin-activator.php
		the-newspaper\theme-vars\theme-style\admin\demo-content-importer.php
		the-newspaper\theme-vars\theme-style\admin\theme-settings-defaults.php
		the-newspaper\theme-vars\languages\the-newspaper.pot
		the-newspaper\readme.txt
		
	Plugins added:
		CMSMasters Custom Fonts
		CMSMasters Importer
--------------------------------------
Version 1.0.5: files operations:

	Theme Files edited:
		the-newspaper\framework\admin\inc\css\admin-theme-styles.css
		the-newspaper\framework\admin\options\css\cmsmasters-theme-options.css
		the-newspaper\framework\admin\settings\css\cmsmasters-theme-settings.css
		the-newspaper\framework\admin\settings\css\cmsmasters-theme-settings-rtl.css
		the-newspaper\style.css
		the-newspaper\theme-framework\theme-style\css\adaptive.css
		the-newspaper\theme-framework\theme-style\css\rtl.css
		the-newspaper\theme-framework\theme-style\css\style.css
		the-newspaper\theme-vars\theme-style\css\styles\the-newspaper.css
		the-newspaper\framework\admin\options\js\cmsmasters-theme-options.js
		the-newspaper\js\jquery.script.js
		the-newspaper\js\smooth-sticky.min.js
		the-newspaper\theme-framework\theme-style\admin\js\theme-settings-toggle.js
		the-newspaper\theme-framework\theme-style\js\jquery.isotope.mode.js
		the-newspaper\theme-framework\theme-style\js\jquery.theme-script.js
		the-newspaper\theme-framework\theme-style\css\less\adaptive.less
		the-newspaper\theme-framework\theme-style\css\less\style.less
		the-newspaper\framework\admin\options\cmsmasters-theme-options.php
		the-newspaper\framework\admin\settings\cmsmasters-theme-settings.php
		the-newspaper\framework\admin\settings\inc\cmsmasters-helper-functions.php
		the-newspaper\framework\class\class-tgm-plugin-activation.php
		the-newspaper\framework\function\general-functions.php
		the-newspaper\framework\function\likes.php
		the-newspaper\framework\function\theme-categories-icon.php
		the-newspaper\framework\function\views.php
		the-newspaper\functions.php
		the-newspaper\page.php
		the-newspaper\sitemap.php
		the-newspaper\theme-framework\theme-style\admin\theme-settings.php
		the-newspaper\theme-framework\theme-style\cmsmasters-c-c\shortcodes\cmsmasters-portfolio.php
		the-newspaper\theme-framework\theme-style\cmsmasters-c-c\shortcodes\cmsmasters-posts-slider.php
		the-newspaper\theme-framework\theme-style\cmsmasters-c-c\shortcodes\cmsmasters-pricing-table-item.php
		the-newspaper\theme-framework\theme-style\cmsmasters-c-c\shortcodes\cmsmasters-quotes.php
		the-newspaper\theme-framework\theme-style\cmsmasters-c-c\shortcodes\cmsmasters-stat.php
		the-newspaper\theme-framework\theme-style\cmsmasters-c-c\shortcodes\cmsmasters-tab.php
		the-newspaper\theme-framework\theme-style\cmsmasters-c-c\shortcodes\cmsmasters-toggles.php
		the-newspaper\theme-framework\theme-style\function\template-functions.php
		the-newspaper\theme-framework\theme-style\function\template-functions-post.php
		the-newspaper\theme-framework\theme-style\function\template-functions-profile.php
		the-newspaper\theme-framework\theme-style\function\template-functions-project.php
		the-newspaper\theme-framework\theme-style\function\template-functions-shortcodes.php
		the-newspaper\theme-framework\theme-style\function\theme-colors-primary.php
		the-newspaper\theme-framework\theme-style\function\theme-fonts.php
		the-newspaper\theme-framework\theme-style\post-type\blog\post-single.php
		the-newspaper\theme-framework\theme-style\post-type\portfolio\project-single.php
		the-newspaper\theme-framework\theme-style\post-type\profile\profile-single.php
		the-newspaper\theme-framework\theme-style\post-type\quote\quote-grid.php
		the-newspaper\theme-framework\theme-style\theme-functions.php
		the-newspaper\theme-vars\plugin-activator.php
		the-newspaper\theme-vars\theme-style\admin\demo-content-importer.php
		the-newspaper\theme-vars\languages\the-newspaper.pot
		the-newspaper\readme.txt
--------------------------------------
Version 1.0.4: files operations:

	Theme Files edited:
        the-newspaper\style.css
		the-newspaper\theme-framework\theme-style\css\adaptive.css
		the-newspaper\theme-framework\theme-style\css\style.css
		the-newspaper\js\jquery.script.js
		the-newspaper\js\smooth-sticky.min.js
		the-newspaper\theme-framework\theme-style\css\less\adaptive.less
		the-newspaper\theme-framework\theme-style\css\less\style.less
		the-newspaper\comments.php
		the-newspaper\framework\admin\inc\admin-scripts.php
		the-newspaper\framework\admin\settings\cmsmasters-theme-settings.php
		the-newspaper\framework\class\browser.php
		the-newspaper\framework\function\breadcrumbs.php
		the-newspaper\framework\function\general-functions.php
		the-newspaper\framework\function\likes.php
		the-newspaper\framework\function\views.php
		the-newspaper\functions.php
		the-newspaper\theme-framework\theme-style\class\theme-widgets.php
		the-newspaper\theme-framework\theme-style\function\template-functions.php
		the-newspaper\theme-framework\theme-style\function\template-functions-post.php
		the-newspaper\theme-framework\theme-style\function\template-functions-profile.php
		the-newspaper\theme-framework\theme-style\function\template-functions-project.php
		the-newspaper\theme-framework\theme-style\function\template-functions-shortcodes.php
		the-newspaper\theme-framework\theme-style\function\template-functions-single.php
		the-newspaper\theme-framework\theme-style\post-type\blog\post-default.php
		the-newspaper\theme-framework\theme-style\post-type\blog\post-single.php
		the-newspaper\theme-framework\theme-style\post-type\portfolio\project-single.php
		the-newspaper\theme-framework\theme-style\post-type\profile\profile-single.php
		the-newspaper\theme-framework\theme-style\template\footer.php
		the-newspaper\theme-framework\theme-style\template\header-bot.php
		the-newspaper\theme-framework\theme-style\template\header-mid.php
		the-newspaper\theme-vars\plugin-activator.php
        the-newspaper\theme-vars\languages\the-newspaper.pot
		the-newspaper\theme-vars\theme-style\admin\theme-settings-defaults.php
		the-newspaper\readme.txt
--------------------------------------
Version 1.0.3: files operations:

	Theme Files edited:
        the-newspaper\archive.php
        the-newspaper\author.php
        the-newspaper\footer.php
        the-newspaper\framework\admin\inc\js\wp-color-picker-alpha.js
        the-newspaper\framework\admin\options\cmsmasters-theme-options.php
        the-newspaper\framework\admin\options\css\cmsmasters-theme-options.css
        the-newspaper\framework\admin\options\js\cmsmasters-theme-options.js
        the-newspaper\framework\admin\settings\cmsmasters-theme-settings-single.php
        the-newspaper\framework\admin\settings\cmsmasters-theme-settings.php
        the-newspaper\framework\admin\settings\css\cmsmasters-theme-settings.css
        the-newspaper\framework\admin\settings\js\cmsmasters-theme-settings.js
        the-newspaper\framework\function\breadcrumbs.php
        the-newspaper\framework\function\general-functions.php
        the-newspaper\framework\function\likes.php
        the-newspaper\framework\function\pagination.php
        the-newspaper\framework\function\views.php
        the-newspaper\functions.php
        the-newspaper\header.php
        the-newspaper\image.php
        the-newspaper\index.php
        the-newspaper\js\jquery.script.js
        the-newspaper\js\scrollspy.js
        the-newspaper\page.php
        the-newspaper\readme.txt
        the-newspaper\search.php
        the-newspaper\sidebar-bottom.php
        the-newspaper\single-profile.php
        the-newspaper\single-project.php
        the-newspaper\single.php
        the-newspaper\sitemap.php
        the-newspaper\style.css
        the-newspaper\theme-framework\languages\the-newspaper.pot
        the-newspaper\theme-framework\plugin-activator.php
        the-newspaper\theme-framework\plugins\cmsmasters-contact-form-builder.zip
        the-newspaper\theme-framework\plugins\cmsmasters-content-composer.zip
        the-newspaper\theme-framework\plugins\LayerSlider.zip
        the-newspaper\theme-framework\plugins\revslider.zip
        the-newspaper\theme-framework\theme-style\admin\js\theme-settings-toggle.js
        the-newspaper\theme-framework\theme-style\admin\theme-settings.php
        the-newspaper\theme-framework\theme-style\class\theme-widgets.php
        the-newspaper\theme-framework\theme-style\cmsmasters-c-c\js\cmsmasters-c-c-theme-extend.js
        the-newspaper\theme-framework\theme-style\css\adaptive.css
        the-newspaper\theme-framework\theme-style\css\less\adaptive.less
        the-newspaper\theme-framework\theme-style\css\less\style.less
        the-newspaper\theme-framework\theme-style\css\rtl.css
        the-newspaper\theme-framework\theme-style\css\style.css
        the-newspaper\theme-framework\theme-style\css\styles\the-newspaper.css
        the-newspaper\theme-framework\theme-style\function\single-comment.php
        the-newspaper\theme-framework\theme-style\function\template-functions.php
        the-newspaper\theme-framework\theme-style\function\theme-colors-secondary.php
        the-newspaper\theme-framework\theme-style\function\theme-fonts.php
        the-newspaper\theme-framework\theme-style\post-type\blog\post-default.php
        the-newspaper\theme-framework\theme-style\post-type\blog\post-masonry.php
        the-newspaper\theme-framework\theme-style\post-type\blog\post-single.php
        the-newspaper\theme-framework\theme-style\post-type\blog\post-timeline.php
        the-newspaper\theme-framework\theme-style\post-type\portfolio\project-grid.php
        the-newspaper\theme-framework\theme-style\post-type\portfolio\project-puzzle.php
        the-newspaper\theme-framework\theme-style\post-type\portfolio\project-single.php
        the-newspaper\theme-framework\theme-style\post-type\posts-slider\slider-post.php
        the-newspaper\theme-framework\theme-style\post-type\posts-slider\slider-project.php
        the-newspaper\theme-framework\theme-style\post-type\profile\profile-horizontal.php
        the-newspaper\theme-framework\theme-style\post-type\profile\profile-single.php
        the-newspaper\theme-framework\theme-style\post-type\profile\profile-vertical.php
        the-newspaper\theme-framework\theme-style\post-type\quote\quote-grid.php
        the-newspaper\theme-framework\theme-style\post-type\quote\quote-slider.php
        the-newspaper\theme-framework\theme-style\template\404.php
        the-newspaper\theme-framework\theme-style\template\header-bot.php
        the-newspaper\theme-framework\theme-style\template\header-mid.php
        the-newspaper\theme-framework\theme-style\template\header-top.php
-------------------------------------
Version 1.0.2: files operations:

	Theme Files edited:
		the-newspaper\framework\admin\inc\js\wp-color-picker-alpha.js
		the-newspaper\framework\admin\settings\cmsmasters-theme-settings-single.php
		the-newspaper\framework\admin\settings\css\cmsmasters-theme-settings.css
		the-newspaper\framework\function\general-functions.php
		the-newspaper\js\jquery.script.js
		the-newspaper\js\scrollspy.js
		the-newspaper\readme.txt
		the-newspaper\sidebar-bottom.php
		the-newspaper\sidebar.php
		the-newspaper\style.css
		the-newspaper\theme-framework\languages\the-newspaper.pot
		the-newspaper\theme-framework\plugin-activator.php
		the-newspaper\theme-framework\plugins\cmsmasters-contact-form-builder.zip
		the-newspaper\theme-framework\plugins\cmsmasters-content-composer.zip
		the-newspaper\theme-framework\plugins\cmsmasters-mega-menu.zip
		the-newspaper\theme-framework\plugins\LayerSlider.zip
		the-newspaper\theme-framework\plugins\revslider.zip
		the-newspaper\theme-framework\theme-style\admin\theme-settings-defaults.php
		the-newspaper\theme-framework\theme-style\class\theme-widgets.php
		the-newspaper\theme-framework\theme-style\css\less\style.less
		the-newspaper\theme-framework\theme-style\css\style.css
		the-newspaper\theme-framework\theme-style\function\template-functions-single.php
		the-newspaper\theme-framework\theme-style\post-type\blog\post-single.php
		the-newspaper\theme-framework\theme-style\post-type\portfolio\project-single.php
		the-newspaper\theme-framework\theme-style\post-type\profile\profile-single.php
		the-newspaper\theme-framework\plugins\envato-market.zip
-------------------------------------
Version 1.0: Release!