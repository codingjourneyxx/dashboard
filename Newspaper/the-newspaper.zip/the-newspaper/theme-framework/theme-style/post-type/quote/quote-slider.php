<?php
/**
 * @package 	WordPress
 * @subpackage 	The Newspaper
 * @version		1.0.3
 * 
 * Quote Slider Template
 * Created by CMSMasters
 * 
 */


?>
<!-- Start Quote Slider Article -->
<article class="cmsmasters_quote_inner">
<?php 
	if ($quote_name != '' || $quote_subtitle != '' || $quote_website != '' || $quote_link != '') {
		echo '<header class="cmsmasters_quote_header">' . 
			
			($quote_name != '' ? '<span class="cmsmasters_quote_title">' . esc_html__('By', 'the-newspaper') . ' ' . esc_html($quote_name) . '</span>' : '') . 
			
			($quote_subtitle != '' ? '<span class="cmsmasters_quote_subtitle">' . esc_html($quote_subtitle) . '</span>' : '');
			
			if ($quote_website != '' || $quote_link != '') {
				echo '<span class="cmsmasters_quote_site">' . 
					($quote_link != '' ? '<a href="' . esc_url($quote_link) . '" target="_blank">' : '') . 
					
					($quote_website != '' ? esc_html($quote_website) : esc_html($quote_link)) . 
					
					($quote_link != '' ? '</a>' : '') . 
				'</span>';
			}
			
		echo '</header>';
	}
	
	
	echo cmsmasters_divpdel('<div class="cmsmasters_quote_content">' . 
		do_shortcode(wpautop(wp_kses(stripslashes($quote_content), 'post'))) . 
	'</div>');
	
	
	echo '<figure class="cmsmasters_quote_image">';
		if ($quote_image != '') {
			echo wp_get_attachment_image(strstr($quote_image, '|', true), 'cmsmasters-small-thumb');
		}
	echo '</figure>';
?>
</article>
<!-- Finish Quote Slider Article -->

