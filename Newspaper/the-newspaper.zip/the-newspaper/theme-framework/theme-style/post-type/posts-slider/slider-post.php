<?php
/**
 * @package 	WordPress
 * @subpackage 	The Newspaper
 * @version		1.0.3
 * 
 * Posts Slider Post Template
 * Created by CMSMasters
 * 
 */


$cmsmasters_metadata = explode(',', $cmsmasters_post_metadata);


$title = in_array('title', $cmsmasters_metadata) ? true : false;
$excerpt = (in_array('excerpt', $cmsmasters_metadata) && the_newspaper_slider_post_check_exc_cont('post')) ? true : false;
$date = in_array('date', $cmsmasters_metadata) ? true : false;
$categories = (get_the_category() && (in_array('categories', $cmsmasters_metadata))) ? true : false;
$author = in_array('author', $cmsmasters_metadata) ? true : false;
$comments = (comments_open() && (in_array('comments', $cmsmasters_metadata))) ? true : false;
$likes = in_array('likes', $cmsmasters_metadata) ? true : false;
$more = in_array('more', $cmsmasters_metadata) ? true : false;


$cmsmasters_post_format = get_post_format();

?>
<!-- Start Posts Slider Post Article -->
<article id="post-<?php the_ID(); ?>" <?php post_class('cmsmasters_slider_post'); ?>>
	<div class="cmsmasters_slider_post_outer">
	<?php		
		if ($date || $title || $author || $categories || $excerpt || $likes || $comments || $more) {
			echo '<div class="cmsmasters_slider_post_inner">';
				
				if ($date || $categories) {
					echo '<div class="cmsmasters_slider_post_cont_info entry-meta">';
						
						$date ? the_newspaper_get_slider_post_date('post') : '';
						
						$categories ? the_newspaper_get_slider_post_category(get_the_ID(), 'category', 'post') : '';
						
						$author ? the_newspaper_get_slider_post_author('post') : '';
						
						$likes ? the_newspaper_slider_post_like('post') : '';
						
						$comments ? the_newspaper_get_slider_post_comments('post') : '';
					echo '</div>';
				}
				
				
				$title ? the_newspaper_slider_post_heading(get_the_ID(), 'post', 'h3') : '';
				
				
				$excerpt ? the_newspaper_slider_post_exc_cont('post') : '';
				
				
				if ($more) {
					echo '<footer class="cmsmasters_slider_post_footer entry-meta">';
						
						$more ? the_newspaper_slider_post_more(get_the_ID()) : '';
						
					echo '</footer>';
				}
				
			echo '</div>';
		}
	?>
	</div>
</article>
<!-- Finish Posts Slider Post Article -->

