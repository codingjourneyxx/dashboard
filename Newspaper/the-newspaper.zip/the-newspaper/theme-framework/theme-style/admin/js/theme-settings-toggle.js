/**
 * @package 	WordPress
 * @subpackage 	The Newspaper
 * @version		1.0.5
 * 
 * Theme Admin Settings Toggles Scripts
 * Created by CMSMasters
 * 
 */


(function ($) { 
	"use strict";
	
	/* General 'Header' Tab Fields Load */
	$('#' + cmsmasters_theme_settings.shortname + '_header_search').parents('tr').show();
	
	if ($('input[name*="' + cmsmasters_theme_settings.shortname + '_header_top_line_short_cont"]:checked').val() === 'date') {
		$('#' + cmsmasters_theme_settings.shortname + '_header_top_line_short_info').parents('tr').hide();
	}
	
	
	/* General 'Header' Tab Fields Change */
	$('input[name*="' + cmsmasters_theme_settings.shortname + '_header_top_line_short_cont"]').on('change', function () { 
		if ($('input[name*="' + cmsmasters_theme_settings.shortname + '_header_top_line_short_cont"]:checked').val() === 'date') {
			$('#' + cmsmasters_theme_settings.shortname + '_header_top_line_short_info').parents('tr').hide();
		} else {
			$('#' + cmsmasters_theme_settings.shortname + '_header_top_line_short_info').parents('tr').show();
		}
	} );
} )(jQuery);