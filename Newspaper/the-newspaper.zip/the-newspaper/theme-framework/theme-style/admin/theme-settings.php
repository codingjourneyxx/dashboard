<?php 
/**
 * @package 	WordPress
 * @subpackage 	The Newspaper
 * @version		1.0.5
 * 
 * Theme Admin Settings
 * Created by CMSMasters
 * 
 */


/* General Settings */
function the_newspaper_theme_options_general_fields($options, $tab) {
	if ($tab == 'header') {
		$new_options = array();
		
		foreach ($options as $option) {
			if ($option['id'] == 'the-newspaper' . '_header_top_line_short_info') {
				$new_options[] = array( 
					'section' => 'header_section', 
					'id' => 'the-newspaper' . '_header_top_line_short_cont', 
					'title' => esc_html__('Top Short Content', 'the-newspaper'), 
					'desc' => '', 
					'type' => 'radio', 
					'std' => 'html', 
					'choices' => array( 
						esc_html__('Top Line Custom HTML', 'the-newspaper') . '|html', 
						esc_html__('Top Line Current Date (Date format is set in WordPress Settings)', 'the-newspaper') . '|date' 
					) 
				);
				
				$option['title'] = esc_html__('Top Short Info HTML', 'the-newspaper');
				
				
				
				$new_options[] = $option;
			} else {
				$new_options[] = $option;
			}
		}
		
		$options = $new_options;
	}
	
	
	return $options;
}

add_filter('cmsmasters_options_general_fields_filter', 'the_newspaper_theme_options_general_fields', 10, 2);
