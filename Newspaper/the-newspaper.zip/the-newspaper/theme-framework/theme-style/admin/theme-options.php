<?php 
/**
 * @package 	WordPress
 * @subpackage 	The Newspaper
 * @version		1.0.0
 * 
 * Theme Admin Options
 * Created by CMSMasters
 * 
 */

