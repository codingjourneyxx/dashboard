<?php
/**
 * @package 	WordPress
 * @subpackage 	The Newspaper
 * @version 	1.0.3
 * 
 * 404 Error Page Template
 * Created by CMSMasters
 * 
 */


$cmsmasters_option = the_newspaper_get_global_options();

?>

</div>

<!-- Start Content -->
<div class="entry">
	<div class="error">
		<div class="error_bg">
			<div class="error_inner">
				<h1 class="error_title"><?php echo esc_html__('404', 'the-newspaper'); ?></h1>
				<h2 class="error_subtitle"><?php echo esc_html__("We're sorry, but the page you were", 'the-newspaper'); ?><br /><?php echo esc_html__("looking for doesn't exist.", 'the-newspaper'); ?></h2>
				
				<div class="error_cont">
					<?php 
					if ($cmsmasters_option['the-newspaper' . '_error_search']) { 
						get_search_form(); 
					}
					
					
					if ($cmsmasters_option['the-newspaper' . '_error_sitemap_button'] && $cmsmasters_option['the-newspaper' . '_error_sitemap_link'] != '') {
						echo '<div class="error_button_wrap"><a href="' . esc_url($cmsmasters_option['the-newspaper' . '_error_sitemap_link']) . '" class="button">' . esc_html__('Sitemap', 'the-newspaper') . '</a></div>';
					}
					?>
				</div>
			</div>
		</div>
	</div>
</div>
<div class="content_wrap fullwidth">
<!-- Finish Content -->