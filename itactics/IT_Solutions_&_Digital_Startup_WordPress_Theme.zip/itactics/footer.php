<?php
/**
 * The Footer: widgets area, logo, footer menu and socials
 *
 * @package ITACTICS
 * @since ITACTICS 1.0
 */

							do_action( 'itactics_action_page_content_end_text' );
							
							// Widgets area below the content
							itactics_create_widgets_area( 'widgets_below_content' );
						
							do_action( 'itactics_action_page_content_end' );
							?>
						</div>
						<?php
						
						do_action( 'itactics_action_after_page_content' );

						// Show main sidebar
						get_sidebar();

						do_action( 'itactics_action_content_wrap_end' );
						?>
					</div>
					<?php

					do_action( 'itactics_action_after_content_wrap' );

					// Widgets area below the page and related posts below the page
					$itactics_body_style = itactics_get_theme_option( 'body_style' );
					$itactics_widgets_name = itactics_get_theme_option( 'widgets_below_page', 'hide' );
					$itactics_show_widgets = ! itactics_is_off( $itactics_widgets_name ) && is_active_sidebar( $itactics_widgets_name );
					$itactics_show_related = itactics_is_single() && itactics_get_theme_option( 'related_position', 'below_content' ) == 'below_page';
					if ( $itactics_show_widgets || $itactics_show_related ) {
						if ( 'fullscreen' != $itactics_body_style ) {
							?>
							<div class="content_wrap">
							<?php
						}
						// Show related posts before footer
						if ( $itactics_show_related ) {
							do_action( 'itactics_action_related_posts' );
						}

						// Widgets area below page content
						if ( $itactics_show_widgets ) {
							itactics_create_widgets_area( 'widgets_below_page' );
						}
						if ( 'fullscreen' != $itactics_body_style ) {
							?>
							</div>
							<?php
						}
					}
					do_action( 'itactics_action_page_content_wrap_end' );
					?>
			</div>
			<?php
			do_action( 'itactics_action_after_page_content_wrap' );

			// Don't display the footer elements while actions 'full_post_loading' and 'prev_post_loading'
			if ( ( ! itactics_is_singular( 'post' ) && ! itactics_is_singular( 'attachment' ) ) || ! in_array ( itactics_get_value_gp( 'action' ), array( 'full_post_loading', 'prev_post_loading' ) ) ) {
				
				// Skip link anchor to fast access to the footer from keyboard
				?>
				<a id="footer_skip_link_anchor" class="itactics_skip_link_anchor" href="#"></a>
				<?php

				do_action( 'itactics_action_before_footer' );

				// Footer
				$itactics_footer_type = itactics_get_theme_option( 'footer_type' );
				if ( 'custom' == $itactics_footer_type && ! itactics_is_layouts_available() ) {
					$itactics_footer_type = 'default';
				}
				get_template_part( apply_filters( 'itactics_filter_get_template_part', "templates/footer-" . sanitize_file_name( $itactics_footer_type ) ) );

				do_action( 'itactics_action_after_footer' );

			}
			?>

			<?php do_action( 'itactics_action_page_wrap_end' ); ?>

		</div>

		<?php do_action( 'itactics_action_after_page_wrap' ); ?>

	</div>

	<?php do_action( 'itactics_action_after_body' ); ?>

	<?php wp_footer(); ?>

</body>
</html>