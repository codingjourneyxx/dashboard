<?php
/* Tutor LMS support functions
------------------------------------------------------------------------------- */

// Theme init priorities:
// 1 - register filters, that add/remove lists items for the Theme Options
if ( ! function_exists( 'itactics_tutor_theme_setup1' ) ) {
	add_action( 'after_setup_theme', 'itactics_tutor_theme_setup1', 1 );
	function itactics_tutor_theme_setup1() {
		add_filter( 'itactics_filter_list_sidebars', 'itactics_tutor_list_sidebars' );
	}
}

// Theme init priorities:
// 3 - add/remove Theme Options elements
if ( ! function_exists( 'itactics_tutor_theme_setup3' ) ) {
	add_action( 'after_setup_theme', 'itactics_tutor_theme_setup3', 3 );
	function itactics_tutor_theme_setup3() {
		if ( itactics_exists_tutor() ) {
			// Section 'Tutor'
			itactics_storage_merge_array(
				'options', '', array_merge(
					array(
						'tutor' => array(
							"title" => esc_html__( 'Tutor LMS', 'itactics' ),
							"desc" => wp_kses_data( __( 'Select parameters to display the Tutor LMS pages', 'itactics' ) ),
							'icon'  => 'icon-courses',
							"type" => "section"
							),
					),
					itactics_options_get_list_cpt_options( 'tutor' )
				)
			);
		}
	}
}


// Theme init priorities:
// 9 - register other filters (for installer, etc.)
if ( ! function_exists( 'itactics_tutor_theme_setup9' ) ) {
	add_action( 'after_setup_theme', 'itactics_tutor_theme_setup9', 9 );
	function itactics_tutor_theme_setup9() {
		if ( itactics_exists_tutor() ) {
			add_action( 'wp_enqueue_scripts', 'itactics_tutor_frontend_scripts', 1100 );
			add_action( 'trx_addons_action_load_scripts_front_tutor', 'itactics_tutor_frontend_scripts', 10, 1 );
			add_action( 'wp_enqueue_scripts', 'itactics_tutor_frontend_scripts_responsive', 2000 );
			add_action( 'trx_addons_action_load_scripts_front_tutor', 'itactics_tutor_frontend_scripts_responsive', 10, 1 );
			add_filter( 'itactics_filter_merge_styles', 'itactics_tutor_merge_styles' );
			add_filter( 'itactics_filter_merge_styles_responsive', 'itactics_tutor_merge_styles_responsive' );
			add_filter( 'itactics_filter_post_type_taxonomy', 'itactics_tutor_post_type_taxonomy', 10, 2 );
			add_action( 'itactics_action_override_theme_options', 'itactics_tutor_override_theme_options' );
			add_filter( 'itactics_filter_list_posts_types', 'itactics_tutor_list_post_types');
			add_filter( 'itactics_filter_detect_blog_mode', 'itactics_tutor_detect_blog_mode' );
			add_filter( 'trx_addons_filter_get_blog_title', 'itactics_tutor_get_blog_title' );
			add_filter( 'itactics_filter_get_post_categories', 'itactics_tutor_get_post_categories', 10, 2 );
			add_filter( 'tutor_course_thumbnail_size', 'itactics_tutor_course_thumbnail_size', 10, 2 );
			// Redirect templates to the skin
			add_filter( 'tutor_get_template_path', 'itactics_tutor_get_template_path', 10000, 2 );
			add_filter( 'tutor_get_template_part_path', 'itactics_tutor_get_template_part_path', 10000, 2 );
		}
		if ( is_admin() ) {
			add_filter( 'itactics_filter_tgmpa_required_plugins', 'itactics_tutor_tgmpa_required_plugins' );
			add_filter( 'itactics_filter_theme_plugins', 'itactics_tutor_theme_plugins' );
		}
	}
}


// Filter to add in the required plugins list
if ( !function_exists( 'itactics_tutor_tgmpa_required_plugins' ) ) {
	//Handler of the add_filter( 'itactics_filter_tgmpa_required_plugins', 'itactics_tutor_tgmpa_required_plugins' );
	function itactics_tutor_tgmpa_required_plugins( $list = array() ) {
		if ( itactics_storage_isset( 'required_plugins', 'tutor' ) ) {
			$list[] = array(
					'name' 		=> itactics_storage_get_array( 'required_plugins', 'tutor', 'title' ),
					'slug' 		=> 'tutor',
					'required' 	=> false
				);
		}
		if ( itactics_storage_isset( 'required_plugins', 'tutor-lms-elementor-addons' ) ) {
			$list[] = array(
					'name' 		=> itactics_storage_get_array( 'required_plugins', 'tutor-lms-elementor-addons', 'title' ),
					'slug' 		=> 'tutor-lms-elementor-addons',
					'required' 	=> false
				);
		}
		return $list;
	}
}


// Filter theme-supported plugins list
if ( ! function_exists( 'itactics_tutor_theme_plugins' ) ) {
	//Handler of the add_filter( 'itactics_filter_theme_plugins', 'itactics_tutor_theme_plugins' );
	function itactics_tutor_theme_plugins( $list = array() ) {
		return itactics_add_group_and_logo_to_slave( $list, 'tutor', 'tutor-' );
	}
}


// Check if Tutor LMS installed and activated
if ( ! function_exists( 'itactics_exists_tutor' ) ) {
	function itactics_exists_tutor() {
		return function_exists('tutor_utils');
	}
}

// Return a list of option names for Tutor LMS pages
if ( ! function_exists( 'itactics_tutor_get_options_page_ids' ) ) {
	function itactics_tutor_get_options_page_ids() {
		return apply_filters( 'itactics_filter_tutor_pages', array(
			'tutor_dashboard_page_id',
			'tutor_toc_page_id',
			'tutor_cart_page_id',
			'tutor_checkout_page_id',
			'course_archive_page',
			'instructor_register_page',
			'student_register_page'
		) );
	}
}

// Return true, if current page is any tutor page
if ( ! function_exists( 'itactics_is_tutor_page' ) ) {
	function itactics_is_tutor_page() {
		$rez = false;
		if ( itactics_exists_tutor() && ! is_search() && ! is_admin() ) {
			$rez = tutor_utils()->is_tutor_frontend_dashboard()
					|| tutor_utils()->get_course_builder_screen()
					|| is_post_type_archive( tutor()->course_post_type )
					|| is_tax( 'course-category' )
					|| is_tax( 'course-tag' )
					|| is_singular( array(
							tutor()->course_post_type,
							tutor()->lesson_post_type,
							tutor()->quiz_post_type,
							tutor()->assignment_post_type,
							tutor()->zoom_post_type,
							tutor()->meet_post_type,
						) )
					|| ( itactics_check_url( '/profile/' ) && itactics_check_url( 'view=student' ) )
					|| ( itactics_check_url( '/profile/' ) && itactics_check_url( 'view=instructor' ) );
			if ( ! $rez ) {
				$id = get_the_ID();
				if ( $id > 0 ) {
					foreach( itactics_tutor_get_options_page_ids() as $page ) {
						$page_id = (int)tutor_utils()->get_option( $page );
						if ( $page_id > 0 && is_page() && $id == $page_id ) {
							$rez = true;
							break;
						}
					}
				}
			}
		}
		return $rez;
	}
}

// Detect current blog mode
if ( ! function_exists( 'itactics_tutor_detect_blog_mode' ) ) {
	//Handler of the add_filter( 'itactics_filter_detect_blog_mode', 'itactics_tutor_detect_blog_mode' );
	function itactics_tutor_detect_blog_mode( $mode = '' ) {
		if ( itactics_is_tutor_page() ) {
			$mode = 'tutor';
		}
		return $mode;
	}
}


// Return taxonomy for current post type
if ( ! function_exists( 'itactics_tutor_post_type_taxonomy' ) ) {
	//Handler of the add_filter( 'itactics_filter_post_type_taxonomy', 'itactics_tutor_post_type_taxonomy', 10, 2 );
	function itactics_tutor_post_type_taxonomy( $tax = '', $post_type = '' ) {
		if ( itactics_exists_tutor() ) {
			if ( $post_type == tutor()->course_post_type ) {
				$tax = 'course-category';
			}
		}
		return $tax;
	}
}

// Show categories of the current course
if ( ! function_exists( 'itactics_tutor_get_post_categories' ) ) {
	//Handler of the add_filter( 'itactics_filter_get_post_categories', 'itactics_tutor_get_post_categories', 10, 2 );
	function itactics_tutor_get_post_categories( $cats = '', $args = array() ) {
		if ( itactics_exists_tutor() && get_post_type() == tutor()->course_post_type ) {
			$cat_sep = apply_filters(
									'itactics_filter_post_meta_cat_separator',
									'<span class="post_meta_item_cat_separator">' . ( ! isset( $args['cat_sep'] ) || ! empty( $args['cat_sep'] ) ? ', ' : ' ' ) . '</span>',
									$args
									);
			$cats = itactics_get_post_terms( $cat_sep, get_the_ID(), 'course-category' );
		}
		return $cats;
	}
}

// Enqueue styles for frontend
if ( ! function_exists( 'itactics_tutor_frontend_scripts' ) ) {
	//Handler of the add_action( 'wp_enqueue_scripts', 'itactics_tutor_frontend_scripts', 1100 );
	//Handler of the add_action( 'trx_addons_action_load_scripts_front_tutor', 'itactics_tutor_frontend_scripts', 10, 1 );
	function itactics_tutor_frontend_scripts( $force = false ) {
		itactics_enqueue_optimized( 'tutor', $force, array(
			'css' => array(
				'itactics-tutor' => array( 'src' => 'plugins/tutor/tutor.css' ),
			)
		) );
	}
}

// Enqueue responsive styles for frontend
if ( ! function_exists( 'itactics_tutor_frontend_scripts_responsive' ) ) {
	//Handler of the add_action( 'wp_enqueue_scripts', 'itactics_tutor_frontend_scripts_responsive', 2000 );
	//Handler of the add_action( 'trx_addons_action_load_scripts_front_tutor', 'itactics_tutor_frontend_scripts_responsive', 10, 1 );
	function itactics_tutor_frontend_scripts_responsive( $force = false ) {
		itactics_enqueue_optimized_responsive( 'tutor', $force, array(
			'css' => array(
				'itactics-tutor-responsive' => array( 'src' => 'plugins/tutor/tutor-responsive.css', 'media' => 'all' ),
			)
		) );
	}
}


// Merge custom styles
if ( ! function_exists( 'itactics_tutor_merge_styles' ) ) {
	//Handler of the add_filter('itactics_filter_merge_styles', 'itactics_tutor_merge_styles');
	function itactics_tutor_merge_styles( $list ) {
		$list[ 'plugins/tutor/tutor.css' ] = false;
		return $list;
	}
}

// Merge responsive styles
if ( ! function_exists( 'itactics_tutor_merge_styles_responsive' ) ) {
	//Handler of the add_filter('itactics_filter_merge_styles_responsive', 'itactics_tutor_merge_styles_responsive');
	function itactics_tutor_merge_styles_responsive( $list ) {
		$list[ 'plugins/tutor/tutor-responsive.css' ] = false;
		return $list;
	}
}


// Override options with stored page meta on 'tutor' pages
if ( ! function_exists( 'itactics_tutor_override_theme_options' ) ) {
	//Handler of the add_action( 'itactics_action_override_theme_options', 'itactics_tutor_override_theme_options' );
	function itactics_tutor_override_theme_options() {
		if ( itactics_is_tutor_page() ) {
			$id = (int)tutor_utils()->get_option( 'course_archive_page' );
			if ( 0 < $id ) {
				// Get Theme Options from the courses page
				$courses_meta = get_post_meta( $id, 'itactics_options', true );
				// Add (override) with current post (course) options
				if ( is_array( $courses_meta ) && count( $courses_meta ) > 0 ) {
					// Get Theme Options from the current post/page
					$options_meta = itactics_storage_get( 'options_meta' );
					if ( is_array( $options_meta ) ) {
						$courses_meta = array_merge( $courses_meta, $options_meta );
					}
					itactics_storage_set( 'options_meta', $courses_meta );
				}
			}
		}
	}
}


// Check if meta box is allowed
if ( ! function_exists( 'itactics_tutor_allow_override_options' ) ) {
	if ( ! ITACTICS_THEME_FREE ) {
		add_filter( 'itactics_filter_allow_override_options', 'itactics_tutor_allow_override_options', 10, 2);
	}
	function itactics_tutor_allow_override_options( $allow, $post_type ) {
		return $allow || ( itactics_exists_tutor() && tutor()->course_post_type == $post_type );
	}
}


// Return current page title
if ( !function_exists( 'itactics_tutor_get_blog_title' ) ) {
	//Handler of the add_filter( 'trx_addons_filter_get_blog_title', 'itactics_tutor_get_blog_title' );
	function itactics_tutor_get_blog_title( $title = '' ) {
		if ( ! itactics_exists_trx_addons() && itactics_exists_tutor() && is_post_type_archive( tutor()->course_post_type ) ) {
			$id = (int)tutor_utils()->get_option( 'course_archive_page' );
			$title = $id ? get_the_title( $id ) : esc_html__( 'Tutor LMS', 'itactics' );
		}
		return $title;
	}
}


// Add 'course' to the list of the supported post-types
if ( ! function_exists( 'itactics_tutor_list_post_types' ) ) {
	//Handler of the add_filter( 'itactics_filter_list_posts_types', 'itactics_tutor_list_post_types');
	function itactics_tutor_list_post_types( $list = array() ) {
		if ( itactics_exists_tutor() ) {
			$list[ tutor()->course_post_type ] = esc_html__( 'Courses', 'itactics' );
		}
		return $list;
	}
}



// Redirect Tutor templates to the skin
//------------------------------------------------------------------------

// Search theme-specific template's part in the skin dir (if exists)
if ( ! function_exists( 'itactics_tutor_get_template_part_path' ) ) {
	//Handler of the add_filter( 'tutor_get_template_part_path', 'itactics_tutor_get_template_part_path', 10000, 2 );
	function itactics_tutor_get_template_part_path( $path, $template ) {
		$theme_dir = apply_filters( 'itactics_filter_get_theme_file_dir', '', "tutor/template.php" );
		if ( '' != $theme_dir ) {
			$path = $theme_dir;
		}
		return $path;
	}
}

// Search theme-specific template in the skin dir (if exists)
if ( ! function_exists( 'itactics_tutor_get_template_path' ) ) {
	//Handler of the add_filter( 'tutor_get_template_path', 'itactics_tutor_get_template_path', 10000, 5 );
	function itactics_tutor_get_template_path( $path, $template ) {
		$theme_dir = apply_filters( 'itactics_filter_get_theme_file_dir', '', "tutor/{$template}.php" );
		if ( '' != $theme_dir ) {
			$path = $theme_dir;
		}
		return $path;
	}
}



// Add Tutor specific items into lists
//------------------------------------------------------------------------

// Add sidebar
if ( ! function_exists( 'itactics_tutor_list_sidebars' ) ) {
	//Handler of the add_filter( 'itactics_filter_list_sidebars', 'itactics_tutor_list_sidebars' );
	function itactics_tutor_list_sidebars( $list = array() ) {
		$list['tutor_widgets'] = array(
			'name'        => esc_html__( 'Tutor Widgets', 'itactics' ),
			'description' => esc_html__( 'Widgets to be shown on the Tutor LMS pages', 'itactics' ),
		);
		return $list;
	}
}



// Decorate courses
//------------------------------------------------------------------------

// Replace a Tutor thumbsize with a theme-specific one
if ( ! function_exists( 'itactics_tutor_course_thumbnail_size' ) ) {
	//Handler of the add_filter( 'tutor_course_thumbnail_size', 'itactics_tutor_course_thumbnail_size', 10, 2 );
	function itactics_tutor_course_thumbnail_size( $thumb_size ) {
		$thumb_size = itactics_get_thumb_size( 'big' );
		return $thumb_size;
	}
}

// Add plugin-specific colors and fonts to the custom CSS
if ( itactics_exists_tutor() ) {
	$itactics_fdir = itactics_get_file_dir( 'plugins/tutor/tutor-style.php' );
	if ( ! empty( $itactics_fdir ) ) {
		require_once $itactics_fdir;
	}
}
