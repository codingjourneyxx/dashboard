<?php
/**
 * The Header: Logo and main menu
 *
 * @package ITACTICS
 * @since ITACTICS 1.0
 */
?><!DOCTYPE html>
<html <?php language_attributes(); ?> class="no-js<?php
	// Class scheme_xxx need in the <html> as context for the <body>!
	echo ' scheme_' . esc_attr( itactics_get_theme_option( 'color_scheme' ) );
?>">

<head>
	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>

	<?php
	if ( function_exists( 'wp_body_open' ) ) {
		wp_body_open();
	} else {
		do_action( 'wp_body_open' );
	}
	do_action( 'itactics_action_before_body' );
	?>

	<div class="<?php echo esc_attr( apply_filters( 'itactics_filter_body_wrap_class', 'body_wrap' ) ); ?>" <?php do_action('itactics_action_body_wrap_attributes'); ?>>

		<?php do_action( 'itactics_action_before_page_wrap' ); ?>

		<div class="<?php echo esc_attr( apply_filters( 'itactics_filter_page_wrap_class', 'page_wrap' ) ); ?>" <?php do_action('itactics_action_page_wrap_attributes'); ?>>

			<?php do_action( 'itactics_action_page_wrap_start' ); ?>

			<?php
			$itactics_full_post_loading = ( itactics_is_singular( 'post' ) || itactics_is_singular( 'attachment' ) ) && itactics_get_value_gp( 'action' ) == 'full_post_loading';
			$itactics_prev_post_loading = ( itactics_is_singular( 'post' ) || itactics_is_singular( 'attachment' ) ) && itactics_get_value_gp( 'action' ) == 'prev_post_loading';

			// Don't display the header elements while actions 'full_post_loading' and 'prev_post_loading'
			if ( ! $itactics_full_post_loading && ! $itactics_prev_post_loading ) {

				// Short links to fast access to the content, sidebar and footer from the keyboard
				?>
				<a class="itactics_skip_link skip_to_content_link" href="#content_skip_link_anchor" tabindex="<?php echo esc_attr( apply_filters( 'itactics_filter_skip_links_tabindex', 1 ) ); ?>"><?php esc_html_e( "Skip to content", 'itactics' ); ?></a>
				<?php if ( itactics_sidebar_present() ) { ?>
				<a class="itactics_skip_link skip_to_sidebar_link" href="#sidebar_skip_link_anchor" tabindex="<?php echo esc_attr( apply_filters( 'itactics_filter_skip_links_tabindex', 1 ) ); ?>"><?php esc_html_e( "Skip to sidebar", 'itactics' ); ?></a>
				<?php } ?>
				<a class="itactics_skip_link skip_to_footer_link" href="#footer_skip_link_anchor" tabindex="<?php echo esc_attr( apply_filters( 'itactics_filter_skip_links_tabindex', 1 ) ); ?>"><?php esc_html_e( "Skip to footer", 'itactics' ); ?></a>

				<?php
				do_action( 'itactics_action_before_header' );

				// Header
				$itactics_header_type = itactics_get_theme_option( 'header_type' );
				if ( 'custom' == $itactics_header_type && ! itactics_is_layouts_available() ) {
					$itactics_header_type = 'default';
				}
				get_template_part( apply_filters( 'itactics_filter_get_template_part', "templates/header-" . sanitize_file_name( $itactics_header_type ) ) );

				// Side menu
				if ( in_array( itactics_get_theme_option( 'menu_side', 'none' ), array( 'left', 'right' ) ) ) {
					get_template_part( apply_filters( 'itactics_filter_get_template_part', 'templates/header-navi-side' ) );
				}

				// Mobile menu
				if ( apply_filters( 'itactics_filter_use_navi_mobile', true ) ) {
					get_template_part( apply_filters( 'itactics_filter_get_template_part', 'templates/header-navi-mobile' ) );
				}

				do_action( 'itactics_action_after_header' );

			}
			?>

			<?php do_action( 'itactics_action_before_page_content_wrap' ); ?>

			<div class="page_content_wrap<?php
				if ( itactics_is_off( itactics_get_theme_option( 'remove_margins' ) ) ) {
					if ( empty( $itactics_header_type ) ) {
						$itactics_header_type = itactics_get_theme_option( 'header_type' );
					}
					if ( 'custom' == $itactics_header_type && itactics_is_layouts_available() ) {
						$itactics_header_id = itactics_get_custom_header_id();
						if ( $itactics_header_id > 0 ) {
							$itactics_header_meta = itactics_get_custom_layout_meta( $itactics_header_id );
							if ( ! empty( $itactics_header_meta['margin'] ) ) {
								?> page_content_wrap_custom_header_margin<?php
							}
						}
					}
					$itactics_footer_type = itactics_get_theme_option( 'footer_type' );
					if ( 'custom' == $itactics_footer_type && itactics_is_layouts_available() ) {
						$itactics_footer_id = itactics_get_custom_footer_id();
						if ( $itactics_footer_id ) {
							$itactics_footer_meta = itactics_get_custom_layout_meta( $itactics_footer_id );
							if ( ! empty( $itactics_footer_meta['margin'] ) ) {
								?> page_content_wrap_custom_footer_margin<?php
							}
						}
					}
				}
				do_action( 'itactics_action_page_content_wrap_class', $itactics_prev_post_loading );
				?>"<?php
				if ( apply_filters( 'itactics_filter_is_prev_post_loading', $itactics_prev_post_loading ) ) {
					?> data-single-style="<?php echo esc_attr( itactics_get_theme_option( 'single_style' ) ); ?>"<?php
				}
				do_action( 'itactics_action_page_content_wrap_data', $itactics_prev_post_loading );
			?>>
				<?php
				do_action( 'itactics_action_page_content_wrap', $itactics_full_post_loading || $itactics_prev_post_loading );

				// Single posts banner
				if ( apply_filters( 'itactics_filter_single_post_header', itactics_is_singular( 'post' ) || itactics_is_singular( 'attachment' ) ) ) {
					if ( $itactics_prev_post_loading ) {
						if ( itactics_get_theme_option( 'posts_navigation_scroll_which_block', 'article' ) != 'article' ) {
							do_action( 'itactics_action_between_posts' );
						}
					}
					// Single post thumbnail and title
					$itactics_path = apply_filters( 'itactics_filter_get_template_part', 'templates/single-styles/' . itactics_get_theme_option( 'single_style' ) );
					if ( itactics_get_file_dir( $itactics_path . '.php' ) != '' ) {
						get_template_part( $itactics_path );
					}
				}

				// Widgets area above page
				$itactics_body_style   = itactics_get_theme_option( 'body_style' );
				$itactics_widgets_name = itactics_get_theme_option( 'widgets_above_page', 'hide' );
				$itactics_show_widgets = ! itactics_is_off( $itactics_widgets_name ) && is_active_sidebar( $itactics_widgets_name );
				if ( $itactics_show_widgets ) {
					if ( 'fullscreen' != $itactics_body_style ) {
						?>
						<div class="content_wrap">
							<?php
					}
					itactics_create_widgets_area( 'widgets_above_page' );
					if ( 'fullscreen' != $itactics_body_style ) {
						?>
						</div>
						<?php
					}
				}

				// Content area
				do_action( 'itactics_action_before_content_wrap' );
				?>
				<div class="content_wrap<?php echo 'fullscreen' == $itactics_body_style ? '_fullscreen' : ''; ?>">

					<?php do_action( 'itactics_action_content_wrap_start' ); ?>

					<div class="content">
						<?php
						do_action( 'itactics_action_page_content_start' );

						// Skip link anchor to fast access to the content from keyboard
						?>
						<a id="content_skip_link_anchor" class="itactics_skip_link_anchor" href="#"></a>
						<?php
						// Single posts banner between prev/next posts
						if ( ( itactics_is_singular( 'post' ) || itactics_is_singular( 'attachment' ) )
							&& $itactics_prev_post_loading 
							&& itactics_get_theme_option( 'posts_navigation_scroll_which_block', 'article' ) == 'article'
						) {
							do_action( 'itactics_action_between_posts' );
						}

						// Widgets area above content
						itactics_create_widgets_area( 'widgets_above_content' );

						do_action( 'itactics_action_page_content_start_text' );
