<div class="front_page_section front_page_section_about<?php
	$itactics_scheme = itactics_get_theme_option( 'front_page_about_scheme' );
	if ( ! empty( $itactics_scheme ) && ! itactics_is_inherit( $itactics_scheme ) ) {
		echo ' scheme_' . esc_attr( $itactics_scheme );
	}
	echo ' front_page_section_paddings_' . esc_attr( itactics_get_theme_option( 'front_page_about_paddings' ) );
	if ( itactics_get_theme_option( 'front_page_about_stack' ) ) {
		echo ' sc_stack_section_on';
	}
?>"
		<?php
		$itactics_css      = '';
		$itactics_bg_image = itactics_get_theme_option( 'front_page_about_bg_image' );
		if ( ! empty( $itactics_bg_image ) ) {
			$itactics_css .= 'background-image: url(' . esc_url( itactics_get_attachment_url( $itactics_bg_image ) ) . ');';
		}
		if ( ! empty( $itactics_css ) ) {
			echo ' style="' . esc_attr( $itactics_css ) . '"';
		}
		?>
>
<?php
	// Add anchor
	$itactics_anchor_icon = itactics_get_theme_option( 'front_page_about_anchor_icon' );
	$itactics_anchor_text = itactics_get_theme_option( 'front_page_about_anchor_text' );
if ( ( ! empty( $itactics_anchor_icon ) || ! empty( $itactics_anchor_text ) ) && shortcode_exists( 'trx_sc_anchor' ) ) {
	echo do_shortcode(
		'[trx_sc_anchor id="front_page_section_about"'
									. ( ! empty( $itactics_anchor_icon ) ? ' icon="' . esc_attr( $itactics_anchor_icon ) . '"' : '' )
									. ( ! empty( $itactics_anchor_text ) ? ' title="' . esc_attr( $itactics_anchor_text ) . '"' : '' )
									. ']'
	);
}
?>
	<div class="front_page_section_inner front_page_section_about_inner
	<?php
	if ( itactics_get_theme_option( 'front_page_about_fullheight' ) ) {
		echo ' itactics-full-height sc_layouts_flex sc_layouts_columns_middle';
	}
	?>
			"
			<?php
			$itactics_css           = '';
			$itactics_bg_mask       = itactics_get_theme_option( 'front_page_about_bg_mask' );
			$itactics_bg_color_type = itactics_get_theme_option( 'front_page_about_bg_color_type' );
			if ( 'custom' == $itactics_bg_color_type ) {
				$itactics_bg_color = itactics_get_theme_option( 'front_page_about_bg_color' );
			} elseif ( 'scheme_bg_color' == $itactics_bg_color_type ) {
				$itactics_bg_color = itactics_get_scheme_color( 'bg_color', $itactics_scheme );
			} else {
				$itactics_bg_color = '';
			}
			if ( ! empty( $itactics_bg_color ) && $itactics_bg_mask > 0 ) {
				$itactics_css .= 'background-color: ' . esc_attr(
					1 == $itactics_bg_mask ? $itactics_bg_color : itactics_hex2rgba( $itactics_bg_color, $itactics_bg_mask )
				) . ';';
			}
			if ( ! empty( $itactics_css ) ) {
				echo ' style="' . esc_attr( $itactics_css ) . '"';
			}
			?>
	>
		<div class="front_page_section_content_wrap front_page_section_about_content_wrap content_wrap">
			<?php
			// Caption
			$itactics_caption = itactics_get_theme_option( 'front_page_about_caption' );
			if ( ! empty( $itactics_caption ) || ( current_user_can( 'edit_theme_options' ) && is_customize_preview() ) ) {
				?>
				<h2 class="front_page_section_caption front_page_section_about_caption front_page_block_<?php echo ! empty( $itactics_caption ) ? 'filled' : 'empty'; ?>"><?php echo wp_kses( $itactics_caption, 'itactics_kses_content' ); ?></h2>
				<?php
			}

			// Description (text)
			$itactics_description = itactics_get_theme_option( 'front_page_about_description' );
			if ( ! empty( $itactics_description ) || ( current_user_can( 'edit_theme_options' ) && is_customize_preview() ) ) {
				?>
				<div class="front_page_section_description front_page_section_about_description front_page_block_<?php echo ! empty( $itactics_description ) ? 'filled' : 'empty'; ?>"><?php echo wp_kses( wpautop( $itactics_description ), 'itactics_kses_content' ); ?></div>
				<?php
			}

			// Content
			$itactics_content = itactics_get_theme_option( 'front_page_about_content' );
			if ( ! empty( $itactics_content ) || ( current_user_can( 'edit_theme_options' ) && is_customize_preview() ) ) {
				?>
				<div class="front_page_section_content front_page_section_about_content front_page_block_<?php echo ! empty( $itactics_content ) ? 'filled' : 'empty'; ?>">
					<?php
					$itactics_page_content_mask = '%%CONTENT%%';
					if ( strpos( $itactics_content, $itactics_page_content_mask ) !== false ) {
						$itactics_content = preg_replace(
							'/(\<p\>\s*)?' . $itactics_page_content_mask . '(\s*\<\/p\>)/i',
							sprintf(
								'<div class="front_page_section_about_source">%s</div>',
								apply_filters( 'the_content', get_the_content() )
							),
							$itactics_content
						);
					}
					itactics_show_layout( $itactics_content );
					?>
				</div>
				<?php
			}
			?>
		</div>
	</div>
</div>
