<div class="front_page_section front_page_section_features<?php
	$itactics_scheme = itactics_get_theme_option( 'front_page_features_scheme' );
	if ( ! empty( $itactics_scheme ) && ! itactics_is_inherit( $itactics_scheme ) ) {
		echo ' scheme_' . esc_attr( $itactics_scheme );
	}
	echo ' front_page_section_paddings_' . esc_attr( itactics_get_theme_option( 'front_page_features_paddings' ) );
	if ( itactics_get_theme_option( 'front_page_features_stack' ) ) {
		echo ' sc_stack_section_on';
	}
?>"
		<?php
		$itactics_css      = '';
		$itactics_bg_image = itactics_get_theme_option( 'front_page_features_bg_image' );
		if ( ! empty( $itactics_bg_image ) ) {
			$itactics_css .= 'background-image: url(' . esc_url( itactics_get_attachment_url( $itactics_bg_image ) ) . ');';
		}
		if ( ! empty( $itactics_css ) ) {
			echo ' style="' . esc_attr( $itactics_css ) . '"';
		}
		?>
>
<?php
	// Add anchor
	$itactics_anchor_icon = itactics_get_theme_option( 'front_page_features_anchor_icon' );
	$itactics_anchor_text = itactics_get_theme_option( 'front_page_features_anchor_text' );
if ( ( ! empty( $itactics_anchor_icon ) || ! empty( $itactics_anchor_text ) ) && shortcode_exists( 'trx_sc_anchor' ) ) {
	echo do_shortcode(
		'[trx_sc_anchor id="front_page_section_features"'
									. ( ! empty( $itactics_anchor_icon ) ? ' icon="' . esc_attr( $itactics_anchor_icon ) . '"' : '' )
									. ( ! empty( $itactics_anchor_text ) ? ' title="' . esc_attr( $itactics_anchor_text ) . '"' : '' )
									. ']'
	);
}
?>
	<div class="front_page_section_inner front_page_section_features_inner
	<?php
	if ( itactics_get_theme_option( 'front_page_features_fullheight' ) ) {
		echo ' itactics-full-height sc_layouts_flex sc_layouts_columns_middle';
	}
	?>
			"
			<?php
			$itactics_css      = '';
			$itactics_bg_mask  = itactics_get_theme_option( 'front_page_features_bg_mask' );
			$itactics_bg_color_type = itactics_get_theme_option( 'front_page_features_bg_color_type' );
			if ( 'custom' == $itactics_bg_color_type ) {
				$itactics_bg_color = itactics_get_theme_option( 'front_page_features_bg_color' );
			} elseif ( 'scheme_bg_color' == $itactics_bg_color_type ) {
				$itactics_bg_color = itactics_get_scheme_color( 'bg_color', $itactics_scheme );
			} else {
				$itactics_bg_color = '';
			}
			if ( ! empty( $itactics_bg_color ) && $itactics_bg_mask > 0 ) {
				$itactics_css .= 'background-color: ' . esc_attr(
					1 == $itactics_bg_mask ? $itactics_bg_color : itactics_hex2rgba( $itactics_bg_color, $itactics_bg_mask )
				) . ';';
			}
			if ( ! empty( $itactics_css ) ) {
				echo ' style="' . esc_attr( $itactics_css ) . '"';
			}
			?>
	>
		<div class="front_page_section_content_wrap front_page_section_features_content_wrap content_wrap">
			<?php
			// Caption
			$itactics_caption = itactics_get_theme_option( 'front_page_features_caption' );
			if ( ! empty( $itactics_caption ) || ( current_user_can( 'edit_theme_options' ) && is_customize_preview() ) ) {
				?>
				<h2 class="front_page_section_caption front_page_section_features_caption front_page_block_<?php echo ! empty( $itactics_caption ) ? 'filled' : 'empty'; ?>"><?php echo wp_kses( $itactics_caption, 'itactics_kses_content' ); ?></h2>
				<?php
			}

			// Description (text)
			$itactics_description = itactics_get_theme_option( 'front_page_features_description' );
			if ( ! empty( $itactics_description ) || ( current_user_can( 'edit_theme_options' ) && is_customize_preview() ) ) {
				?>
				<div class="front_page_section_description front_page_section_features_description front_page_block_<?php echo ! empty( $itactics_description ) ? 'filled' : 'empty'; ?>"><?php echo wp_kses( wpautop( $itactics_description ), 'itactics_kses_content' ); ?></div>
				<?php
			}

			// Content (widgets)
			?>
			<div class="front_page_section_output front_page_section_features_output">
				<?php
				if ( is_active_sidebar( 'front_page_features_widgets' ) ) {
					dynamic_sidebar( 'front_page_features_widgets' );
				} elseif ( current_user_can( 'edit_theme_options' ) ) {
					if ( ! itactics_exists_trx_addons() ) {
						itactics_customizer_need_trx_addons_message();
					} else {
						itactics_customizer_need_widgets_message( 'front_page_features_caption', 'ThemeREX Addons - Services' );
					}
				}
				?>
			</div>
		</div>
	</div>
</div>
