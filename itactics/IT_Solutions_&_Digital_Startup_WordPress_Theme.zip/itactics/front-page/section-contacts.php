<div class="front_page_section front_page_section_contacts<?php
	$itactics_scheme = itactics_get_theme_option( 'front_page_contacts_scheme' );
	if ( ! empty( $itactics_scheme ) && ! itactics_is_inherit( $itactics_scheme ) ) {
		echo ' scheme_' . esc_attr( $itactics_scheme );
	}
	echo ' front_page_section_paddings_' . esc_attr( itactics_get_theme_option( 'front_page_contacts_paddings' ) );
	if ( itactics_get_theme_option( 'front_page_contacts_stack' ) ) {
		echo ' sc_stack_section_on';
	}
?>"
		<?php
		$itactics_css      = '';
		$itactics_bg_image = itactics_get_theme_option( 'front_page_contacts_bg_image' );
		if ( ! empty( $itactics_bg_image ) ) {
			$itactics_css .= 'background-image: url(' . esc_url( itactics_get_attachment_url( $itactics_bg_image ) ) . ');';
		}
		if ( ! empty( $itactics_css ) ) {
			echo ' style="' . esc_attr( $itactics_css ) . '"';
		}
		?>
>
<?php
	// Add anchor
	$itactics_anchor_icon = itactics_get_theme_option( 'front_page_contacts_anchor_icon' );
	$itactics_anchor_text = itactics_get_theme_option( 'front_page_contacts_anchor_text' );
if ( ( ! empty( $itactics_anchor_icon ) || ! empty( $itactics_anchor_text ) ) && shortcode_exists( 'trx_sc_anchor' ) ) {
	echo do_shortcode(
		'[trx_sc_anchor id="front_page_section_contacts"'
									. ( ! empty( $itactics_anchor_icon ) ? ' icon="' . esc_attr( $itactics_anchor_icon ) . '"' : '' )
									. ( ! empty( $itactics_anchor_text ) ? ' title="' . esc_attr( $itactics_anchor_text ) . '"' : '' )
									. ']'
	);
}
?>
	<div class="front_page_section_inner front_page_section_contacts_inner
	<?php
	if ( itactics_get_theme_option( 'front_page_contacts_fullheight' ) ) {
		echo ' itactics-full-height sc_layouts_flex sc_layouts_columns_middle';
	}
	?>
			"
			<?php
			$itactics_css      = '';
			$itactics_bg_mask  = itactics_get_theme_option( 'front_page_contacts_bg_mask' );
			$itactics_bg_color_type = itactics_get_theme_option( 'front_page_contacts_bg_color_type' );
			if ( 'custom' == $itactics_bg_color_type ) {
				$itactics_bg_color = itactics_get_theme_option( 'front_page_contacts_bg_color' );
			} elseif ( 'scheme_bg_color' == $itactics_bg_color_type ) {
				$itactics_bg_color = itactics_get_scheme_color( 'bg_color', $itactics_scheme );
			} else {
				$itactics_bg_color = '';
			}
			if ( ! empty( $itactics_bg_color ) && $itactics_bg_mask > 0 ) {
				$itactics_css .= 'background-color: ' . esc_attr(
					1 == $itactics_bg_mask ? $itactics_bg_color : itactics_hex2rgba( $itactics_bg_color, $itactics_bg_mask )
				) . ';';
			}
			if ( ! empty( $itactics_css ) ) {
				echo ' style="' . esc_attr( $itactics_css ) . '"';
			}
			?>
	>
		<div class="front_page_section_content_wrap front_page_section_contacts_content_wrap content_wrap">
			<?php

			// Title and description
			$itactics_caption     = itactics_get_theme_option( 'front_page_contacts_caption' );
			$itactics_description = itactics_get_theme_option( 'front_page_contacts_description' );
			if ( ! empty( $itactics_caption ) || ! empty( $itactics_description ) || ( current_user_can( 'edit_theme_options' ) && is_customize_preview() ) ) {
				// Caption
				if ( ! empty( $itactics_caption ) || ( current_user_can( 'edit_theme_options' ) && is_customize_preview() ) ) {
					?>
					<h2 class="front_page_section_caption front_page_section_contacts_caption front_page_block_<?php echo ! empty( $itactics_caption ) ? 'filled' : 'empty'; ?>">
					<?php
						echo wp_kses( $itactics_caption, 'itactics_kses_content' );
					?>
					</h2>
					<?php
				}

				// Description
				if ( ! empty( $itactics_description ) || ( current_user_can( 'edit_theme_options' ) && is_customize_preview() ) ) {
					?>
					<div class="front_page_section_description front_page_section_contacts_description front_page_block_<?php echo ! empty( $itactics_description ) ? 'filled' : 'empty'; ?>">
					<?php
						echo wp_kses( wpautop( $itactics_description ), 'itactics_kses_content' );
					?>
					</div>
					<?php
				}
			}

			// Content (text)
			$itactics_content = itactics_get_theme_option( 'front_page_contacts_content' );
			$itactics_layout  = itactics_get_theme_option( 'front_page_contacts_layout' );
			if ( 'columns' == $itactics_layout && ( ! empty( $itactics_content ) || ( current_user_can( 'edit_theme_options' ) && is_customize_preview() ) ) ) {
				?>
				<div class="front_page_section_columns front_page_section_contacts_columns columns_wrap">
					<div class="column-1_3">
				<?php
			}

			if ( ( ! empty( $itactics_content ) || ( current_user_can( 'edit_theme_options' ) && is_customize_preview() ) ) ) {
				?>
				<div class="front_page_section_content front_page_section_contacts_content front_page_block_<?php echo ! empty( $itactics_content ) ? 'filled' : 'empty'; ?>">
					<?php
					echo wp_kses( $itactics_content, 'itactics_kses_content' );
					?>
				</div>
				<?php
			}

			if ( 'columns' == $itactics_layout && ( ! empty( $itactics_content ) || ( current_user_can( 'edit_theme_options' ) && is_customize_preview() ) ) ) {
				?>
				</div><div class="column-2_3">
				<?php
			}

			// Shortcode output
			$itactics_sc = itactics_get_theme_option( 'front_page_contacts_shortcode' );
			if ( ! empty( $itactics_sc ) || ( current_user_can( 'edit_theme_options' ) && is_customize_preview() ) ) {
				?>
				<div class="front_page_section_output front_page_section_contacts_output front_page_block_<?php echo ! empty( $itactics_sc ) ? 'filled' : 'empty'; ?>">
					<?php
					itactics_show_layout( do_shortcode( $itactics_sc ) );
					?>
				</div>
				<?php
			}

			if ( 'columns' == $itactics_layout && ( ! empty( $itactics_content ) || ( current_user_can( 'edit_theme_options' ) && is_customize_preview() ) ) ) {
				?>
				</div></div>
				<?php
			}
			?>

		</div>
	</div>
</div>
