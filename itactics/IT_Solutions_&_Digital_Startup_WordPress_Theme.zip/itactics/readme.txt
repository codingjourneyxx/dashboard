== ITactics ==
Version: 1.0.0
Copyright: 2025, ThemeREX
WordPress version: required at least 5.5, tested up to 6.8
License: GNU General Public License v2.0 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html


I. Installation

1. In your admin panel, go to 'Appearance > Themes' and click the 'Add New' button.
2. Click 'Upload' and 'Choose File', then select the theme's .zip file. Click 'Install Now'.
3. Click 'Activate' to use your new theme right away.


II. Theme Features Usage

All available options can be used from 'Appearance->Customize' or from 'Theme Panel->Theme Options'.

For the full realization of their capabilities, the theme requires a satellite plugin 'ThemeREX Addons'.
Its installation is offered immediately after theme activation. You can also install it later
from the menu 'Appearance->Install plugins'.
Please install and activate it before starting to use the theme ITactics.

Also the theme supports many popular plugins such as 'Elementor' and many more.
They can be installed after theme activation from the menu 'Theme Panel->Theme Dashboard->Plugins'.


III. Documentation

Theme documentation is available on https://doc.themerex.net/itactics/


IV. Resources

1) Google fonts
   Licensed under one of the following: (SIL Open Font License, 1.1), (Apache License, version 2.0), or (Ubuntu Font License, 1.0)

2) Icons (css/font-icons/*.*)
   The icon set used in ITactics is Fontello.
   Copyright: Roman Shmelev (shmelev), Vitaly Puzrin (puzrin), Aleksey Zapparov (ixti), Evgeny Shkuropat (shkuropat), Vladimir Zapparov (dervus)
   Resource URI: http://fontello.com
   License: MIT license (http://opensource.org/licenses/MIT)
   License URI: https://github.com/fontello/fontello/blob/master/LICENSE

3) js/bideo.js
   Copyright: Rishabh (https://github.com/rishabhp)
   Resource URI: https://github.com/rishabhp/bideo.js?utm_source=hashnode.com
   License: MIT license (http://opensource.org/licenses/MIT)

4) js/colorpicker/spectrum/spectrum.js
   Copyright: Brian Grinstead (https://github.com/bgrins)
   Resource URI: https://github.com/bgrins/spectrum
   License: MIT license (http://opensource.org/licenses/MIT)

5) js/jquery.tubular.js
   Copyright: Sean McCambridge
   Resource URI: http://www.seanmccambridge.com/tubular
   License: MIT license (http://opensource.org/licenses/MIT)
   License URI: https://code.google.com/archive/p/jquery-tubular/

6) js/superfish/superfish.js
   Copyright: Joel Birch
   Resource URI: https://github.com/joeldbirch/superfish/
   License: MIT license (http://opensource.org/licenses/MIT)
   License URI: js/superfish/MIT-LICENSE.txt

7) Images come from:
   https://depositphotos.com/
   https://peopleimages.com/
   https://unsplash.com/
   https://flickr.com/
   https://www.shutterstock.com/
   https://www.pexels.com/
   https://www.freepik.com/
   https://www.midjourney.com/
   https://elements.envato.com/
   https://www.lummi.ai/

   https://ru.freepik.com/premium-photo/handsome-man-sign-contract-multiexposure-abstract-technology-hologram_36086880.htm
   https://ru.freepik.com/free-photo/beautiful-portrait-teenager-woman_27989843.htm#fromView=image_search&page=1&position=25&uuid=e742c47c-ddc0-4255-bcde-4ee75b914a94
   https://ru.freepik.com/free-photo/medium-shot-unknown-woman-posing_26559855.htm#fromView=image_search&page=1&position=0&uuid=a1c83007-48fe-469e-bd48-fc5502916f68
   https://ru.freepik.com/free-photo/beautiful-rendering-dating-app-concept_23669747.htm#fromView=image_search&page=1&position=1&uuid=7deaf352-d7b7-4dea-ae44-828710495455
   https://ru.freepik.com/free-photo/robot-hand-side-view-background-presenting-technology-gesture_17850392.htm#fromView=image_search&page=1&position=0&uuid=616fd301-8d47-4245-a8d4-6642ff377af9
   https://ru.freepik.com/premium-photo/3d-rendering-smiling-robot-with-mock-up-texts-bubbles-messages_39763753.htm#fromView=image_search&page=1&position=24&uuid=f92d4425-8eb6-49fc-8672-63574b010256
   https://ru.freepik.com/free-vector/3d-ai-robot-character-chat-bot-wink-mascot-icon_278701987.htm#fromView=image_search&page=1&position=5&uuid=074f76f3-95b3-426f-9547-3e0f1f7f3cf3
   https://ru.freepik.com/free-vector/chatbot-robot-isolated-white-background_273396038.htm#fromView=image_search&page=1&position=4&uuid=5856ac0b-ea01-4f96-8eb3-c0a9556c6b08
   https://ru.freepik.com/premium-photo/png-3d-robot-technology-transparent-background_414501162.htm#fromView=image_search&page=1&position=16&uuid=cedc1ea2-88df-494a-b5f1-4a94427370c3
   https://www.freepik.com/free-photo/smiling-girl-great-mood-shot-model-with-brown-eyes-bright-knitted-sweater-hat-gray-wall_12608948.htm
   https://www.freepik.com/free-photo/colleagues-office-using-tablet-computer_7336271.htm#from_element=detail_alsolike
   https://www.freepik.com/free-photo/portrait-beautiful-tender-woman-has-cheerful-smile-wears-casual-jumper-with-white-collar-stands-against-vivid-yellow-space-looks-directly-camera_13302096.htm
   https://www.freepik.com/free-vector/abstract-memphis-background-gradient-geometric-shapes-vector_18711036.htm#fromView=image_search&page=1&position=0&uuid=6a64637b-c694-407a-8730-c8f537456f46
   https://www.freepik.com/free-photo/man-wearing-smart-glasses-virtual-scanning-technology-glitch-effect_15474326.htm
   https://www.freepik.com/free-photo/pieces-portrait-concept-with-beautiful-woman_33756171.htm
   https://www.freepik.com/free-photo/dreamy-windows-with-beautiful-nature_38689686.htm
   https://www.freepik.com/premium-photo/close-up-young-man-wearing-sunglasses_97089377.htm
   https://www.freepik.com/premium-photo/emotional-intelligence_268468821.htm
   https://www.freepik.com/premium-photo/cozy-bedroom-interior-scene-3d-model_28401320.htm
   https://www.freepik.com/free-photo/assortment-with-foundation-bottle_16138954.htm
   https://www.freepik.com/free-photo/active-woman-holding-stainless-steel-water-bottle_15669025.htm
   https://www.freepik.com/premium-photo/modern-abstract-dynamic-shapes-black-white-background-with-grainy-paper-texture-digital-art_30460530.htm
   https://ru.freepik.com/premium-photo/robotic-hand-pressing-keyboard-laptop-3d-rendering_5384595.htm
   https://www.freepik.com/premium-photo/work-night-woman-reading-tablet-research-project-planning-proposal-office-building-startup-professional-employee-overtime-working-search-internet-online-communication_52637442.htm
   https://www.freepik.com/free-photo/portrait-young-businesswomen-with-tablet_13296715.htm
   https://www.freepik.com/free-photo/laptop-table_12661314.htm
   https://www.freepik.com/premium-photo/workplace-home-sunny-room-with-two-white-chairs_13661239.htm
   https://www.freepik.com/premium-photo/modern-office-space-featuring-sleek-furniture-city-views_272525556.htm
   https://www.freepik.com/premium-photo/smiling-business-woman-working-laptop-cozy-coworking-space-interior-distance-work-concept_260545976.htm
   https://www.freepik.com/free-photo/portrait-handsome-confident-stylish-hipster-lambersexual-model-with-curly-hairstyle-sexy-man-dressed-jeans-jacket-fashion-male-isolated-blue-wall-studio_26954864.htm
   https://www.freepik.com/free-photo/cloud-technology-with-futuristic-hologram-smartwatch_17121696.htm
   https://www.freepik.com/free-photo/beautiful-rendering-dating-app-concept_23669747.htm
   https://www.freepik.com/free-vector/abstract-memphis-background-gradient-geometric-shapes-vector_18711036.htm
   https://www.freepik.com/free-photo/robot-hand-showing-background-3d-ai-technology-side-view_17850553.htm
   https://www.freepik.com/premium-photo/3d-rendering-smiling-robot-with-mock-up-texts-bubbles-messages_39763753.htm
   https://www.freepik.com/free-psd/time-machine-concept-isolated_381024285.htm
   https://www.freepik.com/free-photo/metaverse-concept-collage-design_27989408.htm
   https://www.freepik.com/premium-ai-image/transform-your-business-with-stunning-effective-website-design_71111240.htm
   https://www.freepik.com/free-ai-image/cartoon-man-wearing-glasses_126197043.htm
   https://www.freepik.com/premium-photo/poster-music-desert-with-words-wild-top_261150791.htm
   https://www.freepik.com/free-photo/colleagues-office-using-tablet-computer_7336271.htm
   https://www.freepik.com/free-photo/medium-shot-unknown-woman-posing_26559855.htm
   https://www.freepik.com/free-photo/smiling-girl-great-mood-shot-model-with-brown-eyes-bright-knitted-sweater-hat-gray-wall_12608948.htm
   https://www.freepik.com/free-photo/dreamy-young-woman-sunglasses-looking-front_12859999.htm
   https://www.freepik.com/free-photo/portrait-fashionable-boy-against-blue-wall_4647746.htm
   https://www.freepik.com/free-photo/portrait-beautiful-tender-woman-has-cheerful-smile-wears-casual-jumper-with-white-collar-stands-against-vivid-yellow-space-looks-directly-camera_13302096.htm
   https://www.freepik.com/free-photo/portrait-pensive-redhead-man-eyeglasses_7339009.htm
   https://www.freepik.com/premium-psd/realistic-urban-3d-phone-mockup_157151926.htm
   https://www.freepik.com/premium-photo/woman-using-mobile-phone-holding-hands_15124158.htm
   https://www.freepik.com/premium-photo/call-center-headphones-woman-is-working-office_402174884.htm
   https://www.freepik.com/premium-photo/handsome-man-sign-contract-multiexposure-abstract-technology-hologram_36086880.htm

   https://unsplash.com/photos/man-in-white-shirt-with-red-and-black-face-paint-a6VVCkPOs8Y
   https://unsplash.com/photos/white-ceramic-mug-with-coffee-csJt89dL9pE
   https://unsplash.com/photos/green-leaf-on-yellow-chair-MBtcLadqc6c
   https://unsplash.com/photos/a-stack-of-paper-money-Y_JQwmLUyLc
   https://unsplash.com/photos/a-stack-of-books-sitting-on-top-of-a-table-nssQgOIT5JU
   https://www.pexels.com/photo/overhead-shot-of-leaves-on-a-black-textile-4862955/
   https://unsplash.com/photos/a-close-up-of-some-papers-NmSPbe0bDtc
   https://unsplash.com/photos/a-black-business-card-sitting-on-top-of-a-table-fxsiR2Zrwy4
   https://unsplash.com/photos/a-person-is-holding-a-box-with-a-name-tag-on-it-pNtvRgODGyE
   https://unsplash.com/photos/a-close-up-of-a-piece-of-paper-with-a-pen-uF7blQmDvh0
   https://unsplash.com/photos/a-picture-of-a-green-object-with-a-white-background-uSNuKKh7wpA

   https://www.shutterstock.com/ru/image-photo/photo-portrait-attractive-young-woman-show-2620233033
   https://www.shutterstock.com/ru/image-photo/full-body-young-happy-woman-she-2571603577
   https://www.shutterstock.com/ru/image-photo/happy-professional-women-collaborating-enthusiasm-modern-2470549275
   https://www.shutterstock.com/ru/image-photo/woman-using-mobile-phone-holding-hands-1953835111
   https://www.shutterstock.com/ru/image-photo/happy-mature-business-man-entrepreneur-using-2426323949
   https://www.shutterstock.com/ru/image-photo/closeup-woman-surfing-on-internet-while-1776825902
   https://www.shutterstock.com/ru/image-photo/black-man-typing-smartphone-standing-full-2473441803

   License: watermark distribution only

Other custom js files and images are our own creation and is licensed under the same license as this theme.