<?php
/**
 * The Sidebar containing the main widget areas.
 *
 * @package ITACTICS
 * @since ITACTICS 1.0
 */

if ( itactics_sidebar_present() ) {
	
	$itactics_sidebar_type = itactics_get_theme_option( 'sidebar_type' );
	if ( 'custom' == $itactics_sidebar_type && ! itactics_is_layouts_available() ) {
		$itactics_sidebar_type = 'default';
	}
	
	// Catch output to the buffer
	ob_start();
	if ( 'default' == $itactics_sidebar_type ) {
		// Default sidebar with widgets
		$itactics_sidebar_name = itactics_get_theme_option( 'sidebar_widgets' );
		itactics_storage_set( 'current_sidebar', 'sidebar' );
		if ( is_active_sidebar( $itactics_sidebar_name ) ) {
			dynamic_sidebar( $itactics_sidebar_name );
		}
	} else {
		// Custom sidebar from Layouts Builder
		$itactics_sidebar_id = itactics_get_custom_sidebar_id();
		do_action( 'itactics_action_show_layout', $itactics_sidebar_id );
	}
	$itactics_out = trim( ob_get_contents() );
	ob_end_clean();
	
	// If any html is present - display it
	if ( ! empty( $itactics_out ) ) {
		$itactics_sidebar_position    = itactics_get_theme_option( 'sidebar_position' );
		$itactics_sidebar_position_ss = itactics_get_theme_option( 'sidebar_position_ss', 'below' );
		?>
		<div class="sidebar widget_area
			<?php
			echo ' ' . esc_attr( $itactics_sidebar_position );
			echo ' sidebar_' . esc_attr( $itactics_sidebar_position_ss );
			echo ' sidebar_' . esc_attr( $itactics_sidebar_type );

			$itactics_sidebar_scheme = apply_filters( 'itactics_filter_sidebar_scheme', itactics_get_theme_option( 'sidebar_scheme', 'inherit' ) );
			if ( ! empty( $itactics_sidebar_scheme ) && ! itactics_is_inherit( $itactics_sidebar_scheme ) && 'custom' != $itactics_sidebar_type ) {
				echo ' scheme_' . esc_attr( $itactics_sidebar_scheme );
			}
			?>
		" role="complementary">
			<?php

			// Skip link anchor to fast access to the sidebar from keyboard
			?>
			<a id="sidebar_skip_link_anchor" class="itactics_skip_link_anchor" href="#"></a>
			<?php

			do_action( 'itactics_action_before_sidebar_wrap', 'sidebar' );

			// Button to show/hide sidebar on mobile
			if ( in_array( $itactics_sidebar_position_ss, array( 'above', 'float' ) ) ) {
				$itactics_title = apply_filters( 'itactics_filter_sidebar_control_title', 'float' == $itactics_sidebar_position_ss ? esc_html__( 'Show Sidebar', 'itactics' ) : '' );
				$itactics_text  = apply_filters( 'itactics_filter_sidebar_control_text', 'above' == $itactics_sidebar_position_ss ? esc_html__( 'Show Sidebar', 'itactics' ) : '' );
				?>
				<a href="#" class="sidebar_control" title="<?php echo esc_attr( $itactics_title ); ?>"><?php echo esc_html( $itactics_text ); ?></a>
				<?php
			}
			?>
			<div class="sidebar_inner">
				<?php
				do_action( 'itactics_action_before_sidebar', 'sidebar' );
				itactics_show_layout( preg_replace( "/<\/aside>[\r\n\s]*<aside/", '</aside><aside', $itactics_out ) );
				do_action( 'itactics_action_after_sidebar', 'sidebar' );
				?>
			</div>
			<?php

			do_action( 'itactics_action_after_sidebar_wrap', 'sidebar' );

			?>
		</div>
		<div class="clearfix"></div>
		<?php
	}
}
