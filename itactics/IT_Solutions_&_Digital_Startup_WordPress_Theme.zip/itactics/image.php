<?php
/**
 * The template to display the attachment
 *
 * @package ITACTICS
 * @since ITACTICS 1.0
 */


get_header();

while ( have_posts() ) {
	the_post();

	// Display post's content
	get_template_part( apply_filters( 'itactics_filter_get_template_part', 'templates/content', 'single-' . itactics_get_theme_option( 'single_style' ) ), 'single-' . itactics_get_theme_option( 'single_style' ) );

	// Parent post navigation.
	$itactics_posts_navigation = itactics_get_theme_option( 'posts_navigation' );
	if ( 'links' == $itactics_posts_navigation ) {
		?>
		<div class="nav-links-single<?php
			if ( ! itactics_is_off( itactics_get_theme_option( 'posts_navigation_fixed', 0 ) ) ) {
				echo ' nav-links-fixed fixed';
			}
		?>">
			<?php
			the_post_navigation( apply_filters( 'itactics_filter_post_navigation_args', array(
					'prev_text' => '<span class="nav-arrow"></span>'
						. '<span class="meta-nav" aria-hidden="true">' . esc_html__( 'Published in', 'itactics' ) . '</span> '
						. '<span class="screen-reader-text">' . esc_html__( 'Previous post:', 'itactics' ) . '</span> '
						. '<h5 class="post-title">%title</h5>'
						. '<span class="post_date">%date</span>',
			), 'image' ) );
			?>
		</div>
		<?php
	}

	// Comments
	do_action( 'itactics_action_before_comments' );
	comments_template();
	do_action( 'itactics_action_after_comments' );
}

get_footer();
