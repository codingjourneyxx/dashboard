<?php
/**
 * The template to display the page title and breadcrumbs
 *
 * @package ITACTICS
 * @since ITACTICS 1.0
 */

// Page (category, tag, archive, author) title

if ( itactics_need_page_title() ) {
	itactics_sc_layouts_showed( 'title', true );
	?>
	<div class="top_panel_title sc_layouts_row">
		<div class="content_wrap">
			<div class="sc_layouts_column sc_layouts_column_align_center">
				<div class="sc_layouts_item">
					<div class="sc_layouts_title sc_align_center">
						<?php
						// Blog/Page title
						?>
						<div class="sc_layouts_title_title">
							<?php
							$itactics_blog_title           = itactics_get_blog_title();
							$itactics_blog_title_text      = '';
							$itactics_blog_title_class     = '';
							$itactics_blog_title_link      = '';
							$itactics_blog_title_link_text = '';
							if ( is_array( $itactics_blog_title ) ) {
								$itactics_blog_title_text      = $itactics_blog_title['text'];
								$itactics_blog_title_class     = ! empty( $itactics_blog_title['class'] ) ? ' ' . $itactics_blog_title['class'] : '';
								$itactics_blog_title_link      = ! empty( $itactics_blog_title['link'] ) ? $itactics_blog_title['link'] : '';
								$itactics_blog_title_link_text = ! empty( $itactics_blog_title['link_text'] ) ? $itactics_blog_title['link_text'] : '';
							} else {
								$itactics_blog_title_text = $itactics_blog_title;
							}
							?>
							<h1 itemprop="headline" class="sc_layouts_title_caption<?php echo esc_attr( $itactics_blog_title_class ); ?>">
								<?php
								$itactics_top_icon = itactics_get_term_image_small();
								if ( ! empty( $itactics_top_icon ) ) {
									$itactics_attr = itactics_getimagesize( $itactics_top_icon );
									?>
									<img src="<?php echo esc_url( $itactics_top_icon ); ?>" alt="<?php esc_attr_e( 'Site icon', 'itactics' ); ?>"
										<?php
										if ( ! empty( $itactics_attr[3] ) ) {
											itactics_show_layout( $itactics_attr[3] );
										}
										?>
									>
									<?php
								}
								echo wp_kses_data( $itactics_blog_title_text );
								?>
							</h1>
							<?php
							if ( ! empty( $itactics_blog_title_link ) && ! empty( $itactics_blog_title_link_text ) ) {
								?>
								<a href="<?php echo esc_url( $itactics_blog_title_link ); ?>" class="theme_button sc_layouts_title_link"><?php echo esc_html( $itactics_blog_title_link_text ); ?></a>
								<?php
							}

							// Category/Tag description
							if ( ! is_paged() && ( is_category() || is_tag() || is_tax() ) ) {
								the_archive_description( '<div class="sc_layouts_title_description">', '</div>' );
							}

							?>
						</div>
						<?php

						// Breadcrumbs
						ob_start();
						do_action( 'itactics_action_breadcrumbs' );
						$itactics_breadcrumbs = ob_get_contents();
						ob_end_clean();
						itactics_show_layout( $itactics_breadcrumbs, '<div class="sc_layouts_title_breadcrumbs">', '</div>' );
						?>
					</div>
				</div>
			</div>
		</div>
	</div>
	<?php
}
