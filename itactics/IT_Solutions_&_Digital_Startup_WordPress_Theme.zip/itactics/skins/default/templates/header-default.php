<?php
/**
 * The template to display default site header
 *
 * @package ITACTICS
 * @since ITACTICS 1.0
 */

$itactics_header_css   = '';
$itactics_header_image = get_header_image();
$itactics_header_video = itactics_get_header_video();
if ( ! empty( $itactics_header_image ) && itactics_trx_addons_featured_image_override( itactics_is_singular() || itactics_storage_isset( 'blog_archive' ) || is_category() ) ) {
	$itactics_header_image = itactics_get_current_mode_image( $itactics_header_image );
}
?><header class="top_panel top_panel_default
	<?php
	echo ! empty( $itactics_header_image ) || ! empty( $itactics_header_video ) ? ' with_bg_image' : ' without_bg_image';
	if ( '' != $itactics_header_video ) {
		echo ' with_bg_video';
	}
	if ( '' != $itactics_header_image ) {
		echo ' ' . esc_attr( itactics_add_inline_css_class( 'background-image: url(' . esc_url( $itactics_header_image ) . ');' ) );
	}
	if ( itactics_is_singular() && has_post_thumbnail() ) {
		echo ' with_featured_image';
	}
	?>
">
	<?php

	// Background video
	if ( ! empty( $itactics_header_video ) ) {
		get_template_part( apply_filters( 'itactics_filter_get_template_part', 'templates/header-video' ) );
	}

	// Main menu
	get_template_part( apply_filters( 'itactics_filter_get_template_part', 'templates/header-navi' ) );

	// Page title and breadcrumbs area
	if ( ! itactics_is_single() ) {
		get_template_part( apply_filters( 'itactics_filter_get_template_part', 'templates/header-title' ) );
	}
	?>
</header>
