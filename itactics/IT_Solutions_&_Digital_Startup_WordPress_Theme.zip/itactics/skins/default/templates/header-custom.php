<?php
/**
 * The template to display custom header from the ThemeREX Addons Layouts
 *
 * @package ITACTICS
 * @since ITACTICS 1.0.06
 */

$itactics_header_css   = '';
$itactics_header_image = get_header_image();
if ( ! empty( $itactics_header_image ) && itactics_trx_addons_featured_image_override( itactics_is_singular() || itactics_storage_isset( 'blog_archive' ) || is_category() ) ) {
	$itactics_header_image = itactics_get_current_mode_image( $itactics_header_image );
}

$itactics_header_id = itactics_get_custom_header_id();
$itactics_header_meta = itactics_get_custom_layout_meta( $itactics_header_id );
if ( ! empty( $itactics_header_meta['margin'] ) ) {
	itactics_add_inline_css( sprintf( '.page_content_wrap{padding-top:%s}', esc_attr( itactics_prepare_css_value( $itactics_header_meta['margin'] ) ) ) );
	itactics_storage_set( 'custom_header_margin', itactics_prepare_css_value( $itactics_header_meta['margin'] ) );
}

?><header class="top_panel top_panel_custom top_panel_custom_<?php echo esc_attr( $itactics_header_id ); ?> top_panel_custom_<?php echo esc_attr( sanitize_title( get_the_title( $itactics_header_id ) ) ); ?>
				<?php
				echo ! empty( $itactics_header_image )
					? ' with_bg_image'
					: ' without_bg_image';
				if ( '' != $itactics_header_image ) {
					echo ' ' . esc_attr( itactics_add_inline_css_class( 'background-image: url(' . esc_url( $itactics_header_image ) . ');' ) );
				}
				if ( itactics_is_single() && has_post_thumbnail() ) {
					echo ' with_featured_image';
				}
				?>
">
	<?php

	// Custom header's layout
	do_action( 'itactics_action_show_layout', $itactics_header_id );

	?>
</header>
