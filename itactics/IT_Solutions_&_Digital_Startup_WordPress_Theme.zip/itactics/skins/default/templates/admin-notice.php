<?php
/**
 * The template to display Admin notices
 *
 * @package ITACTICS
 * @since ITACTICS 1.0.1
 */

$itactics_theme_slug = get_template();
$itactics_theme_obj  = wp_get_theme( $itactics_theme_slug );
?>
<div class="itactics_admin_notice itactics_welcome_notice notice notice-info is-dismissible" data-notice="admin">
	<?php
	// Theme image
	$itactics_theme_img = itactics_get_file_url( 'screenshot.jpg' );
	if ( '' != $itactics_theme_img ) {
		?>
		<div class="itactics_notice_image"><img src="<?php echo esc_url( $itactics_theme_img ); ?>" alt="<?php esc_attr_e( 'Theme screenshot', 'itactics' ); ?>"></div>
		<?php
	}

	// Title
	?>
	<h3 class="itactics_notice_title">
		<?php
		echo esc_html(
			sprintf(
				// Translators: Add theme name and version to the 'Welcome' message
				__( 'Welcome to %1$s v.%2$s', 'itactics' ),
				$itactics_theme_obj->get( 'Name' ) . ( ITACTICS_THEME_FREE ? ' ' . __( 'Free', 'itactics' ) : '' ),
				$itactics_theme_obj->get( 'Version' )
			)
		);
		?>
	</h3>
	<?php

	// Description
	?>
	<div class="itactics_notice_text">
		<p class="itactics_notice_text_description">
			<?php
			echo str_replace( '. ', '.<br>', wp_kses_data( $itactics_theme_obj->description ) );
			?>
		</p>
		<p class="itactics_notice_text_info">
			<?php
			echo wp_kses_data( __( 'Attention! Plugin "ThemeREX Addons" is required! Please, install and activate it!', 'itactics' ) );
			?>
		</p>
	</div>
	<?php

	// Buttons
	?>
	<div class="itactics_notice_buttons">
		<?php
		// Link to the page 'About Theme'
		?>
		<a href="<?php echo esc_url( admin_url() . 'themes.php?page=itactics_about' ); ?>" class="button button-primary"><i class="dashicons dashicons-nametag"></i> 
			<?php
			echo esc_html__( 'Install plugin "ThemeREX Addons"', 'itactics' );
			?>
		</a>
	</div>
</div>
