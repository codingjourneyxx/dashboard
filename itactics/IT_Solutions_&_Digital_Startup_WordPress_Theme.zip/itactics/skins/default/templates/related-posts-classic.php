<?php
/**
 * The template 'Style 2' to displaying related posts
 *
 * @package ITACTICS
 * @since ITACTICS 1.0
 */

$itactics_link        = get_permalink();
$itactics_post_format = get_post_format();
$itactics_post_format = empty( $itactics_post_format ) ? 'standard' : str_replace( 'post-format-', '', $itactics_post_format );

?><div id="post-<?php the_ID(); ?>" <?php post_class( 'related_item post_format_' . esc_attr( $itactics_post_format ) ); ?> data-post-id="<?php the_ID(); ?>">
	<?php
	itactics_show_post_featured(
		array(
			'thumb_size' => apply_filters( 'itactics_filter_related_thumb_size', itactics_get_thumb_size(
				(int) itactics_get_theme_option( 'related_posts' ) == 1 || (int) itactics_get_theme_option( 'related_columns' ) == 1 ? 'full' : 'big' )
			),
		)
	);
	?>
	<div class="post_header entry-header">
		<?php
		if ( in_array( get_post_type(), array( 'post', 'attachment' ) ) ) {
			itactics_show_post_meta(
				array(
					'components' => 'categories',
					'class'      => 'post_meta_categories',
				)
			);	
		}
		?>
		<h4 class="post_title entry-title"><a href="<?php echo esc_url( $itactics_link ); ?>"><?php
			if ( '' == get_the_title() ) {
				esc_html_e( 'No title', 'itactics' );
			} else {
				the_title();
			}
		?></a></h4>
		<?php
		if ( in_array( get_post_type(), array( 'post', 'attachment' ) ) ) {
			itactics_show_post_meta(
				array(
					'components' => 'date, comments',
					'class'      => 'post_meta_info',
				)
			);	
		}
		?>
	</div>
</div>
