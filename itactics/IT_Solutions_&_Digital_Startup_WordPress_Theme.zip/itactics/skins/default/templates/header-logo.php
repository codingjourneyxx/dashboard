<?php
/**
 * The template to display the logo or the site name and the slogan in the Header
 *
 * @package ITACTICS
 * @since ITACTICS 1.0
 */

$itactics_args = get_query_var( 'itactics_logo_args' );

// Site logo
$itactics_logo_type   = isset( $itactics_args['type'] ) ? $itactics_args['type'] : '';
$itactics_logo_image  = itactics_get_logo_image( $itactics_logo_type );
$itactics_logo_text   = itactics_is_on( itactics_get_theme_option( 'logo_text' ) ) ? get_bloginfo( 'name' ) : '';
$itactics_logo_slogan = get_bloginfo( 'description', 'display' );
if ( ! empty( $itactics_logo_image['logo'] ) || ! empty( $itactics_logo_text ) ) {
	?><a class="sc_layouts_logo" href="<?php echo esc_url( home_url( '/' ) ); ?>">
		<?php
		if ( ! empty( $itactics_logo_image['logo'] ) ) {
			if ( empty( $itactics_logo_type ) && function_exists( 'the_custom_logo' ) && is_numeric( $itactics_logo_image['logo'] ) && (int) $itactics_logo_image['logo'] > 0 ) {
				the_custom_logo();
			} else {
				$itactics_attr = itactics_getimagesize( $itactics_logo_image['logo'] );
				echo '<img src="' . esc_url( $itactics_logo_image['logo'] ) . '"'
						. ( ! empty( $itactics_logo_image['logo_retina'] ) ? ' srcset="' . esc_url( $itactics_logo_image['logo_retina'] ) . ' 2x"' : '' )
						. ' alt="' . esc_attr( $itactics_logo_text ) . '"'
						. ( ! empty( $itactics_attr[3] ) ? ' ' . wp_kses_data( $itactics_attr[3] ) : '' )
						. '>';
			}
		} else {
			itactics_show_layout( itactics_prepare_macros( $itactics_logo_text ), '<span class="logo_text">', '</span>' );
			itactics_show_layout( itactics_prepare_macros( $itactics_logo_slogan ), '<span class="logo_slogan">', '</span>' );
		}
		?>
	</a>
	<?php
}
