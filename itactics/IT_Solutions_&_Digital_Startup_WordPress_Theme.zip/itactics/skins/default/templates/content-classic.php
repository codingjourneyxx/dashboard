<?php
/**
 * The Classic template to display the content
 *
 * Used for index/archive/search.
 *
 * @package ITACTICS
 * @since ITACTICS 1.0
 */

$itactics_template_args = get_query_var( 'itactics_template_args' );

if ( is_array( $itactics_template_args ) ) {
	$itactics_columns       = empty( $itactics_template_args['columns'] ) ? 1 : max( 1, $itactics_template_args['columns'] );
	$itactics_blog_style    = array( $itactics_template_args['type'], $itactics_columns );
	$itactics_columns_class = itactics_get_column_class( 1, $itactics_columns, ! empty( $itactics_template_args['columns_tablet']) ? $itactics_template_args['columns_tablet'] : '', ! empty($itactics_template_args['columns_mobile']) ? $itactics_template_args['columns_mobile'] : '' );
} else {
	$itactics_template_args = array();
	$itactics_blog_style    = explode( '_', itactics_get_theme_option( 'blog_style' ) );
	$itactics_columns       = empty( $itactics_blog_style[1] ) ? 1 : max( 1, $itactics_blog_style[1] );
	$itactics_columns_class = itactics_get_column_class( 1, $itactics_columns );
}
$itactics_expanded   = ! itactics_sidebar_present() && itactics_get_theme_option( 'expand_content' ) == 'expand';

$itactics_post_format = get_post_format();
$itactics_post_format = empty( $itactics_post_format ) ? 'standard' : str_replace( 'post-format-', '', $itactics_post_format );

?><div class="<?php
	if ( ! empty( $itactics_template_args['slider'] ) ) {
		echo ' slider-slide swiper-slide';
	} else {
		echo ( itactics_is_blog_style_use_masonry( $itactics_blog_style[0] )
			? 'masonry_item masonry_item-1_' . esc_attr( $itactics_columns )
			: esc_attr( $itactics_columns_class )
			);
	}
?>"><article id="post-<?php the_ID(); ?>" data-post-id="<?php the_ID(); ?>"
	<?php
	post_class(
		'post_item post_item_container post_format_' . esc_attr( $itactics_post_format )
				. ' post_layout_classic post_layout_classic_' . esc_attr( $itactics_columns )
				. ' post_layout_' . esc_attr( $itactics_blog_style[0] )
				. ' post_layout_' . esc_attr( $itactics_blog_style[0] ) . '_' . esc_attr( $itactics_columns )
	);
	itactics_add_blog_animation( $itactics_template_args );
	?>
>
	<?php

	// Sticky label
	if ( is_sticky() && ! is_paged() ) {
		?><span class="post_label label_sticky"></span><?php
	}

	// Featured image
	$itactics_hover      = ! empty( $itactics_template_args['hover'] ) && ! itactics_is_inherit( $itactics_template_args['hover'] )
							? $itactics_template_args['hover']
							: itactics_get_theme_option( 'image_hover' );

	$itactics_components = ! empty( $itactics_template_args['meta_parts'] )
							? ( is_array( $itactics_template_args['meta_parts'] )
								? $itactics_template_args['meta_parts']
								: array_map( 'trim', explode( ',', $itactics_template_args['meta_parts'] ) )
								)
							: itactics_array_get_keys_by_value( itactics_get_theme_option( 'meta_parts' ) );

	itactics_show_post_featured( apply_filters( 'itactics_filter_args_featured',
		array(
			'thumb_size' => ! empty( $itactics_template_args['thumb_size'] )
								? $itactics_template_args['thumb_size']
								: itactics_get_thumb_size(
									strpos( itactics_get_theme_option( 'body_style' ), 'full' ) !== false
										? ( $itactics_columns > 2 ? 'big' : 'full' )
										: ( $itactics_columns > 2
											? 'med'
											: ( $itactics_expanded || $itactics_columns == 1 ? 
												( $itactics_expanded && $itactics_columns == 1 ? 'huge' : 'big' ) 
												: 'med' 
												)
											)												
								),
			'hover'      => $itactics_hover,
			'meta_parts' => $itactics_components,
			'no_links'   => ! empty( $itactics_template_args['no_links'] ),
		),
		'content-classic',
		$itactics_template_args
	) );

	// Title and post meta
	$itactics_show_title = get_the_title() != '';
	$itactics_show_meta  = count( $itactics_components ) > 0;

	if ( $itactics_show_title ) {
		?><div class="post_header entry-header"><?php
			// Categories
			if ( apply_filters( 'itactics_filter_show_blog_categories', $itactics_show_meta && in_array( 'categories', $itactics_components ), array( 'categories' ), 'classic' ) ) {
				do_action( 'itactics_action_before_post_category' );
				?><div class="post_category"><?php
					itactics_show_post_meta( apply_filters(
														'itactics_filter_post_meta_args',
														array(
															'components' => 'categories',
															'seo'        => false,
															'echo'       => true,
															),
														'hover_' . $itactics_hover, 1
														)
										);
				?></div><?php
				$itactics_components = itactics_array_delete_by_value( $itactics_components, 'categories' );
				do_action( 'itactics_action_after_post_category' );
			}
			// Post title
			if ( apply_filters( 'itactics_filter_show_blog_title', true, 'classic' ) ) {
				do_action( 'itactics_action_before_post_title' );
				if ( empty( $itactics_template_args['no_links'] ) ) {
					the_title( sprintf( '<h3 class="post_title entry-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h3>' );
				} else {
					the_title( '<h3 class="post_title entry-title">', '</h3>' );
				}
				do_action( 'itactics_action_after_post_title' );
			}
		?></div><?php
	}
	
	// Post meta
	if ( apply_filters( 'itactics_filter_show_blog_meta', $itactics_show_meta, $itactics_components, 'classic' ) ) {
		if ( count( $itactics_components ) > 0 ) {
			do_action( 'itactics_action_before_post_meta' );
			itactics_show_post_meta(
				apply_filters(
					'itactics_filter_post_meta_args', array(
						'components' => join( ',', $itactics_components ),
						'seo'        => false,
						'echo'       => true,
						'author_avatar' => false,
					), $itactics_blog_style[0], $itactics_columns
				)
			);
			do_action( 'itactics_action_after_post_meta' );
		}
	}

	// Post content
	ob_start();
	if ( apply_filters( 'itactics_filter_show_blog_excerpt', ( ! isset( $itactics_template_args['hide_excerpt'] ) || (int)$itactics_template_args['hide_excerpt'] == 0 ) && (int)itactics_get_theme_option( 'excerpt_length' ) > 0, 'classic' ) ) {
		itactics_show_post_content( $itactics_template_args, '<div class="post_content_inner">', '</div>' );
	}
	$itactics_content = ob_get_contents();
	ob_end_clean();

	itactics_show_layout( $itactics_content, '<div class="post_content entry-content">', '</div>' );

		
	// More button
	if ( apply_filters( 'itactics_filter_show_blog_readmore', ! $itactics_show_title || ! empty( $itactics_template_args['more_button'] ), 'classic' ) ) {
		if ( empty( $itactics_template_args['no_links'] ) ) {
			do_action( 'itactics_action_before_post_readmore' );
			itactics_show_post_more_link( $itactics_template_args, '<p>', '</p>' );
			do_action( 'itactics_action_after_post_readmore' );
		}
	}

	?>

</article></div><?php
// Need opening PHP-tag above, because <div> is a inline-block element (used as column)!
