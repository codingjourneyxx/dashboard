<?php
/**
 * The template to display default site footer
 *
 * @package ITACTICS
 * @since ITACTICS 1.0.10
 */

$itactics_footer_id = itactics_get_custom_footer_id();
$itactics_footer_meta = itactics_get_custom_layout_meta( $itactics_footer_id );
if ( ! empty( $itactics_footer_meta['margin'] ) ) {
	itactics_add_inline_css( sprintf( '.page_content_wrap{padding-bottom:%s}', esc_attr( itactics_prepare_css_value( $itactics_footer_meta['margin'] ) ) ) );
}
?>
<footer class="footer_wrap footer_custom footer_custom_<?php echo esc_attr( $itactics_footer_id ); ?> footer_custom_<?php echo esc_attr( sanitize_title( get_the_title( $itactics_footer_id ) ) ); ?>">
	<?php
	// Custom footer's layout
	do_action( 'itactics_action_show_layout', $itactics_footer_id );
	?>
</footer>