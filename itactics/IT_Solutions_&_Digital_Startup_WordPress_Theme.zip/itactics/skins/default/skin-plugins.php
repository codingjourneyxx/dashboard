<?php
/**
 * Required plugins
 *
 * @package ITACTICS
 * @since ITACTICS 1.76.0
 */

// THEME-SUPPORTED PLUGINS
// If plugin not need - remove its settings from next array
//----------------------------------------------------------
if ( ! function_exists( 'itactics_skin_required_plugins' ) ) {
	add_action( 'after_setup_theme', 'itactics_skin_required_plugins', -1 );
	function itactics_skin_required_plugins() {
		$itactics_theme_required_plugins_groups = array(
			'core'          => esc_html__( 'Core', 'itactics' ),
			'page_builders' => esc_html__( 'Page Builders', 'itactics' ),
			'ecommerce'     => esc_html__( 'E-Commerce & Donations', 'itactics' ),
			'socials'       => esc_html__( 'Socials and Communities', 'itactics' ),
			'events'        => esc_html__( 'Events and Appointments', 'itactics' ),
			'content'       => esc_html__( 'Content', 'itactics' ),
			'other'         => esc_html__( 'Other', 'itactics' ),
		);
		$itactics_theme_required_plugins        = array(
	// Core
	'trx_addons'                 => array(
		'title'       => esc_html__( 'ThemeREX Addons', 'itactics' ),
		'description' => esc_html__( "Will allow you to install recommended plugins, demo content, and improve the theme's functionality overall with multiple theme options", 'itactics' ),
		'required'    => true, // Check this plugin in the list on load Theme Dashboard
		'logo'        => 'trx_addons.png',
		'group'       => $itactics_theme_required_plugins_groups['core'],
	),
	// Page Builders
	'elementor'                  => array(
		'title'       => esc_html__( 'Elementor', 'itactics' ),
		'description' => esc_html__( "Is a beautiful PageBuilder, even the free version of which allows you to create great pages using a variety of modules.", 'itactics' ),
		'required'    => false, // Leave this plugin unchecked on load Theme Dashboard
		'logo'        => 'elementor.png',
		'group'       => $itactics_theme_required_plugins_groups['page_builders'],
	),
	'gutenberg'                  => array(
		'title'       => esc_html__( 'Gutenberg', 'itactics' ),
		'description' => esc_html__( "It's a posts editor coming in place of the classic TinyMCE. Can be installed and used in parallel with Elementor", 'itactics' ),
		'required'    => false,
		'install'     => false, // Do not offer installation of the plugin in the Theme Dashboard and TGMPA
		'logo'        => 'gutenberg.png',
		'group'       => $itactics_theme_required_plugins_groups['page_builders'],
	),
	// Content
	'sitepress-multilingual-cms' => array(
		'title'       => esc_html__( 'WPML - Sitepress Multilingual CMS', 'itactics' ),
		'description' => esc_html__( "Allows you to make your website multilingual", 'itactics' ),
		'required'    => false,
		'install'     => false, // Do not offer installation of the plugin in the Theme Dashboard and TGMPA
		'logo'        => 'sitepress-multilingual-cms.png',
		'group'       => $itactics_theme_required_plugins_groups['content'],
	),
	'metform'             => array(
		'title'       => esc_html__( 'MetForm', 'itactics' ),
		'description' => esc_html__( "Contact Form, Survey, Quiz, & Custom Form Builder for Elementor", 'itactics' ),
		'required'    => false,
		'logo'        => 'metform.png',
		'group'       => $itactics_theme_required_plugins_groups['content'],
	),
	// Other
	'trx_updater'                => array(
		'title'       => esc_html__( 'ThemeREX Updater', 'itactics' ),
		'description' => esc_html__( "Update theme and theme-specific plugins from developer's upgrade server.", 'itactics' ),
		'required'    => false,
		'logo'        => 'trx_updater.png',
		'group'       => $itactics_theme_required_plugins_groups['other'],
	)
		);

		if ( ITACTICS_THEME_FREE ) {
			unset( $itactics_theme_required_plugins['sitepress-multilingual-cms'] );
			unset( $itactics_theme_required_plugins['trx_updater'] );
		}

		// Add plugins list to the global storage
		itactics_storage_set( 'required_plugins', $itactics_theme_required_plugins );
	}
}
