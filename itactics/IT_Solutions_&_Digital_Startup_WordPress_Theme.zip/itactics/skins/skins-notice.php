<?php
/**
 * The template to display Admin notices
 *
 * @package ITACTICS
 * @since ITACTICS 1.0.64
 */

$itactics_skins_url  = get_admin_url( null, 'admin.php?page=trx_addons_theme_panel#trx_addons_theme_panel_section_skins' );
$itactics_skins_args = get_query_var( 'itactics_skins_notice_args' );
?>
<div class="itactics_admin_notice itactics_skins_notice notice notice-info is-dismissible" data-notice="skins">
	<?php
	// Theme image
	$itactics_theme_img = itactics_get_file_url( 'screenshot.jpg' );
	if ( '' != $itactics_theme_img ) {
		?>
		<div class="itactics_notice_image"><img src="<?php echo esc_url( $itactics_theme_img ); ?>" alt="<?php esc_attr_e( 'Theme screenshot', 'itactics' ); ?>"></div>
		<?php
	}

	// Title
	?>
	<h3 class="itactics_notice_title">
		<?php esc_html_e( 'New skins are available', 'itactics' ); ?>
	</h3>
	<?php

	// Description
	$itactics_total      = $itactics_skins_args['update'];	// Store value to the separate variable to avoid warnings from ThemeCheck plugin!
	$itactics_skins_msg  = $itactics_total > 0
							// Translators: Add new skins number
							? '<strong>' . sprintf( _n( '%d new version', '%d new versions', $itactics_total, 'itactics' ), $itactics_total ) . '</strong>'
							: '';
	$itactics_total      = $itactics_skins_args['free'];
	$itactics_skins_msg .= $itactics_total > 0
							? ( ! empty( $itactics_skins_msg ) ? ' ' . esc_html__( 'and', 'itactics' ) . ' ' : '' )
								// Translators: Add new skins number
								. '<strong>' . sprintf( _n( '%d free skin', '%d free skins', $itactics_total, 'itactics' ), $itactics_total ) . '</strong>'
							: '';
	$itactics_total      = $itactics_skins_args['pay'];
	$itactics_skins_msg .= $itactics_skins_args['pay'] > 0
							? ( ! empty( $itactics_skins_msg ) ? ' ' . esc_html__( 'and', 'itactics' ) . ' ' : '' )
								// Translators: Add new skins number
								. '<strong>' . sprintf( _n( '%d paid skin', '%d paid skins', $itactics_total, 'itactics' ), $itactics_total ) . '</strong>'
							: '';
	?>
	<div class="itactics_notice_text">
		<p>
			<?php
			// Translators: Add new skins info
			echo wp_kses_data( sprintf( __( "We are pleased to announce that %s are available for your theme", 'itactics' ), $itactics_skins_msg ) );
			?>
		</p>
	</div>
	<?php

	// Buttons
	?>
	<div class="itactics_notice_buttons">
		<?php
		// Link to the theme dashboard page
		?>
		<a href="<?php echo esc_url( $itactics_skins_url ); ?>" class="button button-primary"><i class="dashicons dashicons-update"></i> 
			<?php
			// Translators: Add theme name
			esc_html_e( 'Go to Skins manager', 'itactics' );
			?>
		</a>
	</div>
</div>
