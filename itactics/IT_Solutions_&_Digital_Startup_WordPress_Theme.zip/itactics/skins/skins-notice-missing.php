<?php
/**
 * The template to display Admin notices
 *
 * @package ITACTICS
 * @since ITACTICS 1.98.0
 */

$itactics_skins_url   = get_admin_url( null, 'admin.php?page=trx_addons_theme_panel#trx_addons_theme_panel_section_skins' );
$itactics_active_skin = itactics_skins_get_active_skin_name();
?>
<div class="itactics_admin_notice itactics_skins_notice notice notice-error">
	<?php
	// Theme image
	$itactics_theme_img = itactics_get_file_url( 'screenshot.jpg' );
	if ( '' != $itactics_theme_img ) {
		?>
		<div class="itactics_notice_image"><img src="<?php echo esc_url( $itactics_theme_img ); ?>" alt="<?php esc_attr_e( 'Theme screenshot', 'itactics' ); ?>"></div>
		<?php
	}

	// Title
	?>
	<h3 class="itactics_notice_title">
		<?php esc_html_e( 'Active skin is missing!', 'itactics' ); ?>
	</h3>
	<div class="itactics_notice_text">
		<p>
			<?php
			// Translators: Add a current skin name to the message
			echo wp_kses_data( sprintf( __( "Your active skin <b>'%s'</b> is missing. Usually this happens when the theme is updated directly through the server or FTP.", 'itactics' ), ucfirst( $itactics_active_skin ) ) );
			?>
		</p>
		<p>
			<?php
			echo wp_kses_data( __( "Please use only <b>'ThemeREX Updater v.1.6.0+'</b> plugin for your future updates.", 'itactics' ) );
			?>
		</p>
		<p>
			<?php
			echo wp_kses_data( __( "But no worries! You can re-download the skin via 'Skins Manager' ( Theme Panel - Theme Dashboard - Skins ).", 'itactics' ) );
			?>
		</p>
	</div>
	<?php

	// Buttons
	?>
	<div class="itactics_notice_buttons">
		<?php
		// Link to the theme dashboard page
		?>
		<a href="<?php echo esc_url( $itactics_skins_url ); ?>" class="button button-primary"><i class="dashicons dashicons-update"></i> 
			<?php
			// Translators: Add theme name
			esc_html_e( 'Go to Skins manager', 'itactics' );
			?>
		</a>
	</div>
</div>
