<?php

return array(
	'default-bg-color' => '#fff',
	'default-line-color' => 'var( --vamtam-accent-color-7-rgb )',

	'vertical-padding' => '30px',

	'no-border-link' => 'none',

	'border-radius' => '0px',
	'border-radius-oval' => '0px',
	'border-radius-small' => '0px',
);
