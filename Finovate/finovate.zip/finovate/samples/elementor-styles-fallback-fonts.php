<?php

return 'https://fonts.googleapis.com/css?family=';
