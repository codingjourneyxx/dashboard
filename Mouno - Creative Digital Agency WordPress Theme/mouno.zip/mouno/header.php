<?php
/**
 * @package Case-Themes
 */
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <link rel="profile" href="//gmpg.org/xfn/11">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
    <?php 
        wp_body_open(); 
        $smooth_scroll = mouno()->get_opt('smooth_scroll', 'off'); 
    ?>
    <div id="pxl-wrapper" class="pxl-wrapper">
    <?php mouno()->page->get_site_loader();
    if($smooth_scroll === 'on') : ?>
        <div id="smooth-wrapper">
            <div id="smooth-content">
    <?php endif; ?>
        <?php 
            mouno()->header->getHeader();
            if((!is_single() && !is_404() && !is_search())) {
                mouno()->page->get_page_title();
            }elseif(!is_404()) {
                mouno()->page->get_post_title();
            }
        ?>
        <div id="pxl-main">
