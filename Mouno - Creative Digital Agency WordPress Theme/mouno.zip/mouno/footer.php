<?php
/**
 * @package Case-Themes
 */
$smooth_scroll = mouno()->get_opt('smooth_scroll', 'off');  
// Back To Top
$back_totop_on = mouno()->get_theme_opt('back_totop_on', true);
?>
		</div><!-- #main -->
		<?php mouno()->footer->getFooter(); ?>
		<?php if($smooth_scroll === 'on') : ?>
			</div>
				</div>
		<?php endif; 
		if (isset($back_totop_on) && $back_totop_on == true) : ?>
			<a class="back-to-top-button" href="#">
				<i class="flaticon-arrow-up"></i>
			</a>
		<?php endif; 
		do_action( 'pxl_anchor_target') ?>
		</div><!-- #wapper -->
	<?php wp_footer(); ?>
	</body>
</html>
