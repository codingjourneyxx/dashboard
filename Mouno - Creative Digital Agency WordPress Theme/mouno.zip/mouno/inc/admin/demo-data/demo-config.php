<?php

$uri = get_template_directory_uri() . '/inc/admin/demo-data/demo-imgs/';
// Demos
$demos = array(
	// Elementor Demos
	'mouno' => array(
		'title'       => 'Mouno',	
		'description' => '',
		'screenshot'  => $uri . 'mouno.jpg',
		'preview'     => 'https://demo.casethemes.net/mouno/',
	),
);