<?php if(!function_exists('mouno_configs')){
    function mouno_configs($value){
        $configs = [
            'theme_colors' => [
                'primary'   => [
                    'title' => esc_html__('Primary', 'mouno'), 
                    'value' => mouno()->get_opt('primary_color', '#FF3D00')
                ],
                'secondary'   => [
                    'title' => esc_html__('Secondary', 'mouno'), 
                    'value' => mouno()->get_opt('secondary_color', '#010101')
                ],
                'third'   => [
                    'title' => esc_html__('Third', 'mouno'), 
                    'value' => mouno()->get_opt('third_color', '#00c5fe')
                ],
                'body-bg'   => [
                    'title' => esc_html__('Body Background Color', 'mouno'), 
                    'value' => mouno()->get_page_opt('body_bg_color', '#fff')
                ],
            ],
            'link' => [
                'color' => mouno()->get_opt('link_color', ['regular' => '#1F1F1F'])['regular'],
                'color-hover'   => mouno()->get_opt('link_color', ['hover' => '#F14F44'])['hover'],
                'color-active'  => mouno()->get_opt('link_color', ['active' => '#F14F44'])['active'],
            ],
            'gradient' => [
                'color-from' => mouno()->get_opt('gradient_color', ['from' => '#6000ff'])['from'],
                'color-to' => mouno()->get_opt('gradient_color', ['to' => '#fe0054'])['to'],
            ],
            'theme_typography' => [
                'primary' => [
                    'title' => esc_html__('Primary', 'mouno'),
                    'value' => mouno()->get_opt('primary_font', 'Kanit')
                ],
                'secondary' => [
                    'title' => esc_html__('Secondary', 'mouno'),
                    'value' => mouno()->get_opt('secondary_font', 'Montserrat')
                ],
                'heading' => [
                    'title' => esc_html__('Heading', 'mouno'),
                    'value' => mouno()->get_opt('heading_font', 'Sora')
                ],
            ]
        ];
        return $configs[$value];
    }
}
if(!function_exists('mouno_inline_styles')) {
    function mouno_inline_styles() {  
        
        $theme_colors      = mouno_configs('theme_colors');
        $link_color        = mouno_configs('link');
        $gradient_color    = mouno_configs('gradient');
        $theme_typography  = mouno_configs('theme_typography');
        ob_start();
        echo ':root{';
            
            foreach ($theme_colors as $color => $value) {
                printf('--%1$s-color: %2$s;', str_replace('#', '',$color),  $value['value']);
            }
            foreach ($link_color as $color => $value) {
                printf('--link-%1$s: %2$s;', $color, $value);
            }
            foreach ($gradient_color as $color => $value) {
                printf('--gradient-%1$s: %2$s;', $color, $value);
            }
            foreach ($theme_typography as $font => $value) {
                $font_family = is_array($value['value']) ? $value['value']['font-family'] : $value['value'];
                printf('--%1$s-font: %2$s;', str_replace('#', '',$font),  $font_family);
            }
        echo '}';

        return ob_get_clean();
         
    }
}
 