<?php
/**
 * Helper functions for the theme
 *
 * @package Case-Themes
 */
  

function mouno_html($html){
    return $html;
}

// Google Fonts
function mouno_fonts_url() {
    $fonts_url = '';
    $fonts     = array();
    $subsets   = 'latin,latin-ext';   

    if ( 'off' !== _x( 'on', 'Montserrat font: on or off', 'mouno' ) ) {
        $fonts[] = 'Montserrat:wght@100..900&display=swap';
    }

    if ( 'off' !== _x( 'on', 'Kanit font: on or off', 'mouno' ) ) {
        $fonts[] = 'Kanit:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap';
    }

    if ( 'off' !== _x( 'on', 'Audiowide font: on or off', 'mouno' ) ) {
        $fonts[] = 'Audiowide:wght@100..800&display=swap';
    }

    if ( 'off' !== _x( 'on', 'Sora font: on or off', 'mouno' ) ) {
        $fonts[] = 'Sora:wght@100..800&display=swap';
    }

    if ( 'off' !== _x( 'on', 'Inter font: on or off', 'mouno' ) ) {
        $fonts[] = 'Inter:ital,opsz,wght@0,14..32,100..900;1,14..32,100..900&display=swap';
    }

    if ( 'off' !== _x( 'on', 'Plus Jakarta Sans font: on or off', 'mouno' ) ) {
        $fonts[] = 'Plus+Jakarta+Sans:ital,wght@0,200..800;1,200..800&display=swap';
    }

    if ( 'off' !== _x( 'on', 'Teko font: on or off', 'mouno' ) ) {
        $fonts[] = 'Teko:wght@300..700&display=swap';
    }

    if ( 'off' !== _x( 'on', 'Playfair Display font: on or off', 'mouno' ) ) {
        $fonts[] = 'Playfair+Display:ital,wght@0,400..900;1,400..900&display=swap';
    }

    if ( 'off' !== _x( 'on', 'Roboto font: on or off', 'mouno' ) ) {
        $fonts[] = 'Roboto:ital,wght@0,100..900;1,100..900&display=swap';
    }

    if ( 'off' !== _x( 'on', 'Public Sans font: on or off', 'mouno' ) ) {
        $fonts[] = 'Public+Sans:ital,wght@0,100..900;1,100..900&display=swap';
    }

    
    if ( $fonts ) {
        $fonts_url = add_query_arg( array(
            'family' => implode( '&family=', $fonts ),
            'subset' => urlencode( $subsets ),
        ), '//fonts.googleapis.com/css2?' );
    }
    return $fonts_url;
}


// Get page ID by Slug
function mouno_get_id_by_slug($slug, $post_type){
    $content = get_page_by_path($slug, OBJECT, $post_type);
    $id = $content->ID;
    return $id;
}

/**
 * Show content by slug
 **/
function mouno_content_by_slug($slug, $post_type){
    $content = mouno_get_content_by_slug($slug, $post_type);

    $id = mouno_get_id_by_slug($slug, $post_type);
    echo apply_filters('the_content',  $content);
}

/**
 * Get content by slug
 **/
function mouno_get_content_by_slug($slug, $post_type){
    $content = get_posts(
        array(
            'name'      => $slug,
            'post_type' => $post_type
        )
    );
    if(!empty($content))
        return $content[0]->post_content;
    else
        return;
}

 
/**
 * Custom Comment List
 */
function mouno_comment_list( $comment, $args, $depth ) {
	if ( 'div' === $args['style'] ) {
        $tag       = 'div';
        $add_below = 'comment';
    } else {
        $tag       = 'li';
        $add_below = 'div-comment';
    }
	?>
    <<?php echo ''.$tag ?> <?php comment_class( empty( $args['has_children'] ) ? '' : 'parent' ) ?> id="comment-<?php comment_ID() ?>">
    <?php if ( 'div' != $args['style'] ) : ?>
        <div id="div-comment-<?php comment_ID() ?>" class="comment-box">
		<?php endif; ?>
		    <div class="comment-inner">
		        <?php if ($args['avatar_size'] != 0) : ?> 
                    <div class="comment-image">
                        <?php echo get_avatar($comment, 90); ?>
                    </div>
                <?php endif; ?>
		        <div class="comment-content">
                    <div class="comment-header">
                        <div class="comment-user">
                            <?php printf( '%s', get_comment_author_link() ); ?>
                        </div>
                        <span class="comment-date">
                            <?php echo get_comment_date(); ?>
                        </span>
                    </div>
                    <div class="comment-text"><?php comment_text(); ?></div>
                    <div class="comment-reply">
                        <?php comment_reply_link( array_merge( $args, array(
                            'add_below' => $add_below,
                            'depth'     => $depth,
                            'max_depth' => $args['max_depth']
                        ) ) ); ?>
                    </div>
		        </div>
		    </div>
		<?php if ( 'div' != $args['style'] ) : ?>
        </div>
	<?php endif;
}

/**
 * Paginate Links
 */
function mouno_ajax_paginate_links($link){
    $parts = parse_url($link);
    if( !isset($parts['query']) ) return $link;
    parse_str($parts['query'], $query);
    if(isset($query['page']) && !empty($query['page'])){
        return '#' . $query['page'];
    }
    else{
        return '#1';
    }
}


/**
 * RGB Color
 */
function mouno_hex_rgb($color) {
 
    $default = '0,0,0';
 
    //Return default if no color provided
    if(empty($color))
        return $default; 
 
    //Sanitize $color if "#" is provided 
    if ($color[0] == '#' ) {
        $color = substr( $color, 1 );
    }

    //Check if color has 6 or 3 characters and get values
    if (strlen($color) == 6) {
        $hex = array( $color[0] . $color[1], $color[2] . $color[3], $color[4] . $color[5] );
    } elseif ( strlen( $color ) == 3 ) {
        $hex = array( $color[0] . $color[0], $color[1] . $color[1], $color[2] . $color[2] );
    } else {
        return $default;
    }

    //Convert hexadec to rgb
    $rgb =  array_map('hexdec', $hex);

    $output = implode(",",$rgb);

    //Return rgb(a) color string
    return $output;
}



/**
 * Search Form
 */
function mouno_header_mobile_search_form() { 
    $search_mobile = mouno()->get_theme_opt( 'search_mobile', false );
    $search_placeholder_mobile = mouno()->get_theme_opt( 'search_placeholder_mobile' );
    if($search_mobile) : ?>
    <div class="pxl-header-search pxl-hide-xl">
        <form role="search" method="get" action="<?php echo esc_url(home_url( '/' )); ?>">
            <input type="text" placeholder="<?php if(!empty($search_placeholder_mobile)) { echo esc_attr($search_placeholder_mobile); } else { esc_attr_e('Search...', 'mouno'); } ?>" name="s" class="search-field" />
            <button type="submit" class="search-submit"><i class="caseicon-search"></i></button>
        </form>
    </div>
<?php endif; }

/* Highlight Shortcode  */
if(function_exists( 'pxl_register_shortcode' )) {
    function mouno_text_highlight_shortcode( $atts = array() ) {
        extract(shortcode_atts(array(
         'text' => '',
        ), $atts));

        ob_start();
        if(!empty($text)) : ?>
            <span class="pxl-text-highlight">
                <?php echo wp_kses_post($text); ?>
            </span>
        <?php  endif;
        $output = ob_get_clean();

        return $output;
    }
    pxl_register_shortcode('highlight', 'mouno_text_highlight_shortcode');
}

// Text Hidden Shortcode
if(function_exists( 'pxl_register_shortcode' )) {
    function mouno_text_hidden_shortcode( $atts = array() ) {
        extract(shortcode_atts(array(
         'text' => '',
        ), $atts));

        ob_start();
        if(!empty($text)) : ?>
            <span class="pxl-text-hidden">
                <?php echo wp_kses_post($text); ?>
            </span>
        <?php  endif;
        $output = ob_get_clean();

        return $output;
    }
    pxl_register_shortcode('hidden_text', 'mouno_text_hidden_shortcode');
}

if(function_exists( 'pxl_register_shortcode' )) {
    function mouno_image_highlight_shortcode( $atts = array() ) {
        extract(shortcode_atts(array(
         'img_id' => '',
        ), $atts));

        global $wp_filesystem;

        ob_start();
        if(!empty($img_id)) : 
            $img  = pxl_get_image_by_size( array(
                'attach_id'  => $img_id,
                'thumb_size' => 'full',
            ));
            if((pathinfo($img['url'], PATHINFO_EXTENSION) === 'svg')) {
                $img_urls = explode('uploads', $img['url']);
                $upload_dir = wp_upload_dir();
                $img_path = $upload_dir['basedir']. $img_urls[1] ;
                $img_content = $wp_filesystem->get_contents( $img_path );
                pxl_print_html($img_content);
            }else{
                pxl_print_html('<span class="pxl-image-highlight" style="background-image: url(' . esc_url($thumbnail_url) . ');"></span>');
            }
        ?>
        <?php 
        $output = ob_get_clean();
        endif;

        return $output;
    }
    pxl_register_shortcode('highlight_image', 'mouno_image_highlight_shortcode');
}

/**
 * Custom Widget Archive - Count
 */
add_filter('get_archives_link', 'mouno_wg_archive_count');
function mouno_wg_archive_count($links) {
    $dir = '';
    $links = str_replace('</a>&nbsp;(', ' <span class="pxl-count '.$dir.'">', $links);
    $links = str_replace(')', '</span></a>', $links);
    return $links;
}

/**
 * Custom Widget Product Categories 
 */
add_filter('wp_list_categories', 'mouno_wc_cat_count_span');
function mouno_wc_cat_count_span($links) {
    $dir = '';
    $links = str_replace('</a> <span class="count">(', ' <span class="pxl-count '.$dir.'">', $links);
    $links = str_replace(')</span>', '</span></a>', $links);
    return $links;
}

/**
 * Get mega menu builder ID
 */
function mouno_get_mega_menu_builder_id(){
    $mn_id = [];
    $menus = get_terms( 'nav_menu', array( 'hide_empty' => false ) );
    if ( is_array( $menus ) && ! empty( $menus ) ) {
        foreach ( $menus as $menu ) {
            if ( is_object( $menu )){
                $menu_obj = get_term( $menu->term_id, 'nav_menu' );
                $menu = wp_get_nav_menu_object( $menu_obj ) ;
                $menu_items = wp_get_nav_menu_items( $menu->term_id, array( 'update_post_term_cache' => false ) );
                foreach ($menu_items as $menu_item) {
                    if( !empty($menu_item->pxl_megaprofile)){
                        $mn_id[] = (int)$menu_item->pxl_megaprofile;
                    }
                }  
            }
        }
    }
    return $mn_id;
}

/**
 * Get page popup builder ID
 */
function mouno_get_page_popup_builder_id(){
    $pp_id = [];
    $page_popup = get_terms( 'nav_menu', array( 'hide_empty' => false ) );
    if ( is_array( $page_popup ) && ! empty( $page_popup ) ) {
        foreach ( $page_popup as $page ) {
            if ( is_object( $page )){
                $page_obj = get_term( $page->term_id, 'nav_menu' );
                $page = wp_get_nav_menu_object( $page_obj ) ;
                $page_items = wp_get_nav_menu_items( $page->term_id, array( 'update_post_term_cache' => false ) );
                foreach ($page_items as $page_item) {
                    if( !empty($page_item->pxl_page_popup)){
                        $pp_id[] = (int)$page_item->pxl_page_popup;
                    }
                }  
            }
        }
    }
    return $pp_id;
}

// Mouse Move Animation 
function mouno_mouse_move_animation() { 
    $mouse_move_animation = mouno()->get_theme_opt('mouse_move_animation', 'off'); 
    if($mouse_move_animation == 'on') {
        wp_enqueue_script( 'mouno-cursor', get_template_directory_uri() . '/assets/js/libs/cursor.js', array( 'jquery' ), '1.0.0', true ); ?>  
        <div class="pxl-cursor pxl-js-cursor">
            <div class="pxl-cursor-wrapper">
                <div class="pxl-cursor--follower pxl-js-follower"></div>
                <div class="pxl-cursor--label pxl-js-label"></div>
                <div class="pxl-cursor--drap pxl-js-drap"></div>
                <div class="pxl-cursor--icon pxl-js-icon"></div>
            </div>
        </div>
    <?php }
}

// Cookie Policy
function mouno_cookie_policy() {
    $cookie_policy = mouno()->get_theme_opt('cookie_policy', 'hide');
    $cookie_policy_description = mouno()->get_theme_opt('cookie_policy_description');
    $cookie_policy_btntext = mouno()->get_theme_opt('cookie_policy_btntext');
    $cookie_policy_link = get_permalink(mouno()->get_theme_opt('cookie_policy_link')); 
    wp_enqueue_script('pxl-cookie'); ?>
    <?php if($cookie_policy == 'show' && !empty($cookie_policy_description)) : ?>
        <div class="pxl-cookie-policy">
            <div class="pxl-item--icon pxl-mr-8"><img src="<?php echo esc_url(get_template_directory_uri().'/assets/img/cookie.png'); ?>" alt="<?php echo esc_attr($cookie_policy_btntext); ?>" /></div>
            <div class="pxl-item--description">
                <?php echo esc_attr($cookie_policy_description); ?>
                <a class="pxl-item--link" href="<?php echo esc_url( $cookie_policy_link ); ?>" target="_blank"><?php echo esc_html($cookie_policy_btntext); ?></a>
            </div>
            <div class="pxl-item--close pxl-close"></div>
        </div>
    <?php endif; ?>
<?php }     

// User custom fields.
add_action( 'show_user_profile', 'mouno_user_fields' );
add_action( 'edit_user_profile', 'mouno_user_fields' );
function mouno_user_fields($user){
    $user_name = get_user_meta($user->ID, 'user_name', true);
    $user_position = get_user_meta($user->ID, 'user_position', true);

    $user_facebook = get_user_meta($user->ID, 'user_facebook', true);
    $user_twitter = get_user_meta($user->ID, 'user_twitter', true);
    $user_instagram = get_user_meta($user->ID, 'user_instagram', true);
    $user_linkedin = get_user_meta($user->ID, 'user_linkedin', true);
    $user_youtube = get_user_meta($user->ID, 'user_youtube', true);

    ?>
    <h3><?php esc_html_e('Theme Custom', 'mouno'); ?></h3>
    <table class="form-table">
        <tr>
            <th><label for="user_name"><?php esc_html_e('Author Name', 'mouno'); ?></label></th>
            <td>
                <input id="user_name" name="user_name" type="text" value="<?php echo esc_attr(isset($user_name) ? $user_name : ''); ?>" />
            </td>
        </tr>

        <tr>
            <th><label for="user_position"><?php esc_html_e('Author Position', 'mouno'); ?></label></th>
            <td>
                <input id="user_position" name="user_position" type="text" value="<?php echo esc_attr(isset($user_position) ? $user_position : ''); ?>" />
            </td>
        </tr>

        <tr>
            <th><label for="user_facebook"><?php esc_html_e('Facebook', 'mouno'); ?></label></th>
            <td>
                <input id="user_facebook" name="user_facebook" type="text" value="<?php echo esc_attr(isset($user_facebook) ? $user_facebook : ''); ?>" />
            </td>
        </tr>
        <tr>
            <th><label for="user_twitter"><?php esc_html_e('Twitter', 'mouno'); ?></label></th>
            <td>
                <input id="user_twitter" name="user_twitter" type="text" value="<?php echo esc_attr(isset($user_twitter) ? $user_twitter : ''); ?>" />
            </td>
        </tr>
        <tr>
            <th><label for="user_instagram"><?php esc_html_e('Instagram', 'mouno'); ?></label></th>
            <td>
                <input id="user_instagram" name="user_instagram" type="text" value="<?php echo esc_attr(isset($user_instagram) ? $user_instagram : ''); ?>" />
            </td>
        </tr>
        <tr>
            <th><label for="user_linkedin"><?php esc_html_e('Linkedin', 'mouno'); ?></label></th>
            <td>
                <input id="user_linkedin" name="user_linkedin" type="text" value="<?php echo esc_attr(isset($user_linkedin) ? $user_linkedin : ''); ?>" />
            </td>
        </tr>
        <tr>
            <th><label for="user_youtube"><?php esc_html_e('Youtube', 'mouno'); ?></label></th>
            <td>
                <input id="user_youtube" name="user_youtube" type="text" value="<?php echo esc_attr(isset($user_youtube) ? $user_youtube : ''); ?>" />
            </td>
        </tr>
    </table>
    <?php
}

add_action( 'personal_options_update', 'mouno_save_user_custom_fields' );
add_action( 'edit_user_profile_update', 'mouno_save_user_custom_fields' );
function mouno_save_user_custom_fields( $user_id )
{
    if ( !current_user_can( 'edit_user', $user_id ) )
        return false;

    if(isset($_POST['user_name']))
        update_user_meta( $user_id, 'user_name', $_POST['user_name'] );

    if(isset($_POST['user_position']))
        update_user_meta( $user_id, 'user_position', $_POST['user_position'] );

    if(isset($_POST['user_facebook']))
        update_user_meta( $user_id, 'user_facebook', $_POST['user_facebook'] );
    if(isset($_POST['user_twitter']))
        update_user_meta( $user_id, 'user_twitter', $_POST['user_twitter'] );
    if(isset($_POST['user_instagram']))
        update_user_meta( $user_id, 'user_instagram', $_POST['user_instagram'] );
    if(isset($_POST['user_linkedin']))
        update_user_meta( $user_id, 'user_linkedin', $_POST['user_linkedin'] );
    if(isset($_POST['user_youtube']))
        update_user_meta( $user_id, 'user_youtube', $_POST['user_youtube'] );
}


// Get Image By Size
if(!function_exists('mouno_get_image_by_size')){
    function mouno_get_image_by_size( $params = [], $post_id = null ) {
        $params = array_merge([
            'img_id' => '',
            'img_dimension' => 'thumbnail',
            'attr' => [],
        ], $params );        
        $params['img_id'] = !is_null($post_id) ? get_post_thumbnail_id($post_id) : ($params['img_id']  ?? '');
        // $thumbnail = '<img class="pxl-image-default" src="' . esc_url( \Elementor\Utils::get_placeholder_image_src() ) . '" alt="Default Image">';
        $thumbnail = '';
        if ( empty($params['img_id']) ) 
            return $thumbnail;
        
        $img_id = apply_filters( 'pxl_object_id', $params['img_id'] );
        $img_dimension = isset($params['img_dimension']) ? $params['img_dimension'] : 'thumbnail';
        $img_attr = isset($params['attr']) ? $params['attr'] : [];
        $img_attr['class'] = isset($img_attr['class']) ? $img_attr['class'] : '';
        $img_attr['alt']   = isset($img_attr['alt']) ? $img_attr['alt'] : trim( wp_strip_all_tags(get_post_meta( $img_id, '_wp_attachment_image_alt', true )) );
        $img_attr['loading'] = 'lazy';
        global $_wp_additional_image_sizes;

        $post = get_post( $post_id );
        if(!empty($post)) {
            $post_title = trim(wp_strip_all_tags( $post->post_title, true));
            $post_excerpt = trim(wp_strip_all_tags( $post->post_excerpt, true));
            if(empty(trim($img_attr['alt']))) {
                $img_attr['alt'] = !empty($post_excerpt) ? $post_excerpt : $post_title;
            }
        }

        if ( !is_array($img_dimension) ) {
            $img_attr['class'] .= ' attachment-'.$img_dimension;
            $thumbnail = wp_get_attachment_image( $img_id, $img_dimension, false, $img_attr );
        }else {
            $img_w = $img_dimension['width'];
            $img_h = $img_dimension['height'];

            $img_crop = pxl_resize( $img_id, null, $img_w, $img_h, true );
            if (!isset($img_crop['url'])) return  ;
            $img_attr = pxl_stringify_attributes(
                array_merge(
                    [
                        'src' => $img_crop['url'],
                        'width' => $img_w,
                        'height' => $img_h,
                    ],
                    $img_attr,
                )
            );
            $thumbnail = '<img ' . $img_attr . ' />';
        } 
        return $thumbnail;
    }
}