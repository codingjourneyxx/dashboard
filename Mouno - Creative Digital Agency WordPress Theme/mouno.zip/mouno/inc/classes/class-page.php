<?php

if (!class_exists('Mouno_Page')) {

    class Mouno_Page
    {
        public function get_site_loader(){

            $site_loader = mouno()->get_theme_opt( 'site_loader', 'off' );
            if($site_loader == 'on') : 
                $site_loader_style = mouno()->get_theme_opt( 'site_loader_style', 'loader-default' );
            ?>
                <div id="preloader" class="preloader <?php echo esc_attr($site_loader_style); ?>">
                    <?php if($site_loader_style === 'loader-style1') : ?>
                        <div class="line"></div>
                        <div class="split top"></div>
                        <div class="split bottom"></div>
                    <?php else: ?>
                        <div class="pxl-loader-spinner">
                            <div class="pxl-loader-bounce1"></div>
                            <div class="pxl-loader-bounce2"></div>
                            <div class="pxl-loader-bounce3"></div>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endif;
        }

        public function get_link_pages() {
            wp_link_pages( array(
                'before'      => '<div class="page-links">',
                'after'       => '</div>',
                'link_before' => '<span>',
                'link_after'  => '</span>',
            ) ); 
        }

        
        public function get_post_title() {
            $post_title_mode = mouno()->get_theme_opt('post_title_mode', '');
            $post_title_layout = (int)mouno()->get_theme_opt('post_title_layout', 0);
            if(is_singular('portfolio')) {
                $post_title_mode = mouno()->get_theme_opt('portfolio_title_mode', '');
                $post_title_layout = (int)mouno()->get_theme_opt('portfolio_title_layout', 0);
            }elseif(is_singular('service')) {
                $post_title_mode = mouno()->get_theme_opt('service_title_mode', '');
                $post_title_layout = (int)mouno()->get_theme_opt('service_title_layout', 0);
            }elseif(is_singular('team')) {
                $post_title_mode = mouno()->get_theme_opt('team_title_mode', '');
                $post_title_layout = (int)mouno()->get_theme_opt('team_title_layout', 0);
            }elseif(is_singular('product')) {
                $post_title_mode = mouno()->get_theme_opt('product_title_mode', '');
                $post_title_layout = (int)mouno()->get_theme_opt('product_title_layout', 0);
            }elseif(is_search()) {
                $post_title_mode = mouno()->get_theme_opt('search_title_mode', '');
                $post_title_layout = (int)mouno()->get_theme_opt('search_title_layout', 0);
            }
            if($post_title_mode === 'disable') return;

            $is_builder = false;
            $id = 'pxl-post-title-default';

            if($post_title_mode === 'builder' && $post_title_layout > 0 && class_exists('Pxltheme_Core') && is_callable( 'Elementor\Plugin::instance' )) {
                $is_builder =  true;
                $id = 'pxl-post-title-builder';
            }
            ?>
            <section id="<?php echo esc_attr($id); ?>" class="pxl-post-title">
                <div class="pxl-post-title-inner">
                    <?php if ($is_builder) : ?>
                        <?php echo Elementor\Plugin::$instance->frontend->get_builder_content_for_display( $post_title_layout);?>
                    <?php else : ?>
                        <?php 
                            $title = $this->get_title();
                            $post_title = $title['title'];    
                        ?>
                        <h1 class="pxl-post-title">
                            <span class="pxl-title-text">
                                <?php echo esc_html($post_title); ?>
                            </span>
                        </h1>
                    <?php endif; ?>
                </div>
            </section>

            <?php
        }

        public function get_page_title(){
            $titles = $this->get_title();
            $pt_mode = mouno()->get_opt('pt_mode');
            $pt_mode_product = mouno()->get_opt('pt_mode_product');
            $ptitle_layout = (int)mouno()->get_opt('ptitle_layout');
            $ptitle_layout_product = (int)mouno()->get_opt('ptitle_layout_product');
            if ($pt_mode == 'bd' && $ptitle_layout > 0 && class_exists('Pxltheme_Core') && is_callable( 'Elementor\Plugin::instance' )) { ?>
                <div id="pxl-page-title-elementor">
                    <?php echo Elementor\Plugin::$instance->frontend->get_builder_content_for_display( $ptitle_layout);?>
                </div>
                <?php 
            } elseif ($pt_mode_product == 'bd' && $ptitle_layout_product > 0 && class_exists('Pxltheme_Core') && is_callable( 'Elementor\Plugin::instance' ) ) { ?>
                <?php if(class_exists( 'WooCommerce' ) && is_shop() || class_exists( 'WooCommerce' ) && is_singular('product')) : ?>
                    <div id="pxl-page-title-elementor" class="pxl-page-title-shop>">
                        <?php echo Elementor\Plugin::$instance->frontend->get_builder_content_for_display( $ptitle_layout_product);?>
                    </div>
                <?php endif; ?>
            <?php } elseif($pt_mode == 'df') {
                $ptitle_breadcrumb_on = mouno()->get_opt( 'ptitle_breadcrumb_on', '1' ); ?>
                <div id="pxl-page-title-default">
                    <div class="container">
                        <div class="row">
                            <div class="col-sm-12 col-md-6 col-lg-6">
                                <h1 class="pxl-page-title"><?php echo mouno_html($titles['title']) ?></h1>
                            </div>
                            <div class="ptitle-col-right col-sm-12 col-md-6 col-lg-6">
                                <?php if($ptitle_breadcrumb_on == '1') : ?>
                                    <?php $this->get_breadcrumb(); ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php } 
        } 

        public function get_title() {
            $title = '';
            // Default titles
            if ( ! is_archive() ) {
                // Posts page view
                if ( is_home() ) {
                    // Only available if posts page is set.
                    if ( ! is_front_page() && $page_for_posts = get_option( 'page_for_posts' ) ) {
                        $title = get_post_meta( $page_for_posts, 'custom_title', true );
                        if ( empty( $title ) ) {
                            $title = get_the_title( $page_for_posts );
                        }
                    }
                    if ( is_front_page() ) {
                        $title = esc_html__( 'Blog', 'mouno' );
                    }
                } // Single page view
                elseif ( is_page() ) {
                    $title = get_post_meta( get_the_ID(), 'custom_title', true );
                    if ( ! $title ) {
                        $title = get_the_title();
                    }
                } elseif ( is_404() ) {
                    $title = esc_html__( '404 Error', 'mouno' );
                } elseif ( is_search() ) {
                    $title = esc_html__( 'Search results', 'mouno' );
                } elseif ( is_singular('lp_course') ) {
                    $title = esc_html__( 'Course', 'mouno' );
                } else {
                    $title = get_post_meta( get_the_ID(), 'custom_title', true );
                    if ( ! $title ) {
                        $title = get_the_title();
                    }
                }
            } else {
                $title = get_the_archive_title();
                if( (class_exists( 'WooCommerce' ) && is_shop()) ) {
                    $title = get_post_meta( wc_get_page_id('shop'), 'custom_title', true );
                    if(!$title) {
                        $title = get_the_title( get_option( 'woocommerce_shop_page_id' ) );
                    }
                }
            }

            return array(
                'title' => $title,
            );
        }

        public function get_breadcrumb() {
            if (!class_exists('CASE_Breadcrumb')) {
                return;
            }

            $breadcrumb = new CASE_Breadcrumb();
            $entries = $breadcrumb->get_entries();

            if (empty($entries)) {
                return;
            }

            ob_start();

            foreach ($entries as $entry) {
                $entry = wp_parse_args($entry, array(
                    'label' => '',
                    'url'   => ''
                ));

                $entry_label = $entry['label'];
                if (!empty($_GET['blog_title'])) {
                    $blog_title = $_GET['blog_title'];
                    $custom_title = explode('_', $blog_title);
                    foreach ($custom_title as $index => $value) {
                    $arr_str_b[$index] = $value;
                    }
                    $str = implode(' ', $arr_str_b);
                    $entry_label = $str;
                }

                if (empty($entry_label)) {
                    continue;
                }

                echo '<li>';

                if (!empty($entry['url'])) {
                    printf(
                    '<a class="pxl-breadcrumb-link" href="%1$s">%2$s</a>',
                    esc_url($entry['url']),
                    esc_attr($entry_label)
                    );
                } else {
                    if(is_singular('portfolio')) {
                        $single_post_title = mouno()->get_theme_opt('sg_portfolio_breadcrumb', 'default');
                        $custom_single_post_title = mouno()->get_theme_opt('custom_sg_portfolio_breadcrumb', 'Portfolio Details');
                    }elseif(is_singular('service')) {
                        $single_post_title = mouno()->get_theme_opt('sg_service_breadcrumb', 'default');
                        $custom_single_post_title = mouno()->get_theme_opt('custom_sg_service_breadcrumb', 'Service Details');
                    }elseif(is_singular('product')) {
                        $single_post_title = mouno()->get_theme_opt('sg_product_breadcrumb', 'default');
                        $custom_single_post_title = mouno()->get_theme_opt('custom_sg_product_breadcrumb', 'Product Single');
                    }elseif(is_singular('post')){
                        $single_post_title = mouno()->get_theme_opt('sg_post_breadcrumb', 'default');
                        $custom_single_post_title = mouno()->get_theme_opt('custom_sg_post_breadcrumb', 'Blog Details');
                    }elseif(is_singular('team')){
                        $single_post_title = mouno()->get_theme_opt('sg_team_breadcrumb', 'default');
                        $custom_single_post_title = mouno()->get_theme_opt('custom_sg_team_breadcrumb', 'Team Single');
                    }elseif(is_search()){
                        $single_post_title = mouno()->get_theme_opt('sg_search_breadcrumb', 'default');
                        $custom_single_post_title = mouno()->get_theme_opt('custom_sg_search_breadcrumb', 'Search Results');
                    }
                    $entry_label = ((is_single() || is_search()) && $single_post_title === 'custom') ? $custom_single_post_title : $entry_label;
                    printf('<span class="pxl-breadcrumb-current">%s</span>', esc_html($entry_label));
                }

                echo '</li>';
                echo '<li class="pxl-breadcrumb-separator">.</li>';
            }

            $output = ob_get_clean();

            if ($output) {
                printf('<ul class="pxl-breadcrumb">%s</ul>', wp_kses_post($output));
            }
        }

        public function get_pagination( $query = null, $ajax = false ){

            if($ajax){
                add_filter('paginate_links', 'mouno_ajax_paginate_links');
            }

            $classes = array();

            if ( empty( $query ) )
            {
                $query = $GLOBALS['wp_query'];
            }

            if ( empty( $query->max_num_pages ) || ! is_numeric( $query->max_num_pages ) || $query->max_num_pages < 2 )
            {
                return;
            }

            $paged = $query->get( 'paged', '' );

            if ( ! $paged && is_front_page() && ! is_home() )
            {
                $paged = $query->get( 'page', '' );
            }

            $paged = $paged ? intval( $paged ) : 1;

            $pagenum_link = html_entity_decode( get_pagenum_link() );
            $query_args   = array();
            $url_parts    = explode( '?', $pagenum_link );

            if ( isset( $url_parts[1] ) )
            {
                wp_parse_str( $url_parts[1], $query_args );
            }

            $pagenum_link = remove_query_arg( array_keys( $query_args ), $pagenum_link );
            $pagenum_link = trailingslashit( $pagenum_link ) . '%_%';
            $prefix_number = $paged < 10 ? '0' : null;
            $paginate_links_args = array(
                'base'     => $pagenum_link,
                'total'    => $query->max_num_pages,
                'current'  => $paged,
                'mid_size' => 1,
                'add_args' => array_map( 'urlencode', $query_args ),
                'prev_text' => '<svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" viewBox="0 0 13 13" fill="none">
                                    <path transform="scale(-1,1) translate(-13,0)" d="M4.09569 11.2054C3.9325 11.0488 3.84082 10.8365 3.84082 10.615C3.84082 10.3936 3.9325 10.1812 4.09569 10.0246L8.40461 5.89077L4.09569 1.75696C3.93712 1.59945 3.84938 1.3885 3.85136 1.16954C3.85335 0.950574 3.9449 0.741117 4.10629 0.58628C4.26769 0.431443 4.48602 0.343616 4.71426 0.341713C4.9425 0.33981 5.16238 0.423985 5.32656 0.576108L10.2509 5.30035C10.4141 5.45696 10.5058 5.66933 10.5058 5.89077C10.5058 6.11222 10.4141 6.32459 10.2509 6.4812L5.32656 11.2054C5.16332 11.362 4.94195 11.45 4.71112 11.45C4.4803 11.45 4.25893 11.362 4.09569 11.2054Z" fill="currentcolor"/>
                                </svg>',
                'next_text' => '<svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" viewBox="0 0 13 13">
                                    <path d="M4.09862 11.2054C3.93543 11.0488 3.84375 10.8365 3.84375 10.615C3.84375 10.3936 3.93543 10.1812 4.09862 10.0246L8.40754 5.89077L4.09862 1.75696C3.94005 1.59945 3.85231 1.3885 3.85429 1.16954C3.85628 0.950574 3.94783 0.741117 4.10922 0.58628C4.27062 0.431443 4.48895 0.343616 4.71719 0.341713C4.94542 0.33981 5.16531 0.423985 5.32949 0.576108L10.2538 5.30035C10.417 5.45696 10.5087 5.66933 10.5087 5.89077C10.5087 6.11222 10.417 6.32459 10.2538 6.4812L5.32949 11.2054C5.16625 11.362 4.94488 11.45 4.71405 11.45C4.48323 11.45 4.26186 11.362 4.09862 11.2054Z" fill="currentcolor"/>
                                </svg>',
                'before_page_number' => '<span>'.$prefix_number,
                'after_page_number' => '</span>',
            );
            if($ajax){
                $paginate_links_args['format'] = '?page=%#%';
            }
            $links = paginate_links( $paginate_links_args );
            if ( $links ):
            ?>
            <nav class="pxl-pagination-wrap <?php echo esc_attr($ajax ? 'ajax' : ''); ?>">
                <?php printf($links); ?>
            </nav>
            <?php
            endif;
        }
    }
}
