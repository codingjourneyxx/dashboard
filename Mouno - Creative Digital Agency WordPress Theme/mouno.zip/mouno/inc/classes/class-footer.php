<?php

if (!class_exists('Mouno_Footer')) {

    class Mouno_Footer
    {
        public function getFooter()
        {
            if(is_singular('elementor_library')) return;
            
            $footer_layout = (int)mouno()->get_opt('footer_layout');
            
            if ($footer_layout <= 0 || !class_exists('Pxltheme_Core') || !is_callable( 'Elementor\Plugin::instance' )) {
                get_template_part( 'template-parts/footer/default');
            } else {
                $args = [
                    'footer_layout' => $footer_layout
                ];
                get_template_part( 'template-parts/footer/elementor','', $args );
            } 

            // Mouse Move Animation
            mouno_mouse_move_animation();

            // Cookie Policy
            mouno_cookie_policy();

            // Cart Sidebar
            mouno_hook_anchor_cart();
            
        }
 
    }
}
 