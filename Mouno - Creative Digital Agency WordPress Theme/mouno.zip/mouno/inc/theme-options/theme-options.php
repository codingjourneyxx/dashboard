<?php
add_action('after_setup_theme', 'theme_options_setup', 1);
function theme_options_setup() {
    if (!class_exists('ReduxFramework')) {
        return;
    }
    
    $opt_name = mouno()->get_option_name();
    $version = mouno()->get_version();

    $args = array(
        // TYPICAL -> Change these values as you need/desire
        'opt_name'             => $opt_name,
        // This is where your data is stored in the database and also becomes your global variable name.
        'display_name'         => '', //$theme->get('Name'),
        // Name that appears at the top of your panel
        'display_version'      => $version,
        // Version that appears at the top of your panel
        'menu_type'            => 'submenu', //class_exists('Pxltheme_Core') ? 'submenu' : '',
        //Specify if the admin menu should appear or not. Options: menu or submenu (Under appearance only)
        'allow_sub_menu'       => true,
        // Show the sections below the admin menu item or not
        'menu_title'           => esc_html__('Theme Options', 'mouno'),
        'page_title'           => esc_html__('Theme Options', 'mouno'),
        // You will need to generate a Google API key to use this feature.
        // Please visit: https://developers.google.com/fonts/docs/developer_api#Auth
        'google_api_key'       => '',
        // Set it you want google fonts to update weekly. A google_api_key value is required.
        'google_update_weekly' => false,
        // Must be defined to add google fonts to the typography module
        'async_typography'     => false,
        // Use a asynchronous font on the front end or font string
        //'disable_google_fonts_link' => true,                    // Disable this in case you want to create your own google fonts loader
        'admin_bar'            => false,
        // Show the panel pages on the admin bar
        'admin_bar_icon'       => 'dashicons-admin-generic',
        // Choose an icon for the admin bar menu
        'admin_bar_priority'   => 50,
        // Choose an priority for the admin bar menu
        'global_variable'      => '',
        // Set a different name for your global variable other than the opt_name
        'dev_mode'             => true,
        // Show the time the page took to load, etc
        'update_notice'        => true,
        // If dev_mode is enabled, will notify developer of updated versions available in the GitHub Repo
        'customizer'           => true,
        // Enable basic customizer support
        //'open_expanded'     => true,                    // Allow you to start the panel in an expanded way initially.
        //'disable_save_warn' => true,                    // Disable the save warning when a user changes a field
        'show_options_object' => false,
        // OPTIONAL -> Give you extra features
        'page_priority'        => 80,
        // Order where the menu appears in the admin area. If there is any conflict, something will not show. Warning.
        'page_parent'          => 'pxlart', //class_exists('Mouno_Admin_Page') ? 'case' : '',
        // For a full list of options, visit: //codex.wordpress.org/Function_Reference/add_submenu_page#Parameters
        'page_permissions'     => 'manage_options',
        // Permissions needed to access the options panel.
        'menu_icon'            => '',
        // Specify a custom URL to an icon
        'last_tab'             => '',
        // Force your panel to always open to a specific tab (by id)
        'page_icon'            => 'icon-themes',
        // Icon displayed in the admin panel next to your menu_title
        'page_slug'            => 'pxlart-theme-options',
        // Page slug used to denote the panel, will be based off page title then menu title then opt_name if not provided
        'save_defaults'        => true,
        // On load save the defaults to DB before user clicks save or not
        'default_show'         => false,
        // If true, shows the default value next to each field that is not the default value.
        'default_mark'         => '',
        // What to print by the field's title if the value shown is default. Suggested: *
        'show_import_export'   => true,
        // Shows the Import/Export panel when not used as a field.
    
        // CAREFUL -> These options are for advanced use only
        'transient_time'       => 60 * MINUTE_IN_SECONDS,
        'output'               => true,
        // Global shut-off for dynamic CSS output by the framework. Will also disable google fonts output
        'output_tag'           => true,
        // Allows dynamic CSS to be generated for customizer and google fonts, but stops the dynamic CSS from going to the head
        // 'footer_credit'     => '',                   // Disable the footer credit of Redux. Please leave if you can help it.
    
        // FUTURE -> Not in use yet, but reserved or partially implemented. Use at your own risk.
        'database'             => '',
        // possible: options, theme_mods, theme_mods_expanded, transient. Not fully functional, warning!
        'use_cdn'              => true,
        // If you prefer not to use the CDN for Select2, Ace Editor, and others, you may download the Redux Vendor Support plugin yourself and run locally or embed it in your code.
    
        // HINTS
        'hints'                => array(
            'icon'          => 'el el-question-sign',
            'icon_position' => 'right',
            'icon_color'    => 'lightgray',
            'icon_size'     => 'normal',
            'tip_style'     => array(
                'color'   => 'red',
                'shadow'  => true,
                'rounded' => false,
                'style'   => '',
            ),
            'tip_position'  => array(
                'my' => 'top left',
                'at' => 'bottom right',
            ),
            'tip_effect'    => array(
                'show' => array(
                    'effect'   => 'slide',
                    'duration' => '500',
                    'event'    => 'mouseover',
                ),
                'hide' => array(
                    'effect'   => 'slide',
                    'duration' => '500',
                    'event'    => 'click mouseleave',
                ),
            ),
        ),
    );
    
    Redux::SetArgs($opt_name, $args);
    
    /*--------------------------------------------------------------
    # Colors
    --------------------------------------------------------------*/
    Redux::setSection($opt_name, array(
        'title'  => esc_html__('Global Colors', 'mouno'),
        'icon'       => 'el el-filter',
        'fields' => array(
            array(
                'id'          => 'primary_color',
                'type'        => 'color',
                'title'       => esc_html__('Primary Color', 'mouno'),
                'transparent' => false,
                'default'     => ''
            ),
            array(
                'id'          => 'secondary_color',
                'type'        => 'color',
                'title'       => esc_html__('Secondary Color', 'mouno'),
                'transparent' => false,
                'default'     => ''
            ),
            array(
                'id'          => 'third_color',
                'type'        => 'color',
                'title'       => esc_html__('Third Color', 'mouno'),
                'transparent' => false,
                'default'     => ''
            ),
    
            array(
                'id'      => 'link_color',
                'type'    => 'link_color',
                'title'   => esc_html__('Link Color', 'mouno'),
                'default' => array(
                    'regular' => '',
                    'hover'   => '',
                    'active'  => ''
                ),
                'output'  => array('a')
            ),
            array(
                'id'          => 'gradient_color',
                'type'        => 'color_gradient',
                'title'       => esc_html__('Gradient Color', 'mouno'),
                'transparent' => false,
                'default'  => array(
                    'from' => '',
                    'to'   => '', 
                ),
            ),
        )
    ));
    
    // Typography
    Redux::setSection($opt_name, array(
        'title'  => esc_html__('Typography', 'mouno'),
        'icon'   => 'el-icon-text-width',
        'fields' => array(
            array(
                'id'          => 'primary_font',
                'type'        => 'typography',
                'title'       => esc_html__('Primary Font', 'mouno'),
                'google'      => true,
                'font-backup' => false,
                'all_styles'  => false,
                'line-height'  => false,
                'font-size'  => false,
                'color'  => false,
                'font-style'  => false,
                'font-weight'  => false,
                'text-align'  => false,
            ),
            array(
                'id'          => 'secondary_font',
                'type'        => 'typography',
                'title'       => esc_html__('Secondary Font', 'mouno'),
                'google'      => true,
                'font-backup' => false,
                'all_styles'  => false,
                'line-height'  => false,
                'font-size'  => false,
                'color'  => false,
                'font-style'  => false,
                'font-weight'  => false,
                'text-align'  => false,
            ),
            array(
                'id'          => 'third_font',
                'type'        => 'typography',
                'title'       => esc_html__('Third Font', 'mouno'),
                'google'      => true,
                'font-backup' => false,
                'all_styles'  => false,
                'line-height'  => false,
                'font-size'  => false,
                'color'  => false,
                'font-style'  => false,
                'font-weight'  => false,
                'text-align'  => false,
            ),
            array(
                'id'          => 'heading_font',
                'type'        => 'typography',
                'title'       => esc_html__('Heading Font', 'mouno'),
                'google'      => true,
                'font-backup' => false,
                'all_styles'  => false,
                'line-height'  => false,
                'font-size'  => false,
                'font-style'  => false,
                'font-weight'  => true,
                'text-align'  => false,
                'color' => true
            ),
            array(
                'id'          => 'font_heading_h1',
                'type'        => 'typography',
                'title'       => esc_html__('Heading H1', 'mouno'),
                'google'      => true,
                'font-backup' => false,
                'all_styles'  => true,
                'text-align'  => false,
                'line-height' => true,
                'font-backup' => false,
                'font-style'  => false,
                'output'      => array('h1', '.h1'),
                'units'       => 'px',
                'font-family' => false,
                'color' => false
            ),
    
            array(
                'id'          => 'font_heading_h2',
                'type'        => 'typography',
                'title'       => esc_html__('Heading H2', 'mouno'),
                'google'      => true,
                'font-backup' => true,
                'all_styles'  => true,
                'text-align'  => false,
                'line-height' => true,
                'font-size'   => true,
                'font-backup' => false,
                'font-style'  => false,
                'output'      => array('h2', '.h2'),
                'units'       => 'px',
                'font-family' => false,
                'color' => false
            ),
    
            array(
                'id'          => 'font_heading_h3',
                'type'        => 'typography',
                'title'       => esc_html__('Heading H3', 'mouno'),
                'google'      => true,
                'font-backup' => true,
                'all_styles'  => true,
                'text-align'  => false,
                'line-height' => true,
                'font-size'   => true,
                'font-backup' => false,
                'font-style'  => false,
                'output'      => array('h3', '.h3'),
                'units'       => 'px',
                'font-family' => false,
                'color' => false
            ),
    
            array(
                'id'          => 'font_heading_h4',
                'type'        => 'typography',
                'title'       => esc_html__('Heading H4', 'mouno'),
                'google'      => true,
                'font-backup' => true,
                'all_styles'  => true,
                'text-align'  => false,
                'line-height' => true,
                'font-size'   => true,
                'font-backup' => false,
                'font-style'  => false,
                'output'      => array('h4', '.h4'),
                'units'       => 'px',            
                'font-family' => false,
                'color' => false
            ),
    
            array(
                'id'          => 'font_heading_h5',
                'type'        => 'typography',
                'title'       => esc_html__('Heading H5', 'mouno'),
                'google'      => true,
                'font-backup' => true,
                'all_styles'  => true,
                'text-align'  => false,
                'line-height' => true,
                'font-size'   => true,
                'font-backup' => false,
                'font-style'  => false,
                'output'      => array('h5', '.h5'),
                'units'       => 'px',
                'font-family' => false,
                'color' => false
            ),
    
            array(
                'id'          => 'font_heading_h6',
                'type'        => 'typography',
                'title'       => esc_html__('Heading H6', 'mouno'),
                'google'      => true,
                'font-backup' => true,
                'all_styles'  => true,
                'text-align'  => false,
                'line-height' => true,
                'font-size'   => true,
                'font-backup' => false,
                'font-style'  => false,
                'output'      => array('h6', '.h6'),
                'units'       => 'px',
                'font-family' => false,
                'color' => false
            ),
        )
    ));
    
    /*--------------------------------------------------------------
    # General
    --------------------------------------------------------------*/
    Redux::setSection($opt_name, array(
        'title'  => esc_html__('General', 'mouno'),
        'icon'   => 'el el-wrench',
        'fields' => array(
            array(
                'id'       => 'site_loader',
                'type'     => 'button_set',
                'title'    => esc_html__('Site Loader', 'mouno'),
                'options'  => array(
                    'on' => esc_html__('On', 'mouno'),
                    'off' => esc_html__('Off', 'mouno'),
                ),
                'default'  => 'off',
            ),
            array(
                'id' => 'site_loader_style',
                'type' => 'select',
                'title' => esc_html__('Site Loader Style', 'mouno'),
                'options' => array(
                    'loader-default' => esc_html__('Default', 'mouno'),
                    'loader-style1' => esc_html__('Style 1', 'mouno'),
                ),
                'default' => 'loader-style1',
                'required' => array( 0 => 'site_loader', 1 => 'equals', 2 => 'on' ),
            ),
            array(
                'id'       => 'mouse_move_animation',
                'type'     => 'button_set',
                'title'    => esc_html__('Mouse Move Animation', 'mouno'),
                'options'  => array(
                    'on' => esc_html__('On', 'mouno'),
                    'off' => esc_html__('Off', 'mouno'),
                ),
                'default'  => 'off',
            ),
            array(
                'id'       => 'smooth_scroll',
                'type'     => 'button_set',
                'title'    => esc_html__('Smooth Scroll', 'mouno'),
                'options'  => array(
                    'on' => esc_html__('On', 'mouno'),
                    'off' => esc_html__('Off', 'mouno'),
                ),
                'default'  => 'off',
            ),
    
            array(
                'id'       => 'cookie_policy',
                'type'     => 'button_set',
                'title'    => esc_html__('Cookie Policy', 'mouno'),
                'options'  => array(
                    'show' => esc_html__('Show', 'mouno'),
                    'hide' => esc_html__('Hide', 'mouno'),
                ),
                'default'  => 'hide',
            ),
            array(
                'id'      => 'cookie_policy_description',
                'type'    => 'text',
                'title'   => esc_html__('Cookie Description', 'mouno'),
                'default' => '',
                'required' => array( 0 => 'cookie_policy', 1 => 'equals', 2 => 'show' ),
            ),
            array(
                'id'          => 'cookie_policy_description_typo',
                'type'        => 'typography',
                'title'       => esc_html__('Cookie Description Font', 'mouno'),
                'google'      => true,
                'font-backup' => false,
                'all_styles'  => true,
                'line-height'  => true,
                'font-size'  => true,
                'text-align'  => false,
                'color'  => false,
                'output'      => array('.pxl-cookie-policy .pxl-item--description'),
                'units'       => 'px',
                'required' => array( 0 => 'cookie_policy', 1 => 'equals', 2 => 'show' ),
            ),
            array(
                'id'      => 'cookie_policy_btntext',
                'type'    => 'text',
                'title'   => esc_html__('Cookie Button Text', 'mouno'),
                'default' => '',
                'required' => array( 0 => 'cookie_policy', 1 => 'equals', 2 => 'show' ),
            ),
            array(
                'id'    => 'cookie_policy_link',
                'type'  => 'select',
                'title' => esc_html__( 'Cookie Button Link', 'mouno' ), 
                'data'  => 'page',
                'args'  => array(
                    'post_type'      => 'page',
                    'posts_per_page' => -1,
                    'orderby'        => 'title',
                    'order'          => 'ASC',
                ),
                'required' => array( 0 => 'cookie_policy', 1 => 'equals', 2 => 'show' ),
            ),
        )
    ));
    
    /*--------------------------------------------------------------
    # Header
    --------------------------------------------------------------*/
    Redux::setSection($opt_name, array(
        'title'  => esc_html__('Header', 'mouno'),
        'icon'   => 'el el-indent-left',
        'fields' => array_merge(
            mouno_header_opts(),
            array(
                array(
                    'id'       => 'sticky_scroll',
                    'type'     => 'button_set',
                    'title'    => esc_html__('Sticky Scroll', 'mouno'),
                    'options'  => array(
                        'scroll-up' => esc_html__('Scroll Up', 'mouno'),
                        'scroll-down'  => esc_html__('Scroll Down', 'mouno'),
                    ),
                    'default'  => 'scroll-down',
                ),
            )
        )
    ));
    
    Redux::setSection($opt_name, array(
        'title'      => esc_html__('Mobile', 'mouno'),
        'icon'       => 'el el-circle-arrow-right',
        'subsection' => true,
        'fields'     => array_merge(
            mouno_header_mobile_opts(),
            array(
                array(
                    'id'       => 'mobile_display',
                    'type'     => 'button_set',
                    'title'    => esc_html__('Display', 'mouno'),
                    'options'  => array(
                        'show'  => esc_html__('Show', 'mouno'),
                        'hide'  => esc_html__('Hide', 'mouno'),
                    ),
                    'default'  => 'show'
                ),
                array(
                    'id'       => 'logo_m',
                    'type'     => 'media',
                    'title'    => esc_html__('Logo Dark in Menu Sidebar', 'mouno'),
                     'default' => array(
                        'url'=>get_template_directory_uri().'/assets/img/logo.png'
                    ),
                    'url'      => false,
                    'required' => array( 0 => 'mobile_display', 1 => 'equals', 2 => 'show' ),
                    'desc'    => sprintf(esc_html__('You can also choose a logo to apply to each Page. Please edit the page and you will see Page Options. %sView Now.%s','mouno'),'<a class="pxl-admin-popup" href="' . esc_url( get_template_directory_uri() ) . '/inc/theme-options/instruct/logo_m_page.png">','</a>'),
                ),
                array(
                    'id'       => 'logo_light_m',
                    'type'     => 'media',
                    'title'    => esc_html__('Logo Light in Menu Sidebar', 'mouno'),
                    'default' => array(
                        'url'=>get_template_directory_uri().'/assets/img/logo-light.png'
                    ),
                    'url'      => false,
                    'required' => array( 0 => 'mobile_display', 1 => 'equals', 2 => 'show' ),
                ),
                array(
                    'id'       => 'logo_height',
                    'type'     => 'dimensions',
                    'title'    => esc_html__('Logo Height', 'mouno'),
                    'width'    => false,
                    'unit'     => 'px',
                    'output'    => array('#pxl-header-default .pxl-header-branding img, #pxl-header-default #pxl-header-mobile .pxl-header-branding img, #pxl-header-elementor #pxl-header-mobile .pxl-header-branding img, .pxl-logo-mobile img'),
                    'required' => array( 0 => 'mobile_display', 1 => 'equals', 2 => 'show' ),
                ),
                array(
                    'id'       => 'search_mobile',
                    'type'     => 'switch',
                    'title'    => esc_html__('Search Form', 'mouno'),
                    'default'  => true,
                    'required' => array( 0 => 'mobile_display', 1 => 'equals', 2 => 'show' ),
                ),
                array(
                    'id'      => 'search_placeholder_mobile',
                    'type'    => 'text',
                    'title'   => esc_html__('Search Text Placeholder', 'mouno'),
                    'default' => '',
                    'subtitle' => esc_html__('Default: Search...', 'mouno'),
                    'required' => array( 0 => 'search_mobile', 1 => 'equals', 2 => true ),
                )
            )
        )
    ));
    
    /*--------------------------------------------------------------
    # Footer
    --------------------------------------------------------------*/
    Redux::setSection($opt_name, array(
        'title'  => esc_html__('Footer', 'mouno'),
        'icon'   => 'el el-website',
        'fields' => array_merge(
            mouno_footer_opts(),
            array(
                array(
                    'id'       => 'back_totop_on',
                    'type'     => 'switch',
                    'title'    => esc_html__('Back to Top', 'mouno'),
                    'default'  => false,
                ),
                array(
                    'id'       => 'footer_fixed',
                    'type'     => 'button_set',
                    'title'    => esc_html__('Footer Fixed', 'mouno'),
                    'options'  => array(
                        'on' => esc_html__('On', 'mouno'),
                        'off' => esc_html__('Off', 'mouno'),
                    ),
                    'default'  => 'off',
                ),
            ) 
        )
        
    ));
    
    /*--------------------------------------------------------------
    # Page Title area
    --------------------------------------------------------------*/
    Redux::setSection($opt_name, array(
        'title'  => esc_html__('Page Title', 'mouno'),
        'icon'   => 'el-icon-map-marker',
        'fields' => array_merge(
            mouno_page_title_opts(),
        )
    ));
    
    Redux::setSection($opt_name, array(
        'title'  => esc_html__('404 Page', 'mouno'),
        'icon'   => 'el-icon-map-marker',
        'fields' => array(
            mouno_get_pages(),
        )
    ));
    
    // $04
    /*--------------------------------------------------------------
    # WordPress default content
    --------------------------------------------------------------*/
    Redux::setSection($opt_name, array(
        'title' => esc_html__('Blog', 'mouno'),
        'icon'  => 'el el-edit',
        'fields'     => array(
        )
    ));
    
    Redux::setSection($opt_name, array(
        'title' => esc_html__('Blog Archive', 'mouno'),
        'icon'  => 'el-icon-pencil',
        'subsection' => true,
        'fields'     => array(
            array(
                'id' => 'blog_general_h',
                'title' => esc_html__('General', 'mouno'),
                'type'  => 'section',
                'indent' => true,
            ),
            mouno_sidebar_options(),
            array(
                'id' => 'blog_display_h',
                'title' => esc_html__('Display', 'mouno'),
                'type'  => 'section',
                'indent' => true,
            ),
            array(
                'id'       => 'archive_date',
                'title'    => esc_html__('Date', 'mouno'),
                'subtitle' => esc_html__('Display the Date for each blog post.', 'mouno'),
                'type'     => 'switch',
                'default'  => true,
            ),
        )
    ));
    
    Redux::setSection($opt_name, array(
        'title'      => esc_html__('Single Post', 'mouno'),
        'icon'       => 'el el-icon-pencil',
        'subsection' => true,
        'fields'     => array_merge(
            array(
                array(
                    'id' => 'sg_post_grneral_h',
                    'title' => esc_html__('General', 'mouno'),
                    'type'  => 'section',
                    'indent' => true,
                ),
                mouno_sidebar_options(['prefix' => 'post']),
                array(
                    'id' => 'sg_post_title_h',
                    'title' => esc_html__('Post Title', 'mouno'),
                    'type'  => 'section',
                    'indent' => true,
                ),
            ),
            mouno_post_title_opts(),
            array(
                array(
                    'id' => 'sg_breadcrumb_post_title_h',
                    'title' => esc_html__('Breadcrumb', 'mouno'),
                    'type'  => 'section',
                    'indent' => true,
                ),
                array(
                    'id'       => 'sg_post_breadcrumb',
                    'type'     => 'button_set',
                    'title'    => esc_html__('Post Title', 'mouno'),
                    'options'  => array(
                        'default' => esc_html__('Use Post Title', 'mouno'),
                        'custom'  => esc_html__('Use Custom Title', 'mouno'),
                    ),
                    'default'  => 'default',
                ),            
                array(
                    'id'      => 'custom_sg_post_breadcrumb',
                    'type'    => 'text',
                    'title'   => esc_html__('Custom Post Title', 'mouno'),
                    'default' => esc_html__('Blog Details', 'mouno'),
                    'required' => array( 0 => 'sg_post_breadcrumb', 1 => 'equals', 2 => 'custom' ),
                ),
                array(
                    'id' => 'sg_post_display_h',
                    'title' => esc_html__('Display', 'mouno'),
                    'type'  => 'section',
                    'indent' => true,
                ),
                array(
                    'id'      => 'sg_featured_img_size',
                    'type'    => 'text',
                    'title'   => esc_html__('Featured Image Size', 'mouno'),
                    'default' => '',
                    'subtitle' => 'Enter image size (Example: "thumbnail", "medium", "large", "full" or other sizes defined by theme). Alternatively enter size in pixels (Default: 370x300 (Width x Height)).',
                ),
                array(
                    'id'       => 'post_date',
                    'title'    => esc_html__('Date', 'mouno'),
                    'subtitle' => esc_html__('Display the Date for blog post.', 'mouno'),
                    'type'     => 'switch',
                    'default'  => true
                ),
                array(
                    'id'       => 'post_author',
                    'title'    => esc_html__('Author', 'mouno'),
                    'subtitle' => esc_html__('Display the Author for blog post.', 'mouno'),
                    'type'     => 'switch',
                    'default'  => true
                ),
                array(
                    'id'       => 'post_comment',
                    'title'    => esc_html__('Comment', 'mouno'),
                    'subtitle' => esc_html__('Display the Comment for blog post.', 'mouno'),
                    'type'     => 'switch',
                    'default'  => true
                ),
                array(
                    'id'       => 'post_category',
                    'title'    => esc_html__('Category', 'mouno'),
                    'subtitle' => esc_html__('Display the Category for blog post.', 'mouno'),
                    'type'     => 'switch',
                    'default'  => true
                ),
                array(
                    'id'       => 'post_tag',
                    'title'    => esc_html__('Tags', 'mouno'),
                    'subtitle' => esc_html__('Display the Tag for blog post.', 'mouno'),
                    'type'     => 'switch',
                    'default'  => true
                ),
                array(
                    'id'       => 'post_navigation',
                    'title'    => esc_html__('Navigation', 'mouno'),
                    'subtitle' => esc_html__('Display the Navigation for blog post.', 'mouno'),
                    'type'     => 'switch',
                    'default'  => false,
                ),
                array(
                    'title' => esc_html__('Social', 'mouno'),
                    'type'  => 'section',
                    'id' => 'social_section_h',
                    'indent' => true,
                ),
                array(
                    'id'       => 'post_social_share',
                    'title'    => esc_html__('Social', 'mouno'),
                    'subtitle' => esc_html__('Display the Social Share for blog post.', 'mouno'),
                    'type'     => 'switch',
                    'default'  => false,
                ),
                array(
                    'id'       => 'social_facebook',
                    'title'    => esc_html__('Facebook', 'mouno'),
                    'type'     => 'switch',
                    'default'  => true,
                    'indent' => true,
                    'required' => array( 0 => 'post_social_share', 1 => 'equals', 2 => '1' ),
                ),
                array(
                    'id'       => 'social_twitter',
                    'title'    => esc_html__('Twitter', 'mouno'),
                    'type'     => 'switch',
                    'default'  => true,
                    'indent' => true,
                    'required' => array( 0 => 'post_social_share', 1 => 'equals', 2 => '1' ),
                ),
                array(
                    'id'       => 'social_pinterest',
                    'title'    => esc_html__('Pinterest', 'mouno'),
                    'type'     => 'switch',
                    'default'  => true,
                    'indent' => true,
                    'required' => array( 0 => 'post_social_share', 1 => 'equals', 2 => '1' ),
                ),
                array(
                    'id'       => 'social_linkedin',
                    'title'    => esc_html__('LinkedIn', 'mouno'),
                    'type'     => 'switch',
                    'default'  => true,
                    'indent' => true,
                    'required' => array( 0 => 'post_social_share', 1 => 'equals', 2 => '1' ),
                ),
            ),
        ),
    ));
    
    Redux::setSection($opt_name, array(
        'title'      => esc_html__('Search Result', 'mouno'),
        'icon'       => 'el el-icon-pencil',
        'subsection' => true,
        'fields'     => array_merge(
            array(
                array(
                    'id' => 'sg_search_grneral_h',
                    'title' => esc_html__('General', 'mouno'),
                    'type'  => 'section',
                    'indent' => true,
                ),
                mouno_sidebar_options(['prefix' => 'search']),
                array(
                    'id' => 'sg_search_title_h',
                    'title' => esc_html__('Search Title', 'mouno'),
                    'type'  => 'section',
                    'indent' => true,
                ),
            ),
            mouno_post_title_opts('search'),
            array(
                array(
                    'id' => 'sg_breadcrumb_search_title_h',
                    'title' => esc_html__('Breadcrumb', 'mouno'),
                    'type'  => 'section',
                    'indent' => true,
                ),
                array(
                    'id'       => 'sg_search_breadcrumb',
                    'type'     => 'button_set',
                    'title'    => esc_html__('Search Title', 'mouno'),
                    'options'  => array(
                        'default' => esc_html__('Use Search Title', 'mouno'),
                        'custom'  => esc_html__('Use Custom Title', 'mouno'),
                    ),
                    'default'  => 'default',
                ),       
                array(
                    'id'      => 'custom_sg_search_breadcrumb',
                    'type'    => 'text',
                    'title'   => esc_html__('Custom Search Title', 'mouno'),
                    'default' => esc_html__('Search Results', 'mouno'),
                    'required' => array( 0 => 'sg_search_breadcrumb', 1 => 'equals', 2 => 'custom' ),
                ),     
            ),
        ),
    ));
    
    Redux::setSection($opt_name, array(
        'title'      => esc_html__('Portfolio', 'mouno'),
        'icon'       => 'el el-briefcase',
        'fields'     => array_merge(
            array(
                array(
                    'title' => esc_html__('General', 'mouno'),
                    'type'  => 'section',
                    'id' => 'portfolio_general_h',
                    'indent' => true,
                ),
                array(
                    'id'       => 'portfolio_display',
                    'type'     => 'button_set',
                    'title'    => esc_html__('Portfolio', 'mouno'),
                    'options'  => array(
                        'on' => esc_html__('On', 'mouno'),
                        'off' => esc_html__('Off', 'mouno'),
                    ),
                    'default'  => 'on',
                ),
                array(
                    'id'      => 'portfolio_slug',
                    'type'    => 'text',
                    'title'   => esc_html__('Portfolio Slug', 'mouno'),
                    'default' => '',
                    'desc'     => 'Default: portfolio',
                    'required' => array( 0 => 'portfolio_display', 1 => 'equals', 2 => 'on' ),
                    'force_output' => true
                ),
                array(
                    'id'      => 'portfolio_name',
                    'type'    => 'text',
                    'title'   => esc_html__('Portfolio Name', 'mouno'),
                    'default' => '',
                    'desc'     => 'Default: Portfolio',
                    'required' => array( 0 => 'portfolio_display', 1 => 'equals', 2 => 'on' ),
                    'force_output' => true
                ),
                array(
                    'id'    => 'archive_portfolio_link',
                    'type'  => 'select',
                    'title' => esc_html__( 'Custom Archive Page Link', 'mouno' ), 
                    'data'  => 'page',
                    'args'  => array(
                        'post_type'      => 'page',
                        'posts_per_page' => -1,
                        'orderby'        => 'title',
                        'order'          => 'ASC',
                    ),
                    'required' => array( 0 => 'portfolio_display', 1 => 'equals', 2 => 'on' ),
                    'force_output' => true
                ),
                array(
                    'title' => esc_html__('Post Title', 'mouno'),
                    'type'  => 'section',
                    'id' => 'portfolio_title_h',
                    'indent' => true,
                ),
            ),
            mouno_post_title_opts('portfolio'),
            array(
                array(
                    'id' => 'sg_breadcrumb_portfolio_title_h',
                    'title' => esc_html__('Breadcrumb', 'mouno'),
                    'type'  => 'section',
                    'indent' => true,
                ),
                array(
                    'id'       => 'sg_portfolio_breadcrumb',
                    'type'     => 'button_set',
                    'title'    => esc_html__('Post Title', 'mouno'),
                    'options'  => array(
                        'default' => esc_html__('Use Post Title', 'mouno'),
                        'custom'  => esc_html__('Use Custom Title', 'mouno'),
                    ),
                    'default'  => 'default',
                ),            
                array(
                    'id'      => 'custom_sg_portfolio_breadcrumb',
                    'type'    => 'text',
                    'title'   => esc_html__('Custom Post Title', 'mouno'),
                    'default' => esc_html__('Portfolio Details', 'mouno'),
                    'required' => array( 0 => 'sg_portfolio_breadcrumb', 1 => 'equals', 2 => 'custom' ),
                ),
            )
        ),
    ));
    
    Redux::setSection($opt_name, array(
        'title'      => esc_html__('Service', 'mouno'),
        'icon'       => 'el el-briefcase',
        'fields'     => array_merge(
            array(
                array(
                    'title' => esc_html__('General', 'mouno'),
                    'type'  => 'section',
                    'id' => 'service_general_h',
                    'indent' => true,
                ),
                array(
                    'id'       => 'service_display',
                    'type'     => 'button_set',
                    'title'    => esc_html__('Service', 'mouno'),
                    'options'  => array(
                        'on' => esc_html__('On', 'mouno'),
                        'off' => esc_html__('Off', 'mouno'),
                    ),
                    'default'  => 'on',
                ),
                array(
                    'id'      => 'service_slug',
                    'type'    => 'text',
                    'title'   => esc_html__('Service Slug', 'mouno'),
                    'default' => '',
                    'desc'     => 'Default: service',
                    'required' => array( 0 => 'service_display', 1 => 'equals', 2 => 'on' ),
                    'force_output' => true
                ),
                array(
                    'id'      => 'service_name',
                    'type'    => 'text',
                    'title'   => esc_html__('Service Name', 'mouno'),
                    'default' => '',
                    'desc'     => 'Default: Service',
                    'required' => array( 0 => 'service_display', 1 => 'equals', 2 => 'on' ),
                    'force_output' => true
                ),
                array(
                    'id'    => 'archive_service_link',
                    'type'  => 'select',
                    'title' => esc_html__( 'Custom Archive Page Link', 'mouno' ), 
                    'data'  => 'page',
                    'args'  => array(
                        'post_type'      => 'page',
                        'posts_per_page' => -1,
                        'orderby'        => 'title',
                        'order'          => 'ASC',
                    ),
                    'required' => array( 0 => 'service_display', 1 => 'equals', 2 => 'on' ),
                    'force_output' => true
                ),
                array(
                    'title' => esc_html__('Post Title', 'mouno'),
                    'type'  => 'section',
                    'id' => 'service_title_h',
                    'indent' => true,
                ),
            ),
            mouno_post_title_opts('service'),
            array(
                array(
                    'id' => 'sg_breadcrumb_service_title_h',
                    'title' => esc_html__('Breadcrumb', 'mouno'),
                    'type'  => 'section',
                    'indent' => true,
                ),
                array(
                    'id'       => 'sg_service_breadcrumb',
                    'type'     => 'button_set',
                    'title'    => esc_html__('Post Title', 'mouno'),
                    'options'  => array(
                        'default' => esc_html__('Use Post Title', 'mouno'),
                        'custom'  => esc_html__('Use Custom Title', 'mouno'),
                    ),
                    'default'  => 'default',
                ),            
                array(
                    'id'      => 'custom_sg_service_breadcrumb',
                    'type'    => 'text',
                    'title'   => esc_html__('Custom Post Title', 'mouno'),
                    'default' => esc_html__('Service Details', 'mouno'),
                    'required' => array( 0 => 'sg_service_breadcrumb', 1 => 'equals', 2 => 'custom' ),
                ),
            )
        ),
    ));
    
    Redux::setSection($opt_name, array(
        'title'      => esc_html__('Team', 'mouno'),
        'icon'       => 'el el-briefcase',
        'fields'     => array_merge(
            array(
                array(
                    'title' => esc_html__('General', 'mouno'),
                    'type'  => 'section',
                    'id' => 'team_general_h',
                    'indent' => true,
                ),
                array(
                    'id'       => 'team_display',
                    'type'     => 'button_set',
                    'title'    => esc_html__('Team', 'mouno'),
                    'options'  => array(
                        'on' => esc_html__('On', 'mouno'),
                        'off' => esc_html__('Off', 'mouno'),
                    ),
                    'default'  => 'on',
                ),
                array(
                    'id'      => 'team_slug',
                    'type'    => 'text',
                    'title'   => esc_html__('Team Slug', 'mouno'),
                    'default' => '',
                    'desc'     => 'Default: team',
                    'required' => array( 0 => 'team_display', 1 => 'equals', 2 => 'on' ),
                    'force_output' => true
                ),
                array(
                    'id'      => 'team_name',
                    'type'    => 'text',
                    'title'   => esc_html__('Team Name', 'mouno'),
                    'default' => '',
                    'desc'     => 'Default: Team',
                    'required' => array( 0 => 'team_display', 1 => 'equals', 2 => 'on' ),
                    'force_output' => true
                ),
                array(
                    'id'    => 'archive_team_link',
                    'type'  => 'select',
                    'title' => esc_html__( 'Custom Archive Page Link', 'mouno' ), 
                    'data'  => 'page',
                    'args'  => array(
                        'post_type'      => 'page',
                        'posts_per_page' => -1,
                        'orderby'        => 'title',
                        'order'          => 'ASC',
                    ),
                    'required' => array( 0 => 'team_display', 1 => 'equals', 2 => 'on' ),
                    'force_output' => true
                ),
                array(
                    'title' => esc_html__('Post Title', 'mouno'),
                    'type'  => 'section',
                    'id' => 'team_title_h',
                    'indent' => true,
                ),
            ),
            mouno_post_title_opts('team'),
            array(
                array(
                    'id' => 'sg_breadcrumb_team_title_h',
                    'title' => esc_html__('Breadcrumb', 'mouno'),
                    'type'  => 'section',
                    'indent' => true,
                ),
                array(
                    'id'       => 'sg_team_breadcrumb',
                    'type'     => 'button_set',
                    'title'    => esc_html__('Post Title', 'mouno'),
                    'options'  => array(
                        'default' => esc_html__('Use Post Title', 'mouno'),
                        'custom'  => esc_html__('Use Custom Title', 'mouno'),
                    ),
                    'default'  => 'default',
                ),            
                array(
                    'id'      => 'custom_sg_team_breadcrumb',
                    'type'    => 'text',
                    'title'   => esc_html__('Custom Post Title', 'mouno'),
                    'default' => esc_html__('Team Details', 'mouno'),
                    'required' => array( 0 => 'sg_team_breadcrumb', 1 => 'equals', 2 => 'custom' ),
                ),
            )
        ),
    ));
    
    /*--------------------------------------------------------------
    # Shop
    --------------------------------------------------------------*/
    if(class_exists('Woocommerce')) {
        Redux::setSection($opt_name, array(
            'title'  => esc_html__('Shop', 'mouno'),
            'icon'   => 'el el-shopping-cart',
        ));
    
        Redux::setSection($opt_name, array(
            'title' => esc_html__('Product Archive', 'mouno'),
            'icon'  => 'el-icon-pencil',
            'subsection' => true,
            'fields'     =>  array(
                mouno_sidebar_options([ 'prefix' => 'shop']),
                array(
                    'id'      => 'shop_featured_img_size',
                    'type'    => 'text',
                    'title'   => esc_html__('Featured Image Size', 'mouno'),
                    'default' => '',
                    'subtitle' => 'Enter image size (Example: "thumbnail", "medium", "large", "full" or other sizes defined by theme). Alternatively enter size in pixels (Default: 370x300 (Width x Height)).',
                ),
                array(
                    'title'         => esc_html__('Number of products per row', 'mouno'),
                    'id'            => 'number_of_products_per_row',
                    'type'          => 'slider',
                    'subtitle'      => esc_html__('Number product to show per row', 'mouno'),
                    'default'       => 3,
                    'min'           => 2,
                    'step'          => 1,
                    'max'           => 5,
                    'display_value' => 'text',
                ),
                array(
                    'title'         => esc_html__('Product pages show at most', 'mouno'),
                    'id'            => 'product_pages_show_at_most',
                    'type'          => 'slider',
                    'subtitle'      => esc_html__('Number product to show', 'mouno'),
                    'default'       => 9,
                    'min'           => 3,
                    'step'          => 1,
                    'max'           => 50,
                    'display_value' => 'text'
                ),
            ),
        ));
    
        Redux::setSection($opt_name, array(
            'title' => esc_html__('Single Product', 'mouno'),
            'icon'  => 'el-icon-pencil',
            'subsection' => true,
            'fields'     => array_merge(
                array(
                    array(
                        'title' => esc_html__('General', 'mouno'),
                        'type'  => 'section',
                        'id' => 'product_general_h',
                        'indent' => true,
                    ),
                    array(
                        'id'       => 'product_display',
                        'type'     => 'button_set',
                        'title'    => esc_html__('Product', 'mouno'),
                        'options'  => array(
                            'on' => esc_html__('On', 'mouno'),
                            'off' => esc_html__('Off', 'mouno'),
                        ),
                        'default'  => 'on',
                    ),
                    array(
                        'id'      => 'product_slug',
                        'type'    => 'text',
                        'title'   => esc_html__('Product Slug', 'mouno'),
                        'default' => '',
                        'desc'     => 'Default: product',
                        'required' => array( 0 => 'product_display', 1 => 'equals', 2 => 'on' ),
                        'force_output' => true
                    ),
                    array(
                        'id'      => 'product_name',
                        'type'    => 'text',
                        'title'   => esc_html__('Product Name', 'mouno'),
                        'default' => '',
                        'desc'     => 'Default: Product',
                        'required' => array( 0 => 'product_display', 1 => 'equals', 2 => 'on' ),
                        'force_output' => true
                    ),
                    array(
                        'id'    => 'archive_product_link',
                        'type'  => 'select',
                        'title' => esc_html__( 'Custom Archive Page Link', 'mouno' ), 
                        'data'  => 'page',
                        'args'  => array(
                            'post_type'      => 'page',
                            'posts_per_page' => -1,
                            'orderby'        => 'title',
                            'order'          => 'ASC',
                        ),
                        'required' => array( 0 => 'product_display', 1 => 'equals', 2 => 'on' ),
                        'force_output' => true
                    ),
                    array(
                        'title' => esc_html__('Post Title', 'mouno'),
                        'type'  => 'section',
                        'id' => 'product_title_h',
                        'indent' => true,
                    ),
                ),
                mouno_post_title_opts('product'),
                array(
                    array(
                        'id' => 'sg_breadcrumb_product_title_h',
                        'title' => esc_html__('Breadcrumb', 'mouno'),
                        'type'  => 'section',
                        'indent' => true,
                    ),
                    array(
                        'id'       => 'sg_product_breadcrumb',
                        'type'     => 'button_set',
                        'title'    => esc_html__('Post Title', 'mouno'),
                        'options'  => array(
                            'default' => esc_html__('Use Post Title', 'mouno'),
                            'custom'  => esc_html__('Use Custom Title', 'mouno'),
                        ),
                        'default'  => 'default',
                    ),            
                    array(
                        'id'      => 'custom_sg_product_breadcrumb',
                        'type'    => 'text',
                        'title'   => esc_html__('Custom Post Title', 'mouno'),
                        'default' => esc_html__('Product Details', 'mouno'),
                        'required' => array( 0 => 'sg_product_breadcrumb', 1 => 'equals', 2 => 'custom' ),
                    ),
                ),
                array(
                    array(
                        'id'       => 'single_img_size',
                        'type'     => 'dimensions',
                        'title'    => esc_html__('Image Size', 'mouno'),
                        'unit'     => 'px',
                    ),
                    array(
                        'id'       => 'product_social_share',
                        'type'     => 'switch',
                        'title'    => esc_html__('Social Share', 'mouno'),
                        'default'  => false
                    ),
                )
            )
        ));
    }
}
