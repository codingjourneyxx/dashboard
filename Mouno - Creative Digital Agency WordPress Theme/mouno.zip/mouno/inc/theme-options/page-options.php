<?php
 
add_action( 'pxl_post_metabox_register', 'mouno_page_options_register' );
function mouno_page_options_register( $metabox ) {
 
	$panels = [
		'post' => [
			'opt_name'            => 'post_option',
			'display_name'        => esc_html__( 'Post Options', 'mouno' ),
			'show_options_object' => false,
			'context'  => 'advanced',
			'priority' => 'default',
			'sections'  => [
				'post_settings' => [
					'title'  => esc_html__( 'Post Options', 'mouno' ),
					'icon'   => 'el el-cog',
					'fields' => array(
						mouno_sidebar_options(['prefix' => 'post', 'page_option' => true, 'default' => 'inherit']),

						array(
							'id'             => 'content_spacing',
							'type'           => 'spacing',
							'output'         => array( '#pxl-wrapper #pxl-main' ),
							'right'          => false,
							'left'           => false,
							'mode'           => 'padding',
							'units'          => array( 'px' ),
							'units_extended' => 'false',
							'title'          => esc_html__( 'Spacing Top/Bottom', 'mouno' ),
							'default'        => array(
								'padding-top'    => '',
								'padding-bottom' => '',
								'units'          => 'px',
							)
						),
					)
				]
			]
		],
		'page' => [
			'opt_name'            => 'pxl_page_options',
			'display_name'        => esc_html__( 'Page Options', 'mouno' ),
			'show_options_object' => false,
			'context'  => 'advanced',
			'priority' => 'default',
			'sections'  => [
				'header' => [
					'title'  => esc_html__( 'Header', 'mouno' ),
					'icon'   => 'el-icon-website',
					'fields' => array_merge(
				        mouno_header_opts([
							'default'         => true,
							'default_value'   => '-1'
						]),
						mouno_header_mobile_opts([
							'default'         => true,
							'default_value'   => '-1'
						]),
						array(
							array(
				                'id'       => 'header_display',
				                'type'     => 'button_set',
				                'title'    => esc_html__('Header Display', 'mouno'),
				                'options'  => array(
				                    'show' => esc_html__('Show', 'mouno'),
				                    'hide'  => esc_html__('Hide', 'mouno'),
				                ),
				                'default'  => 'show',
				            ),
				            array(
				                'id'       => 'page_mobile_style',
				                'type'     => 'button_set',
				                'title'    => esc_html__('Mobile Style', 'mouno'),
				                'options'  => array(
				                    'inherit'  => esc_html__('Inherit', 'mouno'),
				                    'light'  => esc_html__('Light', 'mouno'),
				                    'dark'  => esc_html__('Dark', 'mouno'),
				                ),
				                'default'  => 'inherit',
				            ),
				            array(
				           		'id'       => 'logo_m',
					            'type'     => 'media',
					            'title'    => esc_html__('Mobile Logo Dark', 'mouno'),
					            'default'  => '',
					            'url'      => false,
					        ),
					        array(
				           		'id'       => 'logo_light_m',
					            'type'     => 'media',
					            'title'    => esc_html__('Mobile Logo Light', 'mouno'),
					            'default'  => '',
					            'url'      => false,
					        ),
					        array(
				                'id'       => 'p_menu',
				                'type'     => 'select',
				                'title'    => esc_html__( 'Menu', 'mouno' ),
				                'options'  => mouno_get_nav_menu_slug(),
				                'default' => '',
				                'description' => 'When you select Custom Menu. The custom menu will apply to the entire layout when you use Case Nav Menu widget in Elementor and Menu on header layout in Mobile.'
				            ),
					    ),
					    array(
				            array(
				                'id'       => 'sticky_scroll',
				                'type'     => 'button_set',
				                'title'    => esc_html__('Sticky Scroll', 'mouno'),
				                'options'  => array(
				                    '-1' => esc_html__('Inherit', 'mouno'),
									'scroll-up' => esc_html__('Scroll Up', 'mouno'),
									'scroll-down'  => esc_html__('Scroll Down', 'mouno'),
				                ),
				                'default'  => '-1',
				            ),
				            array(
				                'id'       => 'header_margin',
				                'type'     => 'spacing',
				                'mode'     => 'margin',
				                'title'    => esc_html__('Margin', 'mouno'),
				                'width'    => false,
				                'unit'     => 'px',
				                'output'    => array('#pxl-header-elementor .pxl-header-elementor-main'),
				            ),
				        )
				    )
					 
				],
				'page_title' => [
					'title'  => esc_html__( 'Page Title', 'mouno' ),
					'icon'   => 'el el-indent-left',
					'fields' => array_merge(
				        mouno_page_title_opts([
							'default'         => true,
							'default_value'   => '-1'
						]),
				        array(
				        	array(
					            'id' => 'page_title_custom',
					            'type' => 'text',
					            'title' => esc_html__('Page Title Custom', 'mouno'),
					        ),
					    ),
				    ),
				],
				'content' => [
					'title'  => esc_html__( 'Content', 'mouno' ),
					'icon'   => 'el-icon-pencil',
					'fields' => array(
						mouno_sidebar_options(['prefix' => 'page', 'default' => 'disable']),
						array(
							'id'             => 'content_spacing',
							'type'           => 'spacing',
							'output'         => array( '#pxl-wrapper #pxl-main' ),
							'right'          => false,
							'left'           => false,
							'mode'           => 'padding',
							'units'          => array( 'px' ),
							'units_extended' => 'false',
							'title'          => esc_html__( 'Spacing Top/Bottom', 'mouno' ),
							'default'        => array(
								'padding-top'    => '',
								'padding-bottom' => '',
								'units'          => 'px',
							)
						), 
					)
				],
				'footer' => [
					'title'  => esc_html__( 'Footer', 'mouno' ),
					'icon'   => 'el el-website',
					'fields' => array_merge(
				        mouno_footer_opts([
							'default'         => true,
							'default_value'   => '-1'
						]),
						array(
							array(
				                'id'       => 'footer_display',
				                'type'     => 'button_set',
				                'title'    => esc_html__('Footer Display', 'mouno'),
				                'options'  => array(
				                    'show' => esc_html__('Show', 'mouno'),
				                    'hide'  => esc_html__('Hide', 'mouno'),
				                ),
				                'default'  => 'show',
				            ),
							array(
				                'id'       => 'p_footer_fixed',
				                'type'     => 'button_set',
				                'title'    => esc_html__('Footer Fixed', 'mouno'),
				                'options'  => array(
				                    'inherit' => esc_html__('Inherit', 'mouno'),
				                    'on' => esc_html__('On', 'mouno'),
				                    'off' => esc_html__('Off', 'mouno'),
				                ),
				                'default'  => 'inherit',
				            ),
						)
				    )
				],
				'colors' => [
					'title'  => esc_html__( 'Colors', 'mouno' ),
					'icon'   => 'el el-website',
					'fields' => array_merge(
				        array(
				        	array(
							    'id'        => 'page_body_color',
							    'type'      => 'color',
							    'title'     => esc_html__('Body Background Color', 'mouno'),
							    'default'   => '',
							    'transparent' => false,
							    'output'    => array(
							        'background-color' => 'body',
							    )
							),
				        	array(
					            'id'          => 'primary_color',
					            'type'        => 'color',
					            'title'       => esc_html__('Primary Color', 'mouno'),
					            'transparent' => false,
					            'default'     => ''
					        ),
					        array(
					            'id'          => 'gradient_color',
					            'type'        => 'color_gradient',
					            'title'       => esc_html__('Gradient Color', 'mouno'),
					            'transparent' => false,
					            'default'  => array(
					                'from' => '',
					                'to'   => '', 
					            ),
					        ),
					    )
				    )
				],
				'extra' => [
					'title'  => esc_html__( 'Extra', 'mouno' ),
					'icon'   => 'el el-website',
					'fields' => array_merge(
				        array(
				        	array(
					            'id' => 'body_custom_class',
					            'type' => 'text',
					            'title' => esc_html__('Body Custom Class', 'mouno'),
					        ),
					    )
				    )
				]
			]
		],
		'portfolio' => [
			'opt_name'            => 'pxl_portfolio_options',
			'display_name'        => esc_html__( 'Portfolio Options', 'mouno' ),
			'show_options_object' => false,
			'context'  => 'advanced',
			'priority' => 'default',
			'sections'  => [
				'header' => [
					'title'  => esc_html__( 'General', 'mouno' ),
					'icon'   => 'el-icon-website',
					'fields' => array_merge(
						array(
					        array(
								'id'             => 'content_spacing',
								'type'           => 'spacing',
								'output'         => array( '#pxl-wrapper #pxl-main' ),
								'right'          => false,
								'left'           => false,
								'mode'           => 'padding',
								'units'          => array( 'px' ),
								'units_extended' => 'false',
								'title'          => esc_html__( 'Content Spacing Top/Bottom', 'mouno' ),
								'default'        => array(
									'padding-top'    => '',
									'padding-bottom' => '',
									'units'          => 'px',
								)
							),
						)
				    )
				],
			]
		],
		'service' => [
			'opt_name'            => 'pxl_service_options',
			'display_name'        => esc_html__( 'Service Options', 'mouno' ),
			'show_options_object' => false,
			'context'  => 'advanced',
			'priority' => 'default',
			'sections'  => [
				'header' => [
					'title'  => esc_html__( 'General', 'mouno' ),
					'icon'   => 'el-icon-website',
					'fields' => array_merge(
						array(
							array(
					            'id'=> 'service_external_link',
					            'type' => 'text',
					            'title' => esc_html__('External Link', 'mouno'),
					            'validate' => 'url',
					            'default' => '',
					        ),
							array(
					            'id'=> 'service_features_list',
					            'type' => 'multi_text',
					            'title' => esc_html__('Features List', 'mouno'),
					            'add_text' => 'Add More',
					        ),
					        array(
					            'id'       => 'service_icon_type',
					            'type'     => 'button_set',
					            'title'    => esc_html__('Icon Type', 'mouno'),
					            'options'  => array(
					                'icon'  => esc_html__('Icon', 'mouno'),
					                'image'  => esc_html__('Image', 'mouno'),
					            ),
					            'default'  => 'icon'
					        ),
					        array(
					            'id'       => 'service_icon_font',
					            'type'     => 'pxl_iconpicker',
					            'title'    => esc_html__('Icon', 'mouno'),
					            'required' => array( 0 => 'service_icon_type', 1 => 'equals', 2 => 'icon' ),
            					'force_output' => true
					        ),
					        array(
					            'id'       => 'service_icon_img',
					            'type'     => 'media',
					            'title'    => esc_html__('Icon Image', 'mouno'),
					            'default' => '',
					            'required' => array( 0 => 'service_icon_type', 1 => 'equals', 2 => 'image' ),
				            	'force_output' => true
					        ),
					        array(
								'id'             => 'content_spacing',
								'type'           => 'spacing',
								'output'         => array( '#pxl-wrapper #pxl-main' ),
								'right'          => false,
								'left'           => false,
								'mode'           => 'padding',
								'units'          => array( 'px' ),
								'units_extended' => 'false',
								'title'          => esc_html__( 'Content Spacing Top/Bottom', 'mouno' ),
								'default'        => array(
									'padding-top'    => '',
									'padding-bottom' => '',
									'units'          => 'px',
								)
							),
						),
						// mouno_footer_opts([
						// 	'default'         => true,
						// 	'default_value'   => '-1'
						// ])
				    )
				],
			]
		],

		'team' => [
			'opt_name'            => 'pxl_team_options',
			'display_name'        => esc_html__( 'Team Options', 'mouno' ),
			'show_options_object' => false,
			'context'  => 'advanced',
			'priority' => 'default',
			'sections'  => [
				'info' => [
					'title'  => esc_html__( 'Info', 'mouno' ),
					'icon'   => 'eicon-user-circle-o',
					'fields' => array(					
						array(
							'id'=> 'team_position',
							'type' => 'text',
							'title' => esc_html__('Position', 'mouno'),
							'placeholder' => esc_html__('Head Of Operation', 'mouno'),
						),
						array(
							'id'=> 'team_email',
							'type' => 'text',
							'title' => esc_html__('Email', 'mouno'),
							'placeholder' => esc_html__('user@gmail.com', 'mouno'),
						),
						array(
							'id'=> 'team_phone_number',
							'type' => 'text',
							'title' => esc_html__('Phone Number', 'mouno'),
							'placeholder' => esc_html__('0126 032 001', 'mouno'),
						),
						array(
							'id'=> 'team_address',
							'type' => 'text',
							'title' => esc_html__('Address', 'mouno'),
							'placeholder' => esc_html__('231, Utah Downtown Mall, USA', 'mouno'),
						),
					),
				],
				'socials' => [
					'title'  => esc_html__( 'Social', 'mouno' ),
					'icon'   => 'eicon-social-icons',
					'fields' => array( 
						array(
							'id'             => 'repeater-field-id',
							'type'           => 'repeater',
							'title'          => esc_html__( 'Title', 'mouno' ),
							'subtitle'       => esc_html__( '', 'mouno' ),
							'desc'           => esc_html__( '', 'mouno' ),
							'fields'         => array(
								array(
									'id'          => 'title_field',
									'type'        => 'text',
									'placeholder' => esc_html__( 'Title', 'mouno' ),
								),
							),
						),
						array(
							'id' => 'team_social',
							'type' => 'select',
							'multi' => true,
							'title' => __('Social Share', 'mouno'),
							'options' => array(
								'_facebook'  => __('Facebook','mouno'),
								'_twitter'   => __('Twitter','mouno'),
								'_instagram' => __('Instagram','mouno'), 
								'_pinterest' => __('Pinterest','mouno'), 
								'_youtube'   => __('Youtube','mouno'), 
								'_linkedin'  => __('Linkedin','mouno'), 
							), 
							'default'  => array('_facebook','_twitter','_instagram','_pinterest', '_youtube')
						), 
						array(
							'id'       => 'link_social_facebook',
							'title'    => esc_html__('Link Facebook', 'mouno'),
							'type'     => 'text',
							'default'  => '#',
							'required' => array( 0 => 'team_social', 1 => 'equals', 2 => '_facebook' ),
						),
						array(
							'id'       => 'link_social_twitter',
							'title'    => esc_html__('Link Twitter', 'mouno'),
							'type'     => 'text',
							'default'  => '#',
							'required' => array( 0 => 'team_social', 1 => 'equals', 2 => '_twitter' ),
						),
						array(
							'id'       => 'link_social_instagram',
							'title'    => esc_html__('Link Instagram', 'mouno'),
							'type'     => 'text',
							'default'  => '#',
							'required' => array( 0 => 'team_social', 1 => 'equals', 2 => '_instagram' ),
						),
						array(
							'id'       => 'link_social_pinterest',
							'title'    => esc_html__('Link Pinterest', 'mouno'),
							'type'     => 'text',
							'default'  => '#',
							'required' => array( 0 => 'team_social', 1 => 'equals', 2 => '_pinterest' ),
						),
						array(
							'id'       => 'link_social_youtube',
							'title'    => esc_html__('Link Youtube', 'mouno'),
							'type'     => 'text',
							'default'  => '#',
							'required' => array( 0 => 'team_social', 1 => 'equals', 2 => '_youtube' ),
						),
						array(
							'id'       => 'link_social_linkedin',
							'title'    => esc_html__('Link Linkedin', 'mouno'),
							'type'     => 'text',
							'default'  => '#',
							'required' => array( 0 => 'team_social', 1 => 'equals', 2 => '_linkedin' ),
						),
					),
				],	
			],
		],

		'pxl-template' => [ //post_type
			'opt_name'            => 'pxl_hidden_template_options',
			'display_name'        => esc_html__( 'Template Options', 'mouno' ),
			'show_options_object' => false,
			'context'  => 'advanced',
			'priority' => 'default',
			'sections'  => [
				'header' => [
					'title'  => esc_html__( 'General', 'mouno' ),
					'icon'   => 'el-icon-website',
					'fields' => array(
						array(
							'id'    => 'template_type',
							'type'  => 'select',
							'title' => esc_html__('Type', 'mouno'),
				            'options' => [
				            	'df'       	     => esc_html__('None', 'mouno'), 
								'header'         => esc_html__('Header Desktop', 'mouno'),
								'header-mobile'  => esc_html__('Header Mobile', 'mouno'),
								'footer'         => esc_html__('Footer', 'mouno'), 
								'mega-menu'      => esc_html__('Mega Menu', 'mouno'), 
								'page-title'     => esc_html__('Page Title', 'mouno'), 
								'post-title'     => esc_html__('Post Title', 'mouno'), 
								'hidden-panel'   => esc_html__('Hidden Panel', 'mouno'),
								'popup'          => esc_html__('Popup', 'mouno'),
								'page'           => esc_html__('Page', 'mouno'),
				            ],
				            'default' => 'df',
				        ),
				        array(
							'id'    => 'header_type',
							'type'  => 'select',
							'title' => esc_html__('Header Type', 'mouno'),
				            'options' => [
				            	'pxl-header-default'       	   => esc_html__('Default', 'mouno'), 
								'pxl-header-transparent'       => esc_html__('Transparent', 'mouno'),
				            ],
				            'default' => 'pxl-header-default',
				            'indent' => true,
                			'required' => array( 0 => 'template_type', 1 => 'equals', 2 => 'header' ),
				        ),
					),
				    
				],
			]
		],
	];
 
	$metabox->add_meta_data( $panels );
}
 