<?php
/**
 * @package Case-Themes
 */

dynamic_sidebar( mouno()->get_sidebar() );