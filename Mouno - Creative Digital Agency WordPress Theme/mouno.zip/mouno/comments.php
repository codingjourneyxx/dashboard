<?php
/**
 * @package Case-Themes
 */

if ( post_password_required() ) {
    return;
    } ?>

    <div id="comments" class="comments-area">
        <?php
        if ( have_comments() ) : ?>
            <div class="comment-wrapper">
                <h3 class="comment-title">
                    <span class="title-text"><?php echo esc_html('Comments', 'mouno'); ?></span>
                </h3>

                <?php the_comments_navigation(); ?>

                <ul class="comment-list">
                    <?php
                        wp_list_comments( array(
                            'style'      => 'ul',
                            'short_ping' => true,
                            'callback'   => 'mouno_comment_list',
                            'max_depth'  => 3
                        ) );
                    ?>
                </ul>

                <?php the_comments_navigation(); ?>
            </div>
            <?php if ( ! comments_open() ) : ?>
                <p class="no-comments"><?php esc_html_e( 'Comments are closed.', 'mouno' ); ?></p>
            <?php
            endif;

        endif;

    $args = array(
            'id_form'           => 'commentform',
            'id_submit'         => 'submit',
            'class_submit'         => 'btn pxl-btn-split',
            'title_reply'       => esc_attr__( 'Make a Comment', 'mouno'),
            'title_reply_to'    => esc_attr__( 'Make a Comment To ', 'mouno') . '%s',
            'cancel_reply_link' => esc_attr__( 'Cancel Comment', 'mouno'),
            'submit_button'     => '<button name="%1$s" type="submit" id="%2$s" class="%3$s" />
            <span class="pxl-btn-icon icon-duplicated">
                <svg xmlns="http://www.w3.org/2000/svg" width="38" height="38" viewBox="0 0 38 38" fill="none">
                    <path d="M26.673 23.8894L26.5877 12.0397C26.5877 11.5282 26.1899 11.1304 25.6784 11.1304L13.8287 11.0451C13.3172 11.0451 12.9194 11.443 12.9194 11.9545C12.9194 12.466 13.3172 12.8638 13.8287 12.8638L23.4619 12.9491L11.3849 25.0261C11.0439 25.3671 11.0439 25.9354 11.3849 26.2764C11.7259 26.6174 12.3226 26.6458 12.6636 26.3048L24.7975 14.171L24.8828 23.9178C24.8828 24.1452 24.9964 24.3725 25.1669 24.543C25.3374 24.7135 25.5647 24.8272 25.8205 24.7988C26.2752 24.7988 26.7014 24.3725 26.673 23.8894Z" fill="currentcolor"/>
                </svg>
            </span>
            <span class="pxl-btn-text">'.esc_html__('Send Message', 'mouno').'</span>
            <span class="pxl-btn-icon icon-main">
                <svg xmlns="http://www.w3.org/2000/svg" width="38" height="38" viewBox="0 0 38 38" fill="none">
                    <path d="M26.673 23.8894L26.5877 12.0397C26.5877 11.5282 26.1899 11.1304 25.6784 11.1304L13.8287 11.0451C13.3172 11.0451 12.9194 11.443 12.9194 11.9545C12.9194 12.466 13.3172 12.8638 13.8287 12.8638L23.4619 12.9491L11.3849 25.0261C11.0439 25.3671 11.0439 25.9354 11.3849 26.2764C11.7259 26.6174 12.3226 26.6458 12.6636 26.3048L24.7975 14.171L24.8828 23.9178C24.8828 24.1452 24.9964 24.3725 25.1669 24.543C25.3374 24.7135 25.5647 24.8272 25.8205 24.7988C26.2752 24.7988 26.7014 24.3725 26.673 23.8894Z" fill="currentcolor"/>
                </svg>
            </span>
            </button>',
            'comment_notes_before' => esc_html__('Your email address will not be published. Required field are marked*', 'mouno'),
            'fields' => apply_filters( 'comment_form_default_fields', array(
                    'author' =>
                    '<div class="form-control-group">
                    <div class="comment-form-author form-control">'.
                    '<input id="author" name="author" type="text" value="' . esc_attr( $commenter['comment_author'] ) .
                    '" size="30" placeholder="'.esc_attr__('Name*', 'mouno').'"/></div>',

                    'email' =>
                    '<div class="comment-form-email form-control">'.
                    '<input id="email" name="email" type="text" value="' . esc_attr(  $commenter['comment_author_email'] ) .
                    '" size="30" placeholder="'.esc_attr__('Email Address*', 'mouno').'"/></div></div>',
            )
            ),
            'comment_field' =>  '<div class="comment-form-comment form-control"><textarea id="comment" name="comment" placeholder="'.esc_attr__('Comment Here', 'mouno').'" aria-required="true">' .
            '</textarea></div>',
    );
    comment_form($args); ?>
</div>