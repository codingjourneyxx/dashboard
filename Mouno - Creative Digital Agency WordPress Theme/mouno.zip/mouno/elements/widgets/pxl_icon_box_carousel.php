<?php
pxl_add_custom_widget(
    array(
        'name' => 'pxl_icon_box_carousel',
        'title' => esc_html__('Case Icon Box Carousel', 'mouno' ),
        'icon' => 'eicon-carousel',
        'categories' => array('pxltheme-core'),
        'scripts' => array(
            'swiper',
            'pxl-swiper',
        ),
        'params' => array(
            'sections' => array(
                array(
                    'name' => 'tab_icon_box_layout',
                    'label' => esc_html__('Layout', 'mouno'),
                    'tab' => \Elementor\Controls_Manager::TAB_LAYOUT,
                    'controls' => array(
                        array(
                            'name' => 'layout',
                            'label' => esc_html__('Layout', 'mouno'),
                            'type' => 'layoutcontrol',
                            'default' => '1',
                            'options' => array(
                                '1' => array(
                                    'label' => esc_html__('Layout 1', 'mouno'),
                                    'image' => get_template_directory_uri() . '/elements/assets/img/pxl_accordion/layout1.jpg',
                                ),
                                '2' => array(
                                    'label' => esc_html__('Layout 2', 'mouno'),
                                    'image' => get_template_directory_uri() . '/elements/assets/img/pxl_accordion/layout1.jpg',
                                ),
                            ),
                        ),
                    ),
                ),
                array(
                    'name' => 'tab_icon_box_content',
                    'label' => esc_html__('Icon Box', 'mouno' ),
                    'tab' => 'content',
                    'controls' => array(   
                        array(
                            'name' => 'layout_style',
                            'label' => esc_html__('Layout Style', 'mouno'),
                            'type' => 'select',
                            'default' => 'h4',
                            'options' => [
                                'icon-box-default' => esc_html__('Default', 'mouno'),
                                'icon-box-style1' => esc_html__('Style 1', 'mouno'),
                            ],
                        ),
                        array(
                            'name' => 'title_tag',
                            'label' => esc_html__('Title HTML Tag', 'mouno'),
                            'type' => 'select',
                            'default' => 'h4',
                            'options' => [
                                'h1' => esc_html__('H1', 'mouno'),
                                'h2' => esc_html__('H2', 'mouno'),
                                'h3' => esc_html__('H3', 'mouno'),
                                'h4' => esc_html__('H4', 'mouno'),
                                'h5' => esc_html__('H5', 'mouno'),
                                'h6' => esc_html__('H6', 'mouno'),
                                'div' => esc_html__('div', 'mouno'),
                                'p'  => esc_html__('p', 'mouno'),
                                'span' => esc_html__('span', 'mouno'),
                            ],
                        ),
                        array(
                            'name' => 'icon_boxs',
                            'label' => esc_html__('Icon Boxs', 'mouno' ),
                            'type' => 'repeater',
                            'controls' => array(
                                array(
                                    'name' => 'icon_type',
                                    'label' => esc_html__('Icon Type', 'mouno'),
                                    'type' => 'select',
                                    'default' => 'icon',
                                    'options' => [
                                        'icon' => esc_html__('Icon', 'mouno'),
                                        'index' => esc_html__('Index', 'mouno'),
                                    ],
                                ),
                                array(
                                    'name' => '_icon',
                                    'label' => esc_html__('Icon', 'mouno'),
                                    'type' => \Elementor\Controls_Manager::ICONS,
                                    'fa4compatibility' => 'icon',
                                    'condition' => [
                                        'icon_type' => 'icon',
                                    ],
                                ),
                                array(
                                    'name' => 'title',
                                    'label' => esc_html__('Title', 'mouno'),
                                    'type' => 'text',
                                    'label_block' => true,
                                ),
                                array(
                                    'name' => 'desc',
                                    'label' => esc_html__('Description', 'mouno'),
                                    'type' => \Elementor\Controls_Manager::TEXTAREA,
                                    'rows' => 10,
                                ),
                                array(
                                    'name' => 'link',
                                    'label' => esc_html__('Link', 'mouno'),
                                    'type' => \Elementor\Controls_Manager::URL,
                                    'label_block' => true,
                                    'condition' => [
                                        'icon_type' => 'icon',
                                    ],
                                ),
                            ),
                            'title_field' => '{{{ title }}}',
                            'default' => [
                                [
                                    '_icon' => [
                                        'value' => 'fas fa-star',
                                        'library' => 'Font Awesome 5 Free',
                                    ],
                                    'title' => esc_html__('This is heading 1', 'mouno'),
                                    'desc' => esc_html__('Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.', 'mouno'),
                                ],
                                [
                                    '_icon' => [
                                        'value' => 'fas fa-star',
                                        'library' => 'Font Awesome 5 Free',
                                    ],
                                    'title' => esc_html__('This is heading 2', 'mouno'),
                                    'desc' => esc_html__('Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.', 'mouno'),
                                ],
                                [
                                    '_icon' => [
                                        'value' => 'fas fa-star',
                                        'library' => 'Font Awesome 5 Free',
                                    ],
                                    'title' => esc_html__('This is heading 3', 'mouno'),
                                    'desc' => esc_html__('Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.', 'mouno'),
                                ],
                            ],
                        ),
                    ),
                ),
                array(
                    'name' => 'tab_swiper_add_otps',
                    'label' => esc_html__('Addtional Options', 'mouno'),
                    'tab' => 'content',
                    'controls' => array(
                        array(
                            'name' => 'group_carousel',
                            'label' => esc_html__('Group Carousel', 'mouno'),
                            'type' => 'switcher',
                            'default' => '',
                        ),
                        array(
                            'name' => 'group_carousel_class',
                            'type' => 'text',
                            'label' => esc_html__('Enter Common Class', 'mouno'),
                            'placeholder' => esc_html__('example-class', 'mouno'),
                            'condition' => [
                                'group_carousel!' => '',
                            ],
                        ),
                        swiper_controls_options(),
                    ),
                ),

                array(
                    'name' => 'tab_style_general',
                    'label' => esc_html__('General', 'mouno'),
                    'tab' => \Elementor\Controls_Manager::TAB_STYLE,
                    'controls' => array(
                        array(
                            'name' => 'icon_position',
                            'label' => esc_html__('Icon Position', 'mouno'),
                            'type' => \Elementor\Controls_Manager::CHOOSE,
                            'control_type' => 'responsive',
                            'options' => array(
                                'row' =>[
                                    'title' => esc_html__('Left', 'mouno'),
                                    'icon' => 'eicon-h-align-left',
                                ],
                                'column' => [
                                    'title' => esc_html__('Top', 'mouno'),
                                    'icon' => 'eicon-v-align-top'
                                ],
                                'row-reverse' => [
                                    'title' => esc_html__('Right', 'mouno'),
                                    'icon' => 'eicon-h-align-right',
                                ],
                            ),
                            'selectors' => [
                                '{{WRAPPER}} .pxl-icon-box-carousel .pxl-swiper-slide .pxl-slide-inner' => '--pxl-flex-direction: {{VALUE}};'
                            ],
                        ),
                        array(
                            'name' => 'content_alignment',
                            'label' => esc_html__('Alignment', 'mouno' ),
                            'type' => \Elementor\Controls_Manager::CHOOSE,
                            'control_type' => 'responsive',
                            'options' => [
                                'left' =>  [
                                    'title' => esc_html__('Left', 'mouno'),
                                    'icon' => 'eicon-text-align-left',
                                ],
                                'center' =>  [
                                    'title' => esc_html__('Center', 'mouno'),
                                    'icon' => 'eicon-text-align-center',
                                ],
                                'right' =>  [
                                    'title' => esc_html__('Right', 'mouno'),
                                    'icon' => 'eicon-text-align-right',
                                ],
                                'justify' =>  [
                                    'title' => esc_html__('Justify', 'mouno'),
                                    'icon' => 'eicon-text-align-justify',
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-icon-box-carousel .pxl-swiper-slide .pxl-slide-inner' => 'text-align: {{VALUE}};'
                            ],
                        ),
                        array(
                            'name' => 'max_w',
                            'label' => esc_html__('Max Width', 'mouno'),
                            'type' => 'slider',
                            'control_type' => 'responsive',
                            'size_units' => ['px', '%', 'rem', 'em', 'custom'],
                            'separator' => 'before',
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 1000,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-icon-box-carousel .pxl-swiper-slide .pxl-slide-inner' => 'max-width: {{SIZE}}{{UNIT}};',
                            ],
                        ),
                        array(
                            'name' => 'icon_spacing',
                            'label' => esc_html__('Icon Spacing', 'mouno'),
                            'type' => 'slider',
                            'control_type' => 'responsive',
                            'size_units' => ['px', '%', 'rem', 'em', 'custom'],
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 1000,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-icon-box-carousel .pxl-swiper-slide .pxl-slide-inner' => 'gap: {{SIZE}}{{UNIT}};',
                            ],
                        ),
                        array(
                            'name' => 'content_spacing',
                            'label' => esc_html__('Content Spacing', 'mouno'),
                            'type' => 'slider',
                            'control_type' => 'responsive',
                            'size_units' => ['px', '%', 'rem', 'em', 'custom'],
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 1000,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-icon-box-carousel .pxl-swiper-slide .pxl-slide-inner .pxl-item-title' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                            ],
                        ),
                    ),
                ),

                array(
                    'name' => 'tab_icon_box_anim',
                    'label' => esc_html__('Animation', 'mouno'),
                    'tab' => 'style',
                    'controls' => mouno_get_animation_options([
                        'selector' => '{{WRAPPER}} .pxl-icon-box-carousel .pxl-swiper-slide, '
                    ]),
                ),
            ),
        ),
    ),
    mouno_get_class_widget_path()
);