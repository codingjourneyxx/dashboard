<?php

pxl_add_custom_widget(
    array(
        'name' => 'pxl_navigation_menu',
        'title' => esc_html__('Case Nav Menu', 'mouno'),
        'icon' => 'eicon-nav-menu',
        'categories' => array('pxltheme-core'),
        'scripts' => array(
            'mouno-effects',
        ),
        'params' => array(
            'sections' => array(
                array(
                    'name' => 'tab_nav_menu_layout',
                    'label' => esc_html__('Nav Menu', 'mouno'),
                    'tab' => 'layout',
                    'controls' => array(
                        array(
                            'name' => 'menu',
                            'label' => esc_html__('Select Menu', 'mouno'),
                            'type' => 'select',
                            'options' => mouno_get_menu_options(),
                        ),
                        array(
                            'name' => 'menu_style',
                            'label' => esc_html__('Menu Style', 'mouno' ),
                            'type' => 'select',
                            'options' => [
                                'menu-default'  =>  esc_html__('Menu Default', 'mouno'),
                                'menu-panel'  =>  esc_html__('Menu Panel', 'mouno'),
                                'menu-custom'  =>  esc_html__('Menu Custom', 'mouno'),
                            ],
                            'default' => 'menu-default',
                        ),
                        array(
                            'name' => 'menu_max_height',
                            'label' => esc_html__('Max Height', 'mouno'),
                            'type' => 'slider',
                            'size_units' => ['px', 'custom'],
                            'control_type' => 'responsive',
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 1000,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-navigation-menu-wrapper .pxl-menu-primary' => 'max-height: {{SIZE}}{{UNIT}};',
                            ],
                            'condition' => [
                                'menu_style' => 'menu-panel',
                            ],
                        ),
                        array(
                            'name' => 'menu_wrap',
                            'label' => esc_html__('Menu Wrap', 'mouno' ),
                            'type' => 'choose',
                            'separator' => 'before',
                            'control_type' => 'responsive',
                            'options' => [
                                'wrap' => [
                                    'title' => esc_html__('Wrap', 'mouno' ),
                                    'icon' => 'eicon-wrap',
                                ],
                                'nowrap' => [
                                    'title' => esc_html__('No Wrap', 'mouno' ),
                                    'icon' => 'eicon-nowrap',
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-navigation-menu-wrapper .pxl-menu-primary' => 'flex-wrap: {{VALUE}};',
                            ],
                        ),
                        array(
                            'name' => 'menu_justify_content',
                            'label' => esc_html__('Justify Content', 'mouno' ),
                            'type' => 'choose',
                            'control_type' => 'responsive',
                            'options' => [
                                'start' => [
                                    'title' => esc_html__('Start', 'mouno' ),
                                    'icon' => 'eicon-justify-start-h',
                                ],
                                'center' => [
                                    'title' => esc_html__('Center', 'mouno' ),
                                    'icon' => 'eicon-justify-center-h',
                                ],
                                'end' => [
                                    'title' => esc_html__('End', 'mouno' ),
                                    'icon' => 'eicon-justify-end-h',
                                ],
                                'space-around' => [
                                    'title' => esc_html__('Space Around', 'mouno' ),
                                    'icon' => 'eicon-justify-space-around-h',
                                ],
                                'space-evenly' => [
                                    'title' => esc_html__('Space Evenly', 'mouno' ),
                                    'icon' => 'eicon-justify-space-evenly-h',
                                ],
                                'space-between' => [
                                    'title' => esc_html__('Space Between', 'mouno' ),
                                    'icon' => 'eicon-justify-space-between-h',
                                ],
                            ],
                            'label_block' => true,
                            'selectors' => [
                                '{{WRAPPER}} .pxl-navigation-menu-wrapper .pxl-menu-primary' => 'justify-content: {{VALUE}};',
                            ],
                        ),
                        array(
                            'name' => 'menu_spacing',
                            'label' => esc_html__('Gap', 'mouno'),
                            'type' => 'slider',
                            'size_units' => ['px', 'custom', 'custom'],
                            'control_type' => 'responsive',
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 1000,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-navigation-menu-wrapper .pxl-menu-primary' => 'gap: {{SIZE}}{{UNIT}};',
                            ],
                        ),
                        array(
                            'name' => 'menu_row_gap',
                            'label' => esc_html__('Row Gap', 'mouno'),
                            'type' => 'slider',
                            'size_units' => ['px', 'custom'],
                            'control_type' => 'responsive',
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 1000,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-navigation-menu-wrapper .pxl-menu-primary' => 'row-gap: {{SIZE}}{{UNIT}};',
                            ],
                            'condition' => [
                                'menu_wrap' => 'wrap',
                            ],
                        ),
                        array(
                            'name' => 'menu_h',
                            'label' => esc_html__('Menu Height', 'mouno'),
                            'type' => 'slider',
                            'size_units' => ['px', 'custom'],
                            'control_type' => 'responsive',
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 1000,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-navigation-menu-wrapper .pxl-menu-primary > li' => 'height: {{SIZE}}{{UNIT}};',
                            ],
                        ),
                    ),
                ),
                array(
                    'name' => 'tab_nav_menu_style',
                    'label' => esc_html__('Menu', 'mouno'),
                    'tab' => 'style',
                    'controls' => array_merge(
                        array(
                            array(
                                'name'         => 'menu_typography',
                                'type'         => \Elementor\Group_Control_Typography::get_type(),
                                'control_type' => 'group',
                                'selector'     => '{{WRAPPER}} .pxl-navigation-menu-wrapper .pxl-menu-primary > li',
                            ),
                            array(
                                'name' => 'menu_controls',
                                'control_type' => 'tab',
                                'tabs' => [
                                    [
                                        'name' => 'menu_normal',
                                        'label' => esc_html__('Normal', 'mouno' ),
                                        'type' => 'tab',
                                        'controls' => [  
                                            array(
                                                'name'      => 'menu_color',
                                                'label'     => esc_html__('Text Color', 'mouno' ),
                                                'type'      => 'color',
                                                'selectors' => [
                                                    '{{WRAPPER}} .pxl-navigation-menu-wrapper .pxl-menu-primary > li > a' => 'color: {{VALUE}};',
                                                ],
                                            ),
                                            array(
                                                'name' => 'menu_stroke',
                                                'type' => \Elementor\Group_Control_Text_Stroke::get_type(),
                                                'control_type' => 'group',
                                                'selector' => '{{WRAPPER}} .pxl-navigation-menu-wrapper .pxl-menu-primary > li > a',
                                            ),
                                            array(
                                                'name' => 'menu_shadow',
                                                'type' => \Elementor\Group_Control_Text_Shadow::get_type(),
                                                'control_type' => 'group',
                                                'selector' => '{{WRAPPER}} .pxl-navigation-menu-wrapper .pxl-menu-primary > li > a',
                                            ),
                                            array(
                                                'name' => 'menu_bg',
                                                'label' => esc_html__('Background Color', 'mouno' ),
                                                'type' => \Elementor\Group_Control_Background::get_type(),
                                                'separator' => 'before',
                                                'control_type' => 'group',
                                                'types' => [ 'classic', 'gradient' ],
                                                'selector' => '{{WRAPPER}} .pxl-navigation-menu-wrapper .pxl-menu-primary > li > a ',
                                            ),
                                            array(
                                                'name' => 'menu_border',
                                                'type' => \Elementor\Group_Control_Border::get_type(),
                                                'separator' => 'before',
                                                'control_type' => 'group', 
                                                'selector' => '{{WRAPPER}} .pxl-navigation-menu-wrapper .pxl-menu-primary > li > a',
                                            ),
                                            array(
                                                'name'         => 'menu_box_shadow',
                                                'label' => esc_html__( 'Box Shadow', 'mouno' ),
                                                'type'         => \Elementor\Group_Control_Box_Shadow::get_type(),
                                                'control_type' => 'group',
                                                'selector'     => '{{WRAPPER}} .pxl-navigation-menu-wrapper .pxl-menu-primary > li > a',
                                            ),
                                            array(
                                                'name' => 'menu_border_radius',
                                                'label' => esc_html__('Border Radius', 'mouno' ),
                                                'type' => 'dimensions',
                                                'size_units' => [ 'px', 'custom' ],
                                                'selectors' => [
                                                    '{{WRAPPER}} .pxl-navigation-menu-wrapper .pxl-menu-primary > li > a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                                ],
                                            ),
                                            array(
                                                'name' => 'menu_padding',
                                                'label' => esc_html__('Padding', 'mouno' ),
                                                'type' => 'dimensions',
                                                'size_units' => [ 'px', 'custom' ],
                                                'control_type' => 'responsive',
                                                'separator' => 'before',
                                                'selectors' => [
                                                    '{{WRAPPER}} .pxl-navigation-menu-wrapper .pxl-menu-primary > li > a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                                ],
                                            ),
                                        ],
                                    ],
                                    [
                                        'name' => 'menu_hover',
                                        'label' => esc_html__('Hover', 'mouno' ),
                                        'type' => 'tab',
                                        'controls' => [
                                            array(
                                                'name' => 'menu_hover_style',
                                                'label' => esc_html__('Hover Style', 'mouno' ),
                                                'type' => 'select',
                                                'options' => [
                                                    'hover-text-default' => esc_html__('Default', 'mouno'),
                                                    'hover-underline-ltr' => esc_html__('Underline Left to Right', 'mouno'),
                                                    'hover-underline-rtl' => esc_html__('Underline Right to Left', 'mouno'),
                                                    'hover-underline-expand' => esc_html__('Underline Expand', 'mouno'),
                                                    'hover-underline-split' => esc_html__('Underline Split', 'mouno'),
                                                    'hover-popup-dot'    => esc_html__('Dot Popup', 'mouno'),
                                                    'hover-translate3d-direction'    => esc_html__('Translate 3d Direction', 'mouno'),
                                                ],
                                                'default' => 'hover-text-default',
                                            ),
                                            array(
                                                'name' => 'menu_hover_color',
                                                'label' => esc_html__('Text Color', 'mouno' ),
                                                'type' => 'color',
                                                'selectors' => [
                                                    '{{WRAPPER}} .pxl-navigation-menu-wrapper .pxl-menu-primary > li:hover > a, 
                                                    {{WRAPPER}} .pxl-navigation-menu-wrapper .pxl-menu-primary > li.current-menu-parent > a:not(.is-one-page), 
                                                    {{WRAPPER}} .pxl-navigation-menu-wrapper .pxl-menu-primary > li.current_page_item > a:not(.is-one-page), 
                                                    {{WRAPPER}} .pxl-navigation-menu-wrapper .pxl-menu-primary > li > a.pxl-onepage-active,
                                                    {{WRAPPER}} .pxl-navigation-menu-wrapper .pxl-menu-primary > li.active > a' => 'color: {{VALUE}};',
                                                ],
                                            ),
                                            array(
                                                'name' => 'menu_hover_stroke',
                                                'type' => \Elementor\Group_Control_Text_Stroke::get_type(),
                                                'control_type' => 'group',
                                                'selector' => '{{WRAPPER}} .pxl-navigation-menu-wrapper .pxl-menu-primary > li:hover > a, 
                                                    {{WRAPPER}} .pxl-navigation-menu-wrapper .pxl-menu-primary > li.current-menu-parent > a:not(.is-one-page), 
                                                    {{WRAPPER}} .pxl-navigation-menu-wrapper .pxl-menu-primary > li.current_page_item > a:not(.is-one-page), 
                                                    {{WRAPPER}} .pxl-navigation-menu-wrapper .pxl-menu-primary > li > a.pxl-onepage-active,
                                                    {{WRAPPER}} .pxl-navigation-menu-wrapper .pxl-menu-primary > li.active > a',
                                            ),
                                            array(
                                                'name' => 'menu_hover_shadow',
                                                'type' => \Elementor\Group_Control_Text_Shadow::get_type(),
                                                'control_type' => 'group',
                                                'selector' => '{{WRAPPER}} .pxl-navigation-menu-wrapper .pxl-menu-primary > li:hover > a, 
                                                    {{WRAPPER}} .pxl-navigation-menu-wrapper .pxl-menu-primary > li.current-menu-parent > a:not(.is-one-page), 
                                                    {{WRAPPER}} .pxl-navigation-menu-wrapper .pxl-menu-primary > li.current_page_item > a:not(.is-one-page), 
                                                    {{WRAPPER}} .pxl-navigation-menu-wrapper .pxl-menu-primary > li > a.pxl-onepage-active,
                                                    {{WRAPPER}} .pxl-navigation-menu-wrapper .pxl-menu-primary > li.active > a',
                                            ),
                                            array(
                                                'name' => 'menu_hover_bg',
                                                'label' => esc_html__('Background Color', 'mouno' ),
                                                'type' => \Elementor\Group_Control_Background::get_type(),
                                                'control_type' => 'group',
                                                'separator' => 'before',
                                                'types' => [ 'classic', 'gradient' ],
                                                'selector' => '{{WRAPPER}} .pxl-navigation-menu-wrapper .pxl-menu-primary > li > a .hover-item',
                                            ),
                                            array(
                                                'name' => 'menu_hover_border',
                                                'type' => \Elementor\Group_Control_Border::get_type(),
                                                'separator' => 'before',
                                                'control_type' => 'group', 
                                                'selector' => '{{WRAPPER}} .pxl-navigation-menu-wrapper .pxl-menu-primary > li:hover > a, 
                                                    {{WRAPPER}} .pxl-navigation-menu-wrapper .pxl-menu-primary > li.current-menu-parent > a:not(.is-one-page), 
                                                    {{WRAPPER}} .pxl-navigation-menu-wrapper .pxl-menu-primary > li.current_page_item > a:not(.is-one-page), 
                                                    {{WRAPPER}} .pxl-navigation-menu-wrapper .pxl-menu-primary > li > a.pxl-onepage-active,
                                                    {{WRAPPER}} .pxl-navigation-menu-wrapper .pxl-menu-primary > li.active > a',
                                            ),
                                            array(
                                                'name'         => 'menu_hover_box_shadow',
                                                'label' => esc_html__( 'Box Shadow', 'mouno' ),
                                                'type'         => \Elementor\Group_Control_Box_Shadow::get_type(),
                                                'control_type' => 'group',
                                                'selector'     => '{{WRAPPER}} .pxl-navigation-menu-wrapper .pxl-menu-primary > li:hover > a, 
                                                    {{WRAPPER}} .pxl-navigation-menu-wrapper .pxl-menu-primary > li.current-menu-parent > a:not(.is-one-page), 
                                                    {{WRAPPER}} .pxl-navigation-menu-wrapper .pxl-menu-primary > li.current_page_item > a:not(.is-one-page), 
                                                    {{WRAPPER}} .pxl-navigation-menu-wrapper .pxl-menu-primary > li > a.pxl-onepage-active,
                                                    {{WRAPPER}} .pxl-navigation-menu-wrapper .pxl-menu-primary > li.active > a',
                                            ),
                                            array(
                                                'name' => 'menu_hover_border_radius',
                                                'label' => esc_html__('Border Radius', 'mouno' ),
                                                'type' => 'dimensions',
                                                'size_units' => [ 'px', 'custom' ],
                                                'selectors' => [
                                                    '{{WRAPPER}} .pxl-navigation-menu-wrapper .pxl-menu-primary > li:hover > a, 
                                                    {{WRAPPER}} .pxl-navigation-menu-wrapper .pxl-menu-primary > li.current-menu-parent > a:not(.is-one-page), 
                                                    {{WRAPPER}} .pxl-navigation-menu-wrapper .pxl-menu-primary > li.current_page_item > a:not(.is-one-page), 
                                                    {{WRAPPER}} .pxl-navigation-menu-wrapper .pxl-menu-primary > li > a.pxl-onepage-active,
                                                    {{WRAPPER}} .pxl-navigation-menu-wrapper .pxl-menu-primary > li.active > a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                                ],
                                            ),
                                            array(
                                                'name' => 'menu_hover_padding',
                                                'label' => esc_html__('Padding', 'mouno' ),
                                                'type' => 'dimensions',
                                                'size_units' => [ 'px', 'custom' ],
                                                'control_type' => 'responsive',
                                                'separator' => 'before',
                                                'selectors' => [
                                                    '{{WRAPPER}} .pxl-navigation-menu-wrapper .pxl-menu-primary > li:hover > a, 
                                                    {{WRAPPER}} .pxl-navigation-menu-wrapper .pxl-menu-primary > li.current-menu-parent > a:not(.is-one-page), 
                                                    {{WRAPPER}} .pxl-navigation-menu-wrapper .pxl-menu-primary > li.current_page_item > a:not(.is-one-page), 
                                                    {{WRAPPER}} .pxl-navigation-menu-wrapper .pxl-menu-primary > li > a.pxl-onepage-active,
                                                    {{WRAPPER}} .pxl-navigation-menu-wrapper .pxl-menu-primary > li.active > a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                                ],
                                            ),
                                        ],
                                    ],
                                ],
                            ),
                        ),
                    ),
                ),
                array(
                    'name' => 'tab_style_submenu',
                    'label' => esc_html__('Submenu', 'mouno'),
                    'tab' => 'style',
                    'condition' => [
                        'menu_style!' => ['menu-vertical'],
                    ],
                    'controls' => array(
                        array(
                            'name' => 'submenu_box_h',
                            'label' => esc_html__("Box", 'mouno'),
                            'type' => 'heading',
                        ),
                        array(
                            'name' => 'submenu_show_effect',
                            'label' => esc_html__('Show Effect', 'mouno' ),
                            'type' => 'select',
                            'options' => [
                                'show-effect-fade'      => esc_html__('Fade', 'mouno'),
                                'show-effect-slideup'   => esc_html__('Slide Up', 'mouno'),
                                'show-effect-dropdown'  => esc_html__('Dropdown', 'mouno'),
                                'show-effect-slidedown' => esc_html__('Slide Down 3D', 'mouno'),
                                
                            ],
                            'default' => 'show-effect-slideup',
                        ),
                        array(
                            'name' => 'submenu_bg_color',
                            'type' => \Elementor\Group_Control_Background::get_type(),
                            'control_type' => 'group',
                            'types' => [ 'classic', 'gradient' ],
                            'selector' => '{{WRAPPER}} .pxl-header .pxl-menu-primary .sub-menu, 
                                {{WRAPPER}} .pxl-header .pxl-menu-primary .children',
                        ),
                        array(
                            'name' => 'submenu_box_border',
                            'type' => \Elementor\Group_Control_Border::get_type(),
                            'separator' => 'before',
                            'control_type' => 'group', 
                            'selector' => '{{WRAPPER}} .pxl-header .pxl-menu-primary .sub-menu, 
                                {{WRAPPER}} .pxl-header .pxl-menu-primary .children',
                        ),
                        array(
                            'name'         => 'submenu_box_shadow',
                            'label' => esc_html__( 'Box Shadow', 'mouno' ),
                            'type'         => \Elementor\Group_Control_Box_Shadow::get_type(),
                            'control_type' => 'group',
                            'selector'     => '{{WRAPPER}} .pxl-header .pxl-menu-primary .sub-menu, 
                                {{WRAPPER}} .pxl-header .pxl-menu-primary .children',
                        ),
                        array(
                            'name' => 'submenu_border_radius',
                            'label' => esc_html__('Border Radius', 'mouno' ),
                            'type' => 'dimensions',
                            'size_units' => [ 'px' ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-menu-primary .sub-menu, 
                                {{WRAPPER}} .pxl-menu-primary .children' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            ],
                        ),
                        array(
                            'name' => 'submenu_padding',
                            'label' => esc_html__('Padding', 'mouno' ),
                            'type' => 'dimensions',
                            'size_units' => [ 'px' ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-menu-primary .sub-menu, 
                                {{WRAPPER}} .pxl-menu-primary .children' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            ],
                        ),
                        array(
                            'name' => 'submenu_item_h',
                            'label' => esc_html__("Item", 'mouno'),
                            'type' => 'heading',
                        ),
                        array(
                            'name' => 'submenu_typography',
                            'type' => \Elementor\Group_Control_Typography::get_type(),
                            'control_type' => 'group',
                            'selector' => '{{WRAPPER}} .pxl-navigation-menu-wrapper .pxl-menu-primary li .sub-menu a',
                        ),
                        array(
                            'name' => 'submenu_control',
                            'control_type' => 'tab',
                            'tabs' => [
                                [
                                    'name' => 'submenu_normal',
                                    'label' => esc_html__('Normal', 'mouno' ),
                                    'type' => 'tab',
                                    'controls' => [  
                                        array(
                                            'name' => 'submenu_color',
                                            'label' => esc_html__('Color', 'mouno' ),
                                            'type' => 'color',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-navigation-menu-wrapper .pxl-menu-primary li .sub-menu li > a' => 'color: {{VALUE}};',
                                            ],
                                        ),
                                    ],
                                ],
                                [
                                    'name' => 'submenu_hover',
                                    'label' => esc_html__('Hover', 'mouno' ),
                                    'type' => 'tab',
                                    'controls' => [
                                        array(
                                            'name' => 'submenu_color_hover',
                                            'label' => esc_html__('Color', 'mouno' ),
                                            'type' => 'color',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-navigation-menu-wrapper .pxl-menu-primary li .sub-menu li:hover > a, 
                                                {{WRAPPER}} .pxl-navigation-menu-wrapper .pxl-menu-primary li .sub-menu li.current_page_item > a, 
                                                {{WRAPPER}} .pxl-navigation-menu-wrapper .pxl-menu-primary li .sub-menu li.current-menu-item > a, 
                                                {{WRAPPER}} .pxl-navigation-menu-wrapper .pxl-menu-primary li .sub-menu li.current_page_ancestor > a, 
                                                {{WRAPPER}} .pxl-navigation-menu-wrapper .pxl-menu-primary li .sub-menu li.current-menu-ancestor > a' => 'color: {{VALUE}};',
                                            ],
                                        ),
                                    ],
                                ],
                            ],
                        ),
                    ),
                ),
                array(
                    'name' => 'tab_style_mega_menu',
                    'label' => esc_html__('Mega Menu', 'mouno'),
                    'tab' => 'style',
                    'controls' => array( 
                        array(
                            'name' => 'mega_menu_type',
                            'label' => esc_html__('Width', 'mouno' ),
                            'type' => 'select',
                            'options' => [
                                'pxl-mega-full-width' => esc_html__('Full Width', 'mouno'),
                                'pxl-mega-boxed' => esc_html__('Boxed', 'mouno'),
                            ],
                            'default' => 'pxl-mega-full-width',
                        ),
                        array(
                            'name' => 'mega_menu_max_w',
                            'label' => esc_html__('Max Width', 'mouno' ),
                            'type' => 'slider',
                            'size_units' => [ 'px', 'custom' ],
                            'control_type' => 'responsive',
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 3000,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-navigation-menu-wrapper .pxl-megamenu > .sub-menu' => 'max-width: {{SIZE}}{{UNIT}};',
                            ],
                            'condition' => [
                                'mega_menu_type' => 'pxl-mega-boxed',
                            ],
                        ),
                        array(
                            'name' => 'mega_menu_border_radius',
                            'label' => esc_html__('Border Radius', 'mouno' ),
                            'type' => 'dimensions',
                            'size_units' => [ 'px' ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-menu-primary .pxl-mega-menu' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            ],
                        ),
                        array(
                            'name' => 'mega_menu_margin',
                            'label' => esc_html__('Margin', 'mouno' ),
                            'type' => 'dimensions',
                            'size_units' => [ 'px' ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-navigation-menu-wrapper.pxl-mega-full-width .sub-menu.pxl-mega-menu' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};max-width: inherit',
                            ],
                        ),
                    ),
                ),
            ),
        ),
    ),
    mouno_get_class_widget_path()
);