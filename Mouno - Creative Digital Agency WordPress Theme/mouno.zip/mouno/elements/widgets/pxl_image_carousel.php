<?php
pxl_add_custom_widget(
    array(
        'name' => 'pxl_image_carousel',
        'title' => esc_html__('BR Image Carousel', 'mouno' ),
        'icon' => 'eicon-carousel',
        'categories' => array('pxltheme-core'),
        'scripts' => [
            'mouno-swiper',
        ],
        'params' => array(
            'sections' => array(
                array(
                    'name' => 'tab_img_carousel_content',
                    'label' => esc_html__('Image Carousel', 'mouno' ),
                    'tab' => 'content',
                    'controls' => array(
                        array(
                            'name' => 'images',
                            'label' => esc_html__( 'Add Images', 'mouno' ),
                            'type' => 'gallery',
                            'show_label' => false,
                            'default' => [],
                        ),
                    ),
                ),
                array(
                    'name' => 'tab_swiper_additional_opts',
                    'label' => esc_html__('Additional Options', 'mouno' ),
                    'tab' => 'content',
                    'controls' => array(
                        array(
                            'name' => 'group_carousel',
                            'label' => esc_html__('Group Carousel', 'mouno'),
                            'type' => 'switcher',
                            'default' => '',
                        ),
                        array(
                            'name' => 'group_carousel_class',
                            'type' => 'text',
                            'label' => esc_html__('Enter Common Class', 'mouno'),
                            'placeholder' => esc_html__('example-class', 'mouno'),
                            'condition' => [
                                'group_carousel!' => '',
                            ],
                        ),
                        swiper_controls_options(),
                    ),
                ),
                array(
                    'name' => 'tab_img_style',
                    'label' => esc_html__('Image', 'mouno' ),
                    'tab' => 'style',
                    'controls' => array(
                        array(
                            'name' => 'img_w',
                            'label' => esc_html__('Width', 'mouno' ),
                            'type' => 'slider',
                            'control_type' => 'responsive',
                            'size_units' => [ 'px', '%', 'custom' ],
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 2000,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-swiper .pxl-image-item img' => 'width: {{SIZE}}{{UNIT}};',
                            ],
                        ),
                        array(
                            'name' => 'img_max_w',
                            'label' => esc_html__('Max Width', 'mouno' ),
                            'type' => 'slider',
                            'control_type' => 'responsive',
                            'size_units' => [ 'px', '%', 'custom' ],
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 2000,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-swiper .pxl-image-item img' => 'max-width: {{SIZE}}{{UNIT}};',
                            ],
                        ),
                        array(
                            'name' => 'img_h',
                            'label' => esc_html__('Height', 'mouno' ),
                            'type' => 'slider',
                            'control_type' => 'responsive',
                            'size_units' => [ 'px', '%', 'custom' ],
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 2000,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-swiper .pxl-image-item img' => 'height: {{SIZE}}{{UNIT}};',
                            ],
                        ),
                        array(
                            'name' => 'img_controls',
                            'control_type' => 'tab',
                            'separator' => 'before',
                            'tabs' => [
                                [
                                    'name' => 'img_normal',
                                    'label' => esc_html__('Normal', 'mouno' ),
                                    'type' => 'tab',
                                    'controls' => [  
                                        array(
                                            'name' => 'img_opacity',
                                            'label' => esc_html__('Opacity', 'mouno' ),
                                            'type' => 'slider',
                                            'control_type' => 'responsive',
                                            'size_units' => ['px'],
                                            'range' => [
                                                'px' => [
                                                    'min' => 0,
                                                    'max' => 1,
                                                    'step' => 0.01,
                                                ],
                                            ],
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-swiper .pxl-image-item img' => 'opacity: {{SIZE}};',
                                            ],
                                        ),
                                        array(
                                            'name'     => 'img_css_filters',
                                            'type'     => \Elementor\Group_Control_Css_Filter::get_type(),
                                            'control_type' => 'group',
                                            'selector' => '{{WRAPPER}} .pxl-swiper .pxl-image-item img',
                                        ),
                                        array(
                                            'name' => 'img_border',
                                            'type' => \Elementor\Group_Control_Border::get_type(),
                                            'control_type' => 'group', 
                                            'separator' => 'before',
                                            'selector' => '{{WRAPPER}} .pxl-swiper .pxl-image-item img',
                                        ),
                                        array(
                                            'name'         => 'img_box_shadow',
                                            'type'         => \Elementor\Group_Control_Box_Shadow::get_type(),
                                            'control_type' => 'group',
                                            'selector'     => '{{WRAPPER}} .pxl-swiper .pxl-image-item img',
                                        ),
                                        array(
                                            'name' => 'img_border_radius',
                                            'label' => esc_html__('Border Radius', 'mouno' ),
                                            'type' => 'dimensions',
                                            'size_units' => [ 'px', '%', 'custom' ],
                                            'control_type' => 'responsive',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-swiper .swiper-container, {{WRAPPER}} .pxl-swiper .pxl-image-item img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                    ],
                                ],
                                [
                                    'name' => 'img_hover',
                                    'label' => esc_html__('Hover', 'mouno' ),
                                    'type' => 'tab',
                                    'controls' => [
                                        array(
                                            'name' => 'img_hover_opacity',
                                            'label' => esc_html__('Opacity', 'mouno' ),
                                            'type' => 'slider',
                                            'control_type' => 'responsive',
                                            'size_units' => ['px'],
                                            'range' => [
                                                'px' => [
                                                    'min' => 0,
                                                    'max' => 1,
                                                    'step' => 0.01,
                                                ],
                                            ],
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-swiper .pxl-image-item img:hover' => 'opacity: {{SIZE}};',
                                            ],
                                        ),
                                        array(
                                            'name'     => 'img_hover_css_filters',
                                            'type'     => \Elementor\Group_Control_Css_Filter::get_type(),
                                            'control_type' => 'group',
                                            'selector' => '{{WRAPPER}} .pxl-swiper .pxl-image-item img:hover',
                                        ),
                                        array(
                                            'name' => 'img_hover_border',
                                            'type' => \Elementor\Group_Control_Border::get_type(),
                                            'control_type' => 'group', 
                                            'separator' => 'before',
                                            'selector' => '{{WRAPPER}} .pxl-swiper .pxl-image-item img:hover',
                                        ),
                                        array(
                                            'name'         => 'img_hover_box_shadow',
                                            'type'         => \Elementor\Group_Control_Box_Shadow::get_type(),
                                            'control_type' => 'group',
                                            'selector'     => '{{WRAPPER}} .pxl-swiper .pxl-image-item img:hover',
                                        ),
                                        array(
                                            'name' => 'img_hover_border_radius',
                                            'label' => esc_html__('Border Radius', 'mouno' ),
                                            'type' => 'dimensions',
                                            'size_units' => [ 'px', '%', 'custom' ],
                                            'control_type' => 'responsive',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-swiper .pxl-image-item img:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'img_hover_effect',
                                            'label' => esc_html__('Hover Effect', 'mouno' ),
                                            'type' => 'select',
                                            'separator' => 'before',
                                            'options' => [
                                                ''               => esc_html__('None', 'mouno'),
                                                'hover-parallax' => esc_html__('Parallax', 'mouno'),
                                                'hover-flowmap-deformation flowmap-deformation1' => esc_html__('Flowmap Deformation 1', 'mouno'),
                                                'hover-flowmap-deformation flowmap-deformation2' => esc_html__('Flowmap Deformation 2', 'mouno'),
                                            ],
                                            'default' => '',
                                        ),
                                    ],
                                ],
                            ],
                        ),
                    ),
                ),
                array(
                    'name' => 'tab_motion_effects',
                    'label' => esc_html__('Motion Effects', 'mouno' ),
                    'tab' => 'style',
                    'controls' => mouno_get_animation_options([
                        'selector' => '{{WRAPPER}} .pxl-swiper .swiper-slide',
                    ]),
                ),
            ),
        ),
    ),
    mouno_get_class_widget_path()
);