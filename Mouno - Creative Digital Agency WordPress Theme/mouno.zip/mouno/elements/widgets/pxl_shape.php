<?php
pxl_add_custom_widget(
    array(
        'name' => 'pxl_shape',
        'title' => esc_html__('Case Shape', 'mouno' ),
        'icon' => 'eicon-shape',
        'categories' => array('pxltheme-core'),
        'scripts' => array(
            'mouno-effects'
        ),
        'params' => array(
            'sections' => array(
                array(
                    'name' => 'tab_shape_content',
                    'label' => esc_html__('Slider', 'mouno' ),
                    'tab' => 'content',
                    'controls' => array(   
                        array(
                            'name' => 'shape_style',
                            'label' => esc_html__( 'Shape Style', 'mouno' ),
                            'type' => 'select',
                            'options' => [
                                'shape-default'  => esc_html__('Default', 'mouno'),
                                'shape-circle'  => esc_html__('Circle', 'mouno'),

                                'shape-rounded-corner' => esc_html__('Rounded Corner', 'mouno'),
                                'custom'  =>  esc_html__('Custom', 'mouno'),
                            ],
                            'default' => 'shape-default',
                        ),
                        array(
                            'name' => 'shape_type',
                            'label' => esc_html__( 'Shape Type', 'mouno' ),
                            'type' => 'select',
                            'options' => [
                                'color'  => esc_html__('Color', 'mouno'),
                                'img' => esc_html__('Image', 'mouno'),
                            ],
                            'default' => 'color',
                        ),
                        array(
                            'name' => 'shape_color',
                            'label' => esc_html__('Color', 'mouno' ),
                            'type' => 'color',
                            'selectors' => [
                                '{{WRAPPER}} .pxl-shape-wrapper .pxl-shape-item' => 'background-color: {{VALUE}};',
                            ],
                            'condition' => [
                                'shape_type' => 'color',
                                'shape_style!' => 'shape-rounded-corner',
                            ],
                        ),
                        array(
                            'name' => 'shape_bg',
                            'type' => \Elementor\Group_Control_Background::get_type(),
                            'control_type' => 'group',
                            'types' => [ 'classic', 'gradient' ],
                            'selector' => '{{WRAPPER}} .pxl-shape-wrapper .pxl-shape-item',
                        ),
                        array(
                            'name' => 'shape_img',
                            'label' => esc_html__('Image', 'mouno' ),
                            'type' => 'media',
                            'condition' => [
                                'shape_type' => 'img',
                            ],
                        ),
                        array(
                            'name' => 'shape_box_sz',
                            'type' => 'slider',
                            'label' => esc_html__('Box Size', 'mouno'),
                            'size_units' => ['px', '%', 'custom'],
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 1000,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-shape-wrapper .pxl-shape-item' => '--pxl-box-size: {{SIZE}}{{UNIT}};',
                            ],
                        ), 
                        array(
                            'name' => 'shape_h',
                            'type' => 'slider',
                            'label' => esc_html__('Min Height ', 'mouno'),
                            'size_units' => ['px', '%', 'custom'],
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 1000,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-shape-wrapper .pxl-shape-item svg' => 'min-height: {{SIZE}}{{UNIT}};',
                                '{{WRAPPER}} .pxl-shape-wrapper .pxl-shape-item' => 'min-height: {{SIZE}}{{UNIT}};',

                            ],
                        ), 
                        array(
                            'name' => 'shape_opcity',
                            'type' => 'slider',
                            'label' => esc_html__('Opacity', 'mouno'),
                            'size_units' => ['%', 'custom'],
                            'range' => [
                                '%' => [
                                    'min' => 0,
                                    'max' => 100,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-shape-wrapper .pxl-shape-item' => 'opacity: {{SIZE}}{{UNIT}};',
                            ],
                        ), 
                    ),
                ),
                array(
                    'name' => 'tab_shape_style',
                    'label' => esc_html__('Shape', 'mouno' ),
                    'tab' => 'style',
                    'controls' => array(  

                    ), 
                ),
            ),
        ),
    ),
    mouno_get_class_widget_path()
);