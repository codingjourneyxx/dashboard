<?php
pxl_add_custom_widget(
    array(
        'name' => 'pxl_index_box_carousel',
        'title' => esc_html__('Case Index Box Carousel', 'mouno' ),
        'icon' => 'eicon-carousel',
        'categories' => array('pxltheme-core'),
        'scripts' => array(
            'mouno-swiper'
        ),
        'params' => array(
            'sections' => array(
                array(
                    'name' => 'tab_index_box_layout',
                    'label' => esc_html__('Layout', 'mouno'),
                    'tab' => 'layout',
                    'controls' => array(
                        array(
                            'name' => 'layout',
                            'label' => esc_html__('Layout', 'mouno'),
                            'type' => 'layoutcontrol',
                            'default' => '1',
                            'options' => array(
                                '1' => array(
                                    'label' => esc_html__('Layout 1', 'mouno'),
                                    'image' => get_template_directory_uri() . '/elements/assets/img/pxl_accordion/layout1.jpg',
                                ),
                                '2' => array(
                                    'label' => esc_html__('Layout 2', 'mouno'),
                                    'image' => get_template_directory_uri() . '/elements/assets/img/pxl_accordion/layout1.jpg',
                                ),
                            ),
                        ),
                    ),
                ),
                array(
                    'name' => 'tab_index_box_content',
                    'label' => esc_html__('Icon Box', 'mouno' ),
                    'tab' => 'content',
                    'controls' => array(   
                        array(
                            'name' => 'title_tag',
                            'label' => esc_html__('Title HTML Tag', 'mouno'),
                            'type' => 'select',
                            'default' => 'h4',
                            'options' => [
                                'h1' => esc_html__('H1', 'mouno'),
                                'h2' => esc_html__('H2', 'mouno'),
                                'h3' => esc_html__('H3', 'mouno'),
                                'h4' => esc_html__('H4', 'mouno'),
                                'h5' => esc_html__('H5', 'mouno'),
                                'h6' => esc_html__('H6', 'mouno'),
                                'div' => esc_html__('div', 'mouno'),
                                'p'  => esc_html__('p', 'mouno'),
                                'span' => esc_html__('span', 'mouno'),
                            ],
                        ),
                        array(
                            'name' => 'index_boxs',
                            'label' => esc_html__('Index Boxs', 'mouno' ),
                            'type' => 'repeater',
                            'controls' => array(
                                array(
                                    'name' => 'title',
                                    'label' => esc_html__('Title', 'mouno'),
                                    'type' => 'text',
                                    'label_block' => true,
                                ),
                                array(
                                    'name' => 'desc',
                                    'label' => esc_html__('Description', 'mouno'),
                                    'type' => \Elementor\Controls_Manager::TEXTAREA,
                                    'rows' => 10,
                                ),
                                array(
                                    'name' => 'link',
                                    'label' => esc_html__('Link URL', 'mouno'),
                                    'type' => \Elementor\Controls_Manager::URL,
                                    'label_block' => true,
                                ),
                            ),
                            'title_field' => '{{{ title }}}',
                            'default' => [
                                [
                                    'title' => esc_html__('This is heading 1', 'mouno'),
                                    'desc' => esc_html__('Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.', 'mouno'),
                                ],
                                [
                                    'title' => esc_html__('This is heading 2', 'mouno'),
                                    'desc' => esc_html__('Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.', 'mouno'),
                                ],
                                [
                                    'title' => esc_html__('This is heading 3', 'mouno'),
                                    'desc' => esc_html__('Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.', 'mouno'),
                                ],
                            ],
                        ),
                    ),
                ),
                array(
                    'name' => 'tab_swiper_add_otps',
                    'label' => esc_html__('Addtional Options', 'mouno'),
                    'tab' => 'settings',
                    'controls' => array(
                        swiper_controls_options(),
                    ),
                ),
                array(
                    'name' => 'tab_style_general',
                    'label' => esc_html__('General', 'mouno'),
                    'tab' => 'style',
                    'controls' => array(
                        array(
                            'name' => 'content_alignment',
                            'label' => esc_html__('Alignment', 'mouno' ),
                            'type' => \Elementor\Controls_Manager::CHOOSE,
                            'control_type' => 'responsive',
                            'options' => [
                                'left' =>  [
                                    'title' => esc_html__('Left', 'mouno'),
                                    'icon' => 'eicon-text-align-left',
                                ],
                                'center' =>  [
                                    'title' => esc_html__('Center', 'mouno'),
                                    'icon' => 'eicon-text-align-center',
                                ],
                                'right' =>  [
                                    'title' => esc_html__('Right', 'mouno'),
                                    'icon' => 'eicon-text-align-right',
                                ],
                                'justify' =>  [
                                    'title' => esc_html__('Justify', 'mouno'),
                                    'icon' => 'eicon-text-align-justify',
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-index-box-carousel .pxl-index-box-item .pxl-index-box-title,
                                {{WRAPPER}} .pxl-index-box-carousel .pxl-index-box-item .pxl-index-box-description' => 'text-align: {{VALUE}};'
                            ],
                        ),
                        array(
                            'name' => 'title_spacing',
                            'label' => esc_html__('Title Spacing', 'mouno'),
                            'type' => 'slider',
                            'control_type' => 'responsive',
                            'size_units' => ['px', '%', 'rem', 'em', 'custom'],
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 1000,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-index-box-carousel .pxl-index-box-item .pxl-index-box-title' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                            ],
                        ),

                        array(
                            'name' => 'dot_color',
                            'type' => \Elementor\Group_Control_Background::get_type(),
                            'control_type' => 'group',
                            'types' => ['classic', 'gradient'],
                            'selector' => '{{WRAPPER}} .pxl-index-box-carousel .pxl-index-box-item .pxl-index-box-index::after',
                        ),
                    ),
                ),

                array(
                    'name' => 'tab_index_style',
                    'label' => esc_html__('Index', 'mouno' ),
                    'tab' => 'style',
                    'controls' => array(
                        array(
                            'name' => 'index_color',
                            'label' => esc_html__('Text Color', 'mouno' ),
                            'type' => 'color',
                             'selectors' => [
                                '{{WRAPPER}} .pxl-index-box-carousel .pxl-index-box-item .pxl-index-box-index .pxl-index-number' => 'color: {{VALUE}};',
                            ],
                        ),
                        array(
                            'name' => 'index_typography',
                            'type' => \Elementor\Group_Control_Typography::get_type(),
                            'control_type' => 'group',
                            'selector' => '{{WRAPPER}} .pxl-index-box-carousel .pxl-index-box-item .pxl-index-box-index .pxl-index-number',
                        ),
                        array(
                            'name'         => 'index_box_shadow',
                            'type'         => \Elementor\Group_Control_Text_Shadow::get_type(),
                            'control_type' => 'group',
                            'selector'     => '{{WRAPPER}} .pxl-index-box-carousel .pxl-index-box-item .pxl-index-box-index .pxl-index-number'
                        ),
                        array(
                            'name'         => 'index_box_stroke',
                            'type'         => \Elementor\Group_Control_Text_Stroke::get_type(),
                            'control_type' => 'group',
                            'selector'     => '{{WRAPPER}} .pxl-index-box-carousel .pxl-index-box-item .pxl-index-box-index .pxl-index-number'
                        ),

                    ),
                ),

                array(
                    'name' => 'tab_title_style',
                    'label' => esc_html__('Title', 'mouno' ),
                    'tab' => 'style',
                    'controls' => array(
                        array(
                            'name' => 'title_color',
                            'label' => esc_html__('Text Color', 'mouno' ),
                            'type' => 'color',
                             'selectors' => [
                                '{{WRAPPER}} .pxl-index-box-carousel .pxl-index-box-item .pxl-index-box-title' => 'color: {{VALUE}};',
                            ],
                        ),
                        array(
                            'name' => 'title_typography',
                            'type' => \Elementor\Group_Control_Typography::get_type(),
                            'control_type' => 'group',
                            'selector' => '{{WRAPPER}} .pxl-index-box-carousel .pxl-index-box-item .pxl-index-box-title',
                        ),
                        array(
                            'name'         => 'title_box_shadow',
                            'type'         => \Elementor\Group_Control_Text_Shadow::get_type(),
                            'control_type' => 'group',
                            'selector'     => '{{WRAPPER}} .pxl-index-box-carousel .pxl-index-box-item .pxl-index-box-title'
                        ),
                    ),
                ),

                array(
                    'name' => 'tab_description_style',
                    'label' => esc_html__('Description', 'mouno' ),
                    'tab' => 'style',
                    'controls' => array(
                        array(
                            'name' => 'description_color',
                            'label' => esc_html__('Text Color', 'mouno' ),
                            'type' => 'color',
                             'selectors' => [
                                '{{WRAPPER}} .pxl-index-box-carousel .pxl-index-box-item .pxl-index-box-description' => 'color: {{VALUE}};',
                            ],
                        ),
                        array(
                            'name' => 'description_typography',
                            'type' => \Elementor\Group_Control_Typography::get_type(),
                            'control_type' => 'group',
                            'selector' => '{{WRAPPER}} .pxl-index-box-carousel .pxl-index-box-item .pxl-index-box-description',
                        ),
                        array(
                            'name'         => 'description_box_shadow',
                            'type'         => \Elementor\Group_Control_Text_Shadow::get_type(),
                            'control_type' => 'group',
                            'selector'     => '{{WRAPPER}} .pxl-index-box-carousel .pxl-index-box-item .pxl-index-box-description'
                        ),
                    ),
                ),

                array(
                    'name' => 'tab_motion_effects',
                    'label' => esc_html__('Motion Effects', 'mouno'),
                    'tab' => 'style',
                    'controls' => mouno_get_animation_options([
                        'selector' => '{{WRAPPER}} .pxl-swiper .swiper-slide'
                    ]),
                ),
            ),
        ),
    ),
    mouno_get_class_widget_path()
);