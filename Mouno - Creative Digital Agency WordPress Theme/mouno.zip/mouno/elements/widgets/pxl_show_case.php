<?php
pxl_add_custom_widget(
    array(
        'name' => 'pxl_show_case',
        'title' => esc_html__('Case Show Case', 'mouno' ),
        'icon' => 'eicon-inner-container',
        'categories' => array('pxltheme-core'),
        'scripts' => array(
            'tilt',
            'mouno-effects',
        ),
        'params' => array(
            'sections' => array(
                array(
                    'name' => 'tab_show_case_content',
                    'label' => esc_html__('Show Case', 'mouno'),
                    'tab' => 'layout',
                    'controls' => array(
                        array(
                            'name' => 'layout_style',
                            'label' => esc_html__('Layout Style', 'mouno'),
                            'type' => 'select',
                            'options' => array(
                                'show-case-default' => esc_html__('Default', 'mouno'),
                                'show-case-style1' => esc_html__('Style 1', 'mouno'),
                            ),
                            'default' => 'show-case-default',
                        ),
                        array(
                            'name' => 'cooming_soon',
                            'type' => 'switcher',
                            'label' => esc_html__('Cooming Soon', 'mouno'),
                            'default' => '',
                        ),
                        array(
                            'name' => 'title',
                            'label' => esc_html__('Title', 'mouno' ),
                            'type' => 'text',
                        ),
                        array(
                            'name' => 'show_case_img',
                            'label' => esc_html__('Image', 'mouno' ),
                            'type' => 'media',
                        ),
                        array(
                            'name' => 'img_min_h',
                            'label' => esc_html__('Min Height', 'mouno' ),
                            'type' => 'slider',
                            'control_type' => 'responsive',
                            'size_units' => [ 'px', 'custom'],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-show-case-wrapper img' => 'min-height: {{SIZE}}{{UNIT}};'
                            ],
                        ),
                        array(
                            'name' => 'btns',
                            'label' => esc_html__('Buttons', 'mouno' ),
                            'type' => 'repeater',
                            'condition' => [
                                'cooming_soon' => '',
                            ],
                            'controls' => [
                                array(
                                    'name' => 'btn_text',
                                    'label' => esc_html__('Text', 'mouno' ),
                                    'type' => 'text',
                                ),
                                array(
                                    'name' => 'btn_link',
                                    'label' => esc_html__('URL', 'mouno' ),
                                    'type' => 'url',
                                ),
                                array(
                                    'name' => 'current_item_color',
                                    'label' => esc_html__('Color', 'mouno' ),
                                    'type' => 'color',
                                    'separator' => 'before',
                                    'selectors' => [
                                        '{{WRAPPER}} .pxl-show-case-wrapper .pxl-show-case-btn{{CURRENT_ITEM}}' => 'color: {{VALUE}}; border-color: {{VALUE}};',
                                    ]
                                ),
                                array(
                                    'name' => 'box_current_item_color',
                                    'label' => esc_html__('Background Color', 'mouno' ),
                                    'type' => 'color',
                                    'selectors' => [
                                        '{{WRAPPER}} .pxl-show-case-wrapper .pxl-show-case-btn{{CURRENT_ITEM}}' => 'background-color: {{VALUE}};',
                                    ]
                                ),
                                array(
                                    'name' => 'btn_currrent_border',
                                    'type' => \Elementor\Group_Control_Border::get_type(),
                                    'control_type' => 'group', 
                                    'selector' => '{{WRAPPER}} .pxl-show-case-wrapper .pxl-show-case-btn{{CURRENT_ITEM}}',
                                ),
                                array(
                                    'name' => 'current_item_hover_color',
                                    'label' => esc_html__('Color', 'mouno' ),
                                    'type' => 'color',
                                    'selectors' => [
                                        '{{WRAPPER}} .pxl-show-case-wrapper .pxl-show-case-btn{{CURRENT_ITEM}}:hover' => 'color: {{VALUE}}; border-color: {{VALUE}};',
                                    ]
                                ),
                                array(
                                    'name' => 'current_item_hover_bg_color',
                                    'label' => esc_html__('Background Color', 'mouno' ),
                                    'type' => 'color',
                                    'selectors' => [
                                        '{{WRAPPER}} .pxl-show-case-wrapper .pxl-show-case-btn{{CURRENT_ITEM}}:hover' => 'background-color: {{VALUE}};',
                                    ]
                                ),
                                array(
                                    'name' => 'current_item_hover_border',
                                    'type' => \Elementor\Group_Control_Border::get_type(),
                                    'control_type' => 'group', 
                                    'selector' => '{{WRAPPER}} .pxl-show-case-wrapper .pxl-show-case-btn{{CURRENT_ITEM}}:hover',
                                ),
                            ],
                            'title_field' => '{{{btn_text}}}',
                        ),
                    ),
                ),

                array(
                    'name' => 'tab_box_style',
                    'label' => esc_html__('Box', 'mouno' ),
                    'tab' => 'style',
                    'controls' => array(
                        array(
                            'name' => 'box_controls',
                            'control_type' => 'tab',
                            'tabs' => [
                                [
                                    'name' => 'box_normal',
                                    'label' => esc_html__('Normal', 'mouno' ),
                                    'type' => 'tab',
                                    'controls' => [  
                                        array(
                                            'name' => 'box_bg',
                                            'type' => \Elementor\Group_Control_Background::get_type(),
                                            'control_type' => 'group',
                                            'types' => [ 'classic', 'gradient' ],
                                            'selector' => '{{WRAPPER}} .pxl-show-case-wrapper .pxl-show-case-box',
                                        ),
                                        array(
                                            'name' => 'box_border',
                                            'type' => \Elementor\Group_Control_Border::get_type(),
                                            'separator' => 'before',
                                            'control_type' => 'group', 
                                            'selector' => '{{WRAPPER}} .pxl-show-case-wrapper .pxl-show-case-box',
                                        ),
                                        array(
                                            'name'         => 'box_box_shadow',
                                            'label' => esc_html__( 'Box Shadow', 'mouno' ),
                                            'type'         => \Elementor\Group_Control_Box_Shadow::get_type(),
                                            'control_type' => 'group',
                                            'selector'     => '{{WRAPPER}} .pxl-show-case-wrapper .pxl-show-case-box',
                                        ),
                                        array(
                                            'name' => 'box_border_radius',
                                            'label' => esc_html__('Border Radius', 'mouno' ),
                                            'type' => 'dimensions',
                                            'control_type' => 'responsive',
                                            'size_units' => [ 'px', 'custom' ],
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-show-case-wrapper .pxl-show-case-box' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}; overflow: hidden;',
                                            ],
                                        ),
                                        array(
                                            'name' => 'box_padding',
                                            'label' => esc_html__('Padding', 'mouno' ),
                                            'type' => 'dimensions',
                                            'size_units' => [ 'px', 'custom' ],
                                            'control_type' => 'responsive',
                                            'separator' => 'before',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-show-case-wrapper .pxl-show-case-box' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                    ],
                                ],
                                [
                                    'name' => 'box_hover',
                                    'label' => esc_html__('Hover/Active', 'mouno' ),
                                    'type' => 'tabs',
                                    'controls' => [
                                        array(
                                            'name' => 'box_hover_style',
                                            'label' => esc_html__('Hover Style', 'mouno'),
                                            'type' => 'select',
                                            'options' => [
                                                'hover-box-default' => esc_html__('Default', 'mouno'), 
                                                'hover-rotate3d-direction' => esc_html__('Rotate by Direction', 'mouno'), 
                                                'hover-translate3d-direction' => esc_html__('Translate by Direction', 'mouno'), 
                                                'hover-box-shadow-underfoot'    => esc_html__('Shadow Underfoot', 'mouno'),
                                            ],
                                            'default' => 'hover-box-default',
                                        ),
                                        array(
                                            'name' => 'box_hover_bg',
                                            'type' => \Elementor\Group_Control_Background::get_type(),
                                            'control_type' => 'group',
                                            'types' => [ 'classic', 'gradient' ],
                                            'selector' => '{{WRAPPER}} .pxl-layout-service:not(.pxl-layout-service4):not(.pxl-layout-service2):not(.pxl-layout-service5) .pxl-post-item:not(.hover-rotate3d-direction):not(.hover-translate3d-direction):hover,
                                            {{WRAPPER}} .pxl-layout-service4 .item-hover:after,
                                            {{WRAPPER}} .pxl-layout-service .pxl-post-item .direction-item,
                                            {{WRAPPER}} .pxl-layout-service5 .pxl-post-item:hover .pxl-post-header,
                                            {{WRAPPER}} .pxl-layout-service5 .pxl-post-item.active .pxl-post-header',
                                        ),
                                        array(
                                            'name' => '_box_hover_border_color',
                                            'label' => esc_html__('Border Color', 'mouno' ),
                                            'type' => 'color',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-layout-service:not(.pxl-layout-service4) .pxl-post-item:hover,
                                                {{WRAPPER}} .pxl-layout-service4 .pxl-post-item:hover .pxl-post-header,
                                                {{WRAPPER}} .pxl-layout-service4 .pxl-post-item.active .pxl-post-header' => 'border-color: {{VALUE}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'box_hover_border',
                                            'type' => \Elementor\Group_Control_Border::get_type(),
                                            'separator' => 'before',
                                            'control_type' => 'group', 
                                            'selector' => '{{WRAPPER}} .pxl-layout-service:not(.pxl-layout-service4) .pxl-post-item:hover,
                                                {{WRAPPER}} .pxl-layout-service4 .pxl-post-item:hover .pxl-post-header,
                                                {{WRAPPER}} .pxl-layout-service4 .pxl-post-item.active .pxl-post-header',
                                        ),
                                        array(
                                            'name'         => 'box_hover_box_shadow',
                                            'label' => esc_html__( 'Box Shadow', 'mouno' ),
                                            'type'         => \Elementor\Group_Control_Box_Shadow::get_type(),
                                            'control_type' => 'group',
                                            'selector'     => '{{WRAPPER}} .pxl-layout-service:not(.pxl-layout-service4) .pxl-post-item:hover,
                                                {{WRAPPER}} .pxl-layout-service4 .pxl-post-item:hover .pxl-post-header,
                                                {{WRAPPER}} .pxl-layout-service4 .pxl-post-item.active .pxl-post-header',
                                        ),
                                        array(
                                            'name' => 'box_hover_border_radius',
                                            'label' => esc_html__('Border Radius', 'mouno' ),
                                            'type' => 'dimensions',
                                            'size_units' => [ 'px', '%', 'custom' ],
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-layout-service:not(.pxl-layout-portfolio3):not(.pxl-layout-portfolio4) .pxl-post-item:hover, 
                                                {{WRAPPER}} .pxl-layout-service4 .pxl-post-item:hover .pxl-post-header,
                                                {{WRAPPER}} .pxl-layout-service4 .pxl-post-item.active .pxl-post-header' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'box_hover_padding',
                                            'label' => esc_html__('Padding', 'mouno' ),
                                            'type' => 'dimensions',
                                            'size_units' => [ 'px', '%', 'custom' ],
                                            'control_type' => 'responsive',
                                            'separator' => 'before',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-layout-service:not(.pxl-layout-service4) .pxl-post-item:hover,
                                                {{WRAPPER}} .pxl-layout-service4 .pxl-post-item:hover .pxl-post-header,
                                                {{WRAPPER}} .pxl-layout-service4 .pxl-post-item.active .pxl-post-header' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                    ],
                                ],
                            ],
                        ),
                    ),
                ),

                array(
                    'name' => 'tab_btn_style',
                    'label' => esc_html__('Box', 'mouno' ),
                    'tab' => 'style',
                    'controls' => array(
                        array(
                            'name' => 'btn_typography',
                            'label' => esc_html__('Typography', 'mouno' ),
                            'type' => \Elementor\Group_Control_Typography::get_type(),
                            'control_type' => 'group',
                            'selector' => '{{WRAPPER}} .pxl-heading-wrapper .pxl-heading-subtitle',
                        ),
                        array(
                            'name' => 'btn_controls',
                            'control_type' => 'tab',
                            'tabs' => [
                                [
                                    'name' => 'btn_normal',
                                    'label' => esc_html__('Normal', 'mouno' ),
                                    'type' => 'tab',
                                    'controls' => [  
                                        array(
                                            'name' => 'btn_bg',
                                            'type' => \Elementor\Group_Control_Background::get_type(),
                                            'control_type' => 'group',
                                            'types' => [ 'classic', 'gradient' ],
                                            'selector' => '{{WRAPPER}} .pxl-show-case-wrapper .pxl-show-case-btn',
                                        ),
                                        array(
                                            'name' => 'btn_border',
                                            'type' => \Elementor\Group_Control_Border::get_type(),
                                            'separator' => 'before',
                                            'control_type' => 'group', 
                                            'selector' => '{{WRAPPER}} .pxl-show-case-wrapper .pxl-show-case-btn',
                                        ),
                                        array(
                                            'name'         => 'btn_shadow',
                                            'label' => esc_html__( 'Box Shadow', 'mouno' ),
                                            'type'         => \Elementor\Group_Control_Box_Shadow::get_type(),
                                            'control_type' => 'group',
                                            'selector'     => '{{WRAPPER}} .pxl-show-case-wrapper .pxl-show-case-btn',
                                        ),
                                        array(
                                            'name' => 'btn_border_radius',
                                            'label' => esc_html__('Border Radius', 'mouno' ),
                                            'type' => 'dimensions',
                                            'control_type' => 'responsive',
                                            'size_units' => [ 'px', 'custom' ],
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-show-case-wrapper .pxl-show-case-btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'btn_padding',
                                            'label' => esc_html__('Padding', 'mouno' ),
                                            'type' => 'dimensions',
                                            'size_units' => [ 'px', 'custom' ],
                                            'control_type' => 'responsive',
                                            'separator' => 'before',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-show-case-wrapper .pxl-show-case-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                    ],
                                ],
                                [
                                    'name' => 'btn_hover',
                                    'label' => esc_html__('Hover/Active', 'mouno' ),
                                    'type' => 'tabs',
                                    'controls' => [
                                        array(
                                            'name' => 'btn_hover_style',
                                            'label' => esc_html__('Hover Style', 'mouno'),
                                            'type' => 'select',
                                            'options' => [
                                                'hover-btn-default' => esc_html__('Default', 'mouno'), 
                                            ],
                                            'default' => 'hover-btn-default',
                                        ),
                                        array(
                                            'name' => 'btn_hover_bg',
                                            'type' => \Elementor\Group_Control_Background::get_type(),
                                            'control_type' => 'group',
                                            'types' => [ 'classic', 'gradient' ],
                                            'selector' => '{{WRAPPER}} .pxl-show-case-wrapper .pxl-show-case-btn:hover',
                                        ),
                                        array(
                                            'name' => '_btn_hover_border_color',
                                            'label' => esc_html__('Border Color', 'mouno' ),
                                            'type' => 'color',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-show-case-wrapper .pxl-show-case-btn:hover' => 'border-color: {{VALUE}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'btn_hover_border',
                                            'type' => \Elementor\Group_Control_Border::get_type(),
                                            'separator' => 'before',
                                            'control_type' => 'group', 
                                            'selector' => '{{WRAPPER}} .pxl-show-case-wrapper .pxl-show-case-btn:hover',
                                        ),
                                        array(
                                            'name'         => 'btn_hover_box_shadow',
                                            'label' => esc_html__( 'Box Shadow', 'mouno' ),
                                            'type'         => \Elementor\Group_Control_Box_Shadow::get_type(),
                                            'control_type' => 'group',
                                            'selector'     => '{{WRAPPER}} .pxl-show-case-wrapper .pxl-show-case-btn:hover',
                                        ),
                                        array(
                                            'name' => 'btn_hover_border_radius',
                                            'label' => esc_html__('Border Radius', 'mouno' ),
                                            'type' => 'dimensions',
                                            'size_units' => [ 'px', '%', 'custom' ],
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-show-case-wrapper .pxl-show-case-btn:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'btn_hover_padding',
                                            'label' => esc_html__('Padding', 'mouno' ),
                                            'type' => 'dimensions',
                                            'size_units' => [ 'px', '%', 'custom' ],
                                            'control_type' => 'responsive',
                                            'separator' => 'before',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-show-case-wrapper .pxl-show-case-btn:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                    ],
                                ],
                            ],
                        ),
                    ),
                ),
            ),
        ),
    ),
);