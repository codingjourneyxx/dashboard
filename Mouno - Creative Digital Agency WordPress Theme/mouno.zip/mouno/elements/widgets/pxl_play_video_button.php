<?php
pxl_add_custom_widget(
    array(
        'name' => 'pxl_play_video_button',
        'title' => esc_html__('Case Play Video Button', 'mouno' ),
        'icon' => 'eicon-play',
        'categories' => array('pxltheme-core'),
        'scripts' => array(),
        'params' => array(
            'sections' => array(
                array(
                    'name' => 'tab_btn_content',
                    'label' => esc_html__('Play Video Button', 'mouno' ),
                    'tab' => 'content',
                    'controls' => array( 
                        array(
                            'name' => 'btn_style',
                            'label' => esc_html__('Button Style', 'mouno' ),
                            'type' => 'select',
                            'default' => 'pxl-play-video-button1',
                            'options' => [
                                'pxl-play-video-button1' => esc_html__('Default', 'mouno'),
                            ]
                        ),
                        array(
                            'name' => 'video_link',
                            'label' => esc_html__('Video Link', 'mouno' ),
                            'type' => \Elementor\Controls_Manager::URL,
                            'default' => [
                                'url' => esc_url('https://www.youtube.com/watch?v=NkQlmPCQfgY'),
                            ],
                        ),
                        array(
                            'name' => 'btn_icon',
                            'label' => esc_html__('Button Icon', 'mouno' ),
                            'type' => \Elementor\Controls_Manager::ICONS,
                            'fa4compatibility' => 'icon',
                            'default' => [
                                'value' => [ 
                                    'url' => content_url('/wp-content/uploads/2024/11/play-video.svg'), 
                                    'id' => 2967, 
                                ],
                                'library' => 'svg',
                            ],
                        ),
                    ),
                ),
            ),
        ),
    ),
    mouno_get_class_widget_path()
);