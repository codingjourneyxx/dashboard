<?php
// Register Logo Widget
pxl_add_custom_widget(
    array(
        'name' => 'pxl_site_logo',
        'title' => esc_html__('Case Site Logo', 'mouno' ),
        'icon' => 'eicon-site-logo',
        'categories' => array('pxltheme-core'),
        'params' => array(
            'sections' => array(
                array(
                    'name' => 'tab_logo_content',
                    'label' => esc_html__('Logo', 'mouno' ),
                    'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
                    'controls' => array(
                        array(
                            'name' => 'logo',
                            'label' => esc_html__('Site Logo', 'mouno' ),
                            'type' => \Elementor\Controls_Manager::MEDIA,
                            'default' => [
                                'url' => content_url('/uploads/2024/11/logo_demo_light.png'),
                            ],
                        ),
                        array(
                            'name' => 'logo_link',
                            'label' => esc_html__('Link', 'mouno' ),
                            'type' => \Elementor\Controls_Manager::URL,
                            'default' => [
                                'url' => home_url('/'),
                            ],
                        ),
                    ),
                ),
                array(
                    'name' => 'tab_logo_style',
                    'label' => esc_html__('Site Logo', 'mouno' ),
                    'tab' => \Elementor\Controls_Manager::TAB_STYLE,
                    'controls' => array(
                        array(
                            'name' => 'logo_align',
                            'label' => esc_html__('Alignment', 'mouno' ),
                            'type' => \Elementor\Controls_Manager::CHOOSE,
                            'control_type' => 'responsive',
                            'options' => [
                                'start' => [
                                    'title' => esc_html__('Left', 'mouno' ),
                                    'icon' => 'fa fa-align-left',
                                ],
                                'center' => [
                                    'title' => esc_html__('Center', 'mouno' ),
                                    'icon' => 'fa fa-align-center',
                                ],
                                'end' => [
                                    'title' => esc_html__('Right', 'mouno' ),
                                    'icon' => 'fa fa-align-right',
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-site-logo-wrapper .pxl-site-logo' => 'justify-content: {{VALUE}};',
                            ],
                        ),
                        array(
                            'name' => 'logo_color',
                            'label' => esc_html__('Color', 'mouno' ),
                            'type' => 'color',
                            'selectors' => [
                                '{{WRAPPER}} .pxl-site-logo-wrapper a' => 'color: {{VALUE}};',
                            ],
                        ),
                        array(
                            'name' => 'logo_w',
                            'label' => esc_html__('Width', 'mouno' ),
                            'type' => \Elementor\Controls_Manager::SLIDER,
                            'size_units' => ['px', '%', 'custom'],
                            'control_type' => 'responsive',
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 3000,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-site-logo-wrapper img' => 'width: {{SIZE}}{{UNIT}};',
                            ],
                        ),
                        array(
                            'name' => 'logo_max_w',
                            'label' => esc_html__('Max Width', 'mouno' ),
                            'type' => \Elementor\Controls_Manager::SLIDER,
                            'size_units' => ['px', '%', 'custom'],
                            'control_type' => 'responsive',
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 3000,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-site-logo-wrapper img' => 'max-width: {{SIZE}}{{UNIT}};',
                            ],
                        ),
                        array(
                            'name' => 'logo_h',
                            'label' => esc_html__('Height', 'mouno' ),
                            'type' => \Elementor\Controls_Manager::SLIDER,
                            'size_units' => ['px', '%', 'custom'],
                            'control_type' => 'responsive',
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 3000,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-site-logo-wrapper img' => 'height: {{SIZE}}{{UNIT}};',
                            ],
                        ),
                    ),
                ),
            ),
        ),
    ),
    mouno_get_class_widget_path()
);