<?php
pxl_add_custom_widget(
    array(
        'name' => 'pxl_testimonial_carousel',
        'title' => esc_html__('Case Testimonial Carousel', 'mouno' ),
        'icon' => 'eicon-testimonial-carousel',
        'categories' => array('pxltheme-core'),
        'scripts' => array(
            'mouno-swiper',
        ),
        'params' => array(
            'sections' => array(
                array(
                    'name' => 'tab_layout',
                    'label' => esc_html__('Layout', 'mouno'),
                    'tab' => \Elementor\Controls_Manager::TAB_LAYOUT,
                    'controls' => array(
                        array(
                            'name' => 'layout',
                            'label' => esc_html__('Layout', 'mouno'),
                            'type' => 'layoutcontrol',
                            'default' => '1',
                            'options' => array(
                                '1' => array(
                                    'label' => esc_html__('Layout 1', 'mouno'),
                                    'image' => get_template_directory_uri() . '/elements/assets/img/pxl_accordion/layout1.jpg',
                                ),
                                '2' => array(
                                    'label' => esc_html__('Layout 2', 'mouno'),
                                    'image' => get_template_directory_uri() . '/elements/assets/img/pxl_accordion/layout1.jpg',
                                ),
                                '3' => array(
                                    'label' => esc_html__('Layout 3', 'mouno'),
                                    'image' => get_template_directory_uri() . '/elements/assets/img/pxl_accordion/layout1.jpg',
                                ),
                                '3' => array(
                                    'label' => esc_html__('Layout 3', 'mouno'),
                                    'image' => get_template_directory_uri() . '/elements/assets/img/pxl_accordion/layout1.jpg',
                                ),
                                '4' => array(
                                    'label' => esc_html__('Layout 4', 'mouno'),
                                    'image' => get_template_directory_uri() . '/elements/assets/img/pxl_accordion/layout1.jpg',
                                ),
                                '5' => array(
                                    'label' => esc_html__('Layout 5', 'mouno'),
                                    'image' => get_template_directory_uri() . '/elements/assets/img/pxl_accordion/layout5.jpg',
                                ),
                            ),
                        ),
                    ),
                ),

                array(
                    'name'     => 'tab_testimonial_content',
                    'label'    => esc_html__( 'Testimonials', 'mouno' ),
                    'tab'      => 'content',
                    'controls' => array(
                        array(
                            'name' => 'testimonials',
                            'label' => esc_html__('Testimonials', 'mouno'),
                            'type' => 'repeater',
                            'controls' => [
                                array(
                                    'name' => 'get_layout',
                                    'label' => esc_html__('Get Layout', 'mouno'),
                                    'type' => 'select',
                                    'options' => [
                                        '1'  => esc_html__('Layout 1', 'mouno'),
                                        '2'  => esc_html__('Layout 2', 'mouno'),
                                        '3'  => esc_html__('Layout 3', 'mouno'),
                                        '4'  => esc_html__('Layout 4', 'mouno'),
                                        '5'  => esc_html__('Layout 5', 'mouno'),
                                    ],
                                    'default' => '1',
                                ),
                                array(
                                    'name' => 'img',
                                    'label' => esc_html__('Image', 'mouno' ),
                                    'type' => 'media',
                                    'condition' => [
                                        'get_layout!' => ['1', '4'],
                                    ],
                                ),
                                array(
                                    'name' => 'content',
                                    'type' => 'textarea',
                                    'label' => esc_html__('Content', 'mouno'),
                                    'rows' => 10,
                                ),
                                array(
                                    'name' => 'name',
                                    'label' => esc_html__('Name', 'mouno'),
                                    'type' => 'text',
                                ),
                                array(
                                    'name' => 'title',
                                    'label' => esc_html__('Title', 'mouno'),
                                    'type' => 'text',
                                ),
                                array(
                                    'name' => 'rating',
                                    'label' => esc_html__('Rating', 'mouno'),
                                    'type' => 'number',
                                    'min'  => 1,
                                    'max' => 5,
                                    'condition' => [
                                        'get_layout!' => ['1'],
                                    ],
                                ),
                            ],
                            'title_field' => '{{{name}}}',
                            'default' => [
                                [
                                    'content' => esc_html__('I saved over 50% using Mouno over my company. The customer support staff was very helpful. I will definitely do future collaborations. Thank you !!!', 'mouno'),
                                    'name' => esc_html__('Johannes Times', 'mouno'),
                                    'title' => esc_html__('Chicago', 'mouno'),
                                    'rating' => 5,
                                ],
                                [
                                    'content' => esc_html__('Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat', 'mouno'),
                                    'name' => esc_html__('John Smith', 'mouno'),
                                    'title' => esc_html__('Los Angeles', 'mouno'),
                                    'rating' => 5,
                                ],
                                [
                                    'content' => esc_html__('Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer nec odio. Praesent libero. Sed cursus ante dapibus sint diam.', 'mouno'),
                                    'name' => esc_html__('Alice Johnson', 'mouno'),
                                    'title' => esc_html__('San Francisco', 'mouno'),
                                    'rating' => 5,
                                ],
                            ],
                        ),
                        array(
                            'name' => '_icon',
                            'label' => esc_html__('Icon', 'mouno'),
                            'type' => 'icons',
                            'fa4compatibility' => 'icon',
                            'default' => [
                                'value' => [
                                    'url' => content_url('/uploads/2024/12/quotation-marks-2.svg'),
                                    'id' => 5602,
                                ],
                                'library' => 'svg',
                            ],
                            'condition' => [
                                'layout' => ['5'],
                            ],
                        ),
                    ),
                ),
                array(
                    'name' => 'tab_swiper_add_otps',
                    'label' => esc_html__('Addtional Options', 'mouno'),
                    'tab' => 'content',
                    'controls' => array(
                        array(
                            'name' => 'group_carousel',
                            'label' => esc_html__('Group Carousel', 'mouno'),
                            'type' => 'switcher',
                            'default' => '',
                        ),
                        array(
                            'name' => 'group_carousel_class',
                            'type' => 'text',
                            'label' => esc_html__('Enter Common Class', 'mouno'),
                            'placeholder' => esc_html__('example-class', 'mouno'),
                            'condition' => [
                                'group_carousel!' => '',
                            ],
                        ),
                        swiper_controls_options(),
                    ),
                ),

                
                array(
                    'name'     => 'tab_testimonial_style',
                    'label'    => esc_html__( 'Testimonial', 'mouno' ),
                    'tab'      => 'style',
                    'controls' => array(
                        array(
                            'name' => 'text_align',
                            'label' => esc_html__('Alignment', 'mouno' ),
                            'type' => \Elementor\Controls_Manager::CHOOSE,
                            'control_type' => 'responsive',
                            'options' => [
                                'left' => [
                                    'title' => esc_html__('Left', 'mouno' ),
                                    'icon' => 'fa fa-align-left',
                                ],
                                'center' => [
                                    'title' => esc_html__('Center', 'mouno' ),
                                    'icon' => 'fa fa-align-center',
                                ],
                                'right' => [
                                    'title' => esc_html__('Right', 'mouno' ),
                                    'icon' => 'fa fa-align-right',
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-testimonial-carousel .pxl-testimonial-item' => 'text-align: {{VALUE}};',
                            ],
                        ),
                        array(
                            'name' => 'rating_spacing',
                            'label' => esc_html__('Rating Spacing', 'mouno' ),
                            'type' => 'slider',
                            'separator' => 'before',
                            'control_type' => 'responsive',
                            'size_units' => [ 'px', 'custom'],
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 1000
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-testimonial-carousel .pxl-testimonial-item .pxl-testimonial-rating' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                            ],
                            'condition' => [
                                'layout' => ['3']
                            ]
                        ),
                        array(
                            'name' => 'rating_gap',
                            'label' => esc_html__('Rating Gap', 'mouno' ),
                            'type' => 'slider',
                            'control_type' => 'responsive',
                            'size_units' => [ 'px', 'custom'],
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 1000
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-testimonial-carousel .pxl-testimonial-rating' => 'gap: {{SIZE}}{{UNIT}};',
                            ],
                        ),
                        array(
                            'name' => 'divider_color',
                            'label' => esc_html__('Divider Color', 'mouno' ),
                            'type' => 'color',
                            'separator' => 'before',
                            'selectors' => [
                                '{{WRAPPER}} .pxl-testimonial-carousel .pxl-testimonial-divider' => 'background-color: {{VALUE}};',
                            ],
                            'condition' => [
                                'layout' => ['3', '4']
                            ]
                        ),
                        array(
                            'name' => 'divider_spacing',
                            'label' => esc_html__('Divider Spacing', 'mouno' ),
                            'type' => 'slider',
                            'control_type' => 'responsive',
                            'size_units' => [ 'px', 'custom'],
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 1000
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-testimonial-carousel .pxl-testimonial-item .pxl-testimonial-divider' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                            ],
                            'condition' => [
                                'layout' => ['3', '4']
                            ]
                        ),
                        array(
                            'name' => 'content_spacing',
                            'label' => esc_html__('Content Spacing', 'mouno' ),
                            'type' => 'slider',
                            'separator' => 'before',
                            'control_type' => 'responsive',
                            'size_units' => [ 'px', 'custom'],
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 1000
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-testimonial-carousel .pxl-testimonial-item .pxl-testimonial-content' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                            ],
                            'condition' => [
                                'layout' => ['3', '4']
                            ]
                        ),
                        array(
                            'name' => 'content_max_w',
                            'label' => esc_html__('Content Max Width', 'mouno' ),
                            'type' => 'slider',
                            'control_type' => 'responsive',
                            'size_units' => [ 'px', 'custom'],
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 1000
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-testimonial-carousel1 .pxl-testimonial-wrapper' => 'max-width: {{SIZE}}{{UNIT}};',
                            ],
                            'condition' => [
                                'layout!' => ['3']
                            ]
                        ),
                        array(
                            'name' => 'user_gap',
                            'label' => esc_html__('User Gap', 'mouno' ),
                            'type' => 'slider',
                            'separator' => 'before',
                            'control_type' => 'responsive',
                            'size_units' => [ 'px', 'custom'],
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 1000
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-testimonial-carousel .pxl-testimonial-user' => 'gap: {{SIZE}}{{UNIT}};',
                            ],
                            'condition' => [
                                'layout!' => ['4']
                            ]
                        ),
                    ),
                ),

                array(
                    'name'     => 'tab_content_style',
                    'label'    => esc_html__( 'Content', 'mouno' ),
                    'tab'      => 'style',
                    'controls' => array(
                        array(
                            'name' => 'content_color',
                            'label' => esc_html__('Text Color', 'mouno' ),
                            'type' => 'color',
                            'selectors' => [
                                '{{WRAPPER}} .pxl-testimonial-carousel .pxl-testimonial-content' => 'color: {{VALUE}};',
                            ],
                        ),
                        array(
                            'name' => 'content_typography',
                            'type' => \Elementor\Group_Control_Typography::get_type(),
                            'control_type' => 'group',
                            'selector' => '{{WRAPPER}} .pxl-testimonial-carousel .pxl-testimonial-content',
                        ),
                    ),
                ),
                array(
                    'name' => 'tab_rating_style',
                    'label' => esc_html__('Rating', 'mouno' ),
                    'tab' => 'style',
                    'condition' => [
                        'layout' => ['3', '4']
                    ],
                    'controls' => array(
                        array(
                            'name' => 'rating_label_color',
                            'label' => esc_html__('Label Color', 'mouno' ),
                            'type' => 'color',
                            'selectors' => [
                                '{{WRAPPER}} .pxl-testimonial-carousel .pxl-testimonial-rating .pxl-rating-label' => 'color: {{VALUE}};',
                            ],
                        ),
                        array(
                            'name' => 'rating_label_typography',
                            'type' => \Elementor\Group_Control_Typography::get_type(),
                            'control_type' => 'group',
                            'selector' => '{{WRAPPER}} .pxl-testimonial-carousel .pxl-rating-label',
                        ),
                        array(
                            'name' => 'rating_icon_sz',
                            'label' => esc_html__('Icon Size', 'mouno' ),
                            'type' => 'slider',
                            'control_type' => 'responsive',
                            'size_units' => [ 'px', 'custom'],
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 1000
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-testimonial-carousel .pxl-testimonial-rating .pxl-rating-star' => 'font-size: {{SIZE}}{{UNIT}};',
                                '{{WRAPPER}} .pxl-testimonial-carousel .pxl-testimonial-rating .pxl-rating-star svg' => 'height: {{SIZE}}{{UNIT}}; width: auto;',
                            ],
                        ),
                        array(
                            'name' => 'rating_color',
                            'label' => esc_html__('Icon Color', 'mouno' ),
                            'type' => 'color',
                            'selectors' => [
                                '{{WRAPPER}} .pxl-testimonial-carousel .pxl-testimonial-rating' => 'color: {{VALUE}};',
                            ],
                        ),
                        array(
                            'name' => 'rating_bg',
                            'type' => \Elementor\Group_Control_Background::get_type(),
                            'control_type' => 'group',
                            'types' => [ 'classic', 'gradient' ],
                            'selector' => '{{WRAPPER}} .pxl-testimonial-carousel .pxl-testimonial-rating',
                        ),
                        array(
                            'name' => 'rating_border',
                            'type' => \Elementor\Group_Control_Border::get_type(),
                            'separator' => 'before',
                            'control_type' => 'group', 
                            'selector' => '{{WRAPPER}} .pxl-testimonial-carousel .pxl-testimonial-rating',
                        ),
                        array(
                            'name'         => 'rating_box_shadow',
                            'label' => esc_html__( 'Box Shadow', 'mouno' ),
                            'type'         => \Elementor\Group_Control_Box_Shadow::get_type(),
                            'control_type' => 'group',
                            'selector'     => '{{WRAPPER}} .pxl-testimonial-carousel .pxl-testimonial-rating',
                        ),
                        array(
                            'name' => 'rating_border_radius',
                            'label' => esc_html__('Border Radius', 'mouno' ),
                            'type' => 'dimensions',
                            'size_units' => [ 'px', '%' ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-testimonial-carousel .pxl-testimonial-rating' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            ],
                        ),
                        array(
                            'name' => 'rating_padding',
                            'label' => esc_html__('Padding', 'mouno' ),
                            'type' => 'dimensions',
                            'size_units' => [ 'px', '%' ],
                            'control_type' => 'responsive',
                            'separator' => 'before',
                            'selectors' => [
                                '{{WRAPPER}} .pxl-testimonial-carousel .pxl-testimonial-rating' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            ],
                        ),
                    ),
                ),
                array(
                    'name'     => 'tab_user_style',
                    'label'    => esc_html__( 'User', 'mouno' ),
                    'tab'      => 'style',
                    'controls' => array(
                        array(
                            'name' => 'user_img_title', 
                            'label' => esc_html__('Image', 'mouno'),
                            'type' => 'heading',
                        ),
                        array(
                            'name' => 'user_img_w',
                            'label' => esc_html__('Width', 'mouno' ),
                            'type' => 'slider',
                            'control_type' => 'responsive',
                            'size_units' => [ 'px', 'custom'],
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 1000
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-testimonial-carousel .pxl-testimonial-user .pxl-user-image img' => 'width: {{SIZE}}{{UNIT}};min-width: {{SIZE}}{{UNIT}};',
                            ],
                        ),
                        array(
                            'name' => 'user_img_h',
                            'label' => esc_html__('Height', 'mouno' ),
                            'type' => 'slider',
                            'control_type' => 'responsive',
                            'size_units' => [ 'px', 'custom'],
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 1000
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-testimonial-carousel .pxl-testimonial-user .pxl-user-image img' => 'height: {{SIZE}}{{UNIT}};',
                            ],
                        ),
                        array(
                            'name'     => 'user_img_css_filters',
                            'type'     => \Elementor\Group_Control_Css_Filter::get_type(),
                            'control_type' => 'group',
                            'selector' => '{{WRAPPER}} .pxl-testimonial-carousel .pxl-testimonial-user .pxl-user-image img',
                        ),
                        array(
                            'name' => 'user_img_border',
                            'type' => \Elementor\Group_Control_Border::get_type(),
                            'control_type' => 'group', 
                            'selector' => '{{WRAPPER}} .pxl-testimonial-carousel .pxl-testimonial-user .pxl-user-image img',
                        ),
                        array(
                            'name'         => 'user_img_box_shadow',
                            'type'         => \Elementor\Group_Control_Box_Shadow::get_type(),
                            'control_type' => 'group',
                            'selector'     => '{{WRAPPER}} .pxl-testimonial-carousel .pxl-testimonial-user .pxl-user-image img',
                        ),
                        array(
                            'name' => 'user_img_border_radius',
                            'label' => esc_html__('Border Radius', 'mouno' ),
                            'type' => 'dimensions',
                            'size_units' => [ 'px', '%', 'custom' ],
                            'control_type' => 'responsive',
                            'selectors' => [
                                '{{WRAPPER}} .pxl-testimonial-carousel .pxl-testimonial-user .pxl-user-image img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            ],
                        ),
                        array(
                            'name' => 'user_name_h', 
                            'label' => esc_html__('Name', 'mouno'),
                            'type' => 'heading',
                            'separator' => 'before',
                        ),
                        array(
                            'name' => 'user_name_color',
                            'label' => esc_html__('Text Color', 'mouno' ),
                            'type' => 'color',
                            'selectors' => [
                                '{{WRAPPER}} .pxl-testimonial-carousel .pxl-testimonial-user .pxl-user-name' => 'color: {{VALUE}};',
                            ],
                        ),
                        array(
                            'name' => 'user_name_typography',
                            'type' => \Elementor\Group_Control_Typography::get_type(),
                            'control_type' => 'group',
                            'selector' => '{{WRAPPER}} .pxl-testimonial-carousel .pxl-user-name',
                        ),
                        array(
                            'name' => 'user_title_h', 
                            'label' => esc_html__('Title', 'mouno'),
                            'type' => 'heading',
                            'separator' => 'before',
                        ),
                        array(
                            'name' => 'user_title_color',
                            'label' => esc_html__('Text Color', 'mouno' ),
                            'type' => 'color',
                            'selectors' => [
                                '{{WRAPPER}} .pxl-testimonial-carousel .pxl-testimonial-user .pxl-user-title' => 'color: {{VALUE}};',
                            ],
                        ),
                        array(
                            'name' => 'user_title_typography',
                            'type' => \Elementor\Group_Control_Typography::get_type(),
                            'control_type' => 'group',
                            'selector' => '{{WRAPPER}} .pxl-testimonial-carousel .pxl-testimonial-user .pxl-user-title',
                        ),
                    ),
                ),

                load_more_button_style_options(),
                grid_pagination_style_options(),
                swiper_bullets_pagination_style_options(),
                swiper_navigation_style_options(),
                
                array(
                    'name' => 'tab_motion_effects',
                    'label' => esc_html__('Motion Effects', 'mouno' ),
                    'tab' => 'style',
                    'controls' => mouno_get_animation_options([
                        'selector' => '{{WRAPPER}} .pxl-swiper .swiper-slide',
                    ]),
                ),
            ),
        ),
    ),
    mouno_get_class_widget_path()
);