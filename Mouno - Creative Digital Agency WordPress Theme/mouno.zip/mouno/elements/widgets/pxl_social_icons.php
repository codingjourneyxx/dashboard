<?php
pxl_add_custom_widget(
    array(
        'name' => 'pxl_social_icons',
        'title' => esc_html__('Case Social Icons', 'mouno' ),
        'icon' => 'eicon-social-icons',
        'categories' => array('pxltheme-core'),
        'scripts' => array(),
        'params' => array(
            'sections' => array(
                array(
                    'name' => 'tab_social_icons_content',
                    'label' => esc_html__('Social Icons', 'mouno' ),
                    'tab' => 'content',
                    'controls' => array(   
                        array(
                            'name' => 'social_icon_style',
                            'label' => esc_html__('Social Style', 'mouno' ),
                            'type' => \Elementor\Controls_Manager::SELECT,
                            'separator' => 'before',
                            'default' => 'social-icon-default',
                            'options' => [
                                'social-icon-default' => esc_html__('Default', 'mouno'),
                                'social-icon-square-box' => esc_html__('Square Box', 'mouno'),
                                'social-icon-round-box' => esc_html__('Round Box', 'mouno'),
                            ],
                        ),
                        array(
                            'name' => 'social_icons',
                            'label' => esc_html__('Social Icons', 'mouno' ),
                            'type' => \Elementor\Controls_Manager::REPEATER,
                            'controls' => array(
                                array(
                                    'name' => 'social_icon',
                                    'label' => esc_html__('Icon', 'mouno' ),
                                    'type' => \Elementor\Controls_Manager::ICONS,
                                    'fa4compatibility' => 'icon',
                                ),
                                array(
                                    'name' => 'social_link',
                                    'label' => esc_html__('Link', 'mouno' ),
                                    'type' => \Elementor\Controls_Manager::URL,
                                ),
                            ),
                            'default' => [
                                [
                                    'social_icon' => [
                                        'value' => [
                                            'url' => content_url('/uploads/2024/11/facebook.svg'), 
                                            'id' => 786, 
                                        ],
                                        'library' => 'svg',
                                    ],
                                    'social_link' => [
                                        'url' => '#'
                                    ],
                                ],
                                [
                                    'social_icon' => [
                                        'value' => [
                                            'url' => content_url('/uploads/2024/11/instagram.svg'), 
                                            'id' => 787, 
                                        ],
                                        'library' => 'svg',
                                    ],
                                    'social_link' => [
                                        'url' => '#'
                                    ],
                                ],
                                [
                                    'social_icon' => [
                                        'value' => [
                                            'url' => content_url('/uploads/2024/11/twiter.svg'), 
                                            'id' => 3494, 
                                        ],
                                        'library' => 'svg',
                                    ],
                                    'social_link' => [
                                        'url' => '#'
                                    ],
                                ],
                                [
                                    'social_icon' => [
                                        'value' => [
                                            'url' => content_url('/uploads/2024/11/pinterest.svg'), 
                                            'id' => 3493, 
                                        ],
                                        'library' => 'svg',
                                    ],
                                    'social_link' => [
                                        'url' => '#'
                                    ],
                                ],
                                [
                                    'social_icon' => [
                                        'value' => [
                                            'url' => content_url('/uploads/2024/11/youtube.svg'), 
                                            'id' => 3495, 
                                        ],
                                        'library' => 'svg',
                                    ],
                                    'social_link' => [
                                        'url' => '#'
                                    ],
                                ],
                            ],
                        ),
                    ),
                ),
                array(
                    'name' => 'tab_social_icons_style',
                    'label' => esc_html__('Social Icons', 'mouno' ),
                    'tab' => 'style',
                    'controls' => array(
                        array(
                            'name' => 'direction',
                            'label' => esc_html__('Direction', 'mouno' ),
                            'type' => \Elementor\Controls_Manager::CHOOSE,
                            'options' => [
                                'column' => [
                                    'title' => esc_html__('Start', 'mouno' ),
                                    'icon' => 'eicon-justify-start-h',
                                ],
                                'row' => [
                                    'title' => esc_html__('Center', 'mouno' ),
                                    'icon' => 'eicon-justify-center-h',
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-social-icons-wrapper' => 'flex-direction: {{VALUE}};',
                            ],
                        ),
                        array(
                            'name' => 'justify_content_h',
                            'label' => esc_html__('Justify Content', 'mouno' ),
                            'type' => \Elementor\Controls_Manager::CHOOSE,
                            'options' => [
                                'start' => [
                                    'title' => esc_html__('Start', 'mouno' ),
                                    'icon' => 'eicon-justify-start-h',
                                ],
                                'center' => [
                                    'title' => esc_html__('Center', 'mouno' ),
                                    'icon' => 'eicon-justify-center-h',
                                ],
                                'end' => [
                                    'title' => esc_html__('End', 'mouno' ),
                                    'icon' => 'eicon-justify-end-h',
                                ],
                                'space-around' => [
                                    'title' => esc_html__('Space Around', 'mouno' ),
                                    'icon' => 'eicon-justify-space-around-h',
                                ],
                                'space-evenly' => [
                                    'title' => esc_html__('Space Evenly', 'mouno' ),
                                    'icon' => 'eicon-justify-space-evenly-h',
                                ],
                                'space-between' => [
                                    'title' => esc_html__('Space Between', 'mouno' ),
                                    'icon' => 'eicon-justify-space-between-h',
                                ],
                            ],
                            'label_block' => true,
                            'selectors' => [
                                '{{WRAPPER}} .pxl-social-icons-wrapper' => 'justify-content: {{VALUE}};',
                            ],
                        ),
                        array(
                            'name' => 'item_spacing',
                            'label' => esc_html__('Icon Spacing', 'mouno' ),
                            'type' => 'slider',
                            'control_type' => 'responsive',
                            'size_units' => [ 'px', '%', 'custom' ],
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 300,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-social-icons-wrapper' => 'gap: {{SIZE}}{{UNIT}};',
                            ],
                        ),
                        array(
                            'name' => 'item_sz',
                            'label' => esc_html__('Icon Size', 'mouno' ),
                            'type' => 'slider',
                            'control_type' => 'responsive',
                            'size_units' => [ 'px', '%', 'custom' ],
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 1000,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-social-icons-wrapper .pxl-social-icons-link svg' => 'height: {{SIZE}}{{UNIT}}; width: auto;',
                            ],
                        ),
                        array(
                            'name' => 'social_icon_control',
                            'control_type' => 'tab',
                            'tabs' => [
                                [
                                    'name' => 'social_icon_normal',
                                    'label' => esc_html__('Normal', 'mouno' ),
                                    'type' => 'tab',
                                    'controls' => [  
                                        array(
                                            'name' => 'social_icon_color',
                                            'label' => esc_html__('Color', 'mouno' ),
                                            'type' => 'color',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-social-icons-wrapper .pxl-social-icons-link' => 'color: {{VALUE}};',
                                            ],
                                        ),
                                    ],
                                ],
                                [
                                    'name' => 'social_icon_hover',
                                    'label' => esc_html__('Hover', 'mouno' ),
                                    'type' => \Elementor\Controls_Manager::TAB,
                                    'controls' => [
                                        array(
                                            'name' => 'social_icon_hover_style',
                                            'label' => esc_html__('Hover Style', 'mouno' ),
                                            'type' => 'select',
                                            'default' => 'hover-default',
                                            'options' => [
                                                'hover-default' => esc_html__('Normal', 'mouno' ),
                                            ],
                                        ),
                                        array(
                                            'name' => 'social_icon_hover_color',
                                            'label' => esc_html__('Color', 'mouno' ),
                                            'type' => 'color',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-social-icons-wrapper .pxl-social-icons-link:hover' => 'color: {{VALUE}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'social_icon_transition_duration',
                                            'label' => esc_html__('Transition Duration', 'mouno'),
                                            'type' => \Elementor\Controls_Manager::SLIDER,
                                            'size_units' => ['ms', 's'],
                                            'default' => [
                                                'unit' => 'ms',
                                            ],
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-social-icons-wrapper .pxl-social-icons-link' => 'transition-duration: {{SIZE}}{{UNIT}};',
                                            ],
                                        ),
                                    ],
                                ],
                            ],
                        ),
                    ),
                ),
            ),
        ),
    ),
    mouno_get_class_widget_path()
);