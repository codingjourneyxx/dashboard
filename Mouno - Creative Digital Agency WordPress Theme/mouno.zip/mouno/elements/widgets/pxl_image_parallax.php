<?php
pxl_add_custom_widget(
    array(
        'name' => 'pxl_image_parallax',
        'title' => esc_html__('Case Image Parallax', 'mouno' ),
        'icon' => 'eicon-parallax',
        'categories' => array('pxltheme-core'),
        'scripts' => array(
            'parallax',
        ),
        'params' => array(
            'sections' => array(
                array(
                    'name' => 'tab_img_content',
                    'label' => esc_html__('Image', 'mouno' ),
                    'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
                    'controls' => array(
                        array(
                            'name' => 'img',
                            'label' => esc_html__('Choose Image', 'mouno' ),
                            'type' => 'media',
                        ),
                        array(
                            'name' => 'img_size',
                            'label' => esc_html__('Image Size', 'mouno' ),
                            'type' => 'text',
                            'description' => esc_html__('Ex: "thumbnail", "medium", "large", "full"...Alternatively enter size in pixels. Ex: 200x100 - Width x Height.', 'mouno'),
                        ),
                        array(
                            'name' => 'link_url',
                            'label' => esc_html__('Link URL', 'mouno' ),
                            'type' =>'url',
                        ),
                    ),
                ),
                array(
                    'name' => 'tab_img_style',
                    'label' => esc_html__('Image', 'mouno' ),
                    'tab' => \Elementor\Controls_Manager::TAB_STYLE,
                    'controls' => array(
                        array(
                            'name' => 'img_align',
                            'label' => esc_html__('Alignment', 'mouno' ),
                            'type' => 'choose',
                            'control_type' => 'responsive',
                            'options' => [
                                'left' => [
                                    'title' => esc_html__('Left', 'mouno' ),
                                    'icon' => 'fa fa-align-left',
                                ],
                                'center' => [
                                    'title' => esc_html__('Center', 'mouno' ),
                                    'icon' => 'fa fa-align-center',
                                ],
                                'right' => [
                                    'title' => esc_html__('Right', 'mouno' ),
                                    'icon' => 'fa fa-align-right',
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-image-wrapper' => 'text-align: {{VALUE}};',
                            ],
                        ),
                        array(
                            'name' => 'img_w',
                            'label' => esc_html__('Width', 'mouno' ),
                            'type' => \Elementor\Controls_Manager::SLIDER,
                            'control_type' => 'responsive',
                            'size_units' => ['px', '%', 'custom'],
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 3000,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-image-wrapper .pxl-image-item' => 'width: {{SIZE}}{{UNIT}};',
                            ],
                        ),
                        array(
                            'name' => 'img_max_w',
                            'label' => esc_html__('Max Width', 'mouno' ),
                            'type' => \Elementor\Controls_Manager::SLIDER,
                            'control_type' => 'responsive',
                            'size_units' => ['px', '%', 'custom'],
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 3000,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-image-wrapper .pxl-image-item:not(.scroll-parallax-item)' => 'max-width: {{SIZE}}{{UNIT}};',
                            ],
                        ),
                        array(
                            'name' => 'img_h',
                            'label' => esc_html__('Height', 'mouno' ),
                            'type' => \Elementor\Controls_Manager::SLIDER,
                            'control_type' => 'responsive',
                            'size_units' => ['px', '%', 'custom'],
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 3000,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-image-wrapper .pxl-image-item:not(.scroll-parallax-item) img,
                                {{WRAPPER}} .pxl-image-wrapper' => 'height: {{SIZE}}{{UNIT}};',
                            ],
                        ),

                        array(
                            'name' => 'img_control',
                            'control_type' => 'tab',
                            'tabs' => [
                                [
                                    'name' => 'img_normal',
                                    'label' => esc_html__('Normal', 'mouno' ),
                                    'type' => 'tab',
                                    'controls' => [  
                                        array(
                                            'name' => 'img_opacity',
                                            'label' => esc_html__('Opacity', 'mouno' ),
                                            'type' => \Elementor\Controls_Manager::SLIDER,
                                            'control_type' => 'responsive',
                                            'size_units' => [''],
                                            'range' => [
                                                '' => [
                                                    'min' => 0,
                                                    'max' => 1,
                                                    'step' => 0.01,
                                                ],
                                            ],
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-image-wrapper .pxl-image-item' => 'opacity: {{SIZE}}{{UNIT}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'img_css_filter', 
                                            'type' => \Elementor\Group_Control_Css_Filter::get_type(),
                                            'control_type' => 'group',
                                            'selector' => '{{WRAPPER}} .pxl-image-wrapper .pxl-image-item',
                                        ),
                                        array(
                                            'name' => 'img_box_shadow', 
                                            'type' => \Elementor\Group_Control_Box_Shadow::get_type(),
                                            'control_type' => 'group',
                                            'selector' => '{{WRAPPER}} .pxl-image-wrapper .pxl-image-item',
                                        ),
                                        array(
                                            'name' => 'img_border', 
                                            'type' => \Elementor\Group_Control_Border::get_type(),
                                            'control_type' => 'group',
                                            'selector' => '{{WRAPPER}} .pxl-image-wrapper .pxl-image-item',
                                        ),
                                        array(
                                            'name' => 'img_border_radius',
                                            'label' => esc_html__('Border Radius', 'mouno' ),
                                            'type' => \Elementor\Controls_Manager::DIMENSIONS,
                                            'size_units' => [ 'px', '%' ],
                                            'control_type' => 'responsive',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-image-wrapper .pxl-image-item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'img_padding',
                                            'label' => esc_html__('Padding', 'mouno' ),
                                            'type' => \Elementor\Controls_Manager::DIMENSIONS,
                                            'size_units' => [ 'px', '%' ],
                                            'control_type' => 'responsive',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-image-wrapper .pxl-image-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                    ],
                                ],
                                [
                                    'name' => 'img_hover',
                                    'label' => esc_html__('Hover', 'mouno' ),
                                    'type' => \Elementor\Controls_Manager::TAB,
                                    'controls' => [
                                        array(
                                            'name' => 'img_hover_opacity',
                                            'label' => esc_html__('Opacity', 'mouno' ),
                                            'type' => \Elementor\Controls_Manager::SLIDER,
                                            'control_type' => 'responsive',
                                            'size_units' => [''],
                                            'range' => [
                                                '' => [
                                                    'min' => 0,
                                                    'max' => 1,
                                                    'step' => 0.01,
                                                ],
                                            ],
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-image-wrapper .pxl-image-item' => 'opacity: {{SIZE}}{{UNIT}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'img_hover_border_radius',
                                            'label' => esc_html__('Border Radius', 'mouno' ),
                                            'type' => \Elementor\Controls_Manager::DIMENSIONS,
                                            'size_units' => [ 'px', '%' ],
                                            'control_type' => 'responsive',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-image-wrapper .pxl-image-item:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                    ],
                                ],
                            ],
                        ),
                    ),
                ),
                array(
                    'name' => 'tab_img_effect',
                    'label' => esc_html__('Effect', 'mouno' ),
                    'tab' => \Elementor\Controls_Manager::TAB_STYLE,
                    'controls' => array(
                        array(
                            'name' => 'img_effect',
                            'label' => esc_html__('Effect', 'mouno' ),
                            'type' => \Elementor\Controls_Manager::SELECT,
                            'default' => '',
                            'options' => [
                                ''   => esc_html__('None', 'mouno'),
                                'scroll-parallax'   => esc_html__('Scroll Parallax', 'mouno'),
                            ],
                        ),

                        array(
                            'name' => 'parallax_opcity',
                            'label' => esc_html__( 'Opacity', 'mouno' ),
                            'type' => 'number',
                            'min' => 0,
                            'max' => 1,
                            'step' => 0.1,
                            'condition' => [
                                'img_effect' => 'scroll-parallax',
                            ]
                        ),
                        array(
                            'name' => 'parallax_translate_dir',
                            'label' => esc_html__( 'Translate Direction', 'mouno' ),
                            'type' => \Elementor\Controls_Manager::SELECT,
                            'options' => [
                                'x' => esc_html__('X', 'mouno'), 
                                'y' => esc_html__('Y', 'mouno'), 
                            ],
                            'default' => 'y',
                        ),
                        array(
                            'name' => 'parallax_x',
                            'label' => esc_html__( 'TranslateX', 'mouno' ),
                            'type' => 'slider',
                            'size_units' => ['px'],
                            'range' => [
                                'px' => [
                                    'min' => -1000,
                                    'max' => 1000,
                                ],
                            ],
                            'condition' => [
                                'parallax_translate_dir' => 'x',
                            ],
                        ),
                        array(
                            'name' => 'parallax_y',
                            'label' => esc_html__( 'TranslateY', 'mouno' ),
                            'type' => 'slider',
                            'size_units' => ['px'],
                            'range' => [
                                'px' => [
                                    'min' => -1000,
                                    'max' => 1000,
                                ],
                            ],
                            'condition' => [
                                'parallax_translate_dir' => 'y',
                            ],
                        ),
                        array(
                            'name' => 'parallax_rotate',
                            'label' => esc_html__( 'Rotate', 'mouno' ),
                            'type' => 'number',
                            'min' => -360,
                            'max' => 360,
                            'placeholder' => esc_html__('Ex: 50', 'mouno'),
                        ),
                        array(
                            'name' => 'parallax_scale',
                            'label' => esc_html__( 'Scale', 'mouno' ),
                            'type' => 'number',
                            'min' => -2,
                            'max' => 2,
                            'step' => 0.1,
                            'placeholder' => esc_html__('Ex: 1.2', 'mouno'),
                        ),
            //         array(
            //             'name' => 'wrap_img_height',
            //             'label' => esc_html__('Wrap Height', 'mouno' ),
            //             'type' => \Elementor\Controls_Manager::SLIDER,
            //             'control_type' => 'responsive',
            //             'range' => [
            //                 'px' => [
            //                     'min' => 0,
            //                     'max' => 3000,
            //                 ],
            //             ],
            //             'default' => [
            //                 'unit' => 'px',
            //                 'size' => 350,
            //             ],
            //             'condition' => [
            //                 'img_effect' => 'pxl-scroll-parallax',
            //             ],
            //             'selectors' => [
            //                 '{{WRAPPER}} .pxl-image-wrapper .pxl-image-item a' => 'height: {{SIZE}}{{UNIT}};',
            //             ],
            //         ),
            //         array(
            //             'name' => 'img_offsset_t',
            //             'label' => esc_html__('Top', 'mouno' ),
            //             'type' => \Elementor\Controls_Manager::SLIDER,
            //             'control_type' => 'responsive',
            //             'range' => [
            //                 'px' => [
            //                     'min' => 0,
            //                     'max' => 3000,
            //                 ],
            //             ],
            //             'default' => [
            //                 'unit' => 'px',
            //                 'size' => 0,
            //             ],
            //             'condition' => [
            //                 'img_effect' => 'pxl-scroll-parallax',
            //             ],
            //             'selectors' => [
            //                 '{{WRAPPER}} .pxl-image-wrapper .pxl-image-item .pxl-item-image,
            //                 {{WRAPPER}} .pxl-image-wrapper .pxl-image-item .pxl-item-background' => 'top: {{SIZE}}{{UNIT}};',
            //             ],
            //         ),
            //         array(
            //             'name' => 'img_offsset_r',
            //             'label' => esc_html__('Right', 'mouno' ),
            //             'type' => \Elementor\Controls_Manager::SLIDER,
            //             'control_type' => 'responsive',
            //             'range' => [
            //                 'px' => [
            //                     'min' => 0,
            //                     'max' => 3000,
            //                 ],
            //             ],
            //             'default' => [
            //                 'unit' => 'px',
            //                 'size' => 0,
            //             ],
            //             'condition' => [
            //                 'img_effect' => 'pxl-scroll-parallax',
            //             ],
            //             'selectors' => [
            //                 '{{WRAPPER}} .pxl-image-wrapper .pxl-image-item .pxl-item-image,
            //                 {{WRAPPER}} .pxl-image-wrapper .pxl-image-item .pxl-item-background' => 'right: {{SIZE}}{{UNIT}};',
            //             ],
            //         ),
            //         array(
            //             'name' => 'img_offsset_b',
            //             'label' => esc_html__('Bottom', 'mouno' ),
            //             'type' => \Elementor\Controls_Manager::SLIDER,
            //             'control_type' => 'responsive',
            //             'range' => [
            //                 'px' => [
            //                     'min' => 0,
            //                     'max' => 3000,
            //                 ],
            //             ],
            //             'default' => [
            //                 'unit' => 'px',
            //                 'size' => 0,
            //             ],
            //             'condition' => [
            //                 'img_effect' => 'pxl-scroll-parallax',
            //             ],
            //             'selectors' => [
            //                 '{{WRAPPER}} .pxl-image-wrapper .pxl-image-item .pxl-item-image,
            //                 {{WRAPPER}} .pxl-image-wrapper .pxl-image-item .pxl-item-background' => 'bottom: {{SIZE}}{{UNIT}};',
            //             ],
            //         ),
            //         array(
            //             'name' => 'img_offsset_l',
            //             'label' => esc_html__('Left', 'mouno' ),
            //             'type' => \Elementor\Controls_Manager::SLIDER,
            //             'control_type' => 'responsive',
            //             'range' => [
            //                 'px' => [
            //                     'min' => 0,
            //                     'max' => 3000,
            //                 ],
            //             ],
            //             'default' => [
            //                 'unit' => 'px',
            //                 'size' => 0,
            //             ],
            //             'condition' => [
            //                 'img_effect' => 'pxl-scroll-parallax',
            //             ],
            //             'selectors' => [
            //                 '{{WRAPPER}} .pxl-image-wrapper .pxl-image-item .pxl-item-image,
            //                 {{WRAPPER}} .pxl-image-wrapper .pxl-image-item .pxl-item-background' => 'left: {{SIZE}}{{UNIT}};',
            //             ],
            //         ),
                    ),
                ),
                array(
                    'name' => 'tab_img_animation',
                    'label' => esc_html__('Animation', 'mouno' ),
                    'tab' => \Elementor\Controls_Manager::TAB_STYLE,
                    'controls' => mouno_get_animation_options(),
                ),
                array(
                    'name' => 'tab_style_overlay',
                    'label' => esc_html__('Overlay', 'mouno' ),
                    'tab' => \Elementor\Controls_Manager::TAB_STYLE,
                    'controls' => array(
                        array(
                            'name' => 'show_overlay',
                            'label' => esc_html__('Overlay', 'mouno' ),
                            'type' => \Elementor\Controls_Manager::SWITCHER,
                            'default' => '',
                        ),
                        array(
                            'name' => 'overlay_bg',
                            'type' => \Elementor\Group_Control_Background::get_type(),
                            'types' => [ 'classic', 'gradient'],
                            'control_type' => 'group',
                            'selector' => '{{WRAPPER}} .pxl-image-single .pxl-item-overlay',
                            'condition' => [
                                'show_overlay!' => '',
                            ],
                        ),
                    ),
                ),
            ),
        ),
    ),
    mouno_get_class_widget_path()
);