<?php
pxl_add_custom_widget(
    array(
        'name' => 'pxl_image',
        'title' => esc_html__('Case Image', 'mouno' ),
        'icon' => 'eicon-image',
        'categories' => array('pxltheme-core'),
        'scripts' => [
            'bundle',
            'mouno-effects',
            'mouno-parallax',
        ],
        'params' => array(
            'sections' => array(
                array(
                    'name' => 'tab_img_content',
                    'label' => esc_html__('Image', 'mouno' ),
                    'tab' => 'content',
                    'controls' => array_merge(
                        array(
                            array(
                                'name' => 'img',
                                'label' => esc_html__('Image', 'mouno' ),
                                'type' => 'media',
                            ),
                        ),
                        image_dimension_options(),
                        array(
                            array(
                                'name' => 'is_overlay',
                                'label' => esc_html__('Overlay', 'mouno'),
                                'type' => 'switcher',
                                'separator' => 'before',
                                'default' => '',
                            ),
                            array(
                                'name' => 'overlay_bg',
                                'type' => \Elementor\Group_Control_Background::get_type(),
                                'control_type' => 'group',
                                'types' => [ 'classic', 'gradient' ],
                                'selector' => '{{WRAPPER}} .pxl-image-wrapper .pxl-image-item:after',
                                'condition' => [
                                    'is_overlay!' => '',
                                ],
                            ),
                        )
                    ),
                ),
                array(
                    'name' => 'tab_img_style',
                    'label' => esc_html__('Image', 'mouno' ),
                    'tab' => 'style',
                    'controls' => array(
                        array(
                            'name' => 'justify_content_h',
                            'label' => esc_html__('Justify Content', 'mouno' ),
                            'type' => 'choose',
                            'options' => [
                                'start' => [
                                    'title' => esc_html__('Start', 'mouno' ),
                                    'icon' => 'eicon-justify-start-h',
                                ],
                                'center' => [
                                    'title' => esc_html__('Center', 'mouno' ),
                                    'icon' => 'eicon-justify-center-h',
                                ],
                                'end' => [
                                    'title' => esc_html__('End', 'mouno' ),
                                    'icon' => 'eicon-justify-end-h',
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-image-wrapper' => 'justify-content: {{VALUE}};',
                            ],
                        ),
                        array(
                            'name' => 'img_w',
                            'label' => esc_html__('Width', 'mouno' ),
                            'type' => 'slider',
                            'control_type' => 'responsive',
                            'size_units' => [ 'px', '%', 'custom' ],
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 2000,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-image-wrapper .pxl-image-item img' => 'width: {{SIZE}}{{UNIT}};',
                            ],
                        ),
                        array(
                            'name' => 'img_max_w',
                            'label' => esc_html__('Max Width', 'mouno' ),
                            'type' => 'slider',
                            'control_type' => 'responsive',
                            'size_units' => [ 'px', '%', 'custom' ],
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 2000,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-image-wrapper .pxl-image-item img' => 'max-width: {{SIZE}}{{UNIT}};',
                            ],
                        ),
                        array(
                            'name' => 'img_h',
                            'label' => esc_html__('Height', 'mouno' ),
                            'type' => 'slider',
                            'control_type' => 'responsive',
                            'size_units' => [ 'px', '%', 'custom' ],
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 2000,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-image-wrapper .pxl-image-item' => 'height: {{SIZE}}{{UNIT}};',
                            ],
                        ),
                        array(
                            'name' => 'img_controls',
                            'control_type' => 'tab',
                            'separator' => 'before',
                            'tabs' => [
                                [
                                    'name' => 'img_normal',
                                    'label' => esc_html__('Normal', 'mouno' ),
                                    'type' => 'tab',
                                    'controls' => [  
                                        array(
                                            'name' => 'img_opacity',
                                            'label' => esc_html__('Opacity', 'mouno' ),
                                            'type' => 'slider',
                                            'control_type' => 'responsive',
                                            'size_units' => ['px'],
                                            'range' => [
                                                'px' => [
                                                    'min' => 0,
                                                    'max' => 1,
                                                    'step' => 0.01,
                                                ],
                                            ],
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-image-wrapper .pxl-image-item' => 'opacity: {{SIZE}};',
                                            ],
                                        ),
                                        array(
                                            'name'     => 'img_css_filters',
                                            'type'     => \Elementor\Group_Control_Css_Filter::get_type(),
                                            'control_type' => 'group',
                                            'selector' => '{{WRAPPER}} .pxl-image-wrapper .pxl-image-item',
                                        ),
                                        array(
                                            'name' => 'img_border',
                                            'type' => \Elementor\Group_Control_Border::get_type(),
                                            'control_type' => 'group', 
                                            'separator' => 'before',
                                            'selector' => '{{WRAPPER}} .pxl-image-wrapper .pxl-image-item',
                                        ),
                                        array(
                                            'name'         => 'img_box_shadow',
                                            'type'         => \Elementor\Group_Control_Box_Shadow::get_type(),
                                            'control_type' => 'group',
                                            'selector'     => '{{WRAPPER}} .pxl-image-wrapper .pxl-image-item',
                                        ),
                                        array(
                                            'name' => 'img_border_radius',
                                            'label' => esc_html__('Border Radius', 'mouno' ),
                                            'type' => \Elementor\Controls_Manager::DIMENSIONS,
                                            'size_units' => [ 'px', '%', 'custom' ],
                                            'control_type' => 'responsive',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-image-wrapper .pxl-image-item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                    ],
                                ],
                                [
                                    'name' => 'img_hover',
                                    'label' => esc_html__('Hover', 'mouno' ),
                                    'type' => \Elementor\Controls_Manager::TAB,
                                    'controls' => [
                                        array(
                                            'name' => 'img_hover_opacity',
                                            'label' => esc_html__('Opacity', 'mouno' ),
                                            'type' => 'slider',
                                            'control_type' => 'responsive',
                                            'size_units' => ['px'],
                                            'range' => [
                                                'px' => [
                                                    'min' => 0,
                                                    'max' => 1,
                                                    'step' => 0.01,
                                                ],
                                            ],
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-image-wrapper .pxl-image-item:hover' => 'opacity: {{SIZE}};',
                                            ],
                                        ),
                                        array(
                                            'name'     => 'img_hover_css_filters',
                                            'type'     => \Elementor\Group_Control_Css_Filter::get_type(),
                                            'control_type' => 'group',
                                            'selector' => '{{WRAPPER}} .pxl-image-wrapper .pxl-image-item:hover',
                                        ),
                                        array(
                                            'name' => 'img_hover_border',
                                            'type' => \Elementor\Group_Control_Border::get_type(),
                                            'control_type' => 'group', 
                                            'separator' => 'before',
                                            'selector' => '{{WRAPPER}} .pxl-image-wrapper .pxl-image-item:hover',
                                        ),
                                        array(
                                            'name'         => 'img_hover_box_shadow',
                                            'type'         => \Elementor\Group_Control_Box_Shadow::get_type(),
                                            'control_type' => 'group',
                                            'selector'     => '{{WRAPPER}} .pxl-image-wrapper .pxl-image-item:hover',
                                        ),
                                        array(
                                            'name' => 'img_hover_border_radius',
                                            'label' => esc_html__('Border Radius', 'mouno' ),
                                            'type' => \Elementor\Controls_Manager::DIMENSIONS,
                                            'size_units' => [ 'px', '%', 'custom' ],
                                            'control_type' => 'responsive',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-image-wrapper .pxl-image-item:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'img_hover_effect',
                                            'label' => esc_html__('Hover Effect', 'mouno' ),
                                            'type' => 'select',
                                            'separator' => 'before',
                                            'options' => [
                                                ''               => esc_html__('None', 'mouno'),
                                                'hover-parallax' => esc_html__('Parallax', 'mouno'),
                                                'hover-flowmap-deformation flowmap-deformation1' => esc_html__('Flowmap Deformation 1', 'mouno'),
                                                'hover-flowmap-deformation flowmap-deformation2' => esc_html__('Flowmap Deformation 2', 'mouno'),
                                                'hover-image-distortion' => esc_html__('Image Distortion', 'mouno'),
                                            ],
                                            'default' => '',
                                        ),
                                    ],
                                ],
                            ],
                        ),
                    ),
                ),


                // Motion Effects
                array(
                    'name' => 'tab_motion_effects',
                    'label' => esc_html__('Motion Effects', 'mouno'),
                    'tab' => 'style',
                    'controls' => array_merge(
                        array(
                            array(
                                'name'=> 'scrolling_effect',
                                'label'=> esc_html__('Scrolling Effect', 'mouno'),
                                'type'=> 'select',
                                'options'=> [
                                    '' => esc_html__('None', 'mouno'),
                                    'parallax' => esc_html__('Parallax', 'mouno'),
                                ],
                                'default'=> '',
                            ),
                        ),
                        mouno_parallax_options([
                            'condition' => [
                                'scrolling_effect' => 'parallax',
                            ],
                        ]),
                        array(
                            array(
                                'name' => '__divider',
                                'type' => 'divider',
                            ),
                            array(
                                'name'=> 'anim_effect',
                                'label'=> esc_html__('Animation Effects', 'mouno'),
                                'type'=> 'select',
                                'options'=> [
                                    '' => esc_html__('None', 'mouno'),
                                    'zoom-in-out-animated' => esc_html__('Zoom In Out', 'mouno'),
                                    'slide-ttb-animated' => esc_html__('Slide Top To Bottom', 'mouno'),
                                    'slide-btt-animated' => esc_html__('Slide Bottom To Top', 'mouno'),
                                    'slide-ltr-animated' => esc_html__('Slide Left To Right', 'mouno'),
                                    'slide-rtl-animated' => esc_html__('Slide Right To Left', 'mouno'),
                                    'ring-animated'      => esc_html__('Ring', 'mouno'),
                                    'spin-animated'      => esc_html__('Spin', 'mouno')
                                ],
                                'default'=> '',
                            ),
                            [
                                'name' => 'anim_effect_duration',
                                'label' => esc_html__('Animation Duration(ms)', 'mouno'),
                                'type' => 'number',
                                'condition' => array(
                                    'anim_effect!' => '',
                                ),
                                'selectors' => [
                                    '{{WRAPPER}} .pxl-icon-wrapper .pxl-icon-item' => 'animation-duration: {{SIZE}}ms; -webkit-animation-duration: {{SIZE}}ms;',
                                ],
                            ],
                            array(
                                'name' => '___divider',
                                'type' => 'divider',
                            ),
                        ),
                        mouno_get_animation_options([
                            'selector' => '{{WRAPPER}} pxl-image-wrapper',
                        ]),
                    ),
                ),
            ),
        ),
    ),
    mouno_get_class_widget_path()
);