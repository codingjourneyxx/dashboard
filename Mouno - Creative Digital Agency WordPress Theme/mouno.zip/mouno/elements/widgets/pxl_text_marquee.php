<?php
pxl_add_custom_widget(
    array(
        'name' => 'pxl_text_marquee',
        'title' => esc_html__('Case Text Marquee', 'mouno' ),
        'icon' => 'eicon-wordart',
        'categories' => array('pxltheme-core'),
        'scripts' => array(
            'scroll-trigger',
            'mouno-effects',
        ),
        'params' => array(
            'sections' => array(
                array(
                    'name' => 'tab_content',
                    'label' => esc_html__('Content', 'mouno' ),
                    'tab' => 'content',
                    'controls' => array(   
                        array(
                            'name' => 'text',
                            'type' => \Elementor\Controls_Manager::WYSIWYG,
                            'default' => esc_html__( 'Marketing . Advertising . Promotion', 'mouno' ),
                            'description' => 'Highlight text width shortcode: [highlight text="..."]',
                        ),
                        array(
                            'name' => 'marquee_type',
                            'label' => esc_html__('Marquree', 'mouno'),
                            'type' => 'select',
                            'separator' => 'before',
                            'options' => [
                                '' => esc_html__('Auto', 'mouno'),
                                'scroll-marquee-animation' => esc_html__('Scroll', 'mouno'),
                            ],
                            'default' => '',
                        ),
                        array(
                            'name' => 'justify_content',
                            'label' => esc_html__('Justify Content', 'mouno'),
                            'type' => 'choose',
                            'control_type' => 'responsive',
                            'options' => array(
                                'start' => [
                                    'title' => esc_html__('Start', 'mouno' ),
                                    'icon' => 'eicon-justify-start-h',
                                ],
                                'center' => [
                                    'title' => esc_html__('Center', 'mouno' ),
                                    'icon' => 'eicon-justify-center-h',
                                ],
                                'end' => [
                                    'title' => esc_html__('End', 'mouno' ),
                                    'icon' => 'eicon-justify-end-h',
                                ],
                            ),
                            'selectors' => [
                                '{{WRAPPER}} .pxl-text-marquee-wrapper' => 'justify-content: {{VALUE}};'
                            ],
                            'condition' => [
                                'marquee_type' => 'scroll-marquee-animation',
                            ],
                        ),
                        array(
                            'name' => 'duplicate',
                            'label' => esc_html__('Duplicate', 'mouno'),
                            'type' => 'switcher',
                            'default' => 'true',
                            'condition' => [
                                'marquee_type' => '',
                            ],
                        ),
                        array(
                            'name' => 'direction',
                            'label' => esc_html__('Direction', 'mouno'),
                            'type' => 'select',
                            'options' => [
                                'rtl' => esc_html__('Right to Left', 'mouno'),
                                'ltr' => esc_html__('Left to Right', 'mouno'),
                            ],
                            'default' => 'rtl',
                            'condition' => [
                                'marquee_type' => '',
                            ],
                        ),
                        array(
                            'name' => 'duration',
                            'label' => esc_html__('Duration', 'mouno'),
                            'type' => 'slider',
                            'size_units' => ['ms', 's'],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-text-marquee-wrapper .pxl-text-marquee-item' => '$pxl-duration: {{SIZE}}{{UNIT}};',
                            ],
                            'condition' => [
                                'marquee_type' => '',
                            ],
                        ),
                        array(
                            'name' => 'gap',
                            'label' => esc_html__('Gap', 'mouno'),
                            'type' => 'slider',
                            'size_units' => ['px', '%'],
                            'control_type' => 'responsive',
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 1000,
                                ],
                            ],
                            'condition' => [
                                'marquee_type' => '',
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-text-marquee-wrapper' => '--pxl-spacing: {{SIZE}}{{UNIT}};',
                            ],
                        ),
                    ),
                ),
                array(
                    'name' => 'tab_text_marquee_style',
                    'label' => esc_html__('Text Marquee', 'mouno' ),
                    'tab' => 'style',
                    'controls' => array(
                        array(
                            'name' => 'text_controls',
                            'control_type' => 'tab',
                            'tabs' => [
                                [
                                    'name' => 'text_normal',
                                    'label' => esc_html__('Normal', 'mouno' ),
                                    'type' => 'tab',
                                    'controls' => [  
                                        array(
                                            'name' => 'text_color',
                                            'label' => esc_html('Text Color', 'mouno'),
                                            'type' => 'color',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-text-marquee-wrapper .pxl-text-marquee-item' => 'color: {{VALUE}}',
                                            ],
                                        ),
                                        array(
                                            'name' => 'text_typography',
                                            'type' => \Elementor\Group_Control_Typography::get_type(),
                                            'control_type' => 'group',
                                            'selector' => '{{WRAPPER}} .pxl-text-marquee-wrapper .pxl-text-marquee-item',
                                        ),
                                        array(
                                            'name' => 'text_stroke',
                                            'type' => \Elementor\Group_Control_Text_Stroke::get_type(),
                                            'control_type' => 'group',
                                            'selector' => '{{WRAPPER}} .pxl-text-marquee-wrapper .pxl-text-marquee-item',
                                        ),
                                        array(
                                            'name' => 'text_shadow',
                                            'type' => \Elementor\Group_Control_Text_Shadow::get_type(),
                                            'control_type' => 'group',
                                            'selector' => '{{WRAPPER}} .pxl-text-marquee-wrapper .pxl-text-marquee-item',
                                        ),
                                    ],
                                ],
                                [
                                    'name' => 'text_highlight',
                                    'label' => esc_html__('Highlight', 'mouno' ),
                                    'type' => 'tab',
                                    'controls' => [
                                        array(
                                            'name' => 'text_hl_color',
                                            'label' => esc_html('Text Color', 'mouno'),
                                            'type' => 'color',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-text-marquee-wrapper .pxl-text-marquee-item .pxl-text-highlight' => 'color: {{VALUE}}',
                                            ],
                                        ),
                                        array(
                                            'name' => 'text_hl_typography',
                                            'type' => \Elementor\Group_Control_Typography::get_type(),
                                            'control_type' => 'group',
                                            'selector' => '{{WRAPPER}} .pxl-text-marquee-wrapper .pxl-text-marquee-item .pxl-text-highlight',
                                        ),
                                        array(
                                            'name' => 'text_hl_stroke',
                                            'type' => \Elementor\Group_Control_Text_Stroke::get_type(),
                                            'control_type' => 'group',
                                            'selector' => '{{WRAPPER}} .pxl-text-marquee-wrapper .pxl-text-marquee-item .pxl-text-highlight',
                                        ),
                                        array(
                                            'name' => 'text_hl_shadow',
                                            'type' => \Elementor\Group_Control_Text_Shadow::get_type(),
                                            'control_type' => 'group',
                                            'selector' => '{{WRAPPER}} .pxl-text-marquee-wrapper .pxl-text-marquee-item .pxl-text-highlight',
                                        ),
                                    ],
                                ],
                            ],
                        ),
                    ),
                ),
                array(
                    'name' => 'tab_link_style',
                    'label' => esc_html__( 'Link', 'mouno' ),
                    'tab' => 'style',
                    'controls' => array(
                        array(
                            'name' => 'link_typography',
                            'type' => \Elementor\Group_Control_Typography::get_type(),
                            'selector' => '{{WRAPPER}} .pxl-text-marquee-wrapper a',
                            'control_type' => 'group',
                        ),
                        array(
                            'name' => 'link_style',
                            'label' => esc_html__( 'Link Style', 'mouno' ),
                            'type' => 'select',
                            'options' => [
                                'link-default' => 'Default',
                                'link-underline' => 'Underline'
                            ],
                            'default' => 'link-default',
                        ),
                        array(
                            'name' => 'underline_h',
                            'label' => esc_html__('Underline Height', 'mouno' ),
                            'type' => \Elementor\Controls_Manager::SLIDER,
                            'control_type' => 'responsive',
                            'size_units' => [ 'px', '%' ],
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 3000,
                                ],
                            ],
                            'condition' => [
                                'title_style' => 'heading-title-underline',
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-text-marquee-wrapper a' => '--pxl-height: {{SIZE}}{{UNIT}};',
                            ],
                        ),
                        array(
                            'name' => 'link_controls',
                            'control_type' => 'tab',
                            'tabs' => [
                                [
                                    'name' => 'link_normal',
                                    'label' => esc_html__('Normal', 'mouno' ),
                                    'type' => 'tab',
                                    'controls' => [  
                                        array(
                                            'name' => 'link_color',
                                            'label' => esc_html__( 'Color', 'mouno' ),
                                            'type' => \Elementor\Controls_Manager::COLOR,
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-text-marquee-wrapper a' => 'color: {{VALUE}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'link_highlight_stroke',
                                            'type' => \Elementor\Group_Control_Text_Stroke::get_type(),
                                            'control_type' => 'group',
                                            'selector' => '{{WRAPPER}} .pxl-text-marquee-wrapper .pxl-text-highlight',
                                        ),
                                        array(
                                            'name' => 'link_highlight_shadow',
                                            'type' => \Elementor\Group_Control_Text_Shadow::get_type(),
                                            'control_type' => 'group',
                                            'selector' => '{{WRAPPER}} .pxl-text-marquee-wrapper .pxl-text-highlight',
                                        ),
                                    ],
                                ],
                                [
                                    'name' => 'link_hover',
                                    'label' => esc_html__('Hover', 'mouno' ),
                                    'type' => \Elementor\Controls_Manager::TAB,
                                    'controls' => [
                                        array(
                                            'name' => 'link_hover_style',
                                            'label' => esc_html__( 'Style', 'mouno' ),
                                            'type' => 'select',
                                            'options' => [
                                                'link-hover-default' => 'Default',
                                                'link-hover-underline-slide' => 'Underline Slide'
                                            ],
                                            'default' => 'link-hover-default',
                                            'condition' => [
                                                'link_style!' => 'link-underline',
                                            ],
                                        ),
                                        array(
                                            'name' => 'link_color_hover',
                                            'label' => esc_html__( 'Color Hover', 'mouno' ),
                                            'type' => \Elementor\Controls_Manager::COLOR,
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-text-marquee-wrapper a:hover' => 'color: {{VALUE}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'link_highlight_stroke_hover',
                                            'type' => \Elementor\Group_Control_Text_Stroke::get_type(),
                                            'control_type' => 'group',
                                            'selector' => '{{WRAPPER}} .pxl-text-marquee-wrapper a:hover',
                                        ),
                                        array(
                                            'name' => 'link_highlight_shadow_hover',
                                            'type' => \Elementor\Group_Control_Text_Shadow::get_type(),
                                            'control_type' => 'group',
                                            'selector' => '{{WRAPPER}} .pxl-text-marquee-wrapper a:hover',
                                        ),
                                    ],
                                ],
                            ],
                        ),
                    ),
                ),
                array(
                    'name' => 'tab_motion_effects',
                    'label' => esc_html__('Motion Effects', 'mouno' ),
                    'tab' => 'style',
                    'controls' => mouno_get_animation_options([
                        'selector' => '{{WRAPPER}} .pxl-text-marquee-wrapper',
                    ]),
                ),
            ),
        ),
    ),
    mouno_get_class_widget_path()
);