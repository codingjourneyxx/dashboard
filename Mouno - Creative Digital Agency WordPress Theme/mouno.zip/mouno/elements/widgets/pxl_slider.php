<?php
pxl_add_custom_widget(
    array(
        'name' => 'pxl_slider',
        'title' => esc_html__('Case Slider', 'mouno' ),
        'icon' => 'eicon-post-slider',
        'categories' => array('pxltheme-core'),
        'scripts' => array(
            'split-text',
            'mouno-swiper',
        ),
        'params' => array(
            'sections' => array(
                // Content
                array(
                    'name' => 'tab_slider_content',
                    'label' => esc_html__('Slider', 'mouno' ),
                    'tab' => 'content',
                    'controls' => array(   
                        array(
                            'name' => 'slides',
                            'label' => esc_html__('Slides', 'mouno' ),
                            'type' => 'repeater',
                            'controls' => array(
                                array(
                                    'name' => 'bg_slide',
                                    'type' => \Elementor\Group_Control_Background::get_type(),
                                    'control_type' => 'group',
                                    'types' => [ 'classic', 'gradient' ],
                                    'selector' => '{{WRAPPER}} .pxl-slider {{CURRENT_ITEM}}',
                                ),
                                array(
                                    'name' => '_icon',
                                    'label' => esc_html__('Icon', 'mouno' ),
                                    'type' => 'icons',
                                    'fa4compatibility' => 'icon',
                                    'separator' => 'before',
                                ),
                                array(
                                    'name' => 'icon_link',
                                    'label' => esc_html__('Icon Link', 'mouno'),
                                    'type' => 'url',
                                    'condition' => [
                                        '_icon!' => ''
                                    ],
                                ),
                                array(
                                    'name' => 'subtitle',
                                    'label' => esc_html__('Subtitle', 'mouno'),
                                    'type' => 'text',
                                    'label_block' => true,
                                    'separator' => 'before',
                                ),
                                array(
                                    'name' => 'title',
                                    'label' => esc_html__('Title', 'mouno'),
                                    'type' => 'textarea',
                                    'row' => 3,
                                    'description' => esc_html__('Highlight text using shortcode: [highlight text="..."]', 'mouno'),
                                ),
                                array(
                                    'name' => 'desc',
                                    'label' => esc_html__('Description', 'mouno'),
                                    'type' => 'textarea',
                                    'row' => 5,
                                    'separator' => 'before',
                                ),
                            ),
                            'default' => [
                                'bg_slide' => [
                                    'url' => content_url('/uploads/2024/12/image31.webp'),
                                ],
                                '_icon' => [
                                    'value' => [
                                        'url' => content_url('/uploads/2024/11/arrow-up-right-stroke.svg'), 
                                        'id' => 785, 
                                    ],
                                    'library' => 'svg',
                                ],
                                'subtitle' => esc_html__('Hi, WE ARE MOUNO DIGITAL AGENCY', 'mouno'),
                                'title' => 'CREATIVITY  [highlight text="INNOVATION &"] USER EXPERIENCE',
                                'desc' => esc_html__('We appreciate your trust on us. We feel responsible to deliver best outcome in every projects we do as an agency.', 'mouno'),
                            ],
                            'title_field' => '{{{ title }}}',
                        ),
                    ),
                ),
                array(
                    'name' => 'tab_layer_content',
                    'label' => esc_html__('Layers', 'mouno' ),
                    'tab' => 'content',
                    'controls' => array(   
                        array(
                            'name' => 'layers',
                            'label' => esc_html__('Layers', 'mouno' ),
                            'type' => 'repeater',
                            'controls' => array_merge(
                                array(
                                    array(
                                        'name' => 'show_in_slides',
                                        'label' => esc_html__('Show In', 'mouno' ),
                                        'type' => 'text',
                                        'description' => esc_html__('Enter the index of the slide that displays this layer. By default, the layer is displayed in all slides. If you want to display the layer in multiple slides, enter the syntax: "1-2-3".', 'mouno'),
                                    ),
                                    array(
                                        'name' => 'layer_img',
                                        'label' => esc_html__('Image', 'mouno' ),
                                        'type' => 'media',
                                    ), 
                                    array(
                                        'name' => 'layer_index',
                                        'type' => 'number',
                                        'label' => esc_html__('Z Index', 'mouno'),
                                        'selectors' => [
                                            '{{WRAPPER}} .pxl-slider .pxl-slide-layer{{CURRENT_ITEM}}' => 'z-index: {{VALUE}}',
                                        ],
                                    ),
                                    array(
                                        'name' => 'layer_size_h',
                                        'label' => esc_html__('Size', 'mouno'),
                                        'type' => 'heading',
                                    ),
                                    [
                                        'name' => 'layer_w',
                                        'label' => esc_html__('Width', 'mouno' ),
                                        'type' => 'slider',
                                        'size_units' => [ 'px', 'custom' ],
                                        'control_type' => 'responsive',
                                        'range' => [
                                            'px' => [
                                                'min' => 1,
                                                'max' => 1000,
                                            ],
                                        ],
                                        'selectors' => [
                                            '{{WRAPPER}} .pxl-slider .pxl-slide-layer{{CURRENT_ITEM}} img' => 'width: {{SIZE}}{{UNIT}};',
                                        ],
                                    ],
                                    [
                                        'name' => 'layer_max_w',
                                        'label' => esc_html__('Max Width', 'mouno' ),
                                        'type' => 'slider',
                                        'size_units' => [ 'px', 'custom' ],
                                        'control_type' => 'responsive',
                                        'range' => [
                                            'px' => [
                                                'min' => 1,
                                                'max' => 1000,
                                            ],
                                        ],
                                        'selectors' => [
                                            '{{WRAPPER}} .pxl-slider .pxl-slide-layer{{CURRENT_ITEM}} img' => 'max-width: {{SIZE}}{{UNIT}};',
                                        ],
                                    ],
                                    [
                                        'name' => 'layer_max_h',
                                        'label' => esc_html__('Height', 'mouno' ),
                                        'type' => 'slider',
                                        'size_units' => [ 'px', 'custom' ],
                                        'control_type' => 'responsive',
                                        'range' => [
                                            'px' => [
                                                'min' => 1,
                                                'max' => 1000,
                                            ],
                                        ],
                                        'selectors' => [
                                            '{{WRAPPER}} .pxl-slider .pxl-slide-layer{{CURRENT_ITEM}} img' => 'height: {{SIZE}}{{UNIT}};',
                                        ],
                                    ],
                                    array(
                                        'name' => 'layer_position_h',
                                        'label' => esc_html__('Position', 'mouno'),
                                        'type' => 'heading',
                                    ),
                                    [
                                        'name' => 'layer_offset_t',
                                        'label' => esc_html__('Top', 'mouno' ),
                                        'type' => 'slider',
                                        'size_units' => [ 'px', 'custom' ],
                                        'control_type' => 'responsive',
                                        'range' => [
                                            'px' => [
                                                'min' => 1,
                                                'max' => 1000,
                                            ],
                                        ],
                                        'selectors' => [
                                            '{{WRAPPER}} .pxl-slider .pxl-slide-layer{{CURRENT_ITEM}}' => 'top: {{SIZE}}{{UNIT}};',
                                        ],
                                    ],
                                    [
                                        'name' => 'layer_offset_r' ,
                                        'label' => esc_html__('Right', 'mouno' ),
                                        'type' => 'slider',
                                        'size_units' => [ 'px', 'custom' ],
                                        'control_type' => 'responsive',
                                        'range' => [
                                            'px' => [
                                                'min' => 1,
                                                'max' => 1000,
                                            ],
                                        ],
                                        'selectors' => [
                                            '{{WRAPPER}} .pxl-slider .pxl-slide-layer{{CURRENT_ITEM}}' => 'right: {{SIZE}}{{UNIT}};',
                                        ],
                                    ],
                                    [
                                        'name' => 'layer_offset_b' ,
                                        'label' => esc_html__('Bottom', 'mouno' ),
                                        'type' => 'slider',
                                        'size_units' => [ 'px', 'custom' ],
                                        'control_type' => 'responsive',
                                        'range' => [
                                            'px' => [
                                                'min' => 1,
                                                'max' => 1000,
                                            ],
                                        ],
                                        'selectors' => [
                                            '{{WRAPPER}} .pxl-slider .pxl-slide-layer{{CURRENT_ITEM}}' => 'bottom: {{SIZE}}{{UNIT}};',
                                        ],
                                    ],
                                    [
                                        'name' => 'layer_offset_l' ,
                                        'label' => esc_html__('Left', 'mouno' ),
                                        'type' => 'slider',
                                        'size_units' => [ 'px', 'custom' ],
                                        'control_type' => 'responsive',
                                        'range' => [
                                            'px' => [
                                                'min' => 1,
                                                'max' => 1000,
                                            ],
                                        ],
                                        'selectors' => [
                                            '{{WRAPPER}} .pxl-slider .pxl-slide-layer{{CURRENT_ITEM}}' => 'left: {{SIZE}}{{UNIT}};',
                                        ],
                                    ],

                                ),
                                array(
                                    array(
                                        'name' => 'layer_anim_h',
                                        'label' => esc_html__('Animation', 'mouno'),
                                        'type' => 'heading',
                                    ),
                                    array(
                                        'name'=> 'layer_anim_effect',
                                        'label'=> esc_html__('Animation Effects', 'mouno'),
                                        'type'=> 'select',
                                        'options'=> [
                                            '' => esc_html__('None', 'mouno'),
                                            'zoom-in-out-animated' => esc_html__('Zoom In Out', 'mouno'),
                                            'slide-ttb-animated' => esc_html__('Slide Top To Bottom', 'mouno'),
                                            'slide-btt-animated' => esc_html__('Slide Bottom To Top', 'mouno'),
                                            'slide-ltr-animated' => esc_html__('Slide Left To Right', 'mouno'),
                                            'slide-rtl-animated' => esc_html__('Slide Right To Left', 'mouno'),
                                            'ring-animated'      => esc_html__('Ring', 'mouno'),
                                            'spin-animated'      => esc_html__('Spin', 'mouno'),
                                            'floating1'          => esc_html__('Floating 1', 'mouno'),
                                            'floating2'          => esc_html__('Floating 2', 'mouno'),
                                        ],
                                        'default'=> '',
                                    ),
                                    array(
                                        'name' => 'anim_effect_duration',
                                        'label' => esc_html__('Animation Duration(ms)', 'mouno'),
                                        'type' => 'number',
                                        'condition' => array(
                                            'layer_anim_effect!' => '',
                                        ),
                                        'selectors' => [
                                            '{{WRAPPER}} .pxl-slider .pxl-slide-layer' => 'animation-duration: {{SIZE}}ms; -webkit-animation-duration: {{SIZE}}ms;',
                                        ],
                                    ),
                                    array(
                                        'name' => 'layer_entrance_anim_h',
                                        'label' => esc_html__('Entrance Animation', 'mouno'),
                                        'type' => 'heading',
                                    ),
                                ),
                                mouno_get_animation_options([
                                    'prefix' => 'layer',
                                    'selector' => '{{WRAPPER}} .pxl-slider .pxl-slide-layer{{CURRENT_ITEM}}',
                                ]),
                            ),
                        ),
                    ),
                ),
                array(
                    'name' => 'tab_swiper_controls',
                    'label' => esc_html__('Addtion Options', 'mouno'),
                    'tab' => 'content',
                    'controls' => [
                        array(
                            'name' => 'effect',
                            'label' => esc_html__('Effect', 'mouno' ),
                            'type' => 'select',
                            'options' => array(
                                'slide' => esc_html__('Slide', 'mouno' ),
                                'fade' => esc_html__('Fade', 'mouno' ),
                                'flip' => esc_html__('Flip', 'mouno' ),
                            ),
                            'default' => 'fade',
                        ),
                        array(
                            'name' => 'swiper_divider',
                            'type' => 'divider',
                        ),
                        array(
                            'name' => 'allow_touch_move',
                            'label' => esc_html__('Allow Touch Move', 'mouno'),
                            'type' => 'switcher',
                            'default' => 'true',
                        ),
                        array(
                            'name' => 'autoplay',
                            'label' => esc_html__('Autoplay', 'mouno'),
                            'type' => 'switcher',
                            'default' => '',
                        ),
                        array(
                            'name' => 'disable_on_interaction',
                            'label' => esc_html__('Pause on Interaction', 'mouno'),
                            'type' => 'switcher',
                            'default' => '',
                            'condition' => [
                                'autoplay!' => '',
                            ],
                        ),
                        array(
                            'name' => 'delay',
                            'label' => esc_html__('Delay', 'mouno'),
                            'type' => 'number',
                            'default' => 3000,
                            'condition' => [
                                'autoplay!' => '',
                            ],
                        ),
                        array(
                            'name' => 'loop',
                            'label' => esc_html__('Infinite Loop', 'mouno'),
                            'type' => 'switcher',
                            'default' => '',
                        ),
                        array(
                            'name' => 'speed',
                            'label' => esc_html__('Animation Speed', 'mouno'),
                            'type' => 'number',
                            'default' => 300,
                        ),
                        array(
                            'name' => 'swiper_pagination',
                            'type' => 'select',
                            'label' => esc_html__('Pagination', 'mouno'),
                            'separator' => 'before',
                            'options' => [
                                ''            => esc_html__('None', 'mouno'),
                                'bullets'     => esc_html__('Bullets', 'mouno'),
                                'progressbar' => esc_html__('Progressbar', 'mouno'),
                                'fraction'    => esc_html__('Fraction', 'mouno'),
                            ],
                        ),
                        array(
                            'name' => 'swiper_navigation',
                            'label' => esc_html__('Navigation', 'mouno'),
                            'type' => 'switcher',
                            'default' => '',
                        ),
                        array(
                            'name' => 'use_swiper_nav_widget',
                            'label' => esc_html__('Use Navigation Widget', 'mouno'),
                            'type' => 'switcher',
                            'default' => '',
                            'condition' => [
                                'swiper_navigation!' => '',
                            ],
                        ),
                        array(
                            'name' => 'nav_id',
                            'type' => 'text',
                            'label' => esc_html__('Enter ID Your Navigation', 'mouno'),
                            'condition' => [
                                'swiper_navigation!' => '',
                                'use_swiper_nav_widget!' => ''
                            ],
                            'description' => esc_html__('You need to enter the unique ID you created from the navigation carousel widget, and the navigation with this ID will function as a navigation carousel.', 'mouno'),
                        ),
                        array(
                            'name' => 'swiper_nav_spacing',
                            'label' => esc_html__('Spacing', 'mouno'),
                            'type' => 'slider',
                            'control_type' => 'responsive',
                            'size_units' => ['px', 'custom'],
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 1000,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .swiper-navigation' => 'margin-top: {{SIZE}}{{UNIT}};',
                            ],
                            'condition' => [
                                'swiper_navigation!' => '',
                            ],
                        ),
                        array(
                            'name' => 'nav_btn_style',
                            'label' => esc_html__('Button Style', 'mouno' ),
                            'type' => 'select',
                            'options' => array(
                                'swiper-button-default' => esc_html__('Default', 'mouno' ),
                                'swiper-button-primary' => esc_html__('Primary', 'mouno' ),
                            ),
                            'default' => 'swiper-button-default',
                            'condition' => [
                                'swiper_navigation!' => '',
                                'use_swiper_nav_widget' => ''
                            ],
                        ),
                        array(
                            'name' => 'nav_btn_icon_prev',
                            'label' => esc_html__('Button Icon Prev', 'mouno' ),
                            'type' => 'icons',
                            'fa4compatibility' => 'icon',
                            'default' => [
                                'value' => [
                                    'url' => content_url('/uploads/2024/11/arrow-long-left.svg'),
                                    'id' => 1046,
                                ],
                                'library' => 'svg',
                            ],
                            'condition' => [
                                'swiper_navigation!' => '',
                                'use_swiper_nav_widget' => ''
                            ],
                        ),
                        array(
                            'name' => 'nav_btn_icon_next',
                            'label' => esc_html__('Button Icon Next', 'mouno' ),
                            'type' => 'icons',
                            'fa4compatibility' => 'icon',
                            'default' => [
                                'value' => [
                                    'url' => content_url('/uploads/2024/11/arrow-long-right.svg'),
                                    'id' => 1047,
                                ],
                                'library' => 'svg',
                            ],
                            'condition' => [
                                'swiper_navigation!' => '',
                                'use_swiper_nav_widget' => ''
                            ],
                        ),
                    ],
                ),
                array(
                    'name' => 'tab_slider_style',
                    'label' => esc_html__('Slider', 'mouno' ),
                    'tab' => 'style',
                    'controls' => array( 
                        array(
                            'name' => 'container_heading',
                            'type' => 'heading',
                            'label' => esc_html__('Container', 'mouno'),
                        ),
                        array(
                            'name' => 'container_max_w',
                            'label' => esc_html__('Container Width', 'mouno' ),
                            'type' => 'slider',
                            'size_units' => [ 'px', 'custom' ],
                            'control_type' => 'responsive',
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 2000,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-slider .pxl-slide-item' => 'max-width: {{SIZE}}{{UNIT}};',
                            ],
                        ),
                        array(
                            'name' => 'container_min_h',
                            'label' => esc_html__('Container Min Height', 'mouno' ),
                            'type' => 'slider',
                            'size_units' => [ 'px', 'custom' ],
                            'control_type' => 'responsive',
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 2000,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-slider .pxl-slide-item' => 'height {{SIZE}}{{UNIT}};',
                            ],
                        ),
                        array(
                            'name' => 'container_padding',
                            'label' => esc_html__('Padding', 'mouno' ),
                            'type' => 'dimensions',
                            'size_units' => [ 'px' ],
                            'control_type' => 'responsive',
                            'selectors' => [
                                '{{WRAPPER}} .pxl-slider .pxl-slide-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            ],
                        ),
                        array(
                            'name' => 'content_h',
                            'type' => 'heading',
                            'label' => esc_html__('Content', 'mouno'),
                        ),
                        array(
                            'name' => 'content_max_w',
                            'label' => esc_html__('Max Width', 'mouno' ),
                            'type' => 'slider',
                            'control_type' => 'responsive',
                            'size_units' => [ 'px', 'custom' ],
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 1000,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-slider1 .pxl-slide-inner' => 'max-width: {{SIZE}}{{UNIT}};',
                            ],
                        ),
                        array(
                            'name' => 'subtitle_spacing_b',
                            'label' => esc_html__('Subtitle Spacing', 'mouno' ),
                            'type' => 'slider',
                            'control_type' => 'responsive',
                            'size_units' => [ 'px', 'custom' ],
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 500,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-slider .pxl-heading-subtitle' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                            ],
                        ),
                        array(
                            'name' => 'title_spacing_b',
                            'label' => esc_html__('Title Spacing', 'mouno' ),
                            'type' => 'slider',
                            'control_type' => 'responsive',
                            'size_units' => [ 'px', 'custom' ],
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 500,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-slider .pxl-heading-title' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                            ],
                        ),
                        array(
                            'name' => 'desc_max_w',
                            'label' => esc_html__('Description Max Width', 'mouno' ),
                            'type' => 'slider',
                            'control_type' => 'responsive',
                            'size_units' => [ 'px', 'custom' ],
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 1000,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-slider .pxl-slide-description' => 'max-width: {{SIZE}}{{UNIT}};',
                            ],
                        ),
                    ),
                ),
                array(
                    'name' => 'tab_title_style',
                    'label' => esc_html__('Title', 'mouno' ),
                    'tab' => 'style',
                    'controls' => array_merge(
                        array(
                            array(
                                'name' => 'title_controls',
                                'control_type' => 'tab',
                                'tabs' => [
                                    [
                                        'name' => 'title_normal',
                                        'label' => esc_html__('Normal', 'mouno' ),
                                        'type' => 'tab',
                                        'controls' => [  
                                            array(
                                                'name' => 'title_color',
                                                'label' => esc_html__('Color', 'mouno' ),
                                                'type' => \Elementor\Controls_Manager::COLOR,
                                                'selectors' => [
                                                    '{{WRAPPER}} .pxl-slider .pxl-heading-title' => 'color: {{VALUE}}',
                                                ],
                                            ),
                                            array(
                                                'name' => 'title_typography',
                                                'type' => \Elementor\Group_Control_Typography::get_type(),
                                                'control_type' => 'group',
                                                'selector' => '{{WRAPPER}} .pxl-slider .pxl-heading-title',
                                            ),
                                        ],
                                    ],
                                    [
                                        'name' => 'title_highlight',
                                        'label' => esc_html__('Highlight', 'mouno' ),
                                        'type' => \Elementor\Controls_Manager::TAB,
                                        'controls' => [
                                            array(
                                                'name' => 'title_highlight_color',
                                                'label' => esc_html__('Color', 'mouno' ),
                                                'type' => \Elementor\Controls_Manager::COLOR,
                                                'selectors' => [
                                                    '{{WRAPPER}} .pxl-slider .pxl-heading-title .pxl-text-highlight' => 'color: {{VALUE}}',
                                                ],
                                            ),
                                            array(
                                                'name' => 'title_highlight_typography',
                                                'type' => \Elementor\Group_Control_Typography::get_type(),
                                                'control_type' => 'group',
                                                'selector' => '{{WRAPPER}} .pxl-slider .pxl-heading-title .pxl-text-highlight',
                                            ),
                                        ],
                                    ],
                                ],
                            ),
                            array(
                                'name' => 'divider1',
                                'type' => 'divider',
                            ),
                        ),
                        mouno_get_animation_options([
                            'prefix'   => 'title',
                            'selector' => '{{WRAPPER}} .pxl-slider .pxl-heading-title',
                        ]),
                    ),
                ),
                array(
                    'name' => 'tab_subtitle_style',
                    'label' => esc_html__('Subtitle', 'mouno' ),
                    'tab' => 'style',
                    'controls' => array_merge(  
                        array(
                            array(
                                'name' => 'subtitle_color',
                                'label' => esc_html__('Color', 'mouno' ),
                                'type' => \Elementor\Controls_Manager::COLOR,
                                'selectors' => [
                                    '{{WRAPPER}} .pxl-slider .pxl-heading-subtitle' => 'color: {{VALUE}}',
                                ],
                            ),
                            array(
                                'name' => 'subtitle_typography',
                                'type' => \Elementor\Group_Control_Typography::get_type(),
                                'control_type' => 'group',
                                'selector' => '{{WRAPPER}} .pxl-slider .pxl-heading-subtitle',
                            ),
                            array(
                                'name' => 'divider2',
                                'type' => 'divider',
                            ),
                        ),
                        mouno_get_animation_options([
                            'prefix'   => 'subtitle',
                            'selector' => '{{WRAPPER}} .pxl-slider .pxl-heading-subtitle',
                        ]),
                    ),
                ),
                array(
                    'name'     => 'tab_icon_style',
                    'label'    => esc_html__('Icon', 'mouno' ),
                    'tab'      => 'style',
                    'controls' => array_merge(
                        array(
                            array(
                                'name' => 'icon_size',
                                'label' => esc_html__('Icon Size', 'mouno' ),
                                'type' => 'slider',
                                'control_type' => 'responsive',
                                'size_units' => [ 'px', 'custom'],
                                'selectors' => [
                                    '{{WRAPPER}} .pxl-slider .pxl-slide-icon' => 'font-size: {{SIZE}}{{UNIT}};',
                                    '{{WRAPPER}} .pxl-slider .pxl-slide-icon svg' => 'width: auto; height: {{SIZE}}{{UNIT}};',
                                ],
                            ),
                            array(
                                'name' => 'icon_controls',
                                'control_type' => 'tab',
                                'tabs' => [
                                    [
                                        'name' => 'icon_normal',
                                        'label' => esc_html__('Normal', 'mouno' ),
                                        'type' => 'tab',
                                        'controls' => [  
                                            array(
                                                'name' => 'icon_color',
                                                'label' => esc_html('Icon Color', 'mouno'),
                                                'type' => 'color',
                                                'selectors' => [
                                                    '{{WRAPPER}} .pxl-slider' => 'slide-color: {{VALUE}}',
                                                ],
                                            ),
                                            array(
                                                'name' => 'icon_bg',
                                                'type' => \Elementor\Group_Control_Background::get_type(),
                                                'control_type' => 'group',
                                                'types' => [ 'classic', 'gradient' ],
                                                'selector' => '{{WRAPPER}} .pxl-slider .pxl-slide-icon',
                                                'fields_options' => [
                                                    'background' => [
                                                        'label' => __( 'Background', 'mouno' ),
                                                    ],
                                                ],
                                            ),
                                            array(
                                                'name' => 'icon_border',
                                                'type' => \Elementor\Group_Control_Border::get_type(),
                                                'separator' => 'before',
                                                'control_type' => 'group', 
                                                'selector' => '{{WRAPPER}} .pxl-slider .pxl-slide-icon',
                                            ),
                                            array(
                                                'name'         => 'icon_box_shadow',
                                                'label' => esc_html__( 'Box Shadow', 'mouno' ),
                                                'type'         => \Elementor\Group_Control_Box_Shadow::get_type(),
                                                'control_type' => 'group',
                                                'selector'     => '{{WRAPPER}} .pxl-slider .pxl-slide-icon',
                                            ),
                                            array(
                                                'name' => 'icon_border_radius',
                                                'label' => esc_html__('Border Radius', 'mouno' ),
                                                'type' => 'dimensions',
                                                'size_units' => [ 'px', '%' ],
                                                'selectors' => [
                                                    '{{WRAPPER}} .pxl-slider .pxl-slide-icon' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                                ],
                                            ),
                                            array(
                                                'name' => 'icon_padding',
                                                'label' => esc_html__('Padding', 'mouno' ),
                                                'type' => 'dimensions',
                                                'size_units' => [ 'px', '%' ],
                                                'control_type' => 'responsive',
                                                'separator' => 'before',
                                                'selectors' => [
                                                    '{{WRAPPER}} .pxl-slider .pxl-slide-icon' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                                ],
                                            ),
                                        ],
                                    ],
                                    [
                                        'name' => 'icon_hover',
                                        'label' => esc_html__('Hover/Active', 'mouno' ),
                                        'type' => 'tab',
                                        'controls' => [  
                                            array(
                                                'name' => 'icon_hover_anim',
                                                'label' => esc_html__('Hover Animation', 'mouno'),
                                                'type' => 'select',
                                                'options' => [
                                                    '' => esc_html__('None', 'mouno'), 
                                                    'hover-animation-flipX' => esc_html__('Flip X', 'mouno'), 
                                                    'hover-animation-flipY' => esc_html__('Flip Y', 'mouno'), 
                                                    'hover-animation-shrink-expand' => esc_html__('Shrink & Expand', 'mouno'), 
                                                    'hover-animation-grow-normalize' => esc_html__('Grow & Normalize', 'mouno'), 
                                                ],
                                            ),
                                            array(
                                                'name' => 'icon_hover_color',
                                                'label' => esc_html('Icon Color', 'mouno'),
                                                'type' => 'color',
                                                'selectors' => [
                                                    '{{WRAPPER}} .pxl-slider .pxl-slide-icon:hover' => 'color: {{VALUE}}',
                                                ],
                                            ),
                                            array(
                                                'name' => 'icon_hover_bg',
                                                'type' => \Elementor\Group_Control_Background::get_type(),
                                                'control_type' => 'group',
                                                'types' => [ 'classic', 'gradient' ],
                                                'selector' => '{{WRAPPER}} .pxl-slider .pxl-slide-icon:hover',
                                                'fields_options' => [
                                                    'background' => [
                                                        'label' => __( 'Background', 'mouno' ),
                                                    ],
                                                ],
                                            ),
                                            array(
                                                'name' => 'icon_hover_border',
                                                'type' => \Elementor\Group_Control_Border::get_type(),
                                                'separator' => 'before',
                                                'control_type' => 'group', 
                                                'selector' => '{{WRAPPER}} .pxl-slider .pxl-slide-icon:hover',
                                            ),
                                            array(
                                                'name'         => 'icon_hover_box_shadow',
                                                'label' => esc_html__( 'Box Shadow', 'mouno' ),
                                                'type'         => \Elementor\Group_Control_Box_Shadow::get_type(),
                                                'control_type' => 'group',
                                                'selector'     => '{{WRAPPER}} .pxl-slider .pxl-slide-icon:hover',
                                            ),
                                            array(
                                                'name' => 'icon_hover_border_radius',
                                                'label' => esc_html__('Border Radius', 'mouno' ),
                                                'type' => 'dimensions',
                                                'size_units' => [ 'px', '%' ],
                                                'selectors' => [
                                                    '{{WRAPPER}} .pxl-slider .pxl-slide-icon:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                                ],
                                            ),
                                            array(
                                                'name' => 'icon_hover_padding',
                                                'label' => esc_html__('Padding', 'mouno' ),
                                                'type' => 'dimensions',
                                                'size_units' => [ 'px', '%' ],
                                                'control_type' => 'responsive',
                                                'separator' => 'before',
                                                'selectors' => [
                                                    '{{WRAPPER}} .pxl-slider .pxl-slide-icon:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                                ],
                                            ),
                                        ],
                                    ],
                                ],
                            ),
                            array(
                                'name' => 'divider3',
                                'type' => 'divider',
                            ),
                        ),
                        mouno_get_animation_options([
                            'prefix' => 'icon',
                            'selector' => '{{WRAPPER}} .pxl-slider .pxl-slide-icon',
                        ]),
                    ),
                ),
                array(
                    'name' => 'tab_desc_style',
                    'label' => esc_html__('Description', 'mouno' ),
                    'tab' => 'style',
                    'controls' => array_merge(  
                        array(
                            array(
                                'name' => 'desc_color',
                                'label' => esc_html__('Color', 'mouno' ),
                                'type' => \Elementor\Controls_Manager::COLOR,
                                'selectors' => [
                                    '{{WRAPPER}} .pxl-slider .pxl-slide-description' => 'color: {{VALUE}}',
                                ],
                            ),
                            array(
                                'name' => 'desc_typography',
                                'type' => \Elementor\Group_Control_Typography::get_type(),
                                'control_type' => 'group',
                                'selector' => '{{WRAPPER}} .pxl-slider .pxl-slide-description',
                            ),
                            array(
                                'name' => 'divider4',
                                'type' => 'divider',
                            ),
                        ),
                        mouno_get_animation_options([
                            'prefix' => 'desc',
                            'selector' => '{{WRAPPER}} .pxl-slider .pxl-slide-inner .pxl-slide-description',
                        ]),
                    ),
                ),
            ),
        ),
    ),
    mouno_get_class_widget_path(),
);

