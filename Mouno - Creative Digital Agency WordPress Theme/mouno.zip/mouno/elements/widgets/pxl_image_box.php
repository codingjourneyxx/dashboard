<?php
// Register Image Box Widget
pxl_add_custom_widget(
    array(
        'name' => 'pxl_image_box',
        'title' => esc_html__('BR Image Box', 'mouno' ),
        'icon' => 'eicon-image-box',
        'categories' => array('pxltheme-core'),
        'scripts' => array(
            'mouno-effects'
        ),
        'params' => array(
            'sections' => array(

            ),
        ),
    ),
mouno_get_class_widget_path()
);