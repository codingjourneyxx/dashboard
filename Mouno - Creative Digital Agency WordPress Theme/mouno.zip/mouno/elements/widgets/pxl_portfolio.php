<?php
$post_type = ['portfolio'];
pxl_add_custom_widget(
    array(
        'name' => 'pxl_portfolio',
        'title' => esc_html__('Case Portfolio', 'mouno' ),
        'icon' => 'eicon-post',
        'categories' => array('pxltheme-core'),
        'scripts' => [
            'tilt',
            'imagesloaded',
            'pxl-post-grid',
            'swiper',
            'pxl-swiper',
            'curtainsjs',
            'mouno-effects',
            'mouno-parallax',
        ],
        'params' => array(
            'sections' => array(
                array(
                    'name'     => 'tab_layout',
                    'label'    => esc_html__( 'Layout', 'mouno' ),
                    'tab'      => 'layout',
                    'controls' => array_merge(
                        array(
                            array(
                                'name'     => 'post_type',
                                'label'    => esc_html__( 'Current Post', 'mouno' ),
                                'type'     => 'select',
                                'options'  => mouno_get_post_type_options($post_type),
                                'default'  => 'portfolio'
                            ),
                            array(
                                'name'     => 'layout_type',
                                'label'    => esc_html__( 'Layout Type', 'mouno' ),
                                'type'     => 'select',
                                'options'  => [
                                    'grid' => esc_html__('Grid', 'mouno'),
                                    'carousel' => esc_html__('Carousel', 'mouno'),
                                ],
                                'default'  => 'grid',
                            ),
                            array(
                                'name'     => 'layout1_style',
                                'label'    => esc_html__( 'Layout Style', 'mouno' ),
                                'type'     => 'select',
                                'options'  => [
                                    'layout-portfolio-default' => esc_html__('Default', 'mouno'),
                                    'layout-portfolio-style1' => esc_html__('Style 1', 'mouno'),
                                ],
                                'default'  => 'layout-portfolio-default',
                                'condition' => [
                                    'layout_portfolio' => 'portfolio-1',
                                ],
                            ),
                        ),
                        mouno_get_post_layout($post_type), 
                    ),
                ),
                 
                mouno_source_post_settings($post_type),

                array(
                    'name' => 'tab_display_opts',
                    'label' => esc_html__('Display', 'mouno' ),
                    'tab' => 'settings',
                    'controls' => array_merge(
                        image_dimension_options(),
                        array(
                            array(
                                'name' => 'title_tag',
                                'label' => esc_html__('Title HTML Tag', 'mouno'),
                                'type' => 'select',
                                'options' => [
                                    ''   => esc_html__('Default', 'mouno'),
                                    'h1' => esc_html__('H1', 'mouno'),
                                    'h2' => esc_html__('H2', 'mouno'),
                                    'h3' => esc_html__('H3', 'mouno'),
                                    'h4' => esc_html__('H4', 'mouno'),
                                    'h5' => esc_html__('H5', 'mouno'),
                                    'h6' => esc_html__('H6', 'mouno'),
                                    'div' => esc_html__('div', 'mouno'),
                                    'p'  => esc_html__('p', 'mouno'),
                                    'span' => esc_html__('span', 'mouno'),
                                ],
                                'default' => '',
                            ),
                            array(
                                'name' => 'item_active',
                                'label' => esc_html__('Item Active', 'mouno' ),
                                'type' => 'number',
                                'condition' => [
                                    'layout_portfolio' => ['portfolio-3'],
                                ],
                            ),
                            array(
                                'name' => 'show_excerpt',
                                'label' => esc_html__('Show Excerpt', 'mouno' ),
                                'type' => 'switcher',
                                'separator' => 'before',
                                'default' => 'true',
                                'condition' => [
                                    'layout_portfolio!' => ['portfolio-4', 'portfolio-1', 'portfolio-5'],
                                ],
                            ),
                            array(
                                'name' => 'num_words',
                                'label' => esc_html__('Number of Words', 'mouno' ),
                                'type' => 'number',
                                'condition' => [
                                    'show_excerpt!' => '',
                                    'layout_portfolio!' => ['portfolio-4', 'portfolio-1', 'portfolio-5'],
                                ],
                            ),
                            array(
                                'name' => 'show_btn',
                                'label' => esc_html__('Show Button', 'mouno' ),
                                'type' => 'switcher',
                                'separator' => 'before',
                                'default' => 'true',
                                'condition' => [
                                    'show_excerpt!' => '',
                                    'layout_portfolio!' => ['portfolio-1', 'portfolio-5'],
                                ],
                            ),
                            array(
                                'name' => 'btn_text',
                                'label' => esc_html__('Button Text', 'mouno' ),
                                'type' => 'text',
                                'condition' => [
                                    'show_btn!' => '',
                                    'layout_portfolio!' => ['portfolio-1', 'portfolio-4', 'portfolio-5'],
                                ],
                            ),
                            array(
                                'name' => 'show_category',
                                'label' => esc_html__('Show Category', 'mouno' ),
                                'type' => 'switcher',
                                'separator' => 'before',
                                'default' => 'true',
                                'condition' => [
                                    'layout_portfolio!' => ['portfolio-3'],
                                ],
                            ),
                            array(
                                'name' => 'show_index',
                                'label' => esc_html__('Show Index', 'mouno' ),
                                'type' => 'switcher',
                                'default' => 'true',
                                'condition' => [
                                    'layout_portfolio' => ['portfolio-2', 'portfolio-3'],
                                ],
                            ),
                            array(
                                'name' => 'show_order',
                                'label' => esc_html__('Show Order', 'mouno' ),
                                'type' => 'switcher',
                                'default' => 'true',
                                'condition' => [
                                    'layout_portfolio' => ['portfolio-2'],
                                ],
                            ),
                        ),
                    ),
                ),

                array(
                    'name' => 'tab_grid_add_opts',
                    'label' => esc_html__('Additional Options', 'mouno' ),
                    'tab' => 'settings',
                    'condition' => ['layout_type' => 'grid'],
                    'controls' => grid_controls_options(
                        [ 
                            'filter' => true ,
                        ],
                    ),
                ),

                array(
                    'name' => 'tab_swiper_add_otps',
                    'label' => esc_html__('Addtional Options', 'mouno'),
                    'tab' => 'settings',
                    'condition' => ['layout_type' => 'carousel'],
                    'controls' => array(
                        swiper_controls_options(),
                    ),
                ),

                array(
                    'name' => 'tab_general_style',
                    'label' => esc_html__('General', 'mouno' ),
                    'tab' => 'style',
                    'controls' => array(
                        array(
                            'name' => 'title_spacing',
                            'label' => esc_html__('Title Spacing', 'mouno'),
                            'type' => 'slider',
                            'size_units' => ['px', 'custom'],
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 1000,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-grid .pxl-post-title' => "margin-bottom: {{SIZE}}{{UNIT}};",
                            ],
                        ),
                        array(
                            'name' => 'featured_spacing',
                            'label' => esc_html__('Featured Spacing', 'mouno'),
                            'type' => 'slider',
                            'size_units' => ['px', 'custom'],
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 1000,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-grid:not(.pxl-layout-portfolio4) .pxl-post-content' => "padding-bottom: {{SIZE}}{{UNIT}};",
                            ],
                        ),
                    ),
                ),
                array(
                    'name' => 'tab_box_style',
                    'label' => esc_html__('Box', 'mouno' ),
                    'tab' => 'style',
                    'controls' => array(
                        array(
                            'name' => 'box_height',
                            'label' => esc_html__('Height', 'mouno'),
                            'type' => 'slider',
                            'size_units' => ['px', 'custom'],
                            'control_type' => 'responsive',
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 1000,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-layout-portfolio .pxl-post-item' => "height: {{SIZE}}{{UNIT}};",
                            ],
                        ),
                        array(
                            'name' => 'box_controls',
                            'control_type' => 'tab',
                            'tabs' => [
                                [
                                    'name' => 'box_normal',
                                    'label' => esc_html__('Normal', 'mouno' ),
                                    'type' => 'tab',
                                    'controls' => [  
                                        array(
                                            'name' => 'box_bg',
                                            'type' => \Elementor\Group_Control_Background::get_type(),
                                            'control_type' => 'group',
                                            'types' => [ 'classic', 'gradient' ],
                                            'fields_options' => [
                                                'background' => [
                                                    'label' => __( 'Background', 'mouno' ),
                                                ],
                                            ],
                                            'selector' => '{{WRAPPER}} .pxl-grid .pxl-post-item',
                                        ),
                                        array(
                                            'name' => 'box_backdrop_filter_blur',
                                            'label' => esc_html__('Background Blur', 'mouno'),
                                            'type' => 'slider',
                                            'size_units' => ['px', 'custom'],
                                            'range' => [
                                                'px' => [
                                                    'min' => 0,
                                                    'max' => 1000,
                                                ],
                                            ],
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-grid .pxl-post-item' => "backdrop-filter: blur({{SIZE}}{{UNIT}});",
                                            ],
                                        ),
                                        array(
                                            'name' => 'box_border',
                                            'type' => \Elementor\Group_Control_Border::get_type(),
                                            'separator' => 'before',
                                            'control_type' => 'group', 
                                            'selector' => '{{WRAPPER}} .pxl-grid .pxl-post-item',
                                        ),
                                        array(
                                            'name'         => 'box_box_shadow',
                                            'label' => esc_html__( 'Box Shadow', 'mouno' ),
                                            'type'         => \Elementor\Group_Control_Box_Shadow::get_type(),
                                            'control_type' => 'group',
                                            'selector'     => '{{WRAPPER}} .pxl-grid .pxl-post-item',
                                        ),
                                        array(
                                            'name' => 'box_border_radius',
                                            'label' => esc_html__('Border Radius', 'mouno' ),
                                            'type' => 'dimensions',
                                            'size_units' => [ 'px', '%', 'custom' ],
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-grid .pxl-post-item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'box_padding',
                                            'label' => esc_html__('Padding', 'mouno' ),
                                            'type' => 'dimensions',
                                            'size_units' => [ 'px', '%', 'custom' ],
                                            'control_type' => 'responsive',
                                            'separator' => 'before',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-grid .pxl-post-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                    ],
                                ],
                                [
                                    'name' => 'box_hover',
                                    'label' => esc_html__('Hover/Active', 'mouno' ),
                                    'type' => 'tabs',
                                    'controls' => [
                                        array(
                                            'name' => 'is_btn_as_cursor',
                                            'type' => 'switcher',
                                            'label' => esc_html__('Set button as mouse cursor', 'mouno'),
                                            'default' => '',
                                            'condition' => [
                                                'layout_portfolio' => ['portfolio-4'],
                                            ],
                                        ),
                                        array(
                                            'name' => 'box_content_follow_cursor',
                                            'type' => 'switcher',
                                            'label' => esc_html__('Box content follow cursor', 'mouno'),
                                            'default' => '',
                                            'condition' => [
                                                'layout_portfolio' => ['portfolio-1', 'portfolio-5'],
                                            ],
                                        ),
                                        array(
                                            'name' => 'box_hover_bg',
                                            'type' => \Elementor\Group_Control_Background::get_type(),
                                            'control_type' => 'group',
                                            'types' => [ 'classic', 'gradient' ],
                                            'selector' => '{{WRAPPER}} .pxl-grid .pxl-post-item::before',
                                            'fields_options' => [
                                                'background' => [
                                                    'label' => __( 'Background', 'mouno' ),
                                                ],
                                                'color' => [
                                                    'selectors' => [
                                                        '{{WRAPPER}} .pxl-layout-portfolio .pxl-post-item:hover, {{WRAPPER}} .pxl-layout-portfolio .pxl-post-item.active' => 'background-color: {{VALUE}};',
                                                    ],
                                                ],
                                            ],
                                        ),
                                        array(
                                            'name' => '_box_hover_border_color',
                                            'label' => esc_html__('Border Color', 'mouno' ),
                                            'type' => 'color',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-grid .pxl-post-item:hover, {{WRAPPER}} .pxl-grid .pxl-post-item.active' => 'border-color: {{VALUE}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'box_hover_border',
                                            'type' => \Elementor\Group_Control_Border::get_type(),
                                            'separator' => 'before',
                                            'control_type' => 'group', 
                                            'selector' => '{{WRAPPER}} .pxl-grid .pxl-post-item:hover, {{WRAPPER}} .pxl-grid .pxl-post-item.active',
                                        ),
                                        array(
                                            'name'         => 'box_hover_box_shadow',
                                            'label' => esc_html__( 'Box Shadow', 'mouno' ),
                                            'type'         => \Elementor\Group_Control_Box_Shadow::get_type(),
                                            'control_type' => 'group',
                                            'selector'     => '{{WRAPPER}} .pxl-grid .pxl-post-item:hover, {{WRAPPER}} .pxl-grid .pxl-post-item.active',
                                        ),
                                        array(
                                            'name' => 'box_hover_border_radius',
                                            'label' => esc_html__('Border Radius', 'mouno' ),
                                            'type' => 'dimensions',
                                            'size_units' => [ 'px', '%', 'custom' ],
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-grid:not(.pxl-layout-portfolio3) .pxl-post-item:hover, {{WRAPPER}} .pxl-grid .pxl-post-item.active' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'box_hover_padding',
                                            'label' => esc_html__('Padding', 'mouno' ),
                                            'type' => 'dimensions',
                                            'size_units' => [ 'px', '%', 'custom' ],
                                            'control_type' => 'responsive',
                                            'separator' => 'before',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-grid .pxl-post-item:hover, {{WRAPPER}} .pxl-grid .pxl-post-item.active' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                    ],
                                ],
                            ],
                        ),
                    ),
                ),

                array(
                    'name' => 'tab_featured_style',
                    'label' => esc_html__('Featured', 'mouno' ),
                    'tab' => 'style',
                    'controls' => array(
                        array(
                            'name' => 'featured_w',
                            'label' => esc_html__('Width', 'mouno'),
                            'type' => 'slider',
                            'control_type' => 'responsive',
                            'size_units' => ['px', '%', 'custom'],
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 1000,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-grid .pxl-post-featured' => "width: {{SIZE}}{{UNIT}};",
                            ],
                        ),
                        array(
                            'name' => 'featured_max_w',
                            'label' => esc_html__('Max Width', 'mouno'),
                            'type' => 'slider',
                            'control_type' => 'responsive',
                            'size_units' => ['px', '%', 'custom'],
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 1000,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-grid .pxl-post-featured' => "max-width: {{SIZE}}{{UNIT}};",
                            ],
                        ),
                        array(
                            'name' => 'featured_h',
                            'label' => esc_html__('Height', 'mouno'),
                            'type' => 'slider',
                            'control_type' => 'responsive',
                            'size_units' => ['px', '%', 'custom'],
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 1000,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-grid .pxl-post-featured' => "height: {{SIZE}}{{UNIT}};",
                            ],
                        ),
                        array(
                            'name' => 'featured_max_h',
                            'label' => esc_html__('Max Height', 'mouno'),
                            'type' => 'slider',
                            'control_type' => 'responsive',
                            'size_units' => ['px', '%', 'custom'],
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 1000,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-grid .pxl-post-featured' => "max-height: {{SIZE}}{{UNIT}};",
                            ],
                        ),
                        array(
                            'name' => 'featured_divider',
                            'type' => 'divider',
                        ),
                        array(
                            'name' => 'featured_controls',
                            'control_type' => 'tab',
                            'tabs' => [
                                [
                                    'name' => 'featured_normal',
                                    'label' => esc_html__('Normal', 'mouno' ),
                                    'type' => 'tab',
                                    'controls' => [  
                                        array(
                                            'name' => 'featured_opacity',
                                            'label' => esc_html__('Opacity', 'mouno' ),
                                            'type' => 'slider',
                                            'control_type' => 'responsive',
                                            'size_units' => ['px'],
                                            'range' => [
                                                'px' => [
                                                    'min' => 0,
                                                    'max' => 1,
                                                    'step' => 0.01,
                                                ],
                                            ],
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-grid .pxl-post-featured' => 'opacity: {{SIZE}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'featured_css_filter', 
                                            'type' => \Elementor\Group_Control_Css_Filter::get_type(),
                                            'control_type' => 'group',
                                            'selector' => '{{WRAPPER}} .pxl-grid .pxl-post-featured',
                                        ),
                                        array(
                                            'name' => 'featured_border', 
                                            'type' => \Elementor\Group_Control_Border::get_type(),
                                            'control_type' => 'group',
                                            'separator' => 'before',
                                            'selector' => '{{WRAPPER}} .pxl-grid .pxl-post-featured',
                                        ),
                                        array(
                                            'name' => 'featured_box_shadow', 
                                            'type' => \Elementor\Group_Control_Box_Shadow::get_type(),
                                            'control_type' => 'group',
                                            'separator' => 'before',
                                            'selector' => '{{WRAPPER}} .pxl-grid .pxl-post-featured',
                                        ),
                                        array(
                                            'name' => 'featured_border_radius',
                                            'label' => esc_html__('Border Radius', 'mouno' ),
                                            'type' => 'dimensions',
                                            'size_units' => [ 'px', '%' ],
                                            'control_type' => 'responsive',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-grid .pxl-post-featured' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'featured_padding',
                                            'label' => esc_html__('Padding', 'mouno' ),
                                            'type' => 'dimensions',
                                            'size_units' => [ 'px', '%' ],
                                            'control_type' => 'responsive',
                                            'separator' => 'before',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-grid .pxl-post-featured' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                    ],
                                ],
                                [
                                    'name' => 'featured_hover',
                                    'label' => esc_html__('Hover/Active', 'mouno' ),
                                    'type' => 'tab',
                                    'controls' => [
                                        array(
                                            'name' => 'featured_hover_style',
                                            'label' => esc_html__('Hover Style', 'mouno' ),
                                            'type' => 'select',
                                            'options' => [
                                                'hover-image-default'               => esc_html__('Default', 'mouno'),
                                                'hover-image-zoom-in'               => esc_html__('Zoom In', 'mouno'),
                                                'hover-tilt'                        => esc_html__('Tilt', 'mouno'),
                                                'hover-image-distortion-transition' => esc_html__('Distortion Transition', 'mouno'),
                                                'hover-image-distortion-warp'       => esc_html__('Distortion Warp', 'mouno'),
                                                'hover-image-distortion-wave'       => esc_html__('Distortion Wave', 'mouno'),
                                                'hover-image-parallax'              => esc_html__('Parallax', 'mouno'),
                                            ],
                                            'default' => 'hover-image-default',
                                        ),
                                        array(
                                            'name' => 'displacement_img',
                                            'label' => esc_html__('Displacement Image', 'mouno'),
                                            'type' => 'media',
                                            'default' => [
                                                'url' => content_url('/uploads/2025/01/displacement-4.webp'),
                                                'id' => 9031,
                                            ],
                                            'condition' => [
                                                'featured_hover_style' => 'hover-image-distortion-transition',
                                            ]
                                        ),
                                        array(
                                            'name' => 'featured_zoom_in_val',
                                            'label' => esc_html__('Zoom Value', 'mouno' ),
                                            'type' => 'slider',
                                            'control_type' => 'responsive',
                                            'size_units' => ['px'],
                                            'range' => [
                                                'px' => [
                                                    'min' => 1,
                                                    'max' => 3,
                                                    'step' => 0.01,
                                                ],
                                            ],
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-grid .pxl-post-featured' => '--pxl-scale: {{SIZE}};',
                                            ],
                                            'condition' => [
                                                'featured_hover_style' => 'hover-image-zoom-in',
                                            ],
                                        ),
                                        array(
                                            'name' => 'featured_hover_h',
                                            'label' => esc_html__('Height', 'mouno'),
                                            'type' => 'slider',
                                            'size_units' => ['px', 'custom'],
                                            'separator' => 'before',
                                            'range' => [
                                                'px' => [
                                                    'min' => 0,
                                                    'max' => 1000,
                                                ],
                                            ],
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-grid .pxl-post-item:hover .pxl-post-featured, 
                                                {{WRAPPER}} .pxl-grid .pxl-post-item.active .pxl-post-featured' => "height: {{SIZE}}{{UNIT}};",
                                            ],
                                        ),
                                        array(
                                            'name' => 'featured_hover_max_w',
                                            'label' => esc_html__('Max Width', 'mouno'),
                                            'type' => 'slider',
                                            'size_units' => ['px', '%', 'custom'],
                                            'range' => [
                                                'px' => [
                                                    'min' => 0,
                                                    'max' => 1000,
                                                ],
                                            ],
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-grid .pxl-post-item:hover .pxl-post-featured, 
                                                {{WRAPPER}} .pxl-grid .pxl-post-item.active .pxl-post-featured' => "max-width: {{SIZE}}{{UNIT}};",
                                            ],
                                        ),
                                        array(
                                            'name' => 'featured_hover_opacity',
                                            'label' => esc_html__('Opacity', 'mouno' ),
                                            'type' => 'slider',
                                            'control_type' => 'responsive',
                                            'size_units' => ['px'],
                                            'range' => [
                                                'px' => [
                                                    'min' => 0,
                                                    'max' => 1,
                                                    'step' => 0.01,
                                                ],
                                            ],
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-grid .pxl-post-item:hover .pxl-post-featured, {{WRAPPER}} .pxl-grid .pxl-post-item.active .pxl-post-featured' => 'opacity: {{SIZE}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'featured_hover_css_filter', 
                                            'type' => \Elementor\Group_Control_Css_Filter::get_type(),
                                            'control_type' => 'group',
                                            'selector' => '{{WRAPPER}} .pxl-grid .pxl-post-item:hover .pxl-post-featured, {{WRAPPER}} .pxl-grid .pxl-post-item.active .pxl-post-featured',
                                        ),
                                        array(
                                            'name' => 'featured_hover_border', 
                                            'type' => \Elementor\Group_Control_Border::get_type(),
                                            'control_type' => 'group',
                                            'separator' => 'before',
                                            'selector' => '{{WRAPPER}} .pxl-grid .pxl-post-item:hover .pxl-post-featured, {{WRAPPER}} .pxl-grid .pxl-post-item.active .pxl-post-featured',
                                        ),
                                        array(
                                            'name' => 'featured_hover_box_shadow', 
                                            'type' => \Elementor\Group_Control_Box_Shadow::get_type(),
                                            'control_type' => 'group',
                                            'separator' => 'before',
                                            'selector' => '{{WRAPPER}} .pxl-grid .pxl-post-item:hover .pxl-post-featured, {{WRAPPER}} .pxl-grid .pxl-post-item.active .pxl-post-featured',
                                        ),
                                        array(
                                            'name' => 'featured_hover_border_radius',
                                            'label' => esc_html__('Border Radius', 'mouno' ),
                                            'type' => 'dimensions',
                                            'size_units' => [ 'px', '%' ],
                                            'control_type' => 'responsive',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-grid:not(.pxl-layout-portfolio4) .pxl-post-item:hover .pxl-post-featured, 
                                                {{WRAPPER}} .pxl-grid .pxl-post-item.active .pxl-post-featured' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'featured_hover_padding',
                                            'label' => esc_html__('Padding', 'mouno' ),
                                            'type' => 'dimensions',
                                            'size_units' => [ 'px', '%' ],
                                            'control_type' => 'responsive',
                                            'separator' => 'before',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-grid .pxl-post-item:hover .pxl-post-featured, {{WRAPPER}} .pxl-grid .pxl-post-item.active .pxl-post-featured' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                    ],
                                ],
                            ],
                        ),
                    ),
                ),
                array(
                    'name' => 'tab_title_style',
                    'label' => esc_html__('Title', 'mouno' ),
                    'tab' => 'style',
                    'controls' => array_merge(
                        array(
                            array(
                                'name' => 'title_typography',
                                'type' => \Elementor\Group_Control_Typography::get_type(),
                                'control_type' => 'group',
                                'selector' => '{{WRAPPER}} .pxl-grid .pxl-post-title',
                            ),
                            array(
                                'name' => 'title_controls',
                                'control_type' => 'tab',
                                'tabs' => [
                                    [
                                        'name' => 'title_normal',
                                        'label' => esc_html__('Normal', 'mouno' ),
                                        'type' => 'tab',
                                        'controls' => [  
                                            array(
                                                'name' => 'title_color',
                                                'label' => esc_html__('Text Color', 'mouno' ),
                                                'type' => 'color',
                                                'selectors' => [
                                                    '{{WRAPPER}} .pxl-grid .pxl-post-title, 
                                                    {{WRAPPER}} .pxl-grid .pxl-post-title.hover-3d-cube-flip:before' => 'color: {{VALUE}};',
                                                ],
                                            ),
                                            array(
                                                'name' => 'title_stroke',
                                                'type' => \Elementor\Group_Control_Text_Stroke::get_type(),
                                                'control_type' => 'group',
                                                'selector' => '{{WRAPPER}} .pxl-grid .pxl-post-title',
                                            ),
                                            array(
                                                'name' => 'title_text_shadow',
                                                'type' => \Elementor\Group_Control_Text_Shadow::get_type(),
                                                'control_type' => 'group',
                                                'selector' => '{{WRAPPER}} .pxl-grid .pxl-post-title',
                                            ),
                                        ],
                                    ],
                                    [
                                        'name' => 'title_hover',
                                        'label' => esc_html__('Hover/Active', 'mouno' ),
                                        'type' => 'tab',
                                        'controls' => [
                                            array(
                                                'name' => 'title_hover_style',
                                                'label' => esc_html__('Hover Style', 'mouno' ),
                                                'type' => 'select',
                                                'groups' => [
                                                    [
                                                        'label' => esc_html__('Default', 'mouno'),
                                                        'options' => [
                                                            'hover-text-default' => esc_html__('Default', 'mouno'),
                                                        ],
                                                    ],
                                                    [
                                                        'label' => esc_html__('Underline', 'mouno'),
                                                        'options' => [
                                                            'hover-text-underline' => esc_html__('Underline', 'mouno'),
                                                            'hover-text-underline--slide-ltr' => esc_html__('Slide LTR', 'mouno'),
                                                            'hover-text-underline--slide-rtl' => esc_html__('Slide RTL', 'mouno'),
                                                        ],
                                                    ],
                                                    [
                                                        'label' => esc_html__('Other', 'mouno'),
                                                        'options' => [
                                                            'hover-3d-cube-flip' => esc_html__('3D Flip', 'mouno'),
                                                            'hover-text-fill' => esc_html__('Text Fill', 'mouno'),
                                                        ],
                                                    ],
                                                ],
                                                'default' => 'hover-text-default',
                                            ),
                                            array(
                                                'name' => 'underline_h',
                                                'label' => esc_html__('Underline Weight(px)', 'mouno'),
                                                'type' => 'slider',
                                                'size_units' => ['px'],
                                                'selectors' => [
                                                    '{{WRAPPER}} .pxl-grid .pxl-post-title' => "--pxl-height: {{SIZE}}{{UNIT}};",
                                                ],
                                                'condition' => [
                                                    'title_hover_style' => ['hover-text-underline'],
                                                ],
                                            ),
                                            array(
                                                'name' => 'title_divider',
                                                'type' => 'divider',
                                            ),
                                            array(
                                                'name' => 'title_hover_color',
                                                'label' => esc_html__('Text Color', 'mouno' ),
                                                'type' => 'color',
                                                'selectors' => [
                                                    '{{WRAPPER}} .pxl-grid .pxl-post-item:hover .pxl-post-title:not(.hover-3d-cube-flip):not(.hover-text-fill),
                                                    {{WRAPPER}} .pxl-grid .pxl-post-item.active .pxl-post-title:not(.hover-3d-cube-flip):not(.hover-text-fill),
                                                    {{WRAPPER}} .pxl-grid .pxl-post-title.hover-3d-cube-flip:after' => 'color: {{VALUE}};',
                                                    '{{WRAPPER}} .pxl-grid .pxl-post-item .hover-text-fill'   => '--link-color-hover: {{VALUE}};',
                                                ],
                                            ),
                                            array(
                                                'name' => 'title_hover_stroke',
                                                'type' => \Elementor\Group_Control_Text_Stroke::get_type(),
                                                'control_type' => 'group',
                                                'selector' => '{{WRAPPER}} .pxl-grid .pxl-post-item:hover .pxl-post-title,
                                                {{WRAPPER}} .pxl-grid .pxl-post-item.active .pxl-post-title',
                                            ),
                                            array(
                                                'name' => 'title_hover_text_shadow',
                                                'type' => \Elementor\Group_Control_Text_Shadow::get_type(),
                                                'control_type' => 'group',
                                                'selector' => '{{WRAPPER}} .pxl-grid .pxl-post-item:hover .pxl-post-title,
                                                {{WRAPPER}} .pxl-grid .pxl-post-item.active .pxl-post-title',
                                            ),
                                        ],
                                    ],
                                ],
                            ),
                        ),
                    ),
                ),
                array(
                    'name' => 'tab_excerpt_style',
                    'label' => esc_html__('Excerpt', 'mouno' ),
                    'tab' => 'style',
                    'condition' => [
                        'show_excerpt!' => '',
                        'layout_portfolio!' => ['portfolio-4', 'portfolio-1', 'portfolio-5'],
                    ],
                    'controls' => array(
                        array(
                            'name' => 'excerpt_typography',
                            'type' => \Elementor\Group_Control_Typography::get_type(),
                            'control_type' => 'group',
                            'selector' => '{{WRAPPER}} .pxl-grid .pxl-post-excerpt',
                        ),
                        array(
                            'name' => 'excerpt_controls',
                            'control_type' => 'tab',
                            'tabs' => [
                                [
                                    'name' => 'excerpt_normal',
                                    'label' => esc_html__('Normal', 'mouno' ),
                                    'type' => 'tab',
                                    'controls' => [  
                                        array(
                                            'name' => 'excerpt_color',
                                            'label' => esc_html__('Text Color', 'mouno' ),
                                            'type' => 'color',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-grid .pxl-post-excerpt' => 'color: {{VALUE}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'excerpt_text_shadow',
                                            'type' => \Elementor\Group_Control_Text_Shadow::get_type(),
                                            'control_type' => 'group',
                                            'selector' => '{{WRAPPER}} .pxl-grid .pxl-post-excerpt',
                                        ),
                                    ],
                                ],
                                [
                                    'name' => 'excerpt_hover',
                                    'label' => esc_html__('Hover/Active', 'mouno' ),
                                    'type' => 'tab',
                                    'controls' => [  
                                        array(
                                            'name' => 'excerpt_hover_color',
                                            'label' => esc_html__('Text Color', 'mouno' ),
                                            'type' => 'color',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-grid .pxl-post-item:hover .pxl-post-excerpt, 
                                                {{WRAPPER}} .pxl-grid .pxl-post-item.active .pxl-post-excerpt' => 'color: {{VALUE}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'excerpt_hover_text_shadow',
                                            'type' => \Elementor\Group_Control_Text_Shadow::get_type(),
                                            'control_type' => 'group',
                                            'selector' => '{{WRAPPER}} .pxl-grid .pxl-post-item:hover .pxl-post-excerpt, 
                                            {{WRAPPER}} .pxl-grid .pxl-post-item.active .pxl-post-excerpt',
                                        ),
                                    ],
                                ],
                            ],
                        ),
                    ),
                ),
                array(
                    'name' => 'tab_index_style',
                    'label' => esc_html__('Index', 'mouno' ),
                    'tab' => 'style',
                    'condition' => [
                        'show_index!' => '',
                        'layout_portfolio!' => ['portfolio-4', 'portfolio-1', 'portfolio-5'],
                    ],
                    'controls' => array(
                        array(
                            'name' => 'index_typography',
                            'type' => \Elementor\Group_Control_Typography::get_type(),
                            'control_type' => 'group',
                            'selector' => '{{WRAPPER}} .pxl-grid .pxl-post-index',
                        ),
                        array(
                            'name' => 'index_controls',
                            'control_type' => 'tab',
                            'tabs' => [
                                [
                                    'name' => 'index_normal',
                                    'label' => esc_html__('Normal', 'mouno' ),
                                    'type' => 'tab',
                                    'controls' => [  
                                        array(
                                            'name' => 'index_color',
                                            'label' => esc_html__('Text Color', 'mouno' ),
                                            'type' => 'color',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-grid .pxl-post-index' => 'color: {{VALUE}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'index_text_shadow',
                                            'type' => \Elementor\Group_Control_Text_Shadow::get_type(),
                                            'control_type' => 'group',
                                            'selector' => '{{WRAPPER}} .pxl-grid .pxl-post-index',
                                        ),
                                    ],
                                ],
                                [
                                    'name' => 'index_hover',
                                    'label' => esc_html__('Hover/Active', 'mouno' ),
                                    'type' => 'tab',
                                    'controls' => [  
                                        array(
                                            'name' => 'index_hover_color',
                                            'label' => esc_html__('Text Color', 'mouno' ),
                                            'type' => 'color',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-grid .pxl-post-item:hover .pxl-post-index, 
                                                {{WRAPPER}} .pxl-grid .pxl-post-item.active .pxl-post-index' => 'color: {{VALUE}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'index_hover_text_shadow',
                                            'type' => \Elementor\Group_Control_Text_Shadow::get_type(),
                                            'control_type' => 'group',
                                            'selector' => '{{WRAPPER}} .pxl-grid .pxl-post-item:hover .pxl-post-index, 
                                            {{WRAPPER}} .pxl-grid .pxl-post-item.active .pxl-post-index',
                                        ),
                                    ],
                                ],
                            ],
                        ),
                    ),
                ),
                array(
                    'name' => 'tab_order_style',
                    'label' => esc_html__('Order', 'mouno' ),
                    'tab' => 'style',
                    'condition' => [
                        'show_order!' => '',
                        'layout_portfolio!' => ['portfolio-4', 'portfolio-3', 'portfolio-1', 'portfolio-5'],
                    ],
                    'controls' => array(
                        array(
                            'name' => 'order_typography',
                            'type' => \Elementor\Group_Control_Typography::get_type(),
                            'control_type' => 'group',
                            'selector' => '{{WRAPPER}} .pxl-grid .pxl-post-order',
                        ),
                        array(
                            'name' => 'order_controls',
                            'control_type' => 'tab',
                            'tabs' => [
                                [
                                    'name' => 'order_normal',
                                    'label' => esc_html__('Normal', 'mouno' ),
                                    'type' => 'tab',
                                    'controls' => [  
                                        array(
                                            'name' => 'order_color',
                                            'label' => esc_html__('Text Color', 'mouno' ),
                                            'type' => 'color',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-grid .pxl-post-order' => 'color: {{VALUE}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'order_text_shadow',
                                            'type' => \Elementor\Group_Control_Text_Shadow::get_type(),
                                            'control_type' => 'group',
                                            'selector' => '{{WRAPPER}} .pxl-grid .pxl-post-order',
                                        ),
                                    ],
                                ],
                                [
                                    'name' => 'order_hover',
                                    'label' => esc_html__('Hover/Active', 'mouno' ),
                                    'type' => 'tab',
                                    'controls' => [  
                                        array(
                                            'name' => 'order_hover_color',
                                            'label' => esc_html__('Text Color', 'mouno' ),
                                            'type' => 'color',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-grid .pxl-post-item:hover .pxl-post-order, 
                                                {{WRAPPER}} .pxl-grid .pxl-post-item.active .pxl-post-order' => 'color: {{VALUE}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'order_hover_text_shadow',
                                            'type' => \Elementor\Group_Control_Text_Shadow::get_type(),
                                            'control_type' => 'group',
                                            'selector' => '{{WRAPPER}} .pxl-grid .pxl-post-item:hover .pxl-post-order, 
                                            {{WRAPPER}} .pxl-grid .pxl-post-item.active .pxl-post-order',
                                        ),
                                    ],
                                ],
                            ],
                        ),
                    ),
                ),
                array(
                    'name' => 'tab_category_style',
                    'label' => esc_html__('Category', 'mouno' ),
                    'tab' => 'style',
                    'condition' => [
                        'show_category!' => '',
                        'layout_portfolio!' => ['portfolio-3']
                    ],
                    'controls' => array(
                        array(
                            'name' => 'category_typography',
                            'type' => \Elementor\Group_Control_Typography::get_type(),
                            'control_type' => 'group',
                            'selector' => '{{WRAPPER}} .pxl-grid .pxl-post-category',
                        ),
                        array(
                            'name' => 'category_text_shadow',
                            'label' => esc_html__('Text Shadow', 'mouno' ),
                            'type' => \Elementor\Group_Control_Text_Shadow::get_type(),
                            'control_type' => 'group',
                            'selector' => '{{WRAPPER}} .pxl-grid .pxl-post-category',
                        ),
                        array(
                            'name' => 'category_controls',
                            'control_type' => 'tab',
                            'tabs' => [
                                [
                                    'name' => 'category_normal',
                                    'label' => esc_html__('Normal', 'mouno' ),
                                    'type' => 'tab',
                                    'controls' => [  
                                        array(
                                            'name' => 'category_color',
                                            'label' => esc_html__('Text Color', 'mouno' ),
                                            'type' => 'color',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-grid .pxl-post-category > a' => 'color: {{VALUE}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'category_bg',
                                            'type' => \Elementor\Group_Control_Background::get_type(),
                                            'control_type' => 'group',
                                            'types' => [ 'classic', 'gradient' ],
                                            'selector' => '{{WRAPPER}} .pxl-grid .pxl-post-category > a',
                                        ),
                                        array(
                                            'name' => 'cateogry_border',
                                            'type' => \Elementor\Group_Control_Border::get_type(),
                                            'separator' => 'before',
                                            'control_type' => 'group', 
                                            'selector' => '{{WRAPPER}} .pxl-grid .pxl-post-category > a',
                                        ),
                                        array(
                                            'name'         => 'cateogry_box_shadow',
                                            'label' => esc_html__( 'Box Shadow', 'mouno' ),
                                            'type'         => \Elementor\Group_Control_Box_Shadow::get_type(),
                                            'control_type' => 'group',
                                            'selector'     => '{{WRAPPER}} .pxl-grid .pxl-post-category > a',
                                        ),
                                        array(
                                            'name' => 'cateogry_border_radius',
                                            'label' => esc_html__('Border Radius', 'mouno' ),
                                            'type' => 'dimensions',
                                            'size_units' => [ 'px', '%' ],
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-grid .pxl-post-category > a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'cateogry_padding',
                                            'label' => esc_html__('Padding', 'mouno' ),
                                            'type' => 'dimensions',
                                            'size_units' => [ 'px', '%' ],
                                            'control_type' => 'responsive',
                                            'separator' => 'before',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-grid .pxl-post-category > a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                    ],
                                ],
                                [
                                    'name' => 'category_hover',
                                    'label' => esc_html__('Hover', 'mouno' ),
                                    'type' => 'tab',
                                    'controls' => [
                                        array(
                                            'name' => 'category_hover_color',
                                            'label' => esc_html__('Text Color', 'mouno' ),
                                            'type' => 'color',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-grid .pxl-post-category > a:hover,
                                                {{WRAPPER}} .pxl-grid .hover-parent:hover .pxl-post-category > a' => 'color: {{VALUE}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'category_hover_bg',
                                            'type' => \Elementor\Group_Control_Background::get_type(),
                                            'control_type' => 'group',
                                            'types' => [ 'classic', 'gradient' ],
                                            'selector' => '{{WRAPPER}} .pxl-grid .pxl-post-category > a:hover,
                                                {{WRAPPER}} .pxl-grid .hover-parent:hover .pxl-post-category > a',
                                        ),
                                        array(
                                            'name' => 'category_hover_border',
                                            'type' => \Elementor\Group_Control_Border::get_type(),
                                            'separator' => 'before',
                                            'control_type' => 'group', 
                                            'selector' => '{{WRAPPER}} .pxl-grid .pxl-post-category > a:hover,
                                                {{WRAPPER}} .pxl-grid .hover-parent:hover .pxl-post-category > a',
                                        ),
                                        array(
                                            'name'         => 'category_hover_box_shadow',
                                            'label' => esc_html__( 'Box Shadow', 'mouno' ),
                                            'type'         => \Elementor\Group_Control_Box_Shadow::get_type(),
                                            'control_type' => 'group',
                                            'selector'     => '{{WRAPPER}} .pxl-grid .pxl-post-category > a:hover,
                                                {{WRAPPER}} .pxl-grid .hover-parent:hover .pxl-post-category > a',
                                        ),
                                        array(
                                            'name' => 'category_hover_border_radius',
                                            'label' => esc_html__('Border Radius', 'mouno' ),
                                            'type' => 'dimensions',
                                            'size_units' => [ 'px', '%' ],
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-grid .pxl-post-category > a:hover,
                                                {{WRAPPER}} .pxl-grid .hover-parent:hover .pxl-post-category > a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'category_hover_padding',
                                            'label' => esc_html__('Padding', 'mouno' ),
                                            'type' => 'dimensions',
                                            'size_units' => [ 'px', '%' ],
                                            'control_type' => 'responsive',
                                            'separator' => 'before',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-grid .pxl-post-category > a:hover,
                                                {{WRAPPER}} .pxl-grid .hover-parent:hover .pxl-post-category > a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                    ],
                                ],
                            ],
                        ),
                    ),
                ),
                array(
                    'name' => 'tab_btn_style',
                    'label' => esc_html__('Button', 'mouno' ),
                    'tab' => 'style',
                    'condition' => [
                        'show_btn!' => '',
                        'layout_portfolio!' => ['portfolio-1', 'portfolio-5']
                    ],
                    'controls' => array(
                        array(
                            'name' => 'btn_box_size',
                            'label' => esc_html__('Box Size', 'mouno' ),
                            'type' => 'slider',
                            'size_units' => ['px', 'custom'],
                            'control_type' => 'responsive',
                            'selectors' => [
                                '{{WRAPPER}} .pxl-grid .pxl-post-btn' => '--pxl-box-size: {{SIZE}}{{UNIT}};',
                            ],
                            'condition' => [
                                'layout_portfolio' => ['portfolio-4'],
                            ],
                        ),
                        array(
                            'name' => 'btn_h',
                            'label' => esc_html__('Height', 'mouno' ),
                            'type' => 'slider',
                            'size_units' => ['px', '%', 'custom'],
                            'control_type' => 'responsive',
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 1000,
                                ],
                            ],
                            'condition' => [
                                'layout_portfolio!' => ['portfolio-4'],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-grid .pxl-post-btn' => 'height: {{SIZE}}{{UNIT}};--pxl-height: {{SIZE}}{{UNIT}};',
                            ],
                        ),
                        array(
                            'name' => 'btn_icon_sz',
                            'label' => esc_html__('Icon Size', 'mouno' ),
                            'type' => 'slider',
                            'size_units' => ['px', '%', 'custom'],
                            'control_type' => 'responsive',
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 1000,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-grid .pxl-post-btn i ' => 'font-size: {{SIZE}}{{UNIT}};',
                                '{{WRAPPER}} .pxl-grid .pxl-post-btn svg' => 'width: {{SIZE}}{{UNIT}}; height: auto;',
                            ],
                        ),
                        array(
                            'name' => 'btn_typography',
                            'type' => \Elementor\Group_Control_Typography::get_type(),
                            'control_type' => 'group',
                            'selector' => '{{WRAPPER}} .pxl-grid .pxl-post-btn',
                        ),
                        array(
                            'name' => 'btn_text_shadow',
                            'label' => esc_html__('Text Shadow', 'mouno' ),
                            'type' => \Elementor\Group_Control_Text_Shadow::get_type(),
                            'control_type' => 'group',
                            'selector' => '{{WRAPPER}} .pxl-grid .pxl-post-btn',
                        ),
                        array(
                            'name' => 'btn_control',
                            'control_type' => 'tab',
                            'tabs' => [
                                [
                                    'name' => 'btn_normal',
                                    'label' => esc_html__('Normal', 'mouno' ),
                                    'type' => 'tab',
                                    'controls' => [  
                                        array(
                                            'name' => 'btn_color',
                                            'label' => esc_html__('Text Color', 'mouno' ),
                                            'type' => 'color',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-grid .pxl-post-btn' => 'color: {{VALUE}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'btn_icon_color',
                                            'label' => esc_html__('Icon Color', 'mouno' ),
                                            'type' => 'color',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-grid .pxl-post-btn .pxl-btn-icon' => 'color: {{VALUE}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'btn_bg',
                                            'type' => \Elementor\Group_Control_Background::get_type(),
                                            'control_type' => 'group',
                                            'types' => [ 'classic', 'gradient' ],
                                            'selector' => '{{WRAPPER}} .pxl-grid .pxl-post-btn:not(.pxl-btn-split), 
                                            {{WRAPPER}} .pxl-grid .pxl-post-btn.pxl-btn-split .pxl-btn-icon, 
                                            {{WRAPPER}} .pxl-grid .pxl-post-btn.pxl-btn-split .pxl-btn-text',
                                        ),
                                        array(
                                            'name' => 'btn_border',
                                            'type' => \Elementor\Group_Control_Border::get_type(),
                                            'separator' => 'before',
                                            'control_type' => 'group', 
                                            'selector' => '{{WRAPPER}} .pxl-grid .pxl-post-btn:not(.pxl-btn-split), 
                                            {{WRAPPER}} .pxl-grid .pxl-post-btn.pxl-btn-split .pxl-btn-icon, 
                                            {{WRAPPER}} .pxl-grid .pxl-post-btn.pxl-btn-split .pxl-btn-text',
                                        ),
                                        array(
                                            'name'         => 'btn_box_shadow',
                                            'label' => esc_html__( 'Box Shadow', 'mouno' ),
                                            'type'         => \Elementor\Group_Control_Box_Shadow::get_type(),
                                            'control_type' => 'group',
                                            'selector'     => '{{WRAPPER}} .pxl-grid .pxl-post-btn:not(.pxl-btn-split),
                                                {{WRAPPER}} .pxl-grid .pxl-post-btn.pxl-btn-split .pxl-btn-text,
                                                {{WRAPPER}} .pxl-grid .pxl-post-btn.pxl-btn-split .pxl-btn-icon',
                                        ),
                                        array(
                                            'name' => 'btn_border_radius',
                                            'label' => esc_html__('Border Radius', 'mouno' ),
                                            'type' => 'dimensions',
                                            'size_units' => [ 'px', '%' ],
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-grid .pxl-post-btn:not(.pxl-btn-split),
                                                {{WRAPPER}} .pxl-grid .pxl-post-btn.pxl-btn-split .pxl-btn-text,
                                                {{WRAPPER}} .pxl-grid .pxl-post-btn.pxl-btn-split .pxl-btn-icon' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'btn_padding',
                                            'label' => esc_html__('Padding', 'mouno' ),
                                            'type' => 'dimensions',
                                            'size_units' => [ 'px', '%' ],
                                            'control_type' => 'responsive',
                                            'separator' => 'before',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-grid .pxl-post-btn:not(.pxl-btn-split), 
                                                {{WRAPPER}} .pxl-grid .pxl-post-btn.pxl-btn-split .pxl-btn-text' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                    ],
                                ],
                                [
                                    'name' => 'btn_hover',
                                    'label' => esc_html__('Hover', 'mouno' ),
                                    'type' => 'tab',
                                    'controls' => [
                                        array(
                                            'name' => 'btn_hover_color',
                                            'label' => esc_html__('Text Color', 'mouno' ),
                                            'type' => 'color',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-grid .pxl-post-btn:hover, 
                                                {{WRAPPER}} .pxl-grid:not(.pxl-layout-portfolio) .hover-parent:hover .pxl-post-btn' => 'color: {{VALUE}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'btn_hover_icon_color',
                                            'label' => esc_html__('Icon Color', 'mouno' ),
                                            'type' => 'color',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-grid .pxl-post-btn:hover .pxl-btn-icon' => 'color: {{VALUE}};',
                                            ],
                                        ),
                                        array(
                                            'name' => '_btn_hover_border_color',
                                            'label' => esc_html__('Border Color', 'mouno' ),
                                            'type' => 'color',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-grid .pxl-post-btn:not(.pxl-btn-split):hover,
                                                {{WRAPPER}} .pxl-grid .pxl-post-btn.pxl-btn-split:hover .pxl-btn-icon, 
                                                {{WRAPPER}} .pxl-grid .pxl-post-btn.pxl-btn-split:hover .pxl-btn-text' => 'border-color: {{VALUE}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'btn_hover_bg',
                                            'type' => \Elementor\Group_Control_Background::get_type(),
                                            'control_type' => 'group',
                                            'types' => [ 'classic', 'gradient' ],
                                            'selector' => '{{WRAPPER}} .pxl-grid .pxl-post-btn:not(.pxl-btn-split):hover, 
                                            {{WRAPPER}} .pxl-grid .pxl-post-btn.pxl-btn-split:hover .pxl-btn-icon, 
                                            {{WRAPPER}} .pxl-grid .pxl-post-btn.pxl-btn-split:hover .pxl-btn-text',
                                        ),
                                        array(
                                            'name' => 'btn_hover_border',
                                            'type' => \Elementor\Group_Control_Border::get_type(),
                                            'separator' => 'before',
                                            'control_type' => 'group', 
                                            'selector' => '{{WRAPPER}} .pxl-grid .pxl-post-btn:not(.pxl-btn-split):hover, 
                                            {{WRAPPER}} .pxl-grid .pxl-post-btn.pxl-btn-split:hover .pxl-btn-icon, 
                                            {{WRAPPER}} .pxl-grid .pxl-post-btn.pxl-btn-split:hover .pxl-btn-text',
                                        ),
                                        array(
                                            'name'         => 'btn_hover_box_shadow',
                                            'label' => esc_html__( 'Box Shadow', 'mouno' ),
                                            'type'         => \Elementor\Group_Control_Box_Shadow::get_type(),
                                            'control_type' => 'group',
                                            'selector'     => '{{WRAPPER}} .pxl-grid .pxl-post-btn:not(.pxl-btn-split):hover, 
                                            {{WRAPPER}} .pxl-grid .pxl-post-btn.pxl-btn-split:hover .pxl-btn-icon, 
                                            {{WRAPPER}} .pxl-grid .pxl-post-btn.pxl-btn-split:hover .pxl-btn-text',
                                        ),
                                        array(
                                            'name' => 'btn_hover_border_radius',
                                            'label' => esc_html__('Border Radius', 'mouno' ),
                                            'type' => 'dimensions',
                                            'size_units' => [ 'px', '%' ],
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-grid .pxl-post-btn:not(.pxl-btn-split):hover, 
                                                {{WRAPPER}} .pxl-grid .pxl-post-btn.pxl-btn-split:hover .pxl-btn-icon, 
                                                {{WRAPPER}} .pxl-grid .pxl-post-btn.pxl-btn-split:hover .pxl-btn-text' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'btn_hover_padding',
                                            'label' => esc_html__('Padding', 'mouno' ),
                                            'type' => 'dimensions',
                                            'size_units' => [ 'px', '%' ],
                                            'control_type' => 'responsive',
                                            'separator' => 'before',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-grid .pxl-post-btn:not(.pxl-btn-split):hover, 
                                                {{WRAPPER}} .pxl-grid .pxl-post-btn.pxl-btn-split:hover .pxl-btn-text' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                    ],
                                ],
                            ],
                        ),
                    ),
                ),
                load_more_button_style_options(),
                grid_pagination_style_options(),
                swiper_bullets_pagination_style_options(),
                array(
                    'name' => 'tab_motion_effects',
                    'label' => esc_html__('Motion Effects', 'mouno' ),
                    'tab' => 'style',
                    'controls' => array_merge(
                        array(
                            array(
                                'name' => 'scrolling_effects',
                                'label' => esc_html__('Scrolling Effects', 'mouno'),
                                'type' => 'select',
                                'options' => [
                                    '' => esc_html__('None', 'mouno'),
                                    'parallax' => esc_html__('Parallax', 'mouno'),
                                ],
                                'default' => '',
                                'condition' => [
                                    'layout_portfolio' => 'portfolio-1',
                                ],
                            ),
                            array(
                                'name' => 'divider_scroll',
                                'type' => 'divider',
                                'condition' => [
                                    'layout_portfolio' => 'portfolio-1',
                                ],
                            ),
                        ),
                        array(
                            array(
                                'name' => 'entrance_anim',
                                'label' => esc_html__('Entrance Animation', 'mouno'),
                                'type' => 'select',
                                'groups' => mouno_entrance_anim_group(),
                                'default' => '',
                            ),
                            array(
                                'name' => 'anim_duration',
                                'label' => esc_html__('Animation Duration(ms)', 'mouno'),
                                'type' => 'number',
                                'selectors' => [
                                    '{{WRAPPER}} .pxl-grid .pxl-grid-item, 
                                    {{WRAPPER}} .pxl-swiper .pxl-swiper-slide' => 'animation-duration: {{VALUE}}ms;-webkit-animation-duration: {{VALUE}}ms;',
                                ],
                            ),
                            array(
                                'name' => 'anim_delay',
                                'label' => esc_html__('Animation Delay(ms)', 'mouno'),
                                'type' => 'number',
                                'default' => 0,
                            ),
                        )
                    ),
                ),
            ),
        ),
    ),
    mouno_get_class_widget_path()
);