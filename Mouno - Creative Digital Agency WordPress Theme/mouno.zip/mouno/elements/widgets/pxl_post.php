<?php
$post_type = ['post'];
pxl_add_custom_widget(
    array(
        'name' => 'pxl_post',
        'title' => esc_html__('Case Post', 'mouno' ),
        'icon' => 'eicon-persion',
        'categories' => array('pxltheme-core'),
        'scripts' => [
            'imagesloaded',
            'isotope',
            'pxl-post-grid',
            'swiper',
            'mouno-swiper',
            'mouno-effects',
            'mouno-parallax'
        ],
        'params' => array(
            'sections' => array(
                array(
                    'name'     => 'tab_layout',
                    'label'    => esc_html__( 'Layout', 'mouno' ),
                    'tab'      => 'layout',
                    'controls' => array_merge(
                        array(
                            array(
                                'name'     => 'post_type',
                                'type'     => 'hidden',
                                'options'  => mouno_get_post_type_options($post_type),
                                'default'  => 'post'
                            ),
                            array(
                                'name'     => 'layout_type',
                                'label'    => esc_html__( 'Layout Type', 'mouno' ),
                                'type'     => 'select',
                                'options'  => [
                                    'grid' => esc_html__('Grid', 'mouno'),
                                    'carousel' => esc_html__('Carousel', 'mouno'),
                                ],
                                'default'  => 'grid',
                            ),
                            array(
                                'name'     => 'layout1_style',
                                'label'    => esc_html__( 'Layout Post Style', 'mouno' ),
                                'type'     => 'layoutcontrol',
                                'options'  => [
                                    'layout-post-default' => [
                                        'label' => esc_html__( 'Default', 'mouno' ),
                                        'image' => get_template_directory_uri() . '/elements/templates/pxl_post/img-layout/post-1.webp'
                                    ],
                                    'layout-post-style1' => [
                                        'label' => esc_html__( 'Style 1', 'mouno' ),
                                        'image' => get_template_directory_uri() . '/elements/templates/pxl_post/img-layout/post-1-2.webp'
                                    ],
                                ],
                                'default'  => 'layout-post-default',
                                'condition' => [
                                    'layout_post' => 'post-1',
                                ],
                            ),
                            array(
                                'name' => 'divider_layout',
                                'type' => 'divider',
                            ),
                        ),
                        mouno_get_post_layout($post_type, []), 
                    ),
                ),
                 
                // Settings
                mouno_source_post_settings($post_type),
                array(
                    'name' => 'tab_display_opts',
                    'label' => esc_html__('Display', 'mouno' ),
                    'tab' => 'settings',
                    'controls' => array_merge(
                        image_dimension_options(),
                        array(
                            array(
                                'name' => 'title_tag',
                                'label' => esc_html__('Title HTML Tag', 'mouno'),
                                'type' => 'select',
                                'options' => [
                                    ''   => esc_html__('Default', 'mouno'),
                                    'h1' => esc_html__('H1', 'mouno'),
                                    'h2' => esc_html__('H2', 'mouno'),
                                    'h3' => esc_html__('H3', 'mouno'),
                                    'h4' => esc_html__('H4', 'mouno'),
                                    'h5' => esc_html__('H5', 'mouno'),
                                    'h6' => esc_html__('H6', 'mouno'),
                                    'div' => esc_html__('div', 'mouno'),
                                    'p'  => esc_html__('p', 'mouno'),
                                    'span' => esc_html__('span', 'mouno'),
                                ],
                                'default' => '',
                            ),
                            
                            array(
                                'name' => 'show_date',
                                'label' => esc_html__('Show Date', 'mouno' ),
                                'type' => 'switcher',
                                'separator' => 'before',
                                'default' => 'true',
                            ),
                            array(
                                'name' => 'show_author',
                                'label' => esc_html__('Show Author', 'mouno' ),
                                'type' => 'switcher',
                                'default' => 'true',
                                'condition' => [
                                    'layout_post!' => ['post-2'],
                                ],
                            ),
                            array(
                                'name' => 'show_category',
                                'label' => esc_html__('Show Category', 'mouno' ),
                                'type' => 'switcher',
                                'default' => 'true',
                                'condition' => [
                                    'layout_post' => ['post-2'],
                                ],
                            ),
                        ),
                    ),
                ),

                array(
                    'name' => 'tab_grid_add_opts',
                    'label' => esc_html__('Additional Options', 'mouno' ),
                    'tab' => 'settings',
                    'condition' => ['layout_type' => 'grid'],
                    'controls' => grid_controls_options(
                        [ 
                            'filter' => true ,
                        ],
                    ),
                ),

                array(
                    'name' => 'tab_swiper_add_otps',
                    'label' => esc_html__('Addtional Options', 'mouno'),
                    'tab' => 'settings',
                    'condition' => ['layout_type' => 'carousel'],
                    'controls' => array(
                        swiper_controls_options(),
                    ),
                ),

                // Style
                array(
                    'name' => 'tab_general_style',
                    'label' => esc_html__('General', 'mouno' ),
                    'tab' => \Elementor\Controls_Manager::TAB_STYLE,
                    'controls' => array(
                        array(
                            'name' => 'featured_sapcing',
                            'label' => esc_html__('Featured Spacing', 'mouno'),
                            'type' => 'slider',
                            'size_units' => ['px', '%', 'custom'],
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 1000,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-layout-post .pxl-post-content' => "padding-top: {{SIZE}}{{UNIT}};",
                            ],
                        ),
                        array(
                            'name' => 'date_spacing',
                            'label' => esc_html__('Date Spacing', 'mouno'),
                            'type' => 'slider',
                            'size_units' => ['px', '%', 'custom'],
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 1000,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-layout-post .pxl-post-date' => "margin-bottom: {{SIZE}}{{UNIT}};",
                            ],
                        ),
                        array(
                            'name' => 'title_spacing',
                            'label' => esc_html__('Title Spacing', 'mouno'),
                            'type' => 'slider',
                            'size_units' => ['px', '%', 'custom'],
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 1000,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-layout-post .pxl-post-title' => "margin-bottom: {{SIZE}}{{UNIT}};",
                            ],
                        ),
                        array(
                            'name' => 'meta_separator',
                            'label' => esc_html__('Meta Separator Color', 'mouno' ),
                            'type' => 'color',
                            'selectors' => [
                                '{{WRAPPER}} .pxl-layout-post .pxl-post-separator' => 'color: {{VALUE}};',
                            ],
                        ),
                    ),
                ),
                array(
                    'name' => 'tab_box_style',
                    'label' => esc_html__('Box', 'mouno' ),
                    'tab' => 'style',
                    'controls' => array(
                        array(
                            'name' => 'box_controls',
                            'control_type' => 'tab',
                            'tabs' => [
                                [
                                    'name' => 'box_normal',
                                    'label' => esc_html__('Normal', 'mouno' ),
                                    'type' => 'tab',
                                    'controls' => [  
                                        array(
                                            'name' => 'box_bg',
                                            'type' => \Elementor\Group_Control_Background::get_type(),
                                            'control_type' => 'group',
                                            'types' => [ 'classic', 'gradient' ],
                                            'selector' => '{{WRAPPER}} .pxl-layout-post .pxl-post-item',
                                        ),
                                        array(
                                            'name' => 'box_border',
                                            'type' => \Elementor\Group_Control_Border::get_type(),
                                            'separator' => 'before',
                                            'control_type' => 'group', 
                                            'selector' => '{{WRAPPER}} .pxl-layout-post .pxl-post-item',
                                        ),
                                        array(
                                            'name'         => 'box_box_shadow',
                                            'label' => esc_html__( 'Box Shadow', 'mouno' ),
                                            'type'         => \Elementor\Group_Control_Box_Shadow::get_type(),
                                            'control_type' => 'group',
                                            'selector'     => '{{WRAPPER}} .pxl-layout-post .pxl-post-item',
                                        ),
                                        array(
                                            'name' => 'box_border_radius',
                                            'label' => esc_html__('Border Radius', 'mouno' ),
                                            'type' => 'dimensions',
                                            'size_units' => [ 'px', '%', 'custom' ],
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-layout-post .pxl-post-item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'box_padding',
                                            'label' => esc_html__('Padding', 'mouno' ),
                                            'type' => 'dimensions',
                                            'size_units' => [ 'px', '%', 'custom' ],
                                            'control_type' => 'responsive',
                                            'separator' => 'before',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-layout-post .pxl-post-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                    ],
                                ],
                                [
                                    'name' => 'box_hover',
                                    'label' => esc_html__('Hover', 'mouno' ),
                                    'type' => 'tabs',
                                    'controls' => [
                                        array(
                                            'name' => 'box_hover_bg',
                                            'type' => \Elementor\Group_Control_Background::get_type(),
                                            'control_type' => 'group',
                                            'types' => [ 'classic', 'gradient' ],
                                            'selector' => '{{WRAPPER}} .pxl-layout-post .pxl-post-item:hover',
                                        ),
                                        array(
                                            'name' => '_box_hover_border_color',
                                            'label' => esc_html__('Border Color', 'mouno' ),
                                            'type' => 'color',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-layout-post .pxl-post-item:hover' => 'border-color: {{VALUE}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'box_hover_border',
                                            'type' => \Elementor\Group_Control_Border::get_type(),
                                            'separator' => 'before',
                                            'control_type' => 'group', 
                                            'selector' => '{{WRAPPER}} .pxl-layout-post .pxl-post-item:hover',
                                        ),
                                        array(
                                            'name'         => 'box_hover_box_shadow',
                                            'label' => esc_html__( 'Box Shadow', 'mouno' ),
                                            'type'         => \Elementor\Group_Control_Box_Shadow::get_type(),
                                            'control_type' => 'group',
                                            'selector'     => '{{WRAPPER}} .pxl-layout-post .pxl-post-item:hover',
                                        ),
                                        array(
                                            'name' => 'box_hover_border_radius',
                                            'label' => esc_html__('Border Radius', 'mouno' ),
                                            'type' => 'dimensions',
                                            'size_units' => [ 'px', '%', 'custom' ],
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-layout-post .pxl-post-item:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'box_hover_padding',
                                            'label' => esc_html__('Padding', 'mouno' ),
                                            'type' => 'dimensions',
                                            'size_units' => [ 'px', '%', 'custom' ],
                                            'control_type' => 'responsive',
                                            'separator' => 'before',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-layout-post .pxl-post-item:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                    ],
                                ],
                            ],
                        ),
                    ),
                ),
                array(
                    'name' => 'tab_featured_style',
                    'label' => esc_html__('Featured', 'mouno' ),
                    'tab' => 'style',
                    'controls' => array(
                        array(
                            'name' => 'featured_w',
                            'label' => esc_html__('Width', 'mouno'),
                            'type' => 'slider',
                            'size_units' => ['px', '%', 'custom'],
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 1000,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-layout-post .pxl-post-featured' => "width: {{SIZE}}{{UNIT}};",
                            ],
                        ),
                        array(
                            'name' => 'featured_max_w',
                            'label' => esc_html__('Max Width', 'mouno'),
                            'type' => 'slider',
                            'size_units' => ['px', '%', 'custom'],
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 1000,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-layout-post .pxl-post-featured' => "max-width: {{SIZE}}{{UNIT}};",
                            ],
                        ),
                        array(
                            'name' => 'featured_h',
                            'label' => esc_html__('Height', 'mouno'),
                            'type' => 'slider',
                            'size_units' => ['px', '%', 'custom'],
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 1000,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-layout-post .pxl-post-featured' => "height: {{SIZE}}{{UNIT}};",
                            ],
                        ),
                        array(
                            'name' => 'featured_divider',
                            'type' => 'divider',
                        ),
                        array(
                            'name' => 'featured_controls',
                            'control_type' => 'tab',
                            'tabs' => [
                                [
                                    'name' => 'featured_normal',
                                    'label' => esc_html__('Normal', 'mouno' ),
                                    'type' => 'tab',
                                    'controls' => [  
                                        array(
                                            'name' => 'featured_opacity',
                                            'label' => esc_html__('Opacity', 'mouno' ),
                                            'type' => 'slider',
                                            'control_type' => 'responsive',
                                            'size_units' => ['px'],
                                            'range' => [
                                                'px' => [
                                                    'min' => 0,
                                                    'max' => 1,
                                                    'step' => 0.01,
                                                ],
                                            ],
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-layout-post .pxl-post-featured' => 'opacity: {{SIZE}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'featured_css_filter', 
                                            'type' => \Elementor\Group_Control_Css_Filter::get_type(),
                                            'control_type' => 'group',
                                            'selector' => '{{WRAPPER}} .pxl-layout-post .pxl-post-featured',
                                        ),
                                        array(
                                            'name' => 'featured_border', 
                                            'type' => \Elementor\Group_Control_Border::get_type(),
                                            'control_type' => 'group',
                                            'separator' => 'before',
                                            'selector' => '{{WRAPPER}} .pxl-layout-post .pxl-post-featured',
                                        ),
                                        array(
                                            'name' => 'featured_box_shadow', 
                                            'type' => \Elementor\Group_Control_Box_Shadow::get_type(),
                                            'control_type' => 'group',
                                            'separator' => 'before',
                                            'selector' => '{{WRAPPER}} .pxl-layout-post .pxl-post-featured',
                                        ),
                                        array(
                                            'name' => 'featured_border_radius',
                                            'label' => esc_html__('Border Radius', 'mouno' ),
                                            'type' => 'dimensions',
                                            'size_units' => [ 'px', '%' ],
                                            'control_type' => 'responsive',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-layout-post .pxl-post-featured' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'featured_padding',
                                            'label' => esc_html__('Padding', 'mouno' ),
                                            'type' => 'dimensions',
                                            'size_units' => [ 'px', '%' ],
                                            'control_type' => 'responsive',
                                            'separator' => 'before',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-layout-post .pxl-post-featured' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                    ],
                                ],
                                [
                                    'name' => 'featured_hover',
                                    'label' => esc_html__('Hover', 'mouno' ),
                                    'type' => 'tab',
                                    'controls' => [
                                        array(
                                            'name' => 'featured_hover_style',
                                            'label' => esc_html__('Hover Style', 'mouno' ),
                                            'type' => 'select',
                                            'options' => [
                                                'hover-image-default'               => esc_html__('Default', 'mouno'),
                                                'hover-image-zoom-in'               => esc_html__('Zoom In', 'mouno'),
                                                'hover-tilt'                        => esc_html__('Tilt', 'mouno'),
                                                'hover-image-distortion-transition' => esc_html__('Distortion Transition', 'mouno'),
                                                'hover-image-distortion-warp'       => esc_html__('Distortion Warp', 'mouno'),
                                                'hover-image-distortion-wave'       => esc_html__('Distortion Wave', 'mouno'),
                                                'hover-image-parallax'              => esc_html__('Parallax', 'mouno'),
                                                'hover-image-overlay-fade--x'       => esc_html__('Overlay Fade X', 'mouno')
                                            ],
                                            'default' => 'hover-image-default',
                                        ),
                                        array(
                                            'name' => 'displacement_img',
                                            'label' => esc_html__('Displacement Image', 'mouno'),
                                            'type' => 'media',
                                            'default' => [
                                                'url' => content_url('/uploads/2025/01/displacement-4.webp'),
                                                'id' => 9031,
                                            ],
                                            'condition' => [
                                                'featured_hover_style' => 'hover-image-distortion-transition',
                                            ]
                                        ),
                                        array(
                                            'name' => 'featured_zoom_in_val',
                                            'label' => esc_html__('Zoom Value', 'mouno' ),
                                            'type' => 'slider',
                                            'control_type' => 'responsive',
                                            'size_units' => ['px'],
                                            'range' => [
                                                'px' => [
                                                    'min' => 1,
                                                    'max' => 3,
                                                    'step' => 0.01,
                                                ],
                                            ],
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-layout-post .pxl-post-featured' => '--pxl-scale: {{SIZE}};',
                                            ],
                                            'condition' => [
                                                'featured_hover_style' => 'hover-image-zoom-in',
                                            ],
                                        ),
                                        array(
                                            'name' => 'featured_hover_opacity',
                                            'label' => esc_html__('Opacity', 'mouno' ),
                                            'type' => 'slider',
                                            'control_type' => 'responsive',
                                            'size_units' => ['px'],
                                            'range' => [
                                                'px' => [
                                                    'min' => 0,
                                                    'max' => 1,
                                                    'step' => 0.01,
                                                ],
                                            ],
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-layout-post .hover-parent:hover .pxl-post-featured' => 'opacity: {{SIZE}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'featured_hover_css_filter', 
                                            'type' => \Elementor\Group_Control_Css_Filter::get_type(),
                                            'control_type' => 'group',
                                            'selector' => '{{WRAPPER}} .pxl-layout-post .hover-parent:hover .pxl-post-featured',
                                        ),
                                        array(
                                            'name' => 'featured_hover_border', 
                                            'type' => \Elementor\Group_Control_Border::get_type(),
                                            'control_type' => 'group',
                                            'separator' => 'before',
                                            'selector' => '{{WRAPPER}} .pxl-layout-post .hover-parent:hover .pxl-post-featured',
                                        ),
                                        array(
                                            'name' => 'featured_hover_box_shadow', 
                                            'type' => \Elementor\Group_Control_Box_Shadow::get_type(),
                                            'control_type' => 'group',
                                            'separator' => 'before',
                                            'selector' => '{{WRAPPER}} .pxl-layout-post .hover-parent:hover .pxl-post-featured',
                                        ),
                                        array(
                                            'name' => 'featured_hover_border_radius',
                                            'label' => esc_html__('Border Radius', 'mouno' ),
                                            'type' => 'dimensions',
                                            'size_units' => [ 'px', '%' ],
                                            'control_type' => 'responsive',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-layout-post .hover-parent:hover .pxl-post-featured' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'featured_hover_padding',
                                            'label' => esc_html__('Padding', 'mouno' ),
                                            'type' => 'dimensions',
                                            'size_units' => [ 'px', '%' ],
                                            'control_type' => 'responsive',
                                            'separator' => 'before',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-layout-post .hover-parent:hover .pxl-post-featured' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                    ],
                                ],
                            ],
                        ),
                    ),
                ),
                array(
                    'name' => 'tab_title_style',
                    'label' => esc_html__('Title', 'mouno' ),
                    'tab' => 'style',
                    'controls' => array_merge(
                        array(
                            array(
                                'name' => 'title_typography',
                                'type' => \Elementor\Group_Control_Typography::get_type(),
                                'control_type' => 'group',
                                'selector' => '{{WRAPPER}} .pxl-layout-post .pxl-post-title',
                            ),
                            array(
                                'name' => 'title_controls',
                                'control_type' => 'tab',
                                'tabs' => [
                                    [
                                        'name' => 'title_normal',
                                        'label' => esc_html__('Normal', 'mouno' ),
                                        'type' => 'tab',
                                        'controls' => [  
                                            array(
                                                'name' => 'title_color',
                                                'label' => esc_html__('Text Color', 'mouno' ),
                                                'type' => 'color',
                                                'selectors' => [
                                                    '{{WRAPPER}} .pxl-layout-post .pxl-post-title, 
                                                    {{WRAPPER}} .pxl-layout-post .pxl-post-title.hover-3d-cube-flip:before' => 'color: {{VALUE}};',
                                                ],
                                            ),
                                            array(
                                                'name' => 'title_stroke',
                                                'type' => \Elementor\Group_Control_Text_Stroke::get_type(),
                                                'control_type' => 'group',
                                                'selector' => '{{WRAPPER}} .pxl-layout-post .pxl-post-title',
                                            ),
                                            array(
                                                'name' => 'title_text_shadow',
                                                'type' => \Elementor\Group_Control_Text_Shadow::get_type(),
                                                'control_type' => 'group',
                                                'selector' => '{{WRAPPER}} .pxl-layout-post .pxl-post-title',
                                            ),
                                        ],
                                    ],
                                    [
                                        'name' => 'title_hover',
                                        'label' => esc_html__('Hover/Active', 'mouno' ),
                                        'type' => 'tab',
                                        'controls' => [
                                            array(
                                                'name' => 'title_hover_style',
                                                'label' => esc_html__('Hover Style', 'mouno' ),
                                                'type' => 'select',
                                                'groups' => [
                                                    [
                                                        'label' => esc_html__('Default', 'mouno'),
                                                        'options' => [
                                                            'hover-text-default' => esc_html__('Default', 'mouno'),
                                                        ],
                                                    ],
                                                    [
                                                        'label' => esc_html__('Underline', 'mouno'),
                                                        'options' => [
                                                            'hover-text-underline' => esc_html__('Underline', 'mouno'),
                                                            'hover-text-underline--slide-ltr' => esc_html__('Slide LTR', 'mouno'),
                                                            'hover-text-underline--slide-rtl' => esc_html__('Slide RTL', 'mouno'),
                                                        ],
                                                    ],
                                                    [
                                                        'label' => esc_html__('Other', 'mouno'),
                                                        'options' => [
                                                            'hover-text-fill' => esc_html__('Text Fill', 'mouno'),
                                                        ],
                                                    ],
                                                ],
                                                'default' => 'hover-text-default',
                                            ),
                                            array(
                                                'name' => 'underline_h',
                                                'label' => esc_html__('Underline Weight(px)', 'mouno'),
                                                'type' => 'slider',
                                                'size_units' => ['px'],
                                                'selectors' => [
                                                    '{{WRAPPER}} .pxl-layout-post .pxl-post-item .pxl-post-title' => "--pxl-height: {{SIZE}}{{UNIT}};",
                                                ],
                                                'condition' => [
                                                    'title_hover_style' => ['hover-text-underline', 'hover-text-underline--slide-ltr', 'hover-text-underline--slide-rtl'],
                                                ],
                                            ),
                                            array(
                                                'name' => 'title_divider',
                                                'type' => 'divider',
                                            ),
                                            array(
                                                'name' => 'title_hover_color',
                                                'label' => esc_html__('Text Color', 'mouno' ),
                                                'type' => 'color',
                                                'selectors' => [
                                                    '{{WRAPPER}} .pxl-layout-post .hover-parent:hover .pxl-post-title:not(.hover-3d-cube-flip):not(.hover-text-fill),
                                                    {{WRAPPER}} .pxl-layout-post .pxl-post-title.hover-3d-cube-flip:after' => 'color: {{VALUE}};',
                                                    '{{WRAPPER}} .pxl-layout-post .hover-parent .hover-text-fill'   => '--link-color-hover: {{VALUE}};',
                                                ],
                                            ),
                                            array(
                                                'name' => 'title_hover_stroke',
                                                'type' => \Elementor\Group_Control_Text_Stroke::get_type(),
                                                'control_type' => 'group',
                                                'selector' => '{{WRAPPER}} .pxl-layout-post .hover-parent:hover .pxl-post-title'
                                            ),
                                            array(
                                                'name' => 'title_hover_text_shadow',
                                                'type' => \Elementor\Group_Control_Text_Shadow::get_type(),
                                                'control_type' => 'group',
                                                'selector' => '{{WRAPPER}} .pxl-layout-post .hover-parent:hover .pxl-post-title'
                                            ),
                                        ],
                                    ],
                                ],
                            ),
                        ),
                    ),
                ),
                array(
                    'name' => 'tab_date_style',
                    'label' => esc_html__('Date', 'mouno' ),
                    'tab' => 'style',
                    'condition' => [
                        'show_date!' => '',
                    ],
                    'controls' => array(
                        array(
                            'name' => 'date_typography',
                            'type' => \Elementor\Group_Control_Typography::get_type(),
                            'control_type' => 'group',
                            'selector' => '{{WRAPPER}} .pxl-layout-post .pxl-post-date',
                        ),
                        array(
                            'name' => 'date_text_shadow',
                            'label' => esc_html__('Text Shadow', 'mouno' ),
                            'type' => \Elementor\Group_Control_Text_Shadow::get_type(),
                            'control_type' => 'group',
                            'selector' => '{{WRAPPER}} .pxl-layout-post .pxl-post-date',
                        ),
                        array(
                            'name' => 'date_control',
                            'control_type' => 'tab',
                            'tabs' => [
                                [
                                    'name' => 'date_normal',
                                    'label' => esc_html__('Normal', 'mouno' ),
                                    'type' => 'tab',
                                    'controls' => [  
                                        array(
                                            'name' => 'date_color',
                                            'label' => esc_html__('Text Color', 'mouno' ),
                                            'type' => 'color',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-layout-post .pxl-post-date' => 'color: {{VALUE}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'date_bg',
                                            'type' => \Elementor\Group_Control_Background::get_type(),
                                            'control_type' => 'group',
                                            'types' => [ 'classic', 'gradient' ],
                                            'selector' => '{{WRAPPER}} .pxl-layout-post .pxl-post-date',
                                        ),
                                        array(
                                            'name' => 'date_border',
                                            'type' => \Elementor\Group_Control_Border::get_type(),
                                            'separator' => 'before',
                                            'control_type' => 'group', 
                                            'selector' => '{{WRAPPER}} .pxl-layout-post .pxl-post-date',
                                        ),
                                        array(
                                            'name'         => 'date_box_shadow',
                                            'label' => esc_html__( 'Box Shadow', 'mouno' ),
                                            'type'         => \Elementor\Group_Control_Box_Shadow::get_type(),
                                            'control_type' => 'group',
                                            'selector'     => '{{WRAPPER}} .pxl-layout-post .pxl-post-date',
                                        ),
                                        array(
                                            'name' => 'date_border_radius',
                                            'label' => esc_html__('Border Radius', 'mouno' ),
                                            'type' => 'dimensions',
                                            'size_units' => [ 'px', '%' ],
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-layout-post .pxl-post-date' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'date_padding',
                                            'label' => esc_html__('Padding', 'mouno' ),
                                            'type' => 'dimensions',
                                            'size_units' => [ 'px', '%' ],
                                            'control_type' => 'responsive',
                                            'separator' => 'before',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-layout-post .pxl-post-date' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                    ],
                                ],
                                [
                                    'name' => 'date_hover',
                                    'label' => esc_html__('Hover', 'mouno' ),
                                    'type' => 'tab',
                                    'controls' => [
                                        array(
                                            'name' => 'date_hover_color',
                                            'label' => esc_html__('Text Color', 'mouno' ),
                                            'type' => 'color',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-layout-post .hover-parent:hover .pxl-post-date' => 'color: {{VALUE}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'date_hover_bg',
                                            'type' => \Elementor\Group_Control_Background::get_type(),
                                            'control_type' => 'group',
                                            'types' => [ 'classic', 'gradient' ],
                                            'selector' => '{{WRAPPER}} .pxl-layout-post .hover-parent:hover .pxl-post-date',
                                        ),
                                        array(
                                            'name' => 'date_hover_border',
                                            'type' => \Elementor\Group_Control_Border::get_type(),
                                            'separator' => 'before',
                                            'control_type' => 'group', 
                                            'selector' => '{{WRAPPER}} .pxl-layout-post .hover-parent:hover .pxl-post-date',
                                        ),
                                        array(
                                            'name'         => 'date_hover_box_shadow',
                                            'label' => esc_html__( 'Box Shadow', 'mouno' ),
                                            'type'         => \Elementor\Group_Control_Box_Shadow::get_type(),
                                            'control_type' => 'group',
                                            'selector'     => '{{WRAPPER}} .pxl-layout-post .hover-parent:hover .pxl-post-date',
                                        ),
                                        array(
                                            'name' => 'date_hover_border_radius',
                                            'label' => esc_html__('Border Radius', 'mouno' ),
                                            'type' => 'dimensions',
                                            'size_units' => [ 'px', '%' ],
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-layout-post .hover-parent:hover .pxl-post-date' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'date_hover_padding',
                                            'label' => esc_html__('Padding', 'mouno' ),
                                            'type' => 'dimensions',
                                            'size_units' => [ 'px', '%' ],
                                            'control_type' => 'responsive',
                                            'separator' => 'before',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-layout-post .hover-parent:hover .pxl-post-date' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                    ],
                                ],
                            ],
                        ),
                    ),
                ),
                array(
                    'name' => 'tab_category_style',
                    'label' => esc_html__('Category', 'mouno' ),
                    'tab' => 'style',
                    'condition' => [
                        'show_category!' => '',
                        'layout_post' => ['post-2']
                    ],
                    'controls' => array(
                        array(
                            'name' => 'category_typography',
                            'type' => \Elementor\Group_Control_Typography::get_type(),
                            'control_type' => 'group',
                            'selector' => '{{WRAPPER}} .pxl-layout-post .pxl-post-category',
                        ),
                        array(
                            'name' => 'category_text_shadow',
                            'label' => esc_html__('Text Shadow', 'mouno' ),
                            'type' => \Elementor\Group_Control_Text_Shadow::get_type(),
                            'control_type' => 'group',
                            'selector' => '{{WRAPPER}} .pxl-layout-post .pxl-post-category',
                        ),
                        array(
                            'name' => 'category_controls',
                            'control_type' => 'tab',
                            'tabs' => [
                                [
                                    'name' => 'category_normal',
                                    'label' => esc_html__('Normal', 'mouno' ),
                                    'type' => 'tab',
                                    'controls' => [  
                                        array(
                                            'name' => 'category_color',
                                            'label' => esc_html__('Text Color', 'mouno' ),
                                            'type' => 'color',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-layout-post .pxl-post-category > a' => 'color: {{VALUE}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'category_bg',
                                            'type' => \Elementor\Group_Control_Background::get_type(),
                                            'control_type' => 'group',
                                            'types' => [ 'classic', 'gradient' ],
                                            'selector' => '{{WRAPPER}} .pxl-layout-post .pxl-post-category > a',
                                        ),
                                        array(
                                            'name' => 'category_border',
                                            'type' => \Elementor\Group_Control_Border::get_type(),
                                            'separator' => 'before',
                                            'control_type' => 'group', 
                                            'selector' => '{{WRAPPER}} .pxl-layout-post .pxl-post-category > a',
                                        ),
                                        array(
                                            'name'         => 'category_box_shadow',
                                            'label' => esc_html__( 'Box Shadow', 'mouno' ),
                                            'type'         => \Elementor\Group_Control_Box_Shadow::get_type(),
                                            'control_type' => 'group',
                                            'selector'     => '{{WRAPPER}} .pxl-layout-post .pxl-post-category > a',
                                        ),
                                        array(
                                            'name' => 'category_border_radius',
                                            'label' => esc_html__('Border Radius', 'mouno' ),
                                            'type' => 'dimensions',
                                            'size_units' => [ 'px', '%' ],
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-layout-post .pxl-post-category > a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'category_padding',
                                            'label' => esc_html__('Padding', 'mouno' ),
                                            'type' => 'dimensions',
                                            'size_units' => [ 'px', '%' ],
                                            'control_type' => 'responsive',
                                            'separator' => 'before',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-layout-post .pxl-post-category > a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                    ],
                                ],
                                [
                                    'name' => 'category_hover',
                                    'label' => esc_html__('Hover', 'mouno' ),
                                    'type' => 'tab',
                                    'controls' => [
                                        array(
                                            'name' => 'category_hover_color',
                                            'label' => esc_html__('Text Color', 'mouno' ),
                                            'type' => 'color',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-layout-post .pxl-post-category > a:hover,
                                                {{WRAPPER}} .pxl-layout-post .hover-parent:hover .pxl-post-category > a' => 'color: {{VALUE}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'category_hover_bg',
                                            'type' => \Elementor\Group_Control_Background::get_type(),
                                            'control_type' => 'group',
                                            'types' => [ 'classic', 'gradient' ],
                                            'selector' => '{{WRAPPER}} .pxl-layout-post .pxl-post-category > a:hover,
                                                {{WRAPPER}} .pxl-layout-post .hover-parent:hover .pxl-post-category > a',
                                        ),
                                        array(
                                            'name' => 'category_hover_border',
                                            'type' => \Elementor\Group_Control_Border::get_type(),
                                            'separator' => 'before',
                                            'control_type' => 'group', 
                                            'selector' => '{{WRAPPER}} .pxl-layout-post .pxl-post-category > a:hover,
                                                {{WRAPPER}} .pxl-layout-post .hover-parent:hover .pxl-post-category > a',
                                        ),
                                        array(
                                            'name'         => 'category_hover_box_shadow',
                                            'label' => esc_html__( 'Box Shadow', 'mouno' ),
                                            'type'         => \Elementor\Group_Control_Box_Shadow::get_type(),
                                            'control_type' => 'group',
                                            'selector'     => '{{WRAPPER}} .pxl-layout-post .pxl-post-category > a:hover,
                                                {{WRAPPER}} .pxl-layout-post .hover-parent:hover .pxl-post-category > a',
                                        ),
                                        array(
                                            'name' => 'category_hover_border_radius',
                                            'label' => esc_html__('Border Radius', 'mouno' ),
                                            'type' => 'dimensions',
                                            'size_units' => [ 'px', '%' ],
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-layout-post .pxl-post-category > a:hover,
                                                {{WRAPPER}} .pxl-layout-post .hover-parent:hover .pxl-post-category > a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'category_hover_padding',
                                            'label' => esc_html__('Padding', 'mouno' ),
                                            'type' => 'dimensions',
                                            'size_units' => [ 'px', '%' ],
                                            'control_type' => 'responsive',
                                            'separator' => 'before',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-layout-post .pxl-post-category > a:hover,
                                                {{WRAPPER}} .pxl-layout-post .hover-parent:hover .pxl-post-category > a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                    ],
                                ],
                            ],
                        ),
                    ),
                ),
                array(
                    'name' => 'tab_author_style',
                    'label' => esc_html__('Author', 'mouno' ),
                    'tab' => 'style',
                    'condition' => [
                        'show_author!' => '',
                        'layout_post!' => ['layout-2'],
                    ],
                    'controls' => array(
                        array(
                            'name' => 'author_typography',
                            'type' => \Elementor\Group_Control_Typography::get_type(),
                            'control_type' => 'group',
                            'selector' => '{{WRAPPER}} .pxl-layout-post .pxl-post-author',
                        ),
                        array(
                            'name' => 'author_controls',
                            'control_type' => 'tab',
                            'tabs' => [
                                [
                                    'name' => 'author_normal',
                                    'label' => esc_html__('Normal', 'mouno' ),
                                    'type' => 'tab',
                                    'controls' => [  
                                        array(
                                            'name' => 'author_color',
                                            'label' => esc_html__('Text Color', 'mouno' ),
                                            'type' => 'color',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-layout-post .pxl-post-author' => 'color: {{VALUE}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'author_text_shadow',
                                            'type' => \Elementor\Group_Control_Text_Shadow::get_type(),
                                            'control_type' => 'group',
                                            'selector' => '{{WRAPPER}} .pxl-layout-post .pxl-post-author',
                                        ),
                                    ],
                                ],
                                [
                                    'name' => 'author_hover',
                                    'label' => esc_html__('Hover', 'mouno' ),
                                    'type' => 'tab',
                                    'controls' => [  
                                        array(
                                            'name' => 'author_hover_color',
                                            'label' => esc_html__('Text Color', 'mouno' ),
                                            'type' => 'color',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-layout-post .hover-parent:hover .pxl-post-author' => 'color: {{VALUE}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'author_hover_text_shadow',
                                            'type' => \Elementor\Group_Control_Text_Shadow::get_type(),
                                            'control_type' => 'group',
                                            'selector' => '{{WRAPPER}} .pxl-layout-post .hover-parent:hover .pxl-post-author'     
                                       ),
                                    ],
                                ],
                            ],
                        ),
                    ),
                ),
                load_more_button_style_options(),
                grid_pagination_style_options(),
                swiper_bullets_pagination_style_options(),
                array(
                    'name' => 'tab_motion_effects',
                    'label' => esc_html__('Motion Effects', 'mouno' ),
                    'tab' => 'style',
                    'controls' => mouno_get_animation_options([
                        'selector' => '{{WRAPPER}} .pxl-swiper .swiper-slide, 
                        {{WRAPPER}} .pxl-layout-post .pxl-post-item',
                        '{{WRAPPER}} .pxl-grid .pxl-grid-item',
                    ]),
                ),
            ),
            
        ),
    ),
    mouno_get_class_widget_path()
);

