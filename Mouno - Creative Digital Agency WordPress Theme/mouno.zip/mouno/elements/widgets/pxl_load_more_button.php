<?php
$posts = ['post', 'portfolio', 'service'];
pxl_add_custom_widget(
    array(
        'name' => 'pxl_load_more_button',
        'title' => esc_html__('Case Load More Button', 'mouno' ),
        'icon' => 'eicon-posts-grid',
        'categories' => array('pxltheme-core'),
        'scripts' => array(),
        'params' => array(
            'sections' => array(
                array(
                    'name' => 'tab_load_more_btn_content',
                    'label' => esc_html__('Load More Button', 'mouno' ),
                    'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
                    'controls' => array(   
                        array(
                            'name'     => 'style',
                            'label'    => esc_html__( 'Style', 'mouno' ),
                            'type'     => 'select',
                            'options'  => [
                                'load-more-button-default' => esc_html__( 'Default', 'mouno' ),
                                'load-more-button-half-border' => esc_html__( 'Half Border ', 'mouno' ),
                            ],
                            'default'  => 'load-more-button-default'
                        ) ,
                        array(
                            'name' => '_icon',
                            'label' => esc_html__('Icon', 'mouno' ),
                            'type' => \Elementor\Controls_Manager::ICONS,
                            'fa4compatibility' => 'icon',
                            'default' => [
                                'value' => [
                                    'url' => content_url(''), 
                                    'id' => 0, 
                                ],
                                'library' => 'svg',
                            ],
                        ),
                        array(
                            'name' => 'show_divider',
                            'label' => esc_html__('Divider', 'mouno'),
                            'type' => 'switcher',
                            'default' => '',
                        ),
                    ),
                ),

                array(
                    'name' => 'tab_load_more_btn_style',
                    'label' => esc_html__('Load More Button', 'mouno' ),
                    'tab' => 'style',
                    'controls' => array( 
                        array(
                            'name' => 'justify_content_h',
                            'label' => esc_html__('Justify Content', 'mouno' ),
                            'type' => 'choose',
                            'options' => [
                                'start' => [
                                    'title' => esc_html__('Start', 'mouno' ),
                                    'icon' => 'eicon-justify-start-h',
                                ],
                                'center' => [
                                    'title' => esc_html__('Center', 'mouno' ),
                                    'icon' => 'eicon-justify-center-h',
                                ],
                                'end' => [
                                    'title' => esc_html__('End', 'mouno' ),
                                    'icon' => 'eicon-justify-end-h',
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-load-more-button-wrapper' => 'justify-content: {{VALUE}};',
                            ],
                        ),
                        array(
                            'name' => 'load_more_btn_control',
                            'control_type' => 'tab',
                            'tabs' => [
                                [
                                    'name' => 'load_more_btn_normal',
                                    'label' => esc_html__('Normal', 'mouno' ),
                                    'type' => 'tab',
                                    'controls' => [  
                                        array(
                                            'name' => 'btn_icon_color',
                                            'label' => esc_html__('Icon Color', 'mouno' ),
                                            'type' => 'color',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-load-more-button-wrapper .pxl-load-more-button .pxl-load-more-button-icon' => 'color: {{VALUE}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'icon_sz',
                                            'label' => esc_html__('Icon Size', 'mouno'),
                                            'type' => 'slider',
                                            'control_type' => 'responsive' ,
                                            'size_units' => ['px', '%', 'custom'],
                                            'range' => [
                                                'px' => [
                                                    'min' => 0, 
                                                    'max' => 1000
                                                ],
                                            ],
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-load-more-button-wrapper .pxl-load-more-button .pxl-load-more-button-icon svg' => 'height: {{SIZE}}{{UNIT}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'btn_bg_color',
                                            'type' => \Elementor\Group_Control_Background::get_type(),
                                            'control_type' => 'group',
                                            'types' => [ 'classic', 'gradient' ],
                                            'selector' => '{{WRAPPER}} .pxl-load-more-button-wrapper .pxl-load-more-button',
                                        ),
                                        array(
                                            'name' => 'btn_border',
                                            'type' => \Elementor\Group_Control_Border::get_type(),
                                            'control_type' => 'group', 
                                            'selector' => '{{WRAPPER}} .pxl-load-more-button-wrapper .pxl-load-more-button:not(.load-more-button-half-border), 
                                            {{WRAPPER}} .pxl-load-more-button-wrapper .pxl-load-more-button.load-more-button-half-border::after',
                                        ),
                                        array(
                                            'name' => 'btn_box_sz',
                                            'label' => esc_html__('Box Size', 'mouno'),
                                            'type' => 'slider',
                                            'control_type' => 'responsive' ,
                                            'size_units' => ['px', '%', 'custom'],
                                            'range' => [
                                                'px' => [
                                                    'min' => 0, 
                                                    'max' => 1000
                                                ],
                                            ],
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-load-more-button-wrapper .pxl-load-more-button' => '--pxl-box-size: {{SIZE}}{{UNIT}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'btn_border_radius',
                                            'label' => esc_html__('Border Radius', 'mouno' ),
                                            'type' => \Elementor\Controls_Manager::DIMENSIONS,
                                            'size_units' => [ 'px', '%' ],
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-load-more-button-wrapper .pxl-load-more-button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'child',
                                            'type' => 'heading',
                                            'label' => esc_html__('Child', 'mouno'),
                                        ),
                                        array(
                                            'name' => 'btn_child_bg_color',
                                            'type' => \Elementor\Group_Control_Background::get_type(),
                                            'control_type' => 'group',
                                            'types' => [ 'classic', 'gradient' ],
                                            'selector' => '{{WRAPPER}} .pxl-load-more-button-wrapper .pxl-load-more-button:before',
                                        ),
                                        array(
                                            'name' => 'btn_child_border',
                                            'type' => \Elementor\Group_Control_Border::get_type(),
                                            'control_type' => 'group', 
                                            'selector' => '{{WRAPPER}} .pxl-load-more-button-wrapper .pxl-load-more-button:before',
                                        ),
                                        array(
                                            'name' => 'btn_child_box_sz',
                                            'label' => esc_html__('Child Box Size', 'mouno'),
                                            'type' => 'slider',
                                            'control_type' => 'responsive' ,
                                            'size_units' => ['px', '%', 'custom'],
                                            'range' => [
                                                'px' => [
                                                    'min' => 0, 
                                                    'max' => 1000
                                                ],
                                            ],
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-load-more-button-wrapper .pxl-load-more-button:before' => '--pxl-box-size: {{SIZE}}{{UNIT}};',
                                            ],
                                        ),
                                    ],
                                ],
                                [
                                    'name' => 'load_more_btn_hover',
                                    'label' => esc_html__('Hover', 'mouno' ),
                                    'type' => \Elementor\Controls_Manager::TAB,
                                    'controls' => [
                                    ],
                                ],
                            ],
                        ),
                    ),
                ),
            ),
        ),
    ),
    mouno_get_class_widget_path()
);