<?php
pxl_add_custom_widget(
    array(
        'name' => 'pxl_post_info',
        'title' => esc_html__('Case Post Info', 'mouno' ),
        'icon' => 'eicon-post-info',
        'categories' => array('pxltheme-core'),
        'params' => array(
            'sections' => array(
                array(
                    'name' => 'tab_post_info_content',
                    'label' => esc_html__('Post Info', 'mouno' ),
                    'tab' => 'content',
                    'controls' => array(
                        array(
                            'name' => 'show_title',
                            'label' => esc_html__('Show Title', 'mouno'),
                            'type' => 'switcher',
                            'default' => 'true',
                        ),
                        array(
                            'name' => 'items',
                            'label' => esc_html__('Post Info', 'mouno'),
                            'type' => 'repeater',
                            'description' => esc_html__('Enter the key info you want to display. Keywords will not be capitalized. For example "category, author, date".', 'mouno'),
                            'controls' => array(
                                array(
                                    'name' => 'title',
                                    'label' => esc_html__('Title', 'mouno'),
                                    'type' => 'text',
                                ),
                                array(
                                    'name' => 'info',
                                    'label' => esc_html__('Info', 'mouno' ),
                                    'type' => 'text',
                                ),
                                array(
                                    'name' => '_icon',
                                    'label' => esc_html__('Icon', 'mouno'),
                                    'type' => \Elementor\Controls_Manager::ICONS,
                                    'fa4compatibility' => 'icon',
                                ),
                                array(
                                    'name' => 'link',
                                    'label' => esc_html__('Link URL', 'mouno' ),
                                    'type' => 'url',
                                    'condition' => [
                                        'info!' => ['category', 'date', 'author'],
                                    ],
                                ),
                            ),
                            'title_field' => '{{{title}}}',
                            'default' => [
                                [
                                    'title' => esc_html__('Category', 'mouno'),
                                    'info' => esc_html__('category', 'mouno'),
                                ],
                                [
                                    'title' => esc_html__('Date', 'mouno'),
                                    'info' => esc_html__('date', 'mouno'),
                                ],
                                [
                                    'title' => esc_html__('Author', 'mouno'),
                                    'info' => esc_html__('author', 'mouno'),
                                ],
                            ],
                        ),
                    ),
                ),

                array(
                    'name' => 'tab_post_info_style',
                    'label' => esc_html__('Post Info', 'mouno' ),
                    'tab' => 'style',
                    'controls' => array(
                        array(
                            'name' => 'flex_direction',
                            'label' => esc_html__('Direction', 'mouno'),
                            'type' => 'choose',
                            'control_type' => 'responsive',
                            'options' => [
                                'row' => [
                                    'title' => esc_html__('Row', 'mouno'),
                                    'icon' => 'eicon-arrow-right',
                                ],
                                'column' => [
                                    'title' => esc_html__('Column', 'mouno'),
                                    'icon' => 'eicon-arrow-down',
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-post-info-wrapper' => 'flex-direction: {{VALUE}};',
                            ]
                        ),
                        array(
                            'name' => 'justify_content_h',
                            'label' => esc_html__('Justify Content', 'mouno' ),
                            'type' => 'choose',
                            'control_type' => 'responsive',
                            'options' => [
                                'start' => [
                                    'title' => esc_html__('Start', 'mouno' ),
                                    'icon' => 'eicon-justify-start-h',
                                ],
                                'center' => [
                                    'title' => esc_html__('Center', 'mouno' ),
                                    'icon' => 'eicon-justify-center-h',
                                ],
                                'end' => [
                                    'title' => esc_html__('End', 'mouno' ),
                                    'icon' => 'eicon-justify-end-h',
                                ],
                                'space-around' => [
                                    'title' => esc_html__('Space Around', 'mouno' ),
                                    'icon' => 'eicon-justify-space-around-h',
                                ],
                                'space-evenly' => [
                                    'title' => esc_html__('Space Evenly', 'mouno' ),
                                    'icon' => 'eicon-justify-space-evenly-h',
                                ],
                                'space-between' => [
                                    'title' => esc_html__('Space Between', 'mouno' ),
                                    'icon' => 'eicon-justify-space-between-h',
                                ],
                            ],
                            'label_block' => true,
                            'selectors' => [
                                '{{WRAPPER}} .pxl-post-info-wrapper' => 'justify-content: {{VALUE}};',
                            ],
                            'condition' => [
                                'flex_direction!' => 'column',
                            ],
                        ),
                        array(
                            'name' => 'align_items_h',
                            'label' => esc_html__('Align Items', 'mouno'),
                            'type' => 'choose',
                            'control_type' => 'responsive',
                            'options' => array(
                                'start' =>[
                                    'title' => esc_html__('Start', 'mouno'),
                                    'icon' => 'eicon-align-start-h',
                                ],
                                'center' => [
                                    'title' => esc_html__('Center', 'mouno'),
                                    'icon' => 'eicon-align-center-h'
                                ],
                                'end' => [
                                    'title' => esc_html__('End', 'mouno'),
                                    'icon' => 'eicon-align-end-h',
                                ],
                                'stretch' => [
                                    'title' => esc_html__('Stretch', 'mouno'),
                                    'icon' => 'eicon-align-stretch-h',
                                ],
                            ),
                            'selectors' => [
                                '{{WRAPPER}} .pxl-post-info-wrapper' => 'align-items: {{VALUE}};'
                            ],
                            'condition' => [
                                'flex_direction' => 'column',
                            ],
                        ),
                        array(
                            'name' => 'col_gap',
                            'label' => esc_html__('Column Gap', 'mouno' ),
                            'type' => 'slider',
                            'size_units' => ['px', '%', 'custom'],
                            'control_type' => 'responsive',
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 1000,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-post-info-wrapper' => 'column-gap: {{SIZE}}{{UNIT}};',
                            ],
                        ),
                        array(
                            'name' => 'row_gap',
                            'label' => esc_html__('Row Gap', 'mouno' ),
                            'type' => 'slider',
                            'size_units' => ['px', '%', 'custom'],
                            'control_type' => 'responsive',
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 1000,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-post-info-wrapper' => 'row-gap: {{SIZE}}{{UNIT}};',
                            ],
                        ),
                        array(
                            'name' => 'title_spacing',
                            'label' => esc_html__('Title Spacing', 'mouno' ),
                            'type' => 'slider',
                            'size_units' => ['px', '%', 'custom'],
                            'control_type' => 'responsive',
                            'separator' => 'before',
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 1000,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-post-info-wrapper .pxl-info-title' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                            ],
                            'condition' => [
                                'show_title!' => '',
                            ],
                        ),
                    ),
                ),
                array(
                    'name' => 'tab_info_title_style',
                    'label' => esc_html__('Title', 'mouno' ),
                    'tab' => 'style',
                    'condition' => [
                        'show_title!' => '', 
                    ],
                    'controls' => array(
                        array(
                            'name' => 'title_color',
                            'label' => esc_html__('Text Color', 'mouno' ),
                            'type' => 'color',
                            'selectors' => [
                                '{{WRAPPER}} .pxl-post-info-wrapper .pxl-info-title' => 'color: {{VALUE}};',
                            ],
                        ),
                        array(
                            'name' => 'title_typography',
                            'type' => \Elementor\Group_Control_Typography::get_type(),
                            'control_type' => 'group',
                            'selector' => '{{WRAPPER}} .pxl-post-info-wrapper .pxl-info-title',
                        ),
                        array(
                            'name' => 'title_shadow',
                            'type' => \Elementor\Group_Control_Text_Shadow::get_type(),
                            'control_type' => 'group',
                            'selector' => '{{WRAPPER}} .pxl-post-info-wrapper .pxl-info-title',
                        ),
                    ),
                ),
                array(
                    'name' => 'tab_info_meta_style',
                    'label' => esc_html__('Meta', 'mouno' ),
                    'tab' => 'style',
                    'controls' => array(
                        array(
                            'name' => 'meta_typography',
                            'type' => \Elementor\Group_Control_Typography::get_type(),
                            'control_type' => 'group',
                            'selector' => '{{WRAPPER}} .pxl-post-info-wrapper .pxl-info-meta',
                        ),
                        array(
                            'name' => 'meta_shadow',
                            'type' => \Elementor\Group_Control_Text_Shadow::get_type(),
                            'control_type' => 'group',
                            'selector' => '{{WRAPPER}} .pxl-post-info-wrapper .pxl-info-meta',
                        ),
                        array(
                            'name' => 'tag_controls',
                            'control_type' => 'tab',
                            'tabs' => [
                                [
                                    'name' => 'tag_normal',
                                    'label' => esc_html__('Normal', 'mouno' ),
                                    'type' => 'tab',
                                    'controls' => [  
                                        array(
                                            'name' => 'meta_color',
                                            'label' => esc_html__('Text Color', 'mouno' ),
                                            'type' => 'color',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-post-info-wrapper .pxl-info-meta' => 'color: {{VALUE}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'meta_bg',
                                            'type' => \Elementor\Group_Control_Background::get_type(),
                                            'control_type' => 'group',
                                            'types' => [ 'classic', 'gradient' ],
                                            'selector' => '{{WRAPPER}} .pxl-post-info-wrapper .pxl-info-meta',
                                        ),
                                        array(
                                            'name' => 'meta_border',
                                            'type' => \Elementor\Group_Control_Border::get_type(),
                                            'separator' => 'before',
                                            'control_type' => 'group', 
                                            'selector' => '{{WRAPPER}} .pxl-post-info-wrapper .pxl-info-meta',
                                        ),
                                        array(
                                            'name'         => 'meta_box_shadow',
                                            'label' => esc_html__( 'Box Shadow', 'mouno' ),
                                            'type'         => \Elementor\Group_Control_Box_Shadow::get_type(),
                                            'control_type' => 'group',
                                            'selector'     => '{{WRAPPER}} .pxl-post-info-wrapper .pxl-info-meta',
                                        ),
                                        array(
                                            'name' => 'meta_border_radius',
                                            'label' => esc_html__('Border Radius', 'mouno' ),
                                            'type' => 'dimensions',
                                            'size_units' => [ 'px', '%', 'custom' ],
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-post-info-wrapper .pxl-info-meta' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'meta_padding',
                                            'label' => esc_html__('Padding', 'mouno' ),
                                            'type' => 'dimensions',
                                            'size_units' => [ 'px', '%', 'custom' ],
                                            'control_type' => 'responsive',
                                            'separator' => 'before',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-post-info-wrapper .pxl-info-meta' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                    ],
                                ],
                                [
                                    'name' => 'meta_hover',
                                    'label' => esc_html__('Hover', 'mouno' ),
                                    'type' => 'tabs',
                                    'controls' => [
                                        array(
                                            'name' => 'meta_hove_color',
                                            'label' => esc_html__('Color', 'mouno' ),
                                            'type' => 'color',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-post-info-wrapper .pxl-info-meta:hover' => 'color: {{VALUE}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'meta_hover_bg',
                                            'type' => \Elementor\Group_Control_Background::get_type(),
                                            'control_type' => 'group',
                                            'types' => [ 'classic', 'gradient' ],
                                            'selector' => '{{WRAPPER}} .pxl-post-info-wrapper .pxl-info-meta:hover',
                                        ),
                                        array(
                                            'name' => '_meta_hover_border_color',
                                            'label' => esc_html__('Border Color', 'mouno' ),
                                            'type' => 'color',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-post-info-wrapper .pxl-info-meta:hover' => 'border-color: {{VALUE}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'meta_hover_anim',
                                            'label' => esc_html__( 'Hover Animation', 'mouno' ),
                                            'type' => 'hover_animation',
                                        ),
                                        array(
                                            'name' => 'meta_hover_border',
                                            'type' => \Elementor\Group_Control_Border::get_type(),
                                            'separator' => 'before',
                                            'control_type' => 'group', 
                                            'selector' => '{{WRAPPER}} .pxl-post-info-wrapper .pxl-info-meta:hover',
                                        ),
                                        array(
                                            'name'         => 'meta_hover_box_shadow',
                                            'label' => esc_html__( 'Box Shadow', 'mouno' ),
                                            'type'         => \Elementor\Group_Control_Box_Shadow::get_type(),
                                            'control_type' => 'group',
                                            'selector'     => '{{WRAPPER}} .pxl-post-info-wrapper .pxl-info-meta:hover',
                                        ),
                                        array(
                                            'name' => 'meta_hover_border_radius',
                                            'label' => esc_html__('Border Radius', 'mouno' ),
                                            'type' => 'dimensions',
                                            'size_units' => [ 'px', '%', 'custom' ],
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-post-info-wrapper .pxl-info-meta:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'meta_hover_padding',
                                            'label' => esc_html__('Padding', 'mouno' ),
                                            'type' => 'dimensions',
                                            'size_units' => [ 'px', '%', 'custom' ],
                                            'control_type' => 'responsive',
                                            'separator' => 'before',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-post-info-wrapper .pxl-info-meta:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                    ],
                                ],
                            ],
                        ),
                    ),
                ),
            ),
        ),
    ),
    mouno_get_class_widget_path()
);