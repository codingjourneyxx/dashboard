<?php
//Register Counter Widget
 pxl_add_custom_widget(
    array(
        'name' => 'pxl_counter',
        'title' => esc_html__('Case Counter', 'mouno'),
        'icon' => 'eicon-counter',
        'categories' => array('pxltheme-core'),
        'scripts' => array(
            'scroll-trigger',
            'jquery-numerator',
            'pxl-counter',
            'pxl-counter-slide',
            'mouno-counter',
        ),
        'params' => array(
            'sections' => array(
                array(
                    'name' => 'tab_counter_content',
                    'label' => esc_html__('Counter', 'mouno'),
                    'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
                    'controls' => array(
                        array(
                            'name' => 'counter_style',
                            'label' => esc_html__('Style', 'mouno'),
                            'type' => \Elementor\Controls_Manager::SELECT,
                            'options' => [
                                'counter-default'  => esc_html__('Default', 'mouno'),
                                'counter-style1'  => esc_html__('Style 1', 'mouno'),
                                'counter-stroke1'  => esc_html__('Stroke 1', 'mouno'),

                                'counter-custom'  => esc_html__('Custom', 'mouno'),
                            ],
                            'default' => 'counter-default',
                        ),
                        array(
                            'name' => 'number_effect',
                            'label' => esc_html__('Number Effect', 'mouno' ),
                            'type' => \Elementor\Controls_Manager::SELECT,
                            'options' => [
                                'effect-default' => 'Default',
                                'effect-slide' => 'Slide',
                                'effect-draw' => 'Draw',
                            ],
                            'default' => 'effect-default',
                        ),
                        array(
                            'name' => 'starting_number',
                            'label' => esc_html__('Starting Number', 'mouno'),
                            'type' => 'number',
                            'default' => 1,
                        ),
                        array(
                            'name' => 'ending_number',
                            'label' => esc_html__('Ending Number', 'mouno'),
                            'type' => 'number',
                            'default' => 100,
                        ),
                        array(
                            'name' => 'number_prefix',
                            'label' => esc_html__('Number Prefix', 'mouno'),
                            'type' => 'text',
                        ),
                        array(
                            'name' => 'number_suffix',
                            'label' => esc_html__('Number Suffix', 'mouno'),
                            'type' => 'text',
                        ),
                        array(
                            'name' => 'number_anim_duration',
                            'label' => esc_html__('Animation Duration(ms)', 'mouno'),
                            'type' => 'number',
                            'default' => 2000,
                            'selectors' => [
                                '{{WRAPPER}} .pxl-counter-wrapper .pxl-counter-number .pxl-counter-value.effect-draw' => 'animation-duration: {{VALUE}}ms;',
                            ],
                        ),
                        array(
                            'name' => 'thousand_separator_char',
                            'label' => esc_html__('Thousand Separator', 'mouno'),
                            'type' => \Elementor\Controls_Manager::SELECT,
                            'options' => [
                                ''  => esc_html__('None', 'mouno'),
                                '.' => esc_html__('Dot', 'mouno'),
                                ',' => esc_html__('Comma', 'mouno'),
                                ' ' => esc_html__('Space', 'mouno'),
                            ],
                            'default' => '',
                        ),
                        array(
                            'name' => 'show_title',
                            'type' => 'switcher',
                            'label' => esc_html__('Show Title', 'mouno'),
                            'default' => 'true',
                        ),
                        array(
                            'name' => 'title',
                            'label' => esc_html__('Title', 'mouno'),
                            'type' => 'text',
                            'separator' => 'before',
                            'label_block' => true,
                            'default' => esc_html__('Enter heading here', 'mouno'),
                            'condition' => [
                                'show_title!' => ''
                            ],
                        ),
                        array(
                            'name' => 'title_tag',
                            'label' => esc_html__('Title HTML Tag', 'mouno'),
                            'type' => 'select',
                            'default' => 'h5',
                            'options' => [
                                'h1' => esc_html__('H1', 'mouno'),
                                'h2' => esc_html__('H2', 'mouno'),
                                'h3' => esc_html__('H3', 'mouno'),
                                'h4' => esc_html__('H4', 'mouno'),
                                'h5' => esc_html__('H5', 'mouno'),
                                'h6' => esc_html__('H6', 'mouno'),
                                'div' => esc_html__('div', 'mouno'),
                                'p'  => esc_html__('p', 'mouno'),
                                'span' => esc_html__('span', 'mouno'),
                            ],
                            'condition' => [
                                'show_title!' => ''
                            ],
                        ),
                    ),
                ),
                array(
                    'name' => 'tab_general_style',
                    'label' => esc_html__('Counter', 'mouno' ),
                    'tab' => 'style',
                    'controls' => array(
                        array(
                            'name' => 'flex_direction',
                            'label' => esc_html__('Direction', 'mouno'),
                            'type' => 'choose',
                            'control_type' => 'responsive',
                            'options' => [
                                'row' => [
                                    'title' => esc_html__('Row', 'mouno'),
                                    'icon' => 'eicon-arrow-right',
                                ],
                                'column' => [
                                    'title' => esc_html__('Column', 'mouno'),
                                    'icon' => 'eicon-arrow-down',
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-counter-wrapper' => 'flex-direction: {{VALUE}};',
                            ]
                        ),
                        array(
                            'name' => 'gap',
                            'label' => esc_html__('Gap', 'mouno'),
                            'type' => 'slider',
                            'control_type' => 'responsive',
                            'size_units' => ['px', 'custom'],
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 1000,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-counter-wrapper' => 'gap: {{SIZE}}{{UNIT}};',
                            ],
                        ),
                        array(
                            'name' => 'align_items_h',
                            'label' => esc_html__('Align Items', 'mouno'),
                            'type' => 'choose',
                            'control_type' => 'responsive',
                            'options' => array(
                                'start' =>[
                                    'title' => esc_html__('Start', 'mouno'),
                                    'icon' => 'eicon-align-start-h',
                                ],
                                'center' => [
                                    'title' => esc_html__('Center', 'mouno'),
                                    'icon' => 'eicon-align-center-h'
                                ],
                                'end' => [
                                    'title' => esc_html__('End', 'mouno'),
                                    'icon' => 'eicon-align-end-h',
                                ],
                            ),
                            'selectors' => [
                                '{{WRAPPER}} .pxl-counter-wrapper' => 'align-items: {{VALUE}};'
                            ],
                        ),
                        array(
                            'name' => 'align_items_v',
                            'label' => esc_html__('Align Items', 'mouno'),
                            'type' => 'choose',
                            'control_type' => 'responsive',
                            'options' => array(
                                'start' =>[
                                    'title' => esc_html__('Start', 'mouno'),
                                    'icon' => 'eicon-align-start-v',
                                ],
                                'center' => [
                                    'title' => esc_html__('Center', 'mouno'),
                                    'icon' => 'eicon-align-center-v'
                                ],
                                'end' => [
                                    'title' => esc_html__('End', 'mouno'),
                                    'icon' => 'eicon-align-end-v',
                                ],
                            ),
                            'condition' => [
                                'number_position' => ['row', 'row-reverse'],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-counter-wrapper' => 'align-items: {{VALUE}};'
                            ],
                        ),
                        array(
                            'name' => 'justify_content_h',
                            'label' => esc_html__('Justify Content', 'mouno' ),
                            'type' => 'choose',
                            'options' => [
                                'start' => [
                                    'title' => esc_html__('Start', 'mouno' ),
                                    'icon' => 'eicon-justify-start-h',
                                ],
                                'center' => [
                                    'title' => esc_html__('Center', 'mouno' ),
                                    'icon' => 'eicon-justify-center-h',
                                ],
                                'end' => [
                                    'title' => esc_html__('End', 'mouno' ),
                                    'icon' => 'eicon-justify-end-h',
                                ],
                                'space-around' => [
                                    'title' => esc_html__('Space Around', 'mouno' ),
                                    'icon' => 'eicon-justify-space-around-h',
                                ],
                                'space-evenly' => [
                                    'title' => esc_html__('Space Evenly', 'mouno' ),
                                    'icon' => 'eicon-justify-space-evenly-h',
                                ],
                                'space-between' => [
                                    'title' => esc_html__('Space Between', 'mouno' ),
                                    'icon' => 'eicon-justify-space-between-h',
                                ],
                            ],
                            'condition' => [
                                'number_position' => ['row', 'row-reverse'],
                            ],
                            'label_block' => true,
                            'selectors' => [
                                '{{WRAPPER}} .pxl-counter-wrapper' => 'justify-content: {{VALUE}};',
                            ],
                        ),
                        array(
                            'name' => 'num_align_items',
                            'label' => esc_html__('Number Vertical Align', 'mouno'),
                            'type' => 'choose',
                            'separator' => 'before',
                            'control_type' => 'responsive',
                            'options' => array(
                                'start' =>[
                                    'title' => esc_html__('Start', 'mouno'),
                                    'icon' => 'eicon-align-start-v',
                                ],
                                'center' => [
                                    'title' => esc_html__('Center', 'mouno'),
                                    'icon' => 'eicon-align-center-v'
                                ],
                                'end' => [
                                    'title' => esc_html__('End', 'mouno'),
                                    'icon' => 'eicon-align-end-v',
                                ],
                            ),
                            'selectors' => [
                                '{{WRAPPER}} .pxl-counter-wrapper .pxl-counter-number' => 'align-items: {{VALUE}};'
                            ],
                        ),
                        array(
                            'name' => 'number_affix_spacing',
                            'label' => esc_html__('Affix  Spacing', 'mouno'),
                            'type' => 'slider',
                            'control_type' => 'responsive',
                            'size_units' => ['px', '%', 'custom'],
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 1000,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-counter-wrapper .pxl-counter-number' => 'gap: {{SIZE}}{{UNIT}};',
                            ],
                        ),
                        array(
                            'name' => 'title_align',
                            'label' => esc_html__('Title Alignment', 'mouno' ),
                            'type' => 'choose',
                            'control_type' => 'responsive',
                            'options' => [
                                'left' =>  [
                                    'title' => esc_html__('Left', 'mouno'),
                                    'icon' => 'eicon-text-align-left',
                                ],
                                'center' =>  [
                                    'title' => esc_html__('Center', 'mouno'),
                                    'icon' => 'eicon-text-align-center',
                                ],
                                'right' =>  [
                                    'title' => esc_html__('Right', 'mouno'),
                                    'icon' => 'eicon-text-align-right',
                                ],
                                'justify' =>  [
                                    'title' => esc_html__('Justify', 'mouno'),
                                    'icon' => 'eicon-text-align-justify',
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-heading-wrapper .pxl-counter-title' => 'text-align: {{VALUE}};',
                            ],
                        ),
                        array(
                            'name' => 'max_w',
                            'label' => esc_html__('Max Width', 'mouno' ),
                            'type' => \Elementor\Controls_Manager::SLIDER,
                            'control_type' => 'responsive',
                            'size_units' => [ 'px', '%' ],
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 1000,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}}' => 'max-width: {{SIZE}}{{UNIT}} !important;',
                            ],
                        ),
                    ),
                ),
                array(
                    'name' => 'tab_box_style',
                    'label' => esc_html__('Box', 'mouno' ),
                    'tab' => 'style',
                    'controls' => array(
                        array(
                            'name' => 'box_height',
                            'label' => esc_html__('Height', 'mouno'),
                            'type' => 'slider',
                            'size_units' => ['px', 'custom'],
                            'control_type' => 'responsive',
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 1000,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-counter-wrapper' => "height: {{SIZE}}{{UNIT}};",
                            ],
                        ),
                        array(
                            'name' => 'box_width',
                            'label' => esc_html__('Width', 'mouno'),
                            'type' => 'slider',
                            'size_units' => ['px', 'custom'],
                            'control_type' => 'responsive',
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 1000,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-counter-wrapper' => "width: {{SIZE}}{{UNIT}};",
                            ],
                        ),
                        array(
                            'name' => 'box_bg',
                            'type' => \Elementor\Group_Control_Background::get_type(),
                            'control_type' => 'group',
                            'types' => [ 'classic', 'gradient' ],
                            'fields_options' => [
                                'background' => [
                                    'label' => __( 'Background', 'mouno' ),
                                ],
                            ],
                            'selector' => '{{WRAPPER}} .pxl-counter-wrapper',
                        ),
                        array(
                            'name' => 'box_backdrop_filter_blur',
                            'label' => esc_html__('Background Blur', 'mouno'),
                            'type' => 'slider',
                            'size_units' => ['px', 'custom'],
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 1000,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-counter-wrapper' => "backdrop-filter: blur({{SIZE}}{{UNIT}});",
                            ],
                        ),
                        array(
                            'name' => 'box_border',
                            'type' => \Elementor\Group_Control_Border::get_type(),
                            'separator' => 'before',
                            'control_type' => 'group', 
                            'selector' => '{{WRAPPER}} .pxl-counter-wrapper',
                        ),
                        array(
                            'name'         => 'box_box_shadow',
                            'label' => esc_html__( 'Box Shadow', 'mouno' ),
                            'type'         => \Elementor\Group_Control_Box_Shadow::get_type(),
                            'control_type' => 'group',
                            'selector'     => '{{WRAPPER}} .pxl-counter-wrapper',
                        ),
                        array(
                            'name' => 'box_border_radius',
                            'label' => esc_html__('Border Radius', 'mouno' ),
                            'type' => 'dimensions',
                            'size_units' => [ 'px', '%', 'custom' ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-counter-wrapper' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            ],
                        ),
                        array(
                            'name' => 'box_padding',
                            'label' => esc_html__('Padding', 'mouno' ),
                            'type' => 'dimensions',
                            'size_units' => [ 'px', '%', 'custom' ],
                            'control_type' => 'responsive',
                            'separator' => 'before',
                            'selectors' => [
                                '{{WRAPPER}} .pxl-counter-wrapper' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            ],
                        ),
                    ),
                ),
                array(
                    'name' => 'tab_number_style',
                    'label' => esc_html__('Number', 'mouno' ),
                    'tab' => 'style',
                    'controls' => array(
                        array(
                            'name' => 'number_color',
                            'label' => esc_html__('Color', 'mouno' ),
                            'type' => \Elementor\Controls_Manager::COLOR,
                            'selectors' => [
                                '{{WRAPPER}} .pxl-counter-wrapper .pxl-counter-number' => '--pxl-color: {{VALUE}};',
                            ],
                        ),
                        array(
                            'name' => 'number_typography',
                            'type' => \Elementor\Group_Control_Typography::get_type(),
                            'control_type' => 'group',
                            'selector' => '{{WRAPPER}} .pxl-counter-wrapper .pxl-counter-number, {{WRAPPER}} .pxl-counter-wrapper .pxl-counter-number svg text',
                        ),
                        array(
                            'name' => 'number_stroke',
                            'type' => \Elementor\Group_Control_Text_Stroke::get_type(),
                            'control_type' => 'group',
                            'selector' => '{{WRAPPER}} .pxl-counter-wrapper .pxl-counter-number, {{WRAPPER}} .pxl-counter-wrapper .pxl-counter-number svg text',
                        ),
                        array(
                            'name' => 'number_padding',
                            'label' => esc_html__('Padding', 'mouno' ),
                            'type' => \Elementor\Controls_Manager::DIMENSIONS,
                            'size_units' => [ 'px', '%' ],
                            'separator' => 'before',
                            'control_type' => 'responsive',
                            'selectors' => [
                                '{{WRAPPER}} .pxl-counter-wrapper .pxl-counter-number' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            ],
                        ),
                        array(
                            'name' => 'number_fix_controls',
                            'control_type' => 'tab',
                            'tabs' => [
                                [
                                    'name' => 'num_prefix_normal',
                                    'label' => esc_html__('Prefix', 'mouno' ),
                                    'type' => 'tab',
                                    'controls' => [
                                        array(
                                            'name' => 'num_prefix_color',
                                            'label' => esc_html__('Color', 'mouno' ),
                                            'type' => \Elementor\Controls_Manager::COLOR,
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-counter-wrapper .pxl-counter-number .pxl-number-prefix' => 'color: {{VALUE}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'num_prefix_typography',
                                            'type' => \Elementor\Group_Control_Typography::get_type(),
                                            'control_type' => 'group',
                                            'selector' => '{{WRAPPER}} .pxl-counter-wrapper .pxl-counter-number .pxl-number-prefix, {{WRAPPER}} .pxl-counter-wrapper .pxl-counter-number svg text .pxl-number-prefix',
                                        ),
                
                                    ],
                                ],
                                [
                                    'name' => 'num_suffix_normal',
                                    'label' => esc_html__('Suffix', 'mouno' ),
                                    'type' => 'tab',
                                    'controls' => array_merge(
                                        array(
                                            array(
                                                'name' => 'num_suffix_color',
                                                'label' => esc_html__('Color', 'mouno' ),
                                                'type' => \Elementor\Controls_Manager::COLOR,
                                                'selectors' => [
                                                    '{{WRAPPER}} .pxl-counter-wrapper .pxl-counter-number .pxl-number-suffix' => 'color: {{VALUE}};',
                                                ],
                                            ),
                                            array(
                                                'name' => 'num_suffix_typography',
                                                'type' => \Elementor\Group_Control_Typography::get_type(),
                                                'control_type' => 'group',
                                                'selector' => '{{WRAPPER}} .pxl-counter-wrapper .pxl-counter-number .pxl-number-suffix, {{WRAPPER}} .pxl-counter-wrapper .pxl-counter-number svg text .pxl-number-suffix',
                                            ),
                                            array(
                                                'name' => 'num_suffix_position_h',
                                                'label' => esc_html__('Position', 'mouno'),
                                                'type' => 'heading',
                                            ),
                                            array(
                                                'name' => 'num_suffix_position',
                                                'label' => esc_html__('Position', 'mouno'),
                                                'type' => 'select',
                                                'options' => [
                                                    '' => esc_html__('Default', 'mouno'),
                                                    'relative' => esc_html__('Relative', 'mouno'),
                                                    'absolute' => esc_html__('Absolute', 'mouno'),
                                                    'static' => esc_html__('Static', 'mouno'),
                                                ],
                                                'selectors' => [
                                                    '{{WRAPPER}} .pxl-counter-wrapper .pxl-counter-number .pxl-number-suffix,
                                                    {{WRAPPER}} .pxl-counter-wrapper .pxl-counter-number svg text .pxl-number-suffix' => 'position: {{VALUE}};',
                                                ],
                                            )
                                        ),
                                        mouno_position_options([
                                            'prefix' => 'num_suffix',
                                            'selector' => '{{WRAPPER}} .pxl-counter-wrapper .pxl-counter-number .pxl-number-suffix, 
                                            {{WRAPPER}} .pxl-counter-wrapper .pxl-counter-number svg text .pxl-number-suffix',
                                            'condition' => [
                                                'num_suffix_position' => 'absolute'
                                            ]
                                        ]),
                                    ), 
                                ],
                            ],
                        ),
                    ),
                ),
                array(
                    'name' => 'tab_title_style',
                    'label' => esc_html__('Title', 'mouno' ),
                    'tab' => 'style',
                    'condition' => [
                        'show_title!' => ''
                    ],
                    'controls' => array(
                        array(
                            'name' => 'title_color',
                            'label' => esc_html__('Text Color', 'mouno' ),
                            'type' => \Elementor\Controls_Manager::COLOR,
                            'selectors' => [
                                '{{WRAPPER}} .pxl-counter-wrapper .pxl-counter-title' => 'color: {{VALUE}};',
                            ],
                        ),
                        array(
                            'name' => 'title_typography',
                            'type' => \Elementor\Group_Control_Typography::get_type(),
                            'control_type' => 'group',
                            'selector' => '{{WRAPPER}} .pxl-counter-wrapper .pxl-counter-title',
                        ),
                    ),
                ),
                array(
                    'name' => 'tab_motion_effects',
                    'label' => esc_html__('Motion Effects', 'mouno' ),
                    'tab' => 'style',
                    'controls' => mouno_get_animation_options([
                        'selector' => '{{WRAPPER}} .pxl-counter-wrapper',
                    ]),
                ),
            ),
        ),
    ),
    mouno_get_class_widget_path()
);