<?php
pxl_add_custom_widget(
    array(
        'name' => 'pxl_social',
        'title' => esc_html__('Case Social', 'mouno' ),
        'icon' => 'eicon-facebook',
        'categories' => array('pxltheme-core'),
        'scripts' => array(),
        'params' => array(
            'sections' => array(
                array(
                    'name' => 'tab_social_content',
                    'label' => esc_html__('Slider', 'mouno' ),
                    'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
                    'controls' => array( 
                        array(
                            'name' => 'social_label',
                            'label' => esc_html__('Label', 'mouno' ),
                            'type' => 'text',
                            'default' => esc_html__('Social Label', 'mouno'),
                        ),  
                        array(
                            'name' => 'social_url',
                            'label' => esc_html__('Social URL', 'mouno' ),
                            'type' => \Elementor\Controls_Manager::URL,
                            'default' => [
                                'url' => '#',
                            ],
                        ),
                        array(
                            'name' => 'social_icon',
                            'label' => esc_html__('Social Icon', 'mouno' ),
                            'type' => \Elementor\Controls_Manager::ICONS,
                            'fa4compatibility' => 'icon',
                            'default' => [
                                'value' => [
                                    'url' => content_url('/uploads/2024/11/facebook.svg'), 
                                    'id' => 786, 
                                ],
                                'library' => 'svg',
                            ],
                        ),
                    ),
                ),
                array(
                    'name'     => 'tab_icon_style',
                    'label'    => esc_html__('Icon', 'mouno' ),
                    'tab'      => 'style',
                    'controls' => array(
                        array(
                            'name' => 'icon_size',
                            'label' => esc_html__('Icon Size', 'mouno' ),
                            'type' => 'slider',
                            'control_type' => 'responsive',
                            'size_units' => [ 'px', '%'],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-social-wrapper .pxl-social-icon' => 'font-size: {{SIZE}}{{UNIT}};',
                                '{{WRAPPER}} .pxl-social-wrapper .pxl-social-icon svg' => 'width: auto; height: {{SIZE}}{{UNIT}};'
                            ],
                        ),
                        array(
                            'name' => 'icon_box_sz',
                            'label' => esc_html__('Box Size', 'mouno' ),
                            'type' => 'slider',
                            'control_type' => 'responsive',
                            'size_units' => [ 'px', 'custom'],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-social-wrapper .pxl-social-icon' => '--pxl-box-size: {{SIZE}}{{UNIT}};',
                            ],
                        ),
                        array(
                            'name' => 'icon_controls',
                            'control_type' => 'tab',
                            'tabs' => [
                                [
                                    'name' => 'icon_normal',
                                    'label' => esc_html__('Normal', 'mouno' ),
                                    'type' => 'tab',
                                    'controls' => [  
                                        array(
                                            'name' => 'icon_color',
                                            'label' => esc_html('Icon Color', 'mouno'),
                                            'type' => 'color',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-layout-service .pxl-post-icon' => 'color: {{VALUE}}',
                                            ],
                                        ),
                                        array(
                                            'name' => 'icon_bg',
                                            'type' => \Elementor\Group_Control_Background::get_type(),
                                            'control_type' => 'group',
                                            'types' => [ 'classic', 'gradient' ],
                                            'selector' => '{{WRAPPER}} .pxl-social-wrapper .pxl-social-icon',
                                            'fields_options' => [
                                                'background' => [
                                                    'label' => __( 'Background', 'mouno' ),
                                                ],
                                            ],
                                        ),
                                        array(
                                            'name' => 'icon_border',
                                            'type' => \Elementor\Group_Control_Border::get_type(),
                                            'separator' => 'before',
                                            'control_type' => 'group', 
                                            'selector' => '{{WRAPPER}} .pxl-social-wrapper .pxl-social-icon',
                                        ),
                                        array(
                                            'name'         => 'icon_box_shadow',
                                            'label' => esc_html__( 'Box Shadow', 'mouno' ),
                                            'type'         => \Elementor\Group_Control_Box_Shadow::get_type(),
                                            'control_type' => 'group',
                                            'selector'     => '{{WRAPPER}} .pxl-social-wrapper .pxl-social-icon',
                                        ),
                                        array(
                                            'name' => 'icon_border_radius',
                                            'label' => esc_html__('Border Radius', 'mouno' ),
                                            'type' => 'dimensions',
                                            'size_units' => [ 'px', '%' ],
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-social-wrapper .pxl-social-icon' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'icon_padding',
                                            'label' => esc_html__('Padding', 'mouno' ),
                                            'type' => 'dimensions',
                                            'size_units' => [ 'px', '%' ],
                                            'control_type' => 'responsive',
                                            'separator' => 'before',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-social-wrapper .pxl-social-icon' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                    ],
                                ],
                                [
                                    'name' => 'icon_hover',
                                    'label' => esc_html__('Hover/Active', 'mouno' ),
                                    'type' => 'tab',
                                    'controls' => [  
                                        array(
                                            'name' => 'icon_hover_color',
                                            'label' => esc_html('Icon Color', 'mouno'),
                                            'type' => 'color',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-social-wrapper .pxl-social-item:hover .pxl-social-icon' => 'color: {{VALUE}}',
                                            ],
                                        ),
                                        array(
                                            'name' => 'icon_hover_bg',
                                            'type' => \Elementor\Group_Control_Background::get_type(),
                                            'control_type' => 'group',
                                            'types' => [ 'classic', 'gradient' ],
                                            'selector' => '{{WRAPPER}} .pxl-social-wrapper .pxl-social-item:hover .pxl-social-icon',
                                            'fields_options' => [
                                                'background' => [
                                                    'label' => __( 'Background', 'mouno' ),
                                                ],
                                            ],
                                        ),
                                        array(
                                            'name' => 'icon_hover_border',
                                            'type' => \Elementor\Group_Control_Border::get_type(),
                                            'separator' => 'before',
                                            'control_type' => 'group', 
                                            'selector' => '{{WRAPPER}} .pxl-social-wrapper .pxl-social-item:hover .pxl-social-icon',
                                        ),
                                        array(
                                            'name'         => 'icon_hover_box_shadow',
                                            'label' => esc_html__( 'Box Shadow', 'mouno' ),
                                            'type'         => \Elementor\Group_Control_Box_Shadow::get_type(),
                                            'control_type' => 'group',
                                            'selector'     => '{{WRAPPER}} .pxl-social-wrapper .pxl-social-item:hover .pxl-social-icon',
                                        ),
                                        array(
                                            'name' => 'icon_hover_border_radius',
                                            'label' => esc_html__('Border Radius', 'mouno' ),
                                            'type' => 'dimensions',
                                            'size_units' => [ 'px', '%' ],
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-social-wrapper .pxl-social-item:hover .pxl-social-icon' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'icon_hover_padding',
                                            'label' => esc_html__('Padding', 'mouno' ),
                                            'type' => 'dimensions',
                                            'size_units' => [ 'px', '%' ],
                                            'control_type' => 'responsive',
                                            'separator' => 'before',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-social-wrapper .pxl-social-item:hover .pxl-social-icon' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                    ],
                                ],
                            ],
                        ),
                    ),
                ),
                array(
                    'name' => 'tab_label_style',
                    'label' => esc_html__('Label', 'mouno' ),
                    'tab' => 'style',
                    'controls' => array_merge(
                        array(
                            array(
                                'name' => 'label_controls',
                                'control_type' => 'tab',
                                'tabs' => [
                                    [
                                        'name' => 'label_normal',
                                        'label' => esc_html__('Normal', 'mouno' ),
                                        'type' => 'tab',
                                        'controls' => [  
                                            array(
                                                'name' => 'label_color',
                                                'label' => esc_html__('Text Color', 'mouno' ),
                                                'type' => 'color',
                                                 'selectors' => [
                                                    '{{WRAPPER}} .pxl-social-wrapper .pxl-social-label' => 'color: {{VALUE}};',
                                                ],
                                            ),
                                            array(
                                                'name' => 'label_typography',
                                                'type' => \Elementor\Group_Control_Typography::get_type(),
                                                'control_type' => 'group',
                                                'selector' => '{{WRAPPER}} .pxl-social-wrapper .pxl-social-label',
                                            ),
                                            array(
                                                'name'         => 'label_box_shadow',
                                                'type'         => \Elementor\Group_Control_Text_Shadow::get_type(),
                                                'control_type' => 'group',
                                                'selector'     => '{{WRAPPER}} .pxl-social-wrapper .pxl-social-label'
                                            ),
                                        ],
                                    ],
                                    [
                                        'name' => 'label_hover',
                                        'label' => esc_html__('Highlight', 'mouno' ),
                                        'type' => \Elementor\Controls_Manager::TAB,
                                        'controls' => [
                                            array(
                                                'name' => 'label_hightlight_color',
                                                'label' => esc_html__('Text Color', 'mouno' ),
                                                'type' => 'color',
                                                'selectors' => [
                                                    '{{WRAPPER}} .pxl-social-wrapper .pxl-social-item:hover .pxl-social-label' => 'color: {{VALUE}};-webkit-text-stroke-color:{{VALUE}};',
                                                ],
                                            ),
                                            array(
                                                'name' => 'label_hightlight_typography',
                                                'type' => \Elementor\Group_Control_Typography::get_type(),
                                                'control_type' => 'group',
                                                'selector' => '{{WRAPPER}} .pxl-social-wrapper .pxl-social-item:hover .pxl-social-label',
                                            ),
                                        ],
                                    ],
                                ],
                            ),
                        ),
                    ),
                ),
            ),
        ),
    ),
    mouno_get_class_widget_path()
);