<?php
pxl_add_custom_widget(
    array(
        'name' => 'pxl_icon',
        'title' => esc_html__('Case Icon', 'mouno'),
        'icon' => 'eicon-favorite',
        'categories' => array('pxltheme-core'),
        'scripts' => [
            'mouno-effects',
            'mouno-parallax'
        ],
        'params' => array(
            'sections' => array(
                array(
                    'name' => 'tab_icon_content',
                    'label' => esc_html__('Icon', 'mouno'),
                    'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
                    'controls' => array(
                        array(
                            'name' => '_icon',
                            'label' => esc_html__('Icon', 'mouno'),
                            'type' => 'icons',
                            'fa4compatibility' => 'icon',
                            'default' => [
                                'value' => 'fas fa-star',
                                'library' => 'Font Awesome 5 Free',
                            ],
                        ),
                        array(
                            'name' => 'link',
                            'label' => esc_html__('Link', 'mouno'),
                            'type' => 'url',
                            'label_block' => true,
                        ),
                        array(
                            'name' => 'justify_content',
                            'label' => esc_html__('Justify Content', 'mouno'),
                            'type' => 'choose',
                            'separator' => 'before',
                            'control_type' => 'responsive',
                            'options' => array(
                                'start' => [
                                    'title' => esc_html__('Start', 'mouno' ),
                                    'icon' => 'eicon-justify-start-h',
                                ],
                                'center' => [
                                    'title' => esc_html__('Center', 'mouno' ),
                                    'icon' => 'eicon-justify-center-h',
                                ],
                                'end' => [
                                    'title' => esc_html__('End', 'mouno' ),
                                    'icon' => 'eicon-justify-end-h',
                                ],
                            ),
                            'selectors' => [
                                '{{WRAPPER}} .pxl-icon-wrapper' => 'justify-content: {{VALUE}};'
                            ],
                        ),
                    ),
                ),
                array(
                    'name' => 'tab_style_icon',
                    'label' => esc_html__('Icon', 'mouno'),
                    'tab' => \Elementor\Controls_Manager::TAB_STYLE,
                    'controls' => array(
                        array(
                            'name' => 'icon_fz',
                            'label' => esc_html__('Size', 'mouno'),
                            'type' => 'slider',
                            'control_type' => 'responsive',
                            'size_units' => ['px', 'custom'],
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 1000,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-icon-wrapper .pxl-icon-item' => 'font-size: {{SIZE}}{{UNIT}};',
                                '{{WRAPPER}} .pxl-icon-wrapper .pxl-icon-item svg' => 'height: {{SIZE}}{{UNIT}}; width: auto;',
                            ],
                        ),
                        array(
                            'name' => 'icon_box_sz',
                            'label' => esc_html__('Box Size', 'mouno'),
                            'type' => 'slider',
                            'control_type' => 'responsive',
                            'size_units' => ['px', 'custom'],
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 1000,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-icon-wrapper .pxl-icon-item' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};min-width: {{SIZE}}{{UNIT}};',
                            ],
                        ),
                        array(
                            'name' => 'svg_min_w',
                            'label' => esc_html__('SVG Min Width', 'mouno'),
                            'type' => 'slider',
                            'control_type' => 'responsive',
                            'size_units' => ['px', 'custom'],
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 1000,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-icon-wrapper .pxl-icon-item svg' => 'min-width: {{SIZE}}{{UNIT}};height: auto;',
                            ],
                        ),
                        array(
                            'name' => 'icon_divider',
                            'type' => 'divider',
                        ),
                        array(
                            'name' => 'icon_controls',
                            'control_type' => 'tab',
                            'tabs' => [
                                [
                                    'name' => 'icon_normal',
                                    'label' => esc_html__('Normal', 'mouno' ),
                                    'type' => 'tab',
                                    'controls' => [  
                                        array(
                                            'name' => 'gradient_color',
                                            'label' => esc_html__('Gradient Color', 'mouno'),
                                            'type' => 'switcher',
                                            'default' => '',
                                        ),
                                        array(
                                            'name' => 'icon_color',
                                            'label' => esc_html__('Icon Color', 'mouno' ),
                                            'type' => 'color',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-icon-wrapper .pxl-icon-item' => 'color: {{VALUE}};',
                                            ],
                                            'condition' => [
                                                'gradient_color' => '',
                                            ],
                                        ),
                                        array(
                                            'name' => 'icon_color_from',
                                            'label' => esc_html__('Color From', 'mouno' ),
                                            'type' => 'color',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-icon-wrapper .pxl-icon-item' => '--gradient-color-from: {{VALUE}};',
                                            ],
                                            'condition' => [
                                                'gradient_color!' => '',
                                            ],
                                        ),
                                        array(
                                            'name' => 'icon_color_to',
                                            'label' => esc_html__('Color To', 'mouno' ),
                                            'type' => 'color',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-icon-wrapper .pxl-icon-item' => '--gradient-color-to: {{VALUE}};',
                                            ],
                                            'condition' => [
                                                'gradient_color!' => '',
                                            ],
                                        ),
                                        array(
                                            'name' => 'icon_bg',
                                            'label' => esc_html__('Background Color', 'mouno' ),
                                            'type' => \Elementor\Group_Control_Background::get_type(),
                                            'control_type' => 'group',
                                            'types' => [ 'classic', 'gradient' ],
                                            'exclude' => ['image'],
                                            'selector' => '{{WRAPPER}} .pxl-icon-wrapper .pxl-icon-item',
                                        ),
                                        array(
                                            'name' => 'icon_border',
                                            'type' => \Elementor\Group_Control_Border::get_type(),
                                            'separator' => 'before',
                                            'control_type' => 'group', 
                                            'selector' => '{{WRAPPER}} .pxl-icon-wrapper .pxl-icon-item',
                                        ),
                                        array(
                                            'name'         => 'icon_box_shadow',
                                            'label' => esc_html__( 'Box Shadow', 'mouno' ),
                                            'type'         => \Elementor\Group_Control_Box_Shadow::get_type(),
                                            'control_type' => 'group',
                                            'selector'     => '{{WRAPPER}} .pxl-icon-wrapper .pxl-icon-item',
                                        ),
                                        array(
                                            'name' => 'icon_border_radius',
                                            'label' => esc_html__('Border Radius', 'mouno' ),
                                            'type' => 'dimensions',
                                            'size_units' => [ 'px', '%' ],
                                            'control_type' => 'responsive',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-icon-wrapper .pxl-icon-item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'icon_padding',
                                            'label' => esc_html__('Padding', 'mouno' ),
                                            'type' => 'dimensions',
                                            'size_units' => [ 'px', '%' ],
                                            'control_type' => 'responsive',
                                            'separator' => 'before',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-icon-wrapper .pxl-icon-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                    ],
                                ],
                                [
                                    'name' => 'icon_hover',
                                    'label' => esc_html__('Hover', 'mouno' ),
                                    'type' => \Elementor\Controls_Manager::TAB,
                                    'controls' => [
                                        array(
                                            'name' => 'icon_color_hover',
                                            'label' => esc_html__('Icon Color', 'mouno' ),
                                            'type' => 'color',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-icon-wrapper .pxl-icon-item:hover' => 'color: {{VALUE}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'icon_hover_anim',
                                            'label' => esc_html__('Animation', 'mouno'),
                                            'type' => 'hover_animation',
                                        ),
                                        array(
                                            'name' => 'icon_hover_bg',
                                            'label' => esc_html__('Background Color', 'mouno' ),
                                            'type' => \Elementor\Group_Control_Background::get_type(),
                                            'control_type' => 'group',
                                            'types' => [ 'classic', 'gradient' ],
                                            'exclude' => ['image'],
                                            'selector' => '{{WRAPPER}} .pxl-icon-wrapper .pxl-icon-item:hover',
                                        ),
                                        array(
                                            'name' => 'icon_hover_border',
                                            'type' => \Elementor\Group_Control_Border::get_type(),
                                            'separator' => 'before',
                                            'control_type' => 'group', 
                                            'selector' => '{{WRAPPER}} .pxl-icon-wrapper .pxl-icon-item:hover',
                                        ),
                                        array(
                                            'name'         => 'icon_hover_box_shadow',
                                            'label' => esc_html__( 'Box Shadow', 'mouno' ),
                                            'type'         => \Elementor\Group_Control_Box_Shadow::get_type(),
                                            'control_type' => 'group',
                                            'selector'     => '{{WRAPPER}} .pxl-icon-wrapper .pxl-icon-item:hover',
                                        ),
                                        array(
                                            'name' => 'icon_hover_border_radius',
                                            'label' => esc_html__('Border Radius', 'mouno' ),
                                            'type' => 'dimensions',
                                            'size_units' => [ 'px', '%' ],
                                            'control_type' => 'responsive',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-icon-wrapper .pxl-icon-item:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'icon_hover_padding',
                                            'label' => esc_html__('Padding', 'mouno' ),
                                            'type' => 'dimensions',
                                            'size_units' => [ 'px', '%' ],
                                            'control_type' => 'responsive',
                                            'separator' => 'before',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-icon-wrapper .pxl-icon-item:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                    ],
                                ],
                            ],
                        ),


                        array(
                            'name' => 'icon_effect',
                            'label' => esc_html__('Effect', 'mouno'),
                            'type' => 'select',
                            'options' => [
                                '' => esc_html__('None', 'mouno'),
                                'effect-pulse-light' => esc_html__('Pulse Light', 'mouno'),
                                'radial-burst' => esc_html__('Radial Burst', 'mouno'),
                                'animation-spin' => esc_html__('Spin', 'mouno'),
                                'slide-zoom' => esc_html__('Slide Zoom', 'mouno'),
                            ],
                            'description' => esc_html__('Some effects have the same name as file-name.svg. These effects will only be applied on that file-name.svg', 'mouno'),
                        ),
                    ),
                ),
                array(
                    'name' => 'tab_motion_effects',
                    'label' => esc_html__('Motion Effects', 'mouno'),
                    'tab' => 'style',
                    'controls' => array_merge(
                        array(
                            array(
                                'name'=> 'scrolling_effect',
                                'label'=> esc_html__('Scrolling Effect', 'mouno'),
                                'type'=> 'select',
                                'options'=> [
                                    '' => esc_html__('None', 'mouno'),
                                    'parallax' => esc_html__('Parallax', 'mouno'),
                                ],
                                'default'=> '',
                            ),
                        ),
                        mouno_parallax_options([
                            'condition' => [
                                'scrolling_effect' => 'parallax',
                            ],
                        ]),
                        array(
                            array(
                                'name' => '__divider',
                                'type' => 'divider',
                            ),
                            array(
                                'name'=> 'anim_effect',
                                'label'=> esc_html__('Animation Effects', 'mouno'),
                                'type'=> 'select',
                                'options'=> [
                                    '' => esc_html__('None', 'mouno'),
                                    'zoom-in-out-animated' => esc_html__('Zoom In Out', 'mouno'),
                                    'slide-ttb-animated' => esc_html__('Slide Top To Bottom', 'mouno'),
                                    'slide-btt-animated' => esc_html__('Slide Bottom To Top', 'mouno'),
                                    'slide-ltr-animated' => esc_html__('Slide Left To Right', 'mouno'),
                                    'slide-rtl-animated' => esc_html__('Slide Right To Left', 'mouno'),
                                    'ring-animated'      => esc_html__('Ring', 'mouno'),
                                    'spin-animated'      => esc_html__('Spin', 'mouno'),
                                    'floating1'          => esc_html__('Floating 1', 'mouno'),
                                    'floating2'          => esc_html__('Floating 2', 'mouno'),
                                ],
                                'default'=> '',
                            ),
                            [
                                'name' => 'anim_effect_duration',
                                'label' => esc_html__('Animation Duration(ms)', 'mouno'),
                                'type' => 'number',
                                'condition' => array(
                                    'anim_effect!' => '',
                                ),
                                'selectors' => [
                                    '{{WRAPPER}} .pxl-icon-wrapper .pxl-icon-item' => 'animation-duration: {{SIZE}}ms; -webkit-animation-duration: {{SIZE}}ms;',
                                ],
                            ],
                            array(
                                'name' => '___divider',
                                'type' => 'divider',
                            ),
                        ),
                        mouno_get_animation_options([
                            'selector' => '{{WRAPPER}} .pxl-icon-wrapper',
                        ]),
                    ),
                ),
            ),
        ),
    ),
    mouno_get_class_widget_path()
);
