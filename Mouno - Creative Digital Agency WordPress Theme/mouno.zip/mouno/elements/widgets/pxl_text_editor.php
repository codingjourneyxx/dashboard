<?php
pxl_add_custom_widget(
    array(
        'name' => 'pxl_text_editor',
        'title' => esc_html__('Case Text Editor', 'mouno'),
        'icon' => 'eicon-text',
        'categories' => array('pxltheme-core'),
        'scripts'    => array(
            'split-text',
            'mouno-effects'
        ),
        'params' => array(
            'sections' => array(
                array(
                    'name' => 'tab_text_editor_content',
                    'label' => esc_html__('Text Editor', 'mouno' ),
                    'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
                    'controls' => array(
                        array(
                            'name' => 'text_style',
                            'label' => esc_html__( 'Text Style', 'mouno' ),
                            'type' => 'select',
                            'options' => [
                                ''                 => esc_html__('Default', 'mouno'),
                                'text-primary'     => esc_html__('Primary', 'mouno'),
                                'text-secondary'   => esc_html__('Secondary', 'mouno'),
                                'text-third'       => esc_html__('Third', 'mouno'),
                                'text-fourth'      => esc_html__('Fourth', 'mouno'),
                                'text-fifth'        => esc_html__('Fifth', 'mouno'),
                                'text-vertical'    => esc_html__('Vertical', 'mouno'),
                                'text-custom'      => esc_html__('Custom', 'mouno'),
                            ],
                            'default' => '',
                        ),
                        array(
                            'name' => 'text',
                            'type' => \Elementor\Controls_Manager::WYSIWYG,
                            'default' => esc_html__( 'Click edit button to change this text. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.', 'mouno' ),
                            'description' => 'Highlight text width shortcode: [highlight text="..."]',
                        ),
                    ),
                ),
                array(
                    'name' => 'tab_style_text_editor',
                    'label' => esc_html__( 'Text Editor', 'mouno' ),
                    'tab' => \Elementor\Controls_Manager::TAB_STYLE,
                    'controls' => array(
                        array(
                            'name' => 'text_align',
                            'label' => esc_html__( 'Alignment', 'mouno' ),
                            'type' => \Elementor\Controls_Manager::CHOOSE,
                            'control_type' => 'responsive',
                            'options' => [
                                'left' => [
                                    'title' => esc_html__( 'Left', 'mouno' ),
                                    'icon' => 'eicon-text-align-left',
                                ],
                                'center' => [
                                    'title' => esc_html__( 'Center', 'mouno' ),
                                    'icon' => 'eicon-text-align-center',
                                ],
                                'right' => [
                                    'title' => esc_html__( 'Right', 'mouno' ),
                                    'icon' => 'eicon-text-align-right',
                                ],
                                'justify' => [
                                    'title' => esc_html__( 'Justified', 'mouno' ),
                                    'icon' => 'eicon-text-align-justify',
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-text-editor-wrapper' => 'text-align: {{VALUE}};',
                            ],
                        ),
                        array(
                            'name' => 'white_space',
                            'label' => esc_html__( 'White Space', 'mouno' ),
                            'type' => \Elementor\Controls_Manager::CHOOSE,
                            'control_type' => 'responsive',
                            'options' => [
                                'wrap' => [
                                    'title' => esc_html__( 'Wrap', 'mouno' ),
                                    'icon' => 'eicon-wrap',
                                ],
                                'nowrap' => [
                                    'title' => esc_html__( 'Nowrap', 'mouno' ),
                                    'icon' => 'eicon-nowrap',
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-text-editor-wrapper' => 'white-space: {{VALUE}};',
                            ],
                        ),
                        array(
                            'name' => 'max_w',
                            'label' => esc_html__('Max Width', 'mouno' ),
                            'type' => \Elementor\Controls_Manager::SLIDER,
                            'control_type' => 'responsive',
                            'size_units' => [ 'px', '%' ],
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 1000,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}}' => 'max-width: {{SIZE}}{{UNIT}} !important;',
                            ],
                        ),
                        array(
                            'name' => 'text_controls',
                            'control_type' => 'tab',
                            'tabs' => [
                                [
                                    'name' => 'text_normal',
                                    'label' => esc_html__('Normal', 'mouno' ),
                                    'type' => 'tab',
                                    'controls' => [  
                                        array(
                                            'name' => 'text_color',
                                            'label' => esc_html__( 'Color', 'mouno' ),
                                            'type' => \Elementor\Controls_Manager::COLOR,
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-text-editor-wrapper' => 'color: {{VALUE}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'text_typography',
                                            'type' => \Elementor\Group_Control_Typography::get_type(),
                                            'control_type' => 'group',
                                            'separator' => 'before',
                                            'selector' => '{{WRAPPER}} .pxl-text-editor-wrapper',
                                        ),
                                        array(
                                            'name' => 'text_stroke',
                                            'type' => \Elementor\Group_Control_Text_Stroke::get_type(),
                                            'control_type' => 'group',
                                            'selector' => '{{WRAPPER}} .pxl-text-editor-wrapper',
                                        ),
                                        array(
                                            'name' => 'text_shadow',
                                            'type' => \Elementor\Group_Control_Text_Shadow::get_type(),
                                            'control_type' => 'group',
                                            'selector' => '{{WRAPPER}} .pxl-text-editor-wrapper',
                                        ),
                                    ],
                                ],
                                [
                                    'name' => 'text_highlight',
                                    'label' => esc_html__('Highlight', 'mouno' ),
                                    'type' => \Elementor\Controls_Manager::TAB,
                                    'controls' => [
                                        array(
                                            'name' => 'text_highlight_color',
                                            'label' => esc_html__( 'Color', 'mouno' ),
                                            'type' => \Elementor\Controls_Manager::COLOR,
                                            'default' => '',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-text-editor-wrapper .pxl-text-highlight' => 'color: {{VALUE}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'text_highlight_typography',
                                            'type' => \Elementor\Group_Control_Typography::get_type(),
                                            'control_type' => 'group',
                                            'selector' => '{{WRAPPER}} .pxl-text-editor-wrapper .pxl-text-highlight',
                                        ),
                                        array(
                                            'name' => 'text_highlight_stroke',
                                            'type' => \Elementor\Group_Control_Text_Stroke::get_type(),
                                            'control_type' => 'group',
                                            'selector' => '{{WRAPPER}} .pxl-text-editor-wrapper .pxl-text-highlight',
                                        ),
                                        array(
                                            'name' => 'text_highlight_shadow',
                                            'type' => \Elementor\Group_Control_Text_Shadow::get_type(),
                                            'control_type' => 'group',
                                            'selector' => '{{WRAPPER}} .pxl-text-editor-wrapper .pxl-text-highlight',
                                        ),
                                    ],
                                ],
                            ],
                        ),
                    ),
                ),

                array(
                    'name' => 'tab_link_style',
                    'label' => esc_html__( 'Link', 'mouno' ),
                    'tab' => \Elementor\Controls_Manager::TAB_STYLE,
                    'controls' => array(
                        array(
                            'name' => 'link_style',
                            'label' => esc_html__( 'Link Style', 'mouno' ),
                            'type' => 'select',
                            'options' => [
                                'link-default' => 'Default',
                                'link-underline' => 'Underline'
                            ],
                            'default' => 'link-default',
                        ),
                        array(
                            'name' => 'underline_h',
                            'label' => esc_html__('Underline Height', 'mouno' ),
                            'type' => \Elementor\Controls_Manager::SLIDER,
                            'control_type' => 'responsive',
                            'size_units' => [ 'px', '%' ],
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 3000,
                                ],
                            ],
                            'condition' => [
                                'title_style' => 'heading-title-underline',
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-text-editor-wrapper a' => '--pxl-height: {{SIZE}}{{UNIT}};',
                            ],
                        ),
                        array(
                            'name' => 'link_controls',
                            'control_type' => 'tab',
                            'tabs' => [
                                [
                                    'name' => 'link_normal',
                                    'label' => esc_html__('Normal', 'mouno' ),
                                    'type' => 'tab',
                                    'controls' => [  
                                        array(
                                            'name' => 'link_typography',
                                            'type' => \Elementor\Group_Control_Typography::get_type(),
                                            'selector' => '{{WRAPPER}} .pxl-text-editor-wrapper a',
                                            'control_type' => 'group',
                                        ),
                                        array(
                                            'name' => 'link_color',
                                            'label' => esc_html__( 'Color', 'mouno' ),
                                            'type' => \Elementor\Controls_Manager::COLOR,
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-text-editor-wrapper a' => 'color: {{VALUE}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'link_highlight_stroke',
                                            'type' => \Elementor\Group_Control_Text_Stroke::get_type(),
                                            'control_type' => 'group',
                                            'selector' => '{{WRAPPER}} .pxl-text-editor-wrapper .pxl-text-highlight',
                                        ),
                                        array(
                                            'name' => 'link_highlight_shadow',
                                            'type' => \Elementor\Group_Control_Text_Shadow::get_type(),
                                            'control_type' => 'group',
                                            'selector' => '{{WRAPPER}} .pxl-text-editor-wrapper .pxl-text-highlight',
                                        ),
                                    ],
                                ],
                                [
                                    'name' => 'link_hover',
                                    'label' => esc_html__('Hover', 'mouno' ),
                                    'type' => \Elementor\Controls_Manager::TAB,
                                    'controls' => [
                                        array(
                                            'name' => 'link_hover_style',
                                            'label' => esc_html__( 'Style', 'mouno' ),
                                            'type' => 'select',
                                            'options' => [
                                                'link-hover-default' => 'Default',
                                                'link-hover-underline-slide' => 'Underline Slide'
                                            ],
                                            'default' => 'link-hover-default',
                                            'condition' => [
                                                'link_style!' => 'link-underline',
                                            ],
                                        ),
                                        array(
                                            'name' => 'link_color_hover',
                                            'label' => esc_html__( 'Color Hover', 'mouno' ),
                                            'type' => \Elementor\Controls_Manager::COLOR,
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-text-editor-wrapper a:hover' => 'color: {{VALUE}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'link_hover_typography',
                                            'type' => \Elementor\Group_Control_Typography::get_type(),
                                            'selector' => '{{WRAPPER}} .pxl-text-editor-wrapper a:hover',
                                            'control_type' => 'group',
                                        ),
                                        array(
                                            'name' => 'link_highlight_stroke_hover',
                                            'type' => \Elementor\Group_Control_Text_Stroke::get_type(),
                                            'control_type' => 'group',
                                            'selector' => '{{WRAPPER}} .pxl-text-editor-wrapper a:hover',
                                        ),
                                        array(
                                            'name' => 'link_highlight_shadow_hover',
                                            'type' => \Elementor\Group_Control_Text_Shadow::get_type(),
                                            'control_type' => 'group',
                                            'selector' => '{{WRAPPER}} .pxl-text-editor-wrapper a:hover',
                                        ),
                                    ],
                                ],
                            ],
                        ),
                    ),
                ),
                array(
                    'name' => 'tab_text_editor_animation',
                    'tab' => 'style',
                    'label' => esc_html__('Animation', 'mouno'),
                    'controls' => array_merge(
                        mouno_get_additional_animation_options(),
                        mouno_get_animation_options([
                            'selector' => '{{WRAPPER}} .pxl-text-editor-wrapper',
                            'condition' => [
                                'additional_entrance_anim' => '',
                            ],
                        ]),
                    ),
                ),
            ),
        ),
    ),
    mouno_get_class_widget_path()
);