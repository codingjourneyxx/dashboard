<?php
pxl_add_custom_widget(
    array(
        'name' => 'pxl_image_marquee',
        'title' => esc_html__('Case Image Marquee', 'mouno' ),
        'icon' => 'eicon-image-bold',
        'categories' => array('pxltheme-core'),
        'scripts' => array(

        ),
        'params' => array(
            'sections' => array(
                array(
                    'name' => 'tab_content',
                    'label' => esc_html__('Images', 'mouno' ),
                    'tab' => 'content',
                    'controls' => array_merge(
                        array(
                            array(
                                'name' => 'images',
                                'label' => esc_html__( 'Add Images', 'mouno' ),
                                'type' => 'gallery',
                                'show_label' => false,
                                'default' => [],
                            ),
                        ),
                        image_dimension_options(),
                        array(
                            array(
                                'name' => 'duplicate',
                                'label' => esc_html__('Duplicate', 'mouno'),
                                'type' => 'switcher',
                                'default' => 'true',
                            ),
                            array(
                                'name' => 'direction',
                                'label' => esc_html__('Direction', 'mouno'),
                                'type' => 'select',
                                'options' => [
                                    'rtl' => esc_html__('Right to Left', 'mouno'),
                                    'ltr' => esc_html__('Left to Right', 'mouno'),
                                ],
                                'default' => 'rtl',
                            ),
                            array(
                                'name' => 'duration',
                                'label' => esc_html__('Duration', 'mouno'),
                                'type' => 'slider',
                                'size_units' => ['ms', 's'],
                                'default' => [
                                    'unit' => 's',
                                ],
                                'selectors' => [
                                    '{{WRAPPER}} .pxl-image-marquee-wrapper .pxl-image-marquee-item' => '--pxl-duration: {{SIZE}}{{UNIT}};',
                                ],
                            ),
                            array(
                                'name' => 'spacing',
                                'label' => esc_html__('Spacing', 'mouno'),
                                'type' => 'slider',
                                'size_units' => ['px', '%'],
                                'control_type' => 'responsive',
                                'range' => [
                                    'px' => [
                                        'min' => 0,
                                        'max' => 1000,
                                    ],
                                ],
                                'selectors' => [
                                    '{{WRAPPER}} .pxl-image-marquee-wrapper' => '--pxl-spacing: {{SIZE}}{{UNIT}};',
                                ],
                            ),
                            array(
                                'name' => 'gap',
                                'label' => esc_html__('Gap', 'mouno'),
                                'type' => 'slider',
                                'size_units' => ['px', '%'],
                                'control_type' => 'responsive',
                                'range' => [
                                    'px' => [
                                        'min' => 0,
                                        'max' => 1000,
                                    ],
                                ],
                                'selectors' => [
                                    '{{WRAPPER}} .pxl-image-marquee-wrapper .pxl-image-marquee-item' => 'gap: {{SIZE}}{{UNIT}};',
                                ],
                            ),
                        )
                    ),
                ),
                array(
                    'name' => 'tab_img_style',
                    'label' => esc_html__('Image', 'mouno' ),
                    'tab' => 'style',
                    'controls' => array(
                        array(
                            'name' => 'justify_content_h',
                            'label' => esc_html__('Justify Content', 'mouno' ),
                            'type' => 'choose',
                            'options' => [
                                'start' => [
                                    'title' => esc_html__('Start', 'mouno' ),
                                    'icon' => 'eicon-justify-start-h',
                                ],
                                'center' => [
                                    'title' => esc_html__('Center', 'mouno' ),
                                    'icon' => 'eicon-justify-center-h',
                                ],
                                'end' => [
                                    'title' => esc_html__('End', 'mouno' ),
                                    'icon' => 'eicon-justify-end-h',
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-image-wrapper' => 'justify-content: {{VALUE}};',
                            ],
                        ),
                        array(
                            'name' => 'img_w',
                            'label' => esc_html__('Width', 'mouno' ),
                            'type' => 'slider',
                            'control_type' => 'responsive',
                            'size_units' => [ 'px', '%', 'custom' ],
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 2000,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-image-marquee-wrapper .pxl-image-marquee-item img' => 'width: {{SIZE}}{{UNIT}};',
                            ],
                        ),
                        array(
                            'name' => 'img_max_w',
                            'label' => esc_html__('Max Width', 'mouno' ),
                            'type' => 'slider',
                            'control_type' => 'responsive',
                            'size_units' => [ 'px', '%', 'custom' ],
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 2000,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-image-marquee-wrapper .pxl-image-marquee-item img' => 'max-width: {{SIZE}}{{UNIT}};',
                            ],
                        ),
                        array(
                            'name' => 'img_h',
                            'label' => esc_html__('Height', 'mouno' ),
                            'type' => 'slider',
                            'control_type' => 'responsive',
                            'size_units' => [ 'px', '%', 'custom' ],
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 2000,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-image-marquee-wrapper .pxl-image-marquee-item img' => 'height: {{SIZE}}{{UNIT}};',
                            ],
                        ),
                        array(
                            'name' => 'img_opacity',
                            'label' => esc_html__('Opacity', 'mouno' ),
                            'type' => 'slider',
                            'control_type' => 'responsive',
                            'size_units' => ['px'],
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 1,
                                    'step' => 0.01,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-image-marquee-wrapper .pxl-image-marquee-item img' => 'opacity: {{SIZE}};',
                            ],
                        ),
                        array(
                            'name'     => 'img_css_filters',
                            'type'     => \Elementor\Group_Control_Css_Filter::get_type(),
                            'control_type' => 'group',
                            'selector' => '{{WRAPPER}} .pxl-image-marquee-wrapper .pxl-image-marquee-item img',
                        ),
                        array(
                            'name' => 'img_border',
                            'type' => \Elementor\Group_Control_Border::get_type(),
                            'control_type' => 'group', 
                            'separator' => 'before',
                            'selector' => '{{WRAPPER}} .pxl-image-marquee-wrapper .pxl-image-marquee-item img',
                        ),
                        array(
                            'name'         => 'img_box_shadow',
                            'type'         => \Elementor\Group_Control_Box_Shadow::get_type(),
                            'control_type' => 'group',
                            'selector'     => '{{WRAPPER}} .pxl-image-marquee-wrapper .pxl-image-marquee-item img',
                        ),
                        array(
                            'name' => 'img_border_radius',
                            'label' => esc_html__('Border Radius', 'mouno' ),
                            'type' => \Elementor\Controls_Manager::DIMENSIONS,
                            'size_units' => [ 'px', '%', 'custom' ],
                            'control_type' => 'responsive',
                            'selectors' => [
                                '{{WRAPPER}} .pxl-image-marquee-wrapper .pxl-image-marquee-item img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            ],
                        ),
                    ),
                ),
            ),
        ),
    ),
    mouno_get_class_widget_path()
);