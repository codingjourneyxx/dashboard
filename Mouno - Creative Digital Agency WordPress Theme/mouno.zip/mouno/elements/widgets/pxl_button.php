<?php
$templates_df = ['0' => esc_html__('None', 'mouno')];
$templates = $templates_df + mouno_get_templates_option('popup') ;
pxl_add_custom_widget(
    array(
        'name' => 'pxl_button',
        'title' => esc_html__('Case Button', 'mouno' ),
        'icon' => 'eicon-button',
        'categories' => array('pxltheme-core'),
        'scripts' => array(
            'mouno-effects',
            'mouno-parallax'
        ),
        'params' => array(
            'sections' => array(
                array(
                    'name' => 'tab_btn_content',
                    'label' => esc_html__('Button', 'mouno' ),
                    'tab' => \Elementor\Controls_Manager::TAB_LAYOUT,
                    'controls' => array(
                        array(
                            'name' => 'btn_type',
                            'label' => esc_html__('Button Type', 'mouno' ),
                            'type' => \Elementor\Controls_Manager::SELECT,
                            'default' => 'pxl-btn-normal',
                            'options' => [
                                'pxl-btn-normal' => esc_html__('Normal', 'mouno' ),
                                'pxl-btn-split' => esc_html__('Split', 'mouno'),
                                'pxl-btn-link' => esc_html__('Link', 'mouno'),
                            ],
                        ),
                        array(
                            'name' => 'btn_link_style',
                            'label' => esc_html__('Button Link Style', 'mouno' ),
                            'type' => \Elementor\Controls_Manager::SELECT,
                            'default' => 'pxl-btn-link1',
                            'options' => [
                                'pxl-btn-link1' => esc_html__('Style Defaul', 'mouno'),
                                'pxl-btn-link2' => esc_html__('Style 2', 'mouno'),
                            ],
                            'condition' => [
                                'btn_type' => 'pxl-btn-link',
                            ],
                        ),
                        array(
                            'name' => 'btn_action',
                            'label' => esc_html__('Action', 'mouno' ),
                            'type' => \Elementor\Controls_Manager::SELECT,
                            'default' => 'pxl-atc-link',
                            'options' => [
                                'pxl-atc-link' => esc_html__('Link', 'mouno' ),
                                'pxl-atc-popup' => esc_html__('Popup', 'mouno' ),
                                'pxl-atc-submit' => esc_html__('Submit', 'mouno' ),
                                'pxl-atc-anchor' => esc_html__('Anchor', 'mouno' ),
                            ],
                        ),
                        array(
                            'name' => 'anchor_target_offset',
                            'label' => esc_html__('Target Offset', 'mouno' ),
                            'type' => \Elementor\Controls_Manager::NUMBER,
                            'default' => 0,
                            'condition' => [
                                'btn_action' => 'pxl-atc-anchor',
                            ],
                        ),
                        array(
                            'name' => 'submit_to_id',
                            'label' => esc_html__('Submit To ID', 'mouno' ),
                            'type' => \Elementor\Controls_Manager::TEXT,
                            'description' => esc_html__('Enter the ID of the form you want to submit that was created from "Case Contact Form"', 'mouno'),
                            'condition' => [
                                'btn_action' => 'pxl-atc-submit',
                            ],
                        ),
                        array(
                            'name' => 'btn_link',
                            'label' => esc_html__('Link URL', 'mouno' ),
                            'type' => \Elementor\Controls_Manager::URL,
                            'default' => [
                                'url' => '#',
                            ],
                            'condition' => [
                                'btn_action' => ['pxl-atc-link', 'pxl-atc-anchor'], 
                            ],
                        ),
                        array(
                            'name' => 'popup_template',
                            'label' => esc_html__('Select Popup Template', 'mouno'),
                            'type' => 'select',
                            'options' => $templates,
                            'default' => 'df',
                            'description' => 'Add new tab template: "<a href="' . esc_url( admin_url( 'edit.php?post_type=pxl-template' ) ) . '" target="_blank">Click Here</a>"',
                            'condition' => [
                                'btn_action' => ['pxl-atc-popup'],
                            ],
                        ),
                        array(
                            'name' => 'btn_text',
                            'label' => esc_html__('Button Text', 'mouno' ),
                            'type' => \Elementor\Controls_Manager::TEXT,
                            'default' => esc_html__('Click Here', 'mouno'),
                        ),
                        array(
                            'name' => 'btn_icon',
                            'label' => esc_html__('Icon', 'mouno' ),
                            'type' => \Elementor\Controls_Manager::ICONS,
                            'fa4compatibility' => 'icon',
                        ),
                        array(
                            'name' => 'icon_position',
                            'label' => esc_html__('Icon Position', 'mouno' ),
                            'type' => 'choose',
                            'options' => [
                                'row-reverse' => [
                                    'title' => esc_html__('Left', 'mouno'),
                                    'icon'  => 'eicon-arrow-left'
                                ],
                                'row' => [
                                    'title' => esc_html__('Right', 'mouno'),
                                    'icon'  => 'eicon-arrow-right'
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-button-wrapper .btn' => 'flex-direction: {{VALUE}};',
                            ],
                            'condition' => [
                                'btn_icon[value]!' => '',
                            ],
                        ),
                        array(
                            'name' => 'icon_spacing',
                            'label' => esc_html__('Icon Spacing', 'mouno'),
                            'type' => 'slider',
                            'control_type' => 'responsive' ,
                            'size_units' => ['px', '%', 'custom'],
                            'range' => [
                                'px' => [
                                    'min' => 0, 
                                    'max' => 1000
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-button-wrapper .btn' => 'gap: {{SIZE}}{{UNIT}};',
                            ],
                            'condition' => [
                                'btn_icon[value]!' => '',
                            ],
                        ),
                    ),
                ),
            
                array(
                    'name' => 'tab_btn_style',
                    'label' => esc_html__('Button', 'mouno' ),
                    'tab' => 'style',
                    'controls' => array_merge(
                        array(
                            array(
                                'name' => 'text_align',
                                'label' => esc_html__('Alignment', 'mouno' ),
                                'type' => \Elementor\Controls_Manager::CHOOSE,
                                'control_type' => 'responsive',
                                'options' => [
                                    'start' => [
                                        'title' => esc_html__('Left', 'mouno' ),
                                        'icon' => 'fa fa-align-left',
                                    ],
                                    'center' => [
                                        'title' => esc_html__('Center', 'mouno' ),
                                        'icon' => 'fa fa-align-center',
                                    ],
                                    'end' => [
                                        'title' => esc_html__('Right', 'mouno' ),
                                        'icon' => 'fa fa-align-right',
                                    ],
                                ],
                                'selectors' => [
                                    '{{WRAPPER}} .pxl-button-wrapper' => 'justify-content: {{VALUE}};',
                                ],
                            ),
                            array(
                                'name' => 'btn_typography',
                                'type' => \Elementor\Group_Control_Typography::get_type(),
                                'control_type' => 'group',
                                'selector' => '{{WRAPPER}} .pxl-button-wrapper .btn',
                            ),
                            array(
                                'name' => 'btn_text_shadow',
                                'label' => esc_html__('Text Shadow', 'mouno' ),
                                'type' => \Elementor\Group_Control_Text_Shadow::get_type(),
                                'control_type' => 'group',
                                'selector' => '{{WRAPPER}} .pxl-button-wrapper .btn',
                            ),
                            array(
                                'name' => 'icon_color',
                                'label' => esc_html__('Icon Color', 'mouno' ),
                                'type' => 'color',
                                'selectors' => [
                                    '{{WRAPPER}} .pxl-button-wrapper .btn .pxl-btn-icon' => 'color: {{VALUE}};',
                                ],
                            ),
                            array(
                                'name' => 'icon_sz',
                                'label' => esc_html__('Icon Size', 'mouno' ),
                                'type' => 'slider',
                                'size_units' => ['px', '%', 'custom'],
                                'control_type' => 'responsive',
                                'range' => [
                                    'px' => [
                                        'min' => 0,
                                        'max' => 1000,
                                    ],
                                ],
                                'selectors' => [
                                    '{{WRAPPER}} .pxl-button-wrapper .btn i ' => 'font-size: {{SIZE}}{{UNIT}};',
                                    '{{WRAPPER}} .pxl-button-wrapper .btn svg' => 'height: {{SIZE}}{{UNIT}}; width: auto;',
                                ],
                            ),
                            array(
                                'name' => 'btn_w',
                                'label' => esc_html__('Width', 'mouno' ),
                                'type' => 'slider',
                                'size_units' => ['px', '%', 'custom'],
                                'control_type' => 'responsive',
                                'range' => [
                                    'px' => [
                                        'min' => 0,
                                        'max' => 1000,
                                    ],
                                ],
                                'selectors' => [
                                    '{{WRAPPER}} .pxl-button-wrapper .btn' => 'width: {{SIZE}}{{UNIT}};',
                                ],
                            ),
                            array(
                                'name' => 'btn_h',
                                'label' => esc_html__('Height', 'mouno' ),
                                'type' => 'slider',
                                'size_units' => ['px', '%', 'custom'],
                                'control_type' => 'responsive',
                                'range' => [
                                    'px' => [
                                        'min' => 0,
                                        'max' => 1000,
                                    ],
                                ],
                                'selectors' => [
                                    '{{WRAPPER}} .pxl-button-wrapper .btn' => 'height: {{SIZE}}{{UNIT}};--pxl-height: {{SIZE}}{{UNIT}};',
                                ],
                            ),
                            array(
                                'name' => 'btn_control',
                                'control_type' => 'tab',
                                'tabs' => [
                                    [
                                        'name' => 'btn_normal',
                                        'label' => esc_html__('Normal', 'mouno' ),
                                        'type' => 'tab',
                                        'controls' => [  
                                            array(
                                                'name' => 'is_color_gradient',
                                                'label' => esc_html__('Color Gradient', 'mouno'),
                                                'type' => 'switcher',
                                                'default' => '',
                                            ),
                                            array(
                                                'name' => 'btn_color_gradient',
                                                'type' => \Elementor\Group_Control_Background::get_type(),
                                                'control_type' => 'group',
                                                'types' => ['gradient' ],
                                                'selector' => '{{WRAPPER}} .pxl-button-wrapper .button',
                                                'condition' => [
                                                    'is_color_gradient!' => '',
                                                ],
                                            ),
                                            array(
                                                'name' => 'btn_color',
                                                'label' => esc_html__('Color', 'mouno' ),
                                                'type' => 'color',
                                                'selectors' => [
                                                    '{{WRAPPER}} .pxl-button-wrapper .btn' => 'color: {{VALUE}};',
                                                ],
                                                'condition' => [
                                                    'is_color_gradient' => '',
                                                ],
                                            ),
                                            array(
                                                'name' => 'btn_bg',
                                                'type' => \Elementor\Group_Control_Background::get_type(),
                                                'control_type' => 'group',
                                                'types' => [ 'classic', 'gradient' ],
                                                'selector' => '{{WRAPPER}} .pxl-button-wrapper .btn:not(.pxl-btn-split), 
                                                {{WRAPPER}} .pxl-button-wrapper .btn.pxl-btn-split .pxl-btn-icon, 
                                                {{WRAPPER}} .pxl-button-wrapper .btn.pxl-btn-split .pxl-btn-text',
                                            ),
                                            array(
                                                'name' => 'btn_border',
                                                'type' => \Elementor\Group_Control_Border::get_type(),
                                                'separator' => 'before',
                                                'control_type' => 'group', 
                                                'selector' => '{{WRAPPER}} .pxl-button-wrapper .btn:not(.pxl-btn-split), {{WRAPPER}} .pxl-button-wrapper .btn.pxl-btn-split .pxl-btn-icon, {{WRAPPER}} .pxl-button-wrapper .btn.pxl-btn-split .pxl-btn-text',
                                            ),
                                            array(
                                                'name'         => 'btn_box_shadow',
                                                'label' => esc_html__( 'Box Shadow', 'mouno' ),
                                                'type'         => \Elementor\Group_Control_Box_Shadow::get_type(),
                                                'control_type' => 'group',
                                                'selector'     => '{{WRAPPER}} .pxl-button-wrapper .btn',
                                            ),
                                            array(
                                                'name' => 'btn_border_radius',
                                                'label' => esc_html__('Border Radius', 'mouno' ),
                                                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                                                'size_units' => [ 'px', '%' ],
                                                'selectors' => [
                                                    '{{WRAPPER}} .pxl-button-wrapper .btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                                ],
                                            ),
                                            array(
                                                'name' => 'btn_padding',
                                                'label' => esc_html__('Padding', 'mouno' ),
                                                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                                                'size_units' => [ 'px', '%' ],
                                                'control_type' => 'responsive',
                                                'separator' => 'before',
                                                'selectors' => [
                                                    '{{WRAPPER}} .pxl-button-wrapper .btn:not(.pxl-btn-split), 
                                                    {{WRAPPER}} .pxl-button-wrapper .btn.pxl-btn-split .pxl-btn-text' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                                ],
                                            ),
                                        ],
                                    ],
                                    [
                                        'name' => 'btn_hover',
                                        'label' => esc_html__('Hover', 'mouno' ),
                                        'type' => \Elementor\Controls_Manager::TAB,
                                        'controls' => [
                                            array(
                                                'name' => 'btn_hover_style',
                                                'label' => esc_html__('Hover Style', 'mouno' ),
                                                'type' => 'select',
                                                'options' => [
                                                    'hover-default' => esc_html__('Default', 'mouno'),
                                                    'hover-spotlight-scale' => esc_html__('Spotlight', 'mouno'),
                                                    'hover-parallax' => esc_html__('Parallax', 'mouno'),
                                                ],
                                                'default' => 'hover-default',
                                                'condition' => [
                                                    'btn_type!' => ['pxl-btn-split'],
                                                ],
                                            ),
                                            array(
                                                'name' => 'btn_color_hover',
                                                'label' => esc_html__('Color', 'mouno' ),
                                                'type' => 'color',
                                                'selectors' => [
                                                    '{{WRAPPER}} .pxl-button-wrapper .btn:hover' => 'color: {{VALUE}};',
                                                ],
                                            ),
                                            array(
                                                'name' => 'btn_hover_bg',
                                                'type' => \Elementor\Group_Control_Background::get_type(),
                                                'control_type' => 'group',
                                                'types' => [ 'classic', 'gradient' ],
                                                'selector' => '{{WRAPPER}} .pxl-button-wrapper .btn:not(.pxl-btn-split):not(.hover-spotlight-scale):hover, 
                                                {{WRAPPER}} .pxl-button-wrapper .btn.pxl-btn-split:hover .pxl-btn-icon, 
                                                {{WRAPPER}} .pxl-button-wrapper .btn.pxl-btn-split:hover .pxl-btn-text,
                                                {{WRAPPER}} .pxl-button-wrapper .btn .item-spotlight',
                                            ),
                                            array(
                                                'name' => 'btn_hover_border',
                                                'type' => \Elementor\Group_Control_Border::get_type(),
                                                'separator' => 'before',
                                                'control_type' => 'group', 
                                                'selector' => '{{WRAPPER}} .pxl-button-wrapper .btn:not(.pxl-btn-split):hover, 
                                                {{WRAPPER}} .pxl-button-wrapper .btn.pxl-btn-split:hover .pxl-btn-icon, 
                                                {{WRAPPER}} .pxl-button-wrapper .btn.pxl-btn-split:hover .pxl-btn-text',
                                            ),
                                            array(
                                                'name'         => 'btn_hover_box_shadow',
                                                'label' => esc_html__( 'Box Shadow', 'mouno' ),
                                                'type'         => \Elementor\Group_Control_Box_Shadow::get_type(),
                                                'control_type' => 'group',
                                                'selector'     => '{{WRAPPER}} .pxl-button-wrapper .btn:hover',
                                            ),
                                            array(
                                                'name' => 'btn_hover_border_radius',
                                                'label' => esc_html__('Border Radius', 'mouno' ),
                                                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                                                'size_units' => [ 'px', '%' ],
                                                'selectors' => [
                                                    '{{WRAPPER}} .pxl-button-wrapper .btn:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                                ],
                                            ),
                                            array(
                                                'name' => 'btn_hover_padding',
                                                'label' => esc_html__('Padding', 'mouno' ),
                                                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                                                'size_units' => [ 'px', '%' ],
                                                'control_type' => 'responsive',
                                                'separator' => 'before',
                                                'selectors' => [
                                                    '{{WRAPPER}} .pxl-button-wrapper .btn:not(.pxl-btn-split):hover, 
                                                    {{WRAPPER}} .pxl-button-wrapper .btn.pxl-btn-split:hover .pxl-btn-text' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                                ],
                                            ),
                                        ],
                                    ],
                                ],
                            ),
                        ),
                    ),
                ),

                array(
                    'name' => 'tab_motion_effects',
                    'label' => esc_html__('Motion Effects', 'mouno' ),
                    'tab' => 'style',
                    'controls' => array_merge(
                        mouno_get_animation_options([
                            'condition' => [
                                'btn_type!' => 'pxl-btn-split',
                            ],
                            'selector' => '{{WRAPPER}} .pxl-button-wrapper .btn',
                        ]),
                        array(
                            array(
                                'name' => 'text_anm_h',
                                'label' => esc_html__('Text Animation', 'mouno'),
                                'type' => 'heading',
                                'condition' => [
                                    'btn_type' => 'pxl-btn-split',
                                ],
                            ),
                        ),
                        mouno_get_animation_options([
                            'prefix' => 'text',
                            'condition' => [
                                'btn_type' => 'pxl-btn-split',
                            ],
                            'selector' => '{{WRAPPER}} .pxl-button-wrapper .btn .pxl-btn-text',
                        ]),
                        array(
                            array(
                                'name' => 'icon_anm_h',
                                'label' => esc_html__('Icon Animation', 'mouno'),
                                'type' => 'heading',
                                'condition' => [
                                    'btn_type' => 'pxl-btn-split',
                                ],
                            ),
                        ),
                        mouno_get_animation_options([
                            'prefix' => 'icon',
                            'condition' => [
                                'btn_type' => 'pxl-btn-split',
                            ],
                            'selector' => '{{WRAPPER}} .pxl-button-wrapper .btn .pxl-btn-icon',
                        ]),
                    ),
                ),

            ),
        ),
    ),
    mouno_get_class_widget_path()
);