<?php
$post_type = ['team'];
pxl_add_custom_widget(
    array(
        'name' => 'pxl_team',
        'title' => esc_html__('Case Team', 'mouno' ),
        'icon' => 'eicon-person',
        'categories' => array('pxltheme-core'),
        'scripts' => [
            'imagesloaded',
            'isotope',
            'pxl-post-grid',
            'mouno-parallax',
            'mouno-effects',
            'tilt'
        ],
        'params' => array(
            'sections' => array(
                array(
                    'name'     => 'tab_layout',
                    'label'    => esc_html__( 'Layout', 'mouno' ),
                    'tab'      => 'layout',
                    'controls' => array_merge(
                        array(
                            array(
                                'name'     => 'post_type',
                                'type'     => 'hidden',
                                'options'  => mouno_get_post_type_options($post_type),
                                'default'  => 'team'
                            ),
                            array(
                                'name'     => 'layout_type',
                                'label'    => esc_html__( 'Layout Type', 'mouno' ),
                                'type'     => 'select',
                                'options'  => [
                                    'grid' => esc_html__('Grid', 'mouno'),
                                    'carousel' => esc_html__('Carousel', 'mouno'),
                                ],
                                'default'  => 'grid',
                            ),
                        ),
                        mouno_get_post_layout($post_type, []), 
                    ),
                ),
                 
                // Settings
                mouno_source_post_settings($post_type),
                array(
                    'name' => 'tab_display_opts',
                    'label' => esc_html__('Display', 'mouno' ),
                    'tab' => 'settings',
                    'controls' => array_merge(
                        image_dimension_options(),
                        array(
                            array(
                                'name' => 'title_tag',
                                'label' => esc_html__('Title HTML Tag', 'mouno'),
                                'type' => 'select',
                                'seperator' => 'before',
                                'options' => [
                                    ''   => esc_html__('Default', 'mouno'),
                                    'h1' => esc_html__('H1', 'mouno'),
                                    'h2' => esc_html__('H2', 'mouno'),
                                    'h3' => esc_html__('H3', 'mouno'),
                                    'h4' => esc_html__('H4', 'mouno'),
                                    'h5' => esc_html__('H5', 'mouno'),
                                    'h6' => esc_html__('H6', 'mouno'),
                                    'div' => esc_html__('div', 'mouno'),
                                    'p'  => esc_html__('p', 'mouno'),
                                    'span' => esc_html__('span', 'mouno'),
                                ],
                                'default' => '',
                            ),
                            array(
                                'name' => 'show_social',
                                'label' => esc_html__('Show Social', 'mouno' ),
                                'type' => 'switcher',
                                'default' => 'true',
                            ),
                            array(
                                'name' => 'show_position',
                                'label' => esc_html__('Show Position', 'mouno' ),
                                'type' => 'switcher',
                                'default' => 'true',
                            ),
                        ),
                    ),
                ),
                array(
                    'name' => 'tab_grid_add_opts',
                    'label' => esc_html__('Additional Options', 'mouno' ),
                    'tab' => 'settings',
                    'condition' => ['layout_type' => 'grid'],
                    'controls' => grid_controls_options(
                        [ 'filter' => false ]
                    ),
                ),
                array(
                    'name' => 'tab_swiper_add_otps',
                    'label' => esc_html__('Addtional Options', 'mouno'),
                    'tab' => 'settings',
                    'condition' => ['layout_type' => 'carousel'],
                    'controls' => array(
                        swiper_controls_options(),
                    ),
                ),

                // Style
                array(
                    'name' => 'tab_general_style',
                    'label' => esc_html__('General', 'mouno' ),
                    'tab' => 'style',
                    'controls' => array(
                        array(
                            'name' => 'content_text_align',
                            'label' => esc_html__( 'Content Align', 'mouno' ),
                            'type' => 'choose',
                            'options' => [
                                'left' => [
                                    'title' => esc_html__( 'Left', 'mouno' ),
                                    'icon' => 'eicon-text-align-left',
                                ],
                                'center' => [
                                    'title' => esc_html__( 'Center', 'mouno' ),
                                    'icon' => 'eicon-text-align-center',
                                ],
                                'right' => [
                                    'title' => esc_html__( 'Right', 'mouno' ),
                                    'icon' => 'eicon-text-align-right',
                                ],
                                'justify' => [
                                    'title' => esc_html__( 'Justify', 'mouno' ),
                                    'icon' => 'eicon-text-align-justify'
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-layout-team .pxl-post-content' => "text-align: {{VALUE}};",
                            ]
                        ),
                        array(
                            'name' => 'featured_spacing',
                            'label' => esc_html__('Featured Spacing', 'mouno'),
                            'type' => 'slider',
                            'size_units' => ['px', 'custom'],
                            'separator' => 'before',
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 1000,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-layout-team .pxl-post-content' => "padding-top: {{SIZE}}{{UNIT}};",
                            ],
                        ),
                        array(
                            'name' => 'title_spacing',
                            'label' => esc_html__('Title Spacing', 'mouno'),
                            'type' => 'slider',
                            'size_units' => ['px', 'custom'],
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 1000,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-layout-team .pxl-post-title' => "margin-bottom: {{SIZE}}{{UNIT}};",
                            ],
                        ),
                        array(
                            'name' => 'social_gap',
                            'label' => esc_html__('Social Gap', 'mouno'),
                            'type' => 'slider',
                            'size_units' => ['px', 'custom'],
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 1000,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-layout-team .pxl-post-socials' => "gap: {{SIZE}}{{UNIT}};",
                            ],
                        ),
                    ),
                ),
                array(
                    'name' => 'tab_box_style',
                    'label' => esc_html__('Box', 'mouno' ),
                    'tab' => 'style',
                    'controls' => array(
                        array(
                            'name' => 'box_controls',
                            'control_type' => 'tab',
                            'tabs' => [
                                [
                                    'name' => 'box_normal',
                                    'label' => esc_html__('Normal', 'mouno' ),
                                    'type' => 'tab',
                                    'controls' => [  
                                        array(
                                            'name' => 'box_bg',
                                            'type' => \Elementor\Group_Control_Background::get_type(),
                                            'control_type' => 'group',
                                            'types' => [ 'classic', 'gradient' ],
                                            'selector' => '{{WRAPPER}} .pxl-layout-team .pxl-post-item',
                                        ),
                                        array(
                                            'name' => 'box_border',
                                            'type' => \Elementor\Group_Control_Border::get_type(),
                                            'separator' => 'before',
                                            'control_type' => 'group', 
                                            'selector' => '{{WRAPPER}} .pxl-layout-team .pxl-post-item',
                                        ),
                                        array(
                                            'name'         => 'box_box_shadow',
                                            'label' => esc_html__( 'Box Shadow', 'mouno' ),
                                            'type'         => \Elementor\Group_Control_Box_Shadow::get_type(),
                                            'control_type' => 'group',
                                            'selector'     => '{{WRAPPER}} .pxl-layout-team .pxl-post-item',
                                        ),
                                        array(
                                            'name' => 'box_border_radius',
                                            'label' => esc_html__('Border Radius', 'mouno' ),
                                            'type' => 'dimensions',
                                            'size_units' => [ 'px', '%', 'custom' ],
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-layout-team .pxl-post-item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'box_padding',
                                            'label' => esc_html__('Padding', 'mouno' ),
                                            'type' => 'dimensions',
                                            'size_units' => [ 'px', '%', 'custom' ],
                                            'control_type' => 'responsive',
                                            'separator' => 'before',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-layout-team .pxl-post-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                    ],
                                ],
                                [
                                    'name' => 'box_hover',
                                    'label' => esc_html__('Hover', 'mouno' ),
                                    'type' => 'tabs',
                                    'controls' => [
                                        array(
                                            'name' => 'box_hover_bg',
                                            'type' => \Elementor\Group_Control_Background::get_type(),
                                            'control_type' => 'group',
                                            'types' => [ 'classic', 'gradient' ],
                                            'selector' => '{{WRAPPER}} .pxl-layout-team .pxl-post-item:hover',
                                        ),
                                        array(
                                            'name' => '_box_hover_border_color',
                                            'label' => esc_html__('Border Color', 'mouno' ),
                                            'type' => 'color',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-layout-team .pxl-post-item:hover' => 'border-color: {{VALUE}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'box_hover_border',
                                            'type' => \Elementor\Group_Control_Border::get_type(),
                                            'separator' => 'before',
                                            'control_type' => 'group', 
                                            'selector' => '{{WRAPPER}} .pxl-layout-team .pxl-post-item:hover',
                                        ),
                                        array(
                                            'name'         => 'box_hover_box_shadow',
                                            'label' => esc_html__( 'Box Shadow', 'mouno' ),
                                            'type'         => \Elementor\Group_Control_Box_Shadow::get_type(),
                                            'control_type' => 'group',
                                            'selector'     => '{{WRAPPER}} .pxl-layout-team .pxl-post-item:hover',
                                        ),
                                        array(
                                            'name' => 'box_hover_border_radius',
                                            'label' => esc_html__('Border Radius', 'mouno' ),
                                            'type' => 'dimensions',
                                            'size_units' => [ 'px', '%', 'custom' ],
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-layout-team .pxl-post-item:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'box_hover_padding',
                                            'label' => esc_html__('Padding', 'mouno' ),
                                            'type' => 'dimensions',
                                            'size_units' => [ 'px', '%', 'custom' ],
                                            'control_type' => 'responsive',
                                            'separator' => 'before',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-layout-team .pxl-post-item:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                    ],
                                ],
                            ],
                        ),
                    ),
                ),
                array(
                    'name' => 'tab_featured_style',
                    'label' => esc_html__('Featured', 'mouno' ),
                    'tab' => 'style',
                    'controls' => array(
                        array(
                            'name' => 'featured_w',
                            'label' => esc_html__('Width', 'mouno'),
                            'type' => 'slider',
                            'size_units' => ['px', '%', 'custom'],
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 1000,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-layout-team .pxl-post-featured' => "width: {{SIZE}}{{UNIT}};",
                            ],
                        ),
                        array(
                            'name' => 'featured_max_w',
                            'label' => esc_html__('Max Width', 'mouno'),
                            'type' => 'slider',
                            'size_units' => ['px', '%', 'custom'],
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 1000,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-layout-team .pxl-post-featured' => "max-width: {{SIZE}}{{UNIT}};",
                            ],
                        ),
                        array(
                            'name' => 'featured_h',
                            'label' => esc_html__('Height', 'mouno'),
                            'type' => 'slider',
                            'size_units' => ['px', '%', 'custom'],
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 1000,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-layout-team .pxl-post-featured' => "height: {{SIZE}}{{UNIT}};",
                            ],
                        ),
                        array(
                            'name' => 'featured_divider',
                            'type' => 'divider',
                        ),
                        array(
                            'name' => 'featured_controls',
                            'control_type' => 'tab',
                            'tabs' => [
                                [
                                    'name' => 'featured_normal',
                                    'label' => esc_html__('Normal', 'mouno' ),
                                    'type' => 'tab',
                                    'controls' => [  
                                        array(
                                            'name' => 'featured_opacity',
                                            'label' => esc_html__('Opacity', 'mouno' ),
                                            'type' => 'slider',
                                            'control_type' => 'responsive',
                                            'size_units' => ['px'],
                                            'range' => [
                                                'px' => [
                                                    'min' => 0,
                                                    'max' => 1,
                                                    'step' => 0.01,
                                                ],
                                            ],
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-layout-team .pxl-post-featured' => 'opacity: {{SIZE}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'featured_css_filter', 
                                            'type' => \Elementor\Group_Control_Css_Filter::get_type(),
                                            'control_type' => 'group',
                                            'selector' => '{{WRAPPER}} .pxl-layout-team .pxl-post-featured',
                                        ),
                                        array(
                                            'name' => 'featured_border', 
                                            'type' => \Elementor\Group_Control_Border::get_type(),
                                            'control_type' => 'group',
                                            'separator' => 'before',
                                            'selector' => '{{WRAPPER}} .pxl-layout-team .pxl-post-featured',
                                        ),
                                        array(
                                            'name' => 'featured_box_shadow', 
                                            'type' => \Elementor\Group_Control_Box_Shadow::get_type(),
                                            'control_type' => 'group',
                                            'separator' => 'before',
                                            'selector' => '{{WRAPPER}} .pxl-layout-team .pxl-post-featured',
                                        ),
                                        array(
                                            'name' => 'featured_border_radius',
                                            'label' => esc_html__('Border Radius', 'mouno' ),
                                            'type' => 'dimensions',
                                            'size_units' => [ 'px', '%' ],
                                            'control_type' => 'responsive',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-layout-team .pxl-post-featured' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'featured_padding',
                                            'label' => esc_html__('Padding', 'mouno' ),
                                            'type' => 'dimensions',
                                            'size_units' => [ 'px', '%' ],
                                            'control_type' => 'responsive',
                                            'separator' => 'before',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-layout-team .pxl-post-featured' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                    ],
                                ],
                                [
                                    'name' => 'featured_hover',
                                    'label' => esc_html__('Hover', 'mouno' ),
                                    'type' => 'tab',
                                    'controls' => [
                                        array(
                                            'name' => 'featured_hover_style',
                                            'label' => esc_html__('Hover Style', 'mouno' ),
                                            'type' => 'select',
                                            'options' => [
                                                'hover-image-default'  => esc_html__('Default', 'mouno'),
                                                'hover-image-zoom-in'  => esc_html__('Zoom In', 'mouno'),
                                                'hover-tilt'           => esc_html__('Tilt', 'mouno'),
                                                'hover-image-parallax' => esc_html__('Parallax', 'mouno'),
                                            ],
                                            'default' => 'hover-image-default',
                                        ),
                                        array(
                                            'name' => 'featured_zoom_in_val',
                                            'label' => esc_html__('Zoom Value', 'mouno' ),
                                            'type' => 'slider',
                                            'control_type' => 'responsive',
                                            'size_units' => ['px'],
                                            'range' => [
                                                'px' => [
                                                    'min' => 1,
                                                    'max' => 3,
                                                    'step' => 0.01,
                                                ],
                                            ],
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-layout-team .pxl-post-featured' => '--pxl-scale: {{SIZE}};',
                                            ],
                                            'condition' => [
                                                'featured_hover_style' => 'hover-image-zoom-in',
                                            ],
                                        ),
                                        array(
                                            'name' => 'featured_hover_opacity',
                                            'label' => esc_html__('Opacity', 'mouno' ),
                                            'type' => 'slider',
                                            'control_type' => 'responsive',
                                            'size_units' => ['px'],
                                            'range' => [
                                                'px' => [
                                                    'min' => 0,
                                                    'max' => 1,
                                                    'step' => 0.01,
                                                ],
                                            ],
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-layout-team .pxl-post-item:hover .pxl-post-featured' => 'opacity: {{SIZE}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'featured_hover_css_filter', 
                                            'type' => \Elementor\Group_Control_Css_Filter::get_type(),
                                            'control_type' => 'group',
                                            'selector' => '{{WRAPPER}} .pxl-layout-team .pxl-post-item:hover .pxl-post-featured',
                                        ),
                                        array(
                                            'name' => 'featured_hover_border', 
                                            'type' => \Elementor\Group_Control_Border::get_type(),
                                            'control_type' => 'group',
                                            'separator' => 'before',
                                            'selector' => '{{WRAPPER}} .pxl-layout-team .pxl-post-item:hover .pxl-post-featured',
                                        ),
                                        array(
                                            'name' => 'featured_hover_box_shadow', 
                                            'type' => \Elementor\Group_Control_Box_Shadow::get_type(),
                                            'control_type' => 'group',
                                            'separator' => 'before',
                                            'selector' => '{{WRAPPER}} .pxl-layout-team .pxl-post-item:hover .pxl-post-featured',
                                        ),
                                        array(
                                            'name' => 'featured_hover_border_radius',
                                            'label' => esc_html__('Border Radius', 'mouno' ),
                                            'type' => 'dimensions',
                                            'size_units' => [ 'px', '%' ],
                                            'control_type' => 'responsive',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-layout-team .pxl-post-item:hover .pxl-post-featured' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'featured_hover_padding',
                                            'label' => esc_html__('Padding', 'mouno' ),
                                            'type' => 'dimensions',
                                            'size_units' => [ 'px', '%' ],
                                            'control_type' => 'responsive',
                                            'separator' => 'before',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-layout-team .pxl-post-item:hover .pxl-post-featured' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                    ],
                                ],
                            ],
                        ),
                    ),
                ),
                array(
                    'name' => 'tab_title_style',
                    'label' => esc_html__('Title', 'mouno' ),
                    'tab' => 'style',
                    'controls' => array_merge(
                        array(
                            array(
                                'name' => 'title_typography',
                                'type' => \Elementor\Group_Control_Typography::get_type(),
                                'control_type' => 'group',
                                'selector' => '{{WRAPPER}} .pxl-layout-team .pxl-post-title',
                            ),
                            array(
                                'name' => 'title_controls',
                                'control_type' => 'tab',
                                'tabs' => [
                                    [
                                        'name' => 'title_normal',
                                        'label' => esc_html__('Normal', 'mouno' ),
                                        'type' => 'tab',
                                        'controls' => [  
                                            array(
                                                'name' => 'title_color',
                                                'label' => esc_html__('Text Color', 'mouno' ),
                                                'type' => 'color',
                                                'selectors' => [
                                                    '{{WRAPPER}} .pxl-layout-team .pxl-post-title, 
                                                    {{WRAPPER}} .pxl-layout-team .pxl-post-title.hover-3d-cube-flip:before' => 'color: {{VALUE}};',
                                                ],
                                            ),
                                            array(
                                                'name' => 'title_stroke',
                                                'type' => \Elementor\Group_Control_Text_Stroke::get_type(),
                                                'control_type' => 'group',
                                                'selector' => '{{WRAPPER}} .pxl-layout-team .pxl-post-title',
                                            ),
                                            array(
                                                'name' => 'title_text_shadow',
                                                'type' => \Elementor\Group_Control_Text_Shadow::get_type(),
                                                'control_type' => 'group',
                                                'selector' => '{{WRAPPER}} .pxl-layout-team .pxl-post-title',
                                            ),
                                        ],
                                    ],
                                    [
                                        'name' => 'title_hover',
                                        'label' => esc_html__('Hover/Active', 'mouno' ),
                                        'type' => 'tab',
                                        'controls' => [
                                            array(
                                                'name' => 'title_hover_style',
                                                'label' => esc_html__('Hover Style', 'mouno' ),
                                                'type' => 'select',
                                                'groups' => [
                                                    [
                                                        'label' => esc_html__('Default', 'mouno'),
                                                        'options' => [
                                                            'hover-text-default' => esc_html__('Default', 'mouno'),
                                                        ],
                                                    ],
                                                    [
                                                        'label' => esc_html__('Underline', 'mouno'),
                                                        'options' => [
                                                            'hover-text-underline' => esc_html__('Underline', 'mouno'),
                                                            'hover-text-underline--slide-ltr' => esc_html__('Slide LTR', 'mouno'),
                                                            'hover-text-underline--slide-rtl' => esc_html__('Slide RTL', 'mouno'),
                                                        ],
                                                    ],
                                                    [
                                                        'label' => esc_html__('Other', 'mouno'),
                                                        'options' => [
                                                            'hover-3d-cube-flip' => esc_html__('3D Flip', 'mouno'),
                                                            'hover-text-fill' => esc_html__('Text Fill', 'mouno'),
                                                        ],
                                                    ],
                                                ],
                                                'default' => 'hover-text-default',
                                            ),
                                            array(
                                                'name' => 'underline_h',
                                                'label' => esc_html__('Underline Weight(px)', 'mouno'),
                                                'type' => 'slider',
                                                'size_units' => ['px'],
                                                'selectors' => [
                                                    '{{WRAPPER}} .pxl-layout-team .pxl-post-title' => "--pxl-height: {{SIZE}}{{UNIT}};",
                                                ],
                                                'condition' => [
                                                    'title_hover_style' => ['hover-text-underline', 'hover-text-underline--slide-ltr', 'hover-text-underline--slide-rtl'],
                                                ],
                                            ),
                                            array(
                                                'name' => 'title_divider',
                                                'type' => 'divider',
                                                'condition' => [
                                                    'layout_service!' => ['service-4'],
                                                ],
                                            ),
                                            array(
                                                'name' => 'title_hover_color',
                                                'label' => esc_html__('Text Color', 'mouno' ),
                                                'type' => 'color',
                                                'selectors' => [
                                                    '{{WRAPPER}} .pxl-layout-team .pxl-post-item:hover .pxl-post-title:not(.hover-3d-cube-flip):not(.hover-text-fill),
                                                    {{WRAPPER}} .pxl-layout-team .pxl-post-item.active .pxl-post-title:not(.hover-3d-cube-flip):not(.hover-text-fill),
                                                    {{WRAPPER}} .pxl-layout-team .pxl-post-title.hover-3d-cube-flip:after' => 'color: {{VALUE}};',
                                                    '{{WRAPPER}} .pxl-layout-team .pxl-post-item .hover-text-fill'   => '--link-color-hover: {{VALUE}};',
                                                ],
                                            ),
                                            array(
                                                'name' => 'title_hover_stroke',
                                                'type' => \Elementor\Group_Control_Text_Stroke::get_type(),
                                                'control_type' => 'group',
                                                'selector' => '{{WRAPPER}} .pxl-layout-team .pxl-post-item:hover .pxl-post-title,
                                                {{WRAPPER}} .pxl-layout-team .pxl-post-item.active .pxl-post-title',
                                            ),
                                            array(
                                                'name' => 'title_hover_text_shadow',
                                                'type' => \Elementor\Group_Control_Text_Shadow::get_type(),
                                                'control_type' => 'group',
                                                'selector' => '{{WRAPPER}} .pxl-layout-team .pxl-post-item:hover .pxl-post-title,
                                                {{WRAPPER}} .pxl-layout-team .pxl-post-item.active .pxl-post-title',
                                            ),
                                        ],
                                    ],
                                ],
                            ),
                        ),
                    ),
                ),
                array(
                    'name' => 'tab_position_style',
                    'label' => esc_html__('Position', 'mouno' ),
                    'tab' => 'style',
                    'controls' => array(
                        array(
                            'name' => 'position_typography',
                            'type' => \Elementor\Group_Control_Typography::get_type(),
                            'control_type' => 'group',
                            'selector' => '{{WRAPPER}} .pxl-layout-team .pxl-post-position',
                        ),
                        array(
                            'name' => 'position_controls',
                            'control_type' => 'tab',
                            'tabs' => [
                                [
                                    'name' => 'position_normal',
                                    'label' => esc_html__('Normal', 'mouno' ),
                                    'type' => 'tab',
                                    'controls' => [  
                                        array(
                                            'name' => 'position_color',
                                            'label' => esc_html__('Text Color', 'mouno' ),
                                            'type' => 'color',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-layout-team .pxl-post-position' => 'color: {{VALUE}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'position_text_shadow',
                                            'type' => \Elementor\Group_Control_Text_Shadow::get_type(),
                                            'control_type' => 'group',
                                            'selector' => '{{WRAPPER}} .pxl-layout-team .pxl-post-position',
                                        ),
                                    ],
                                ],
                                [
                                    'name' => 'position_hover',
                                    'label' => esc_html__('Hover', 'mouno' ),
                                    'type' => 'tab',
                                    'controls' => [  
                                        array(
                                            'name' => 'position_hover_color',
                                            'label' => esc_html__('Text Color', 'mouno' ),
                                            'type' => 'color',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-layout-team .pxl-post-item:hover .pxl-post-position' => 'color: {{VALUE}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'position_hover_text_shadow',
                                            'type' => \Elementor\Group_Control_Text_Shadow::get_type(),
                                            'control_type' => 'group',
                                            'selector' => '{{WRAPPER}} .pxl-layout-team .pxl-post-item:hover .pxl-post-position',
                                        ),
                                    ],
                                ],
                            ],
                        ),
                    ),
                ),
                array(
                    'name' => 'tab_social_style',
                    'label' => esc_html__('Social', 'mouno'),
                    'tab' => 'style',
                    'controls' => array(
                        array(
                            'name' => 'show_social_style',
                            'label' => esc_html__('Show Style', 'mouno' ),
                            'type' => 'select',
                            'options' => [
                                'show-social-default' => esc_html__('Default', 'mouno'),
                                'show-social-radial'  => esc_html__('Radial', 'mouno'),
                                'show-social-zoom-in' => esc_html__('Zoom In', 'mouno'),
                            ],
                            'default' => 'show-social-default',
                        ),
                        array(
                            'name' => 'social_icon_sz',
                            'label' => esc_html__('Icon Size', 'mouno' ),
                            'type' => 'slider',
                            'size_units' => ['px', 'custom'],
                            'control_type' => 'responsive',
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 500,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-layout-team .pxl-post-socials .pxl-social-link' => 'font-size: {{SIZE}}{{UNIT}};',
                                '{{WRAPPER}} .pxl-layout-team .pxl-post-socials .pxl-social-link svg' => 'width: {{SIZE}}{{UNIT}}; height: auto',
                            ],
                        ),
                        array(
                            'name' => 'social_box_sz',
                            'label' => esc_html__('Box Size', 'mouno' ),
                            'type' => 'slider',
                            'size_units' => ['px', 'custom'],
                            'control_type' => 'responsive',
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 500,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-layout-team .pxl-post-socials .pxl-social-link' => '--pxl-box-size: {{SIZE}}{{UNIT}};',
                            ],
                        ),
                        array(
                            'name' => 'divider_sicoa',
                            'type' => 'divider',
                        ),
                        array(
                            'name' => 'social_controls',
                            'control_type' => 'tab',
                            'tabs' => [
                                [
                                    'name' => 'social_normal',
                                    'label' => esc_html__('Normal', 'mouno' ),
                                    'type' => 'tab',
                                    'controls' => [  
                                        array(
                                            'name' => 'social_color',
                                            'label' => esc_html__('Icon Color', 'mouno' ),
                                            'type' => 'color',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-layout-team .pxl-post-socials .pxl-social-link' => 'color: {{VALUE}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'social_bg',
                                            'type' => \Elementor\Group_Control_Background::get_type(),
                                            'control_type' => 'group',
                                            'types' => [ 'classic', 'gradient' ],
                                            'selector' => '{{WRAPPER}} .pxl-layout-team .pxl-post-socials .pxl-social-link',
                                        ),
                                        array(
                                            'name' => 'social_border',
                                            'type' => \Elementor\Group_Control_Border::get_type(),
                                            'separator' => 'before',
                                            'control_type' => 'group', 
                                            'selector' => '{{WRAPPER}} .pxl-layout-team .pxl-post-socials .pxl-social-link',
                                        ),
                                        array(
                                            'name'         => 'social_box_shadow',
                                            'label' => esc_html__( 'Box Shadow', 'mouno' ),
                                            'type'         => \Elementor\Group_Control_Box_Shadow::get_type(),
                                            'control_type' => 'group',
                                            'selector'     => '{{WRAPPER}} .pxl-layout-team .pxl-post-socials .pxl-social-link',
                                        ),
                                        array(
                                            'name' => 'social_border_radius',
                                            'label' => esc_html__('Border Radius', 'mouno' ),
                                            'type' => 'dimensions',
                                            'size_units' => [ 'px', '%', 'custom' ],
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-layout-team .pxl-post-socials .pxl-social-link' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'social_padding',
                                            'label' => esc_html__('Padding', 'mouno' ),
                                            'type' => 'dimensions',
                                            'size_units' => [ 'px', '%', 'custom' ],
                                            'control_type' => 'responsive',
                                            'separator' => 'before',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-layout-team .pxl-post-socials .pxl-social-link' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                    ],
                                ],
                                [
                                    'name' => 'social_hover',
                                    'label' => esc_html__('Hover', 'mouno' ),
                                    'type' => 'tabs',
                                    'controls' => [
                                        // array(
                                        //     'name' => 'social_hover_style',
                                        //     'label' => esc_html__('Hover Style', 'mouno' ),
                                        //     'type' => 'select',
                                        //     'options' => [
                                        //         'hover-box-default' => esc_html__('Default', 'mouno'),
                                        //         'hover-spotlight-scale' => esc_html__('Spotlight', 'mouno'),
                                        //         'hover-parallax' => esc_html__('Parallax', 'mouno'),
                                        //     ],
                                        //     'default' => 'hover-default',
                                        //     'condition' => [
                                        //         'social_type!' => ['pxl-social-split'],
                                        //     ],
                                        // ),
                                        array(
                                            'name' => 'social_hove_color',
                                            'label' => esc_html__('Icon Color', 'mouno' ),
                                            'type' => 'color',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-layout-team .pxl-post-socials .pxl-social-link:hover' => 'color: {{VALUE}};',
                                            ],
                                        ),
                                        array(
                                            'name' => '_social_hover_border_color',
                                            'label' => esc_html__('Border Color', 'mouno' ),
                                            'type' => 'color',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-layout-team .pxl-post-socials .pxl-social-link:hover' => 'border-color: {{VALUE}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'social_hover_bg',
                                            'type' => \Elementor\Group_Control_Background::get_type(),
                                            'control_type' => 'group',
                                            'types' => [ 'classic', 'gradient' ],
                                            'selector' => '{{WRAPPER}} .pxl-layout-team .pxl-post-socials .pxl-social-link:hover',
                                        ),
                                        array(
                                            'name' => 'social_hover_anim',
                                            'label' => esc_html__( 'Hover Animation', 'mouno' ),
                                            'type' => 'hover_animation',
                                        ),
                                        array(
                                            'name' => 'social_hover_border',
                                            'type' => \Elementor\Group_Control_Border::get_type(),
                                            'separator' => 'before',
                                            'control_type' => 'group', 
                                            'selector' => '{{WRAPPER}} .pxl-layout-team .pxl-post-socials .pxl-social-link:hover',
                                        ),
                                        array(
                                            'name'         => 'social_hover_box_shadow',
                                            'label' => esc_html__( 'Box Shadow', 'mouno' ),
                                            'type'         => \Elementor\Group_Control_Box_Shadow::get_type(),
                                            'control_type' => 'group',
                                            'selector'     => '{{WRAPPER}} .pxl-layout-team .pxl-post-socials .pxl-social-link:hover',
                                        ),
                                        array(
                                            'name' => 'social_hover_border_radius',
                                            'label' => esc_html__('Border Radius', 'mouno' ),
                                            'type' => 'dimensions',
                                            'size_units' => [ 'px', '%', 'custom' ],
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-layout-team .pxl-post-socials .pxl-social-link:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'social_hover_padding',
                                            'label' => esc_html__('Padding', 'mouno' ),
                                            'type' => 'dimensions',
                                            'size_units' => [ 'px', '%', 'custom' ],
                                            'control_type' => 'responsive',
                                            'separator' => 'before',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-layout-team .pxl-post-socials .pxl-social-link:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                    ],
                                ],
                            ],
                        ),
                    ),
                ),
                grid_pagination_style_options(),
                swiper_bullets_pagination_style_options(),
                array(
                    'name' => 'tab_motion_effects',
                    'label' => esc_html__('Motion Effects', 'mouno' ),
                    'tab' => 'style',
                    'controls' => array_merge(
                        array(
                            array(
                                'name'=> 'scrolling_effect',
                                'label'=> esc_html__('Scrolling Effect', 'mouno'),
                                'type'=> 'select',
                                'options'=> [
                                    '' => esc_html__('None', 'mouno'),
                                    'parallax' => esc_html__('Parallax', 'mouno'),
                                ],
                                'default'=> '',
                            ),
                        ),
                        mouno_parallax_options([
                            'condition' => [
                                'scrolling_effect' => 'parallax',
                            ],
                        ]),
                        array(
                            array(
                                'name' => '__divider',
                                'type' => 'divider',
                            ),
                        ),
                        mouno_get_animation_options(),
                    ),
                ),
            ),
        ),
    ),
    mouno_get_class_widget_path()
);

