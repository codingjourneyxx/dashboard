<?php
pxl_add_custom_widget(
    array(
        'name' => 'pxl_test',
        'title' => esc_html__('TEST', 'mouno' ),
        'icon' => 'eicon-cart',
        'categories' => array('pxltheme-core'),
        'scripts' => array(
            'curtainsjs',
            'mouno-effects',
            'mouno-parallax',
            'tilt',
        ),
        'params' => array(
            'sections' => array(
                array(
                    'name' => 'tab_layout',
                    'label' => esc_html__('Layout', 'mouno'),
                    'tab' => \Elementor\Controls_Manager::TAB_LAYOUT,
                    'controls' => array(
                        array(
                            'name' => 'layout',
                            'label' => esc_html__('Layout', 'mouno'),
                            'type' => 'layoutcontrol',
                            'default' => '1',
                            'options' => array(
                                '1' => array(
                                    'label' => esc_html__('Style 1', 'mouno'),
                                    'image' => get_template_directory_uri() . '/elements/assets/img/pxl_accordion/layout1.jpg',
                                ),
                            ),
                        ),
                    ),
                ),
                array(
                    'name' => 'tab_content',
                    'label' => esc_html__('Slider', 'mouno' ),
                    'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
                    'controls' => array(   
                        array(
                            'name' => 'bg_test',
                            'type' => \Elementor\Group_Control_Background::get_type(),
                            'control_type' => 'group',
                            'types' => [ 'classic', 'gradient' ],
                            'selector' => '{{WRAPPER}} .pxl-layout-service .pxl-post-icon',
                            'fields_options' => [
                                'background' => [
                                    'label' => __( 'Background ABC', 'mouno' ),
                                ],
                                'color' => [
                                    'selectors' => [
                                        '{{WRAPPER}} .e-con-overlay' => '--pxl-background-color: {{VALUE}};',
                                    ],
                                ],
                            ],
                        ),

                        array(
                            'name' => 'bg_test_2',
                            'type' => \Elementor\Group_Control_Background::get_type(),
                            'control_type' => 'group',
                            'types' => [ 'classic', 'gradient' ],
                            'selector' => '{{WRAPPER}} .pxl-layout-service .pxl-post-icon',
                            'fields_options' => [
                                'background' => [
                                    'label' => __( 'Background Test @', 'mouno' ),
                                ],
                                'color' => [
                                    'selectors' => [
                                        '{{WRAPPER}} .e-con-overlay' => '--pxl-background-color: {{VALUE}};',
                                    ],
                                ],
                            ],
                        ),
                    ),
                ),
            ),
        ),
    ),
    mouno_get_class_widget_path()
);
// array(
//     'name' => 'repeater',
//     'label' => esc_html__('Repeater', 'mouno' ),
//     'type' => \Elementor\Controls_Manager::REPEATER,
//     'controls' => array(
//     ),
//     'title_field' => '{{{ title }}}',
// ),
// array(
//     'name' => 'text',
//     'label' => esc_html__('Text', 'mouno' ),
//     'type' => \Elementor\Controls_Manager::TEXT,
//     'label_block' => true,
// ),
// array(
//     'name' => 'textarea',
//     'label' => esc_html__('Textarea', 'mouno' ),
//     'type' => \Elementor\Controls_Manager::TEXTAREA,
//     'rows' => 10,
// ),
// array(
//     'name' => 'media',
//     'label' => esc_html__('Media', 'mouno' ),
//     'type' => \Elementor\Controls_Manager::MEDIA,
// ),
// array(
//     'name' => 'color',
//     'label' => esc_html__('Color', 'mouno' ),
//     'type' => \Elementor\Controls_Manager::COLOR,
//     'selectors' => [
//     ],
// ),
// array(
//     'name' => 'typography',
//     'label' => esc_html__('Typography', 'mouno' ),
//     'type' => \Elementor\Group_Control_Typography::get_type(),
//     'control_type' => 'group',
//     'selector' => '',
// ),
// array(
//     'name' => 'slider',
//     'label' => esc_html__('Slider', 'mouno' ),
//     'type' => 'slider,
//     'control_type' => 'responsive',
//     'size_units' => [ 'px', '%', 'custom' ],
//     'range' => [
//         'px' => [
//             'min' => 0,
//             'max' => 300,
//         ],
//     ],
//     'selectors' => [
//         '' => '{{SIZE}}{{UNIT}},',
//     ],
// ),
// array(
//     'name' => 'divider',
//     'type' => \Elementor\Controls_Manager::DIVIDER,
// ),
// array(
//     'name' => 'heading',
//     'label' => esc_html__('Heading', 'mouno' ),
//     'type' => \Elementor\Controls_Manager::HEADING,
// ),
// array(
//     'name' => 'border',
//     'type' => \Elementor\Group_Control_Border::get_type(),
//     'control_type' => 'group',
//     'selector' => '{{WRAPPER}}',
// ),

// array(
//     'name' => 'wrapper_justify_content',
//     'label' => esc_html__('Justify Content', 'mouno' ),
//     'type' => \Elementor\Controls_Manager::CHOOSE,
//     'options' => [
//         'start' => [
//             'title' => esc_html__('Start', 'mouno' ),
//             'icon' => 'eicon-justify-start-h',
//         ],
//         'center' => [
//             'title' => esc_html__('Center', 'mouno' ),
//             'icon' => 'eicon-justify-center-h',
//         ],
//         'end' => [
//             'title' => esc_html__('End', 'mouno' ),
//             'icon' => 'eicon-justify-end-h',
//         ],
//     ],
//     'selectors' => [
//         '{{WRAPPER}} .pxl-slider1 .pxl-slide-wrapper' => 'justify-content: {{VALUE}};',
//     ],
// ),

// array(
//     'name' => 'btn_control',
//     'control_type' => 'tab',
//     'tabs' => [
//         [
//             'name' => 'btn_normal',
//             'label' => esc_html__('Normal', 'mouno' ),
//             'type' => 'tab',
//             'controls' => [  
//                 array(
//                     'name' => 'btn_color',
//                     'label' => esc_html__('Text Color', 'mouno' ),
//                     'type' => 'color',
//                     'selectors' => [
//                         '{{WRAPPER}} .pxl-button-wrapper .btn' => 'color: {{VALUE}};',
//                     ],
//                 ),
//             ],
//         ],
//         [
//             'name' => 'btn_hover',
//             'label' => esc_html__('Hover', 'mouno' ),
//             'type' => \Elementor\Controls_Manager::TAB,
//             'controls' => [
//             ],
//         ],
//     ],
// ),