<?php
$post_type = ['service'];
pxl_add_custom_widget(
    array(
        'name' => 'pxl_service',
        'title' => esc_html__('Case Services', 'mouno' ),
        'icon' => 'eicon-post',
        'categories' => array('pxltheme-core'),
        'scripts' => [
            'imagesloaded',
            'isotope',
            'pxl-post-grid',
            'mouno-swiper',
            'mouno-effects',
            'mouno-accordion',
            // 'mouno-parallax',
        ],
        'params' => array(
            'sections' => array(
                array(
                    'name'     => 'tab_layout',
                    'label'    => esc_html__( 'Layout', 'mouno' ),
                    'tab'      => 'layout',
                    'controls' => array_merge(
                        array(
                            array(
                                'name'     => 'post_type',
                                'type'     => 'hidden',
                                'options'  => mouno_get_post_type_options($post_type),
                                'default'  => 'service'
                            ),
                            array(
                                'name'     => 'layout_type',
                                'label'    => esc_html__( 'Layout Type', 'mouno' ),
                                'type'     => 'select',
                                'options'  => [
                                    'grid' => esc_html__('Grid', 'mouno'),
                                    'carousel' => esc_html__('Carousel', 'mouno'),
                                ],
                                'default'  => 'grid',
                            ),
                            array(
                                'name'     => 'layout3_style',
                                'label'    => esc_html__( 'Layout Style', 'mouno' ),
                                'type'     => 'select',
                                'options'  => [
                                    'layout-service-default' => esc_html__('Default', 'mouno'),
                                    'layout-service-style1' => esc_html__('Style 1', 'mouno'),
                                ],
                                'default'  => 'layout-service-default',
                                'condition' => [
                                    'layout_service' => ['service-3'],
                                ],
                            ),
                        ),
                        mouno_get_post_layout($post_type, []), 
                    ),
                ),
                 
                mouno_source_post_settings($post_type),

                array(
                    'name' => 'tab_display_opts',
                    'label' => esc_html__('Display', 'mouno' ),
                    'tab' => 'settings',
                    'controls' => array_merge(
                        image_dimension_options(),
                        array(
                            array(
                                'name' => 'title_tag',
                                'label' => esc_html__('Title HTML Tag', 'mouno'),
                                'type' => 'select',
                                'options' => [
                                    ''   => esc_html__('Default', 'mouno'),
                                    'h1' => esc_html__('H1', 'mouno'),
                                    'h2' => esc_html__('H2', 'mouno'),
                                    'h3' => esc_html__('H3', 'mouno'),
                                    'h4' => esc_html__('H4', 'mouno'),
                                    'h5' => esc_html__('H5', 'mouno'),
                                    'h6' => esc_html__('H6', 'mouno'),
                                    'div' => esc_html__('div', 'mouno'),
                                    'p'  => esc_html__('p', 'mouno'),
                                    'span' => esc_html__('span', 'mouno'),
                                ],
                                'default' => '',
                            ),
                            array(
                                'name' => 'service_active',
                                'label' => esc_html__('Post Active', 'mouno' ),
                                'type' => 'number',
                                'condition' => [
                                    'layout_service' => 'service-5',
                                ],
                            ),
                            array(
                                'name' => 'show_icon',
                                'label' => esc_html__('Show Icon', 'mouno' ),
                                'type' => 'switcher',
                                'default' => 'true',
                            ),
                            array(
                                'name' => 'show_features',
                                'label' => esc_html__('Show Features', 'mouno' ),
                                'type' => 'switcher',
                                'default' => 'true',
                                'condition' => [
                                    'layout_service' => ['service-5'],
                                ],
                            ),
                            array(
                                'name' => 'show_index',
                                'label' => esc_html__('Show Index', 'mouno' ),
                                'type' => 'switcher',
                                'default' => 'true',
                                'condition' => [
                                    'layout_service' => ['service-5', 'service-4'],
                                ],
                            ),
                            array(
                                'name' => 'show_excerpt',
                                'label' => esc_html__('Show Excerpt', 'mouno' ),
                                'type' => 'switcher',
                                'separator' => 'before',
                                'default' => 'true',
                            ),
                            array(
                                'name' => 'num_words',
                                'label' => esc_html__('Number of Words', 'mouno' ),
                                'type' => 'number',
                                'condition' => [
                                    'show_excerpt!' => '',
                                ],
                            ),
                            array(
                                'name' => 'show_btn',
                                'label' => esc_html__('Show Button', 'mouno' ),
                                'type' => 'switcher',
                                'separator' => 'before',
                                'default' => 'true',
                                'condition' => [
                                    'layout_service!' => ['service-5'],
                                ],
                            ),
                            array(
                                'name' => 'btn_text',
                                'label' => esc_html__('Button Text', 'mouno' ),
                                'type' => 'text',
                                'condition' => [
                                    'show_btn!' => '',
                                    'layout_service!' => ['service-5', 'service-3'],
                                ],
                            ),
                            array(
                                'name' => 'break_title_line',
                                'label' => esc_html__('Break Title Line', 'mouno' ),
                                'type' => 'switcher',
                                'separator' => 'before',
                                'default' => '',
                                'condition' => [
                                    'layout_service!' => ['service-5'],
                                ],
                            ),
                            array(
                                'name' => 'break_title_from',
                                'label' => esc_html__('Break Title From', 'mouno' ),
                                'type' => 'number',
                                'condition' => [
                                    'break_title_line!' => '',
                                    'layout_service!' => ['service-5'],
                                ],
                            ),
                        ),
                    ),
                ),
                array(
                    'name' => 'tab_grid_add_opts',
                    'label' => esc_html__('Additional Options', 'mouno' ),
                    'tab' => 'settings',
                    'condition' => ['layout_type' => 'grid'],
                    'controls' => grid_controls_options(
                        [ 
                            'filter' => true ,
                        ],
                    ),
                ),
                array(
                    'name' => 'tab_swiper_add_otps',
                    'label' => esc_html__('Addtional Options', 'mouno'),
                    'tab' => 'settings',
                    'condition' => ['layout_type' => 'carousel'],
                    'controls' => array(
                        array(
                            'name' => 'slide_row',
                            'label' => esc_html__('Row', 'mouno'),
                            'type' => 'select',
                            'options' => [
                                ''  => esc_html__('Default', 'mouno'),
                                '1' => '1',
                                '2' => '2',
                            ],
                            'default' => '',
                            'condition' => [
                                'layout_service' => ['service-1', 'service-3']
                            ],
                        ),
                        array(
                            'name' => 'col_spacing',
                            'label' => esc_html__('Column Spacing', 'mouno' ),
                            'type' => 'slider',
                            'control_type' => 'responsive',
                            'size_units' => [ 'px' ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-layout-service .swiper-slide' => 'gap: {{SIZE}}{{UNIT}};',
                            ],
                            'condition' => [
                                'slide_row' => '2',
                                'layout_service' => ['service-1', 'service-3']
                            ],
                        ),
                        array(
                            'name' => 'swiper_slide_height',
                            'label' => esc_html__('Slide Height', 'mouno'),
                            'type' => 'slider',
                            'size_units' => ['px', 'custom'],
                            'control_type' => 'responsive',
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 1000,
                                ],
                            ],
                            'default' => [
                                'size' => 200,
                                'unit' => 'px',
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-swiper .swiper-container.swiper-container-vertical .swiper-slide' => 'height: {{SIZE}}{{UNIT}} !important;',
                            ],
                            'description' => esc_html__('You need to set height for slide for slide to work.', 'mouno'),
                            'condition' => [
                                'layout_service' => ['service-2'],
                            ],
                        ),
                        swiper_controls_options(),
                    ),
                ),
                array(
                    'name' => 'tab_general_style',
                    'label' => esc_html__('General', 'mouno' ),
                    'tab' => 'style',
                    'controls' => array(
                        array(
                            'name' => 'icon_spacing_bottom',
                            'label' => esc_html__('Icon Spacing', 'mouno' ),
                            'type' => 'slider',
                            'control_type' => 'responsive',
                            'size_units' => [ 'px', '%'],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-layout-service1 .pxl-post-icon.pxl-main-icon, 
                                {{WRAPPER}} .pxl-layout-service .pxl-post-icon' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                            ],
                        ),
                        array(
                            'name' => 'title_spacing_b',
                            'label' => esc_html__('Title Spacing', 'mouno' ),
                            'type' => 'slider',
                            'control_type' => 'responsive',
                            'size_units' => [ 'px', 'custom'],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-layout-service .pxl-post-title' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                            ],
                        ),
                        array(
                            'name' => 'justify_content_h',
                            'label' => esc_html__('Justify Content', 'mouno' ),
                            'type' => 'choose',
                            'options' => [
                                'start' => [
                                    'title' => esc_html__('Start', 'mouno' ),
                                    'icon' => 'eicon-justify-start-h',
                                ],
                                'center' => [
                                    'title' => esc_html__('Center', 'mouno' ),
                                    'icon' => 'eicon-justify-center-h',
                                ],
                                'end' => [
                                    'title' => esc_html__('End', 'mouno' ),
                                    'icon' => 'eicon-justify-end-h',
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-layout-service .pxl-post-item' => 'justify-content: {{VALUE}};',
                            ],
                        ),
                        array(
                            'name' => 'content_max_w',
                            'label' => esc_html__('Content Max Width', 'mouno' ),
                            'type' => 'slider',
                            'control_type' => 'responsive',
                            'size_units' => [ 'px', '%'],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-layout-service .pxl-post-inner' => 'max-width: {{SIZE}}{{UNIT}};'
                            ],
                            'condition' => [
                                'layout_service' => ['service-3', 'service-4']
                            ]
                        ),
                        // array(
                        //     'name' => 'content_padding',
                        //     'label' => esc_html__('Content Padding', 'mouno' ),
                        //     'type' => 'dimensions',
                        //     'size_units' => [ 'px', 'custom'],
                        //     'control_type' => 'responsive',
                        //     'separator' => 'before',
                        //     'selectors' => [
                        //         '{{WRAPPER}} .pxl-layout-service .pxl-post-inner' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                        //     ],
                        // ),
                        array(
                            'name' => 'divider_color',
                            'type' => \Elementor\Group_Control_Background::get_type(),
                            'control_type' => 'group',
                            'types' => [ 'classic', 'gradient' ],
                            'condition' => [
                                'layout_service' => ['service-2', 'service-3', 'service-4'],
                            ],
                            'selector' => '{{WRAPPER}} .pxl-layout-service .pxl-post-item::after',
                            'fields_options' => [
                                'background' => [
                                    'label' => __( 'Divider Color', 'mouno' ),
                                ],
                                'color' => [
                                    'selectors' => [
                                        '{{WRAPPER}} .pxl-layout-service .pxl-grid-item + .pxl-grid-item .pxl-post-item, 
                                        {{WRAPPER}} .pxl-layout-service .swiper-slide + .swiper-slide .pxl-post-item' => 'border-color: {{VALUE}};',
                                    ],
                                ],
                            ],
                        ),
                    ),
                ),
                array(
                    'name' => 'tab_box_style',
                    'label' => esc_html__('Box', 'mouno' ),
                    'tab' => 'style',
                    'controls' => array(
                        array(
                            'name' => 'box_min_h',
                            'label' => esc_html__('Min Height', 'mouno' ),
                            'type' => 'slider',
                            'control_type' => 'responsive',
                            'size_units' => [ 'px', 'custom'],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-layout-service:not(.pxl-layout-service5) .pxl-post-item,
                                {{WRAPPER}} .pxl-layout-service5 .pxl-post-header' => 'min-height: {{SIZE}}{{UNIT}};'
                            ],
                        ),
                        array(
                            'name' => 'box_controls',
                            'control_type' => 'tab',
                            'tabs' => [
                                [
                                    'name' => 'box_normal',
                                    'label' => esc_html__('Normal', 'mouno' ),
                                    'type' => 'tab',
                                    'controls' => [  
                                        array(
                                            'name' => 'box_bg',
                                            'type' => \Elementor\Group_Control_Background::get_type(),
                                            'control_type' => 'group',
                                            'types' => [ 'classic', 'gradient' ],
                                            'selector' => '{{WRAPPER}} .pxl-layout-service:not(.pxl-layout-service5) .pxl-post-item,
                                            {{WRAPPER}} .pxl-layout-service5 .pxl-post-header',
                                        ),
                                        array(
                                            'name' => 'box_border',
                                            'type' => \Elementor\Group_Control_Border::get_type(),
                                            'separator' => 'before',
                                            'control_type' => 'group', 
                                            'selector' => '{{WRAPPER}} .pxl-layout-service:not(.pxl-layout-service5) .pxl-post-item,
                                                {{WRAPPER}} .pxl-layout-service5 .pxl-post-header',
                                        ),
                                        array(
                                            'name'         => 'box_box_shadow',
                                            'label' => esc_html__( 'Box Shadow', 'mouno' ),
                                            'type'         => \Elementor\Group_Control_Box_Shadow::get_type(),
                                            'control_type' => 'group',
                                            'selector'     => '{{WRAPPER}} .pxl-layout-service:not(.pxl-layout-service5) .pxl-post-item,
                                                {{WRAPPER}} .pxl-layout-service5 .pxl-post-header',
                                        ),
                                        array(
                                            'name' => 'box_border_radius',
                                            'label' => esc_html__('Border Radius', 'mouno' ),
                                            'type' => 'dimensions',
                                            'control_type' => 'responsive',
                                            'size_units' => [ 'px', 'custom' ],
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-layout-service:not(.pxl-layout-service5) .pxl-post-item,
                                                {{WRAPPER}} .pxl-layout-service5 .pxl-post-header' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'box_padding',
                                            'label' => esc_html__('Padding', 'mouno' ),
                                            'type' => 'dimensions',
                                            'size_units' => [ 'px', 'custom' ],
                                            'control_type' => 'responsive',
                                            'separator' => 'before',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-layout-service:not(.pxl-layout-service5) .pxl-post-item,
                                                {{WRAPPER}} .pxl-layout-service5 .pxl-post-header' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                    ],
                                ],
                                [
                                    'name' => 'box_hover',
                                    'label' => esc_html__('Hover/Active', 'mouno' ),
                                    'type' => 'tabs',
                                    'controls' => [
                                        array(
                                            'name' => 'box_hover_style',
                                            'label' => esc_html__('Hover Style', 'mouno'),
                                            'type' => 'select',
                                            'options' => [
                                                'hover-box-default' => esc_html__('Default', 'mouno'), 
                                                'hover-rotate3d-direction' => esc_html__('Rotate by Direction', 'mouno'), 
                                                'hover-translate3d-direction' => esc_html__('Translate by Direction', 'mouno'), 
                                                'hover-box-shadow-underfoot'    => esc_html__('Shadow Underfoot', 'mouno'),
                                            ],
                                            'default' => 'hover-box-default',
                                        ),
                                        array(
                                            'name' => 'direction_hover',
                                            'label' => esc_html__('Direction Hover', 'mouno'),
                                            'type' => 'select',
                                            'options' => [
                                                'all' => esc_html__('All Direction', 'mouno'), 
                                                'vertical' => esc_html__('Only Vertical', 'mouno'), 
                                                'horizontal' => esc_html__('Only Horizontal', 'mouno'), 
                                            ],
                                            'condition' => [
                                                'box_hover_style' => ['hover-rotate3d-direction', 'hover-translate3d-direction'],
                                            ],
                                            'default' => 'all',
                                        ),
                                        array(
                                            'name' => 'box_hover_bg',
                                            'type' => \Elementor\Group_Control_Background::get_type(),
                                            'control_type' => 'group',
                                            'types' => [ 'classic', 'gradient' ],
                                            'selector' => '{{WRAPPER}} .pxl-layout-service:not(.pxl-layout-service4):not(.pxl-layout-service2):not(.pxl-layout-service5) .pxl-post-item:not(.hover-rotate3d-direction):not(.hover-translate3d-direction):hover,
                                            {{WRAPPER}} .pxl-layout-service4 .item-hover:after,
                                            {{WRAPPER}} .pxl-layout-service .pxl-post-item .direction-item,
                                            {{WRAPPER}} .pxl-layout-service5 .pxl-post-item:hover .pxl-post-header,
                                            {{WRAPPER}} .pxl-layout-service5 .pxl-post-item.active .pxl-post-header',
                                        ),
                                        array(
                                            'name' => '_box_hover_border_color',
                                            'label' => esc_html__('Border Color', 'mouno' ),
                                            'type' => 'color',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-layout-service:not(.pxl-layout-service4):not(.pxl-layout-service5) .pxl-post-item:hover,
                                                {{WRAPPER}} .pxl-layout-service5 .pxl-post-item:hover .pxl-post-header,
                                                {{WRAPPER}} .pxl-layout-service5 .pxl-post-item.active .pxl-post-header' => 'border-color: {{VALUE}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'box_hover_border',
                                            'type' => \Elementor\Group_Control_Border::get_type(),
                                            'separator' => 'before',
                                            'control_type' => 'group', 
                                            'selector' => '{{WRAPPER}} .pxl-layout-service:not(.pxl-layout-service4):not(.pxl-layout-service5) .pxl-post-item:hover,
                                                {{WRAPPER}} .pxl-layout-service5 .pxl-post-item:hover .pxl-post-header,
                                                {{WRAPPER}} .pxl-layout-service5 .pxl-post-item.active .pxl-post-header',
                                        ),
                                        array(
                                            'name'         => 'box_hover_box_shadow',
                                            'label' => esc_html__( 'Box Shadow', 'mouno' ),
                                            'type'         => \Elementor\Group_Control_Box_Shadow::get_type(),
                                            'control_type' => 'group',
                                            'selector'     => '{{WRAPPER}} .pxl-layout-service:not(.pxl-layout-service4):not(.pxl-layout-service5) .pxl-post-item:hover,
                                                {{WRAPPER}} .pxl-layout-service5 .pxl-post-item:hover .pxl-post-header,
                                                {{WRAPPER}} .pxl-layout-service5 .pxl-post-item.active .pxl-post-header',
                                        ),
                                        array(
                                            'name' => 'box_hover_border_radius',
                                            'label' => esc_html__('Border Radius', 'mouno' ),
                                            'type' => 'dimensions',
                                            'size_units' => [ 'px', '%', 'custom' ],
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-layout-service:not(.pxl-layout-portfolio3):not(.pxl-layout-portfolio4):not(.pxl-layout-portfolio5) .pxl-post-item:hover, 
                                                {{WRAPPER}} .pxl-layout-service5 .pxl-post-item:hover .pxl-post-header,
                                                {{WRAPPER}} .pxl-layout-service5 .pxl-post-item.active .pxl-post-header' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'box_hover_padding',
                                            'label' => esc_html__('Padding', 'mouno' ),
                                            'type' => 'dimensions',
                                            'size_units' => [ 'px', '%', 'custom' ],
                                            'control_type' => 'responsive',
                                            'separator' => 'before',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-layout-service:not(.pxl-layout-service4):not(.pxl-layout-service5) .pxl-post-item:hover,
                                                {{WRAPPER}} .pxl-layout-service5 .pxl-post-item:hover .pxl-post-header,
                                                {{WRAPPER}} .pxl-layout-service5 .pxl-post-item.active .pxl-post-header' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                    ],
                                ],
                            ],
                        ),
                    ),
                ),
                
                array(
                    'name'     => 'tab_icon_style',
                    'label'    => esc_html__('Icon', 'mouno' ),
                    'tab'      => 'style',
                    'controls' => array(
                        array(
                            'name' => 'icon_size',
                            'label' => esc_html__('Icon Size', 'mouno' ),
                            'type' => 'slider',
                            'control_type' => 'responsive',
                            'size_units' => [ 'px', '%'],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-layout-service1 .pxl-post-icon.pxl-main-icon' => 'font-size: {{SIZE}}{{UNIT}};',
                                '{{WRAPPER}} .pxl-layout-service1 .pxl-post-icon.pxl-main-icon svg' => 'width: auto; height: {{SIZE}}{{UNIT}};',
                                '{{WRAPPER}} .pxl-layout-service .pxl-post-icon' => 'font-size: {{SIZE}}{{UNIT}};',
                                '{{WRAPPER}} .pxl-layout-service .pxl-post-icon svg' => 'width: auto; height: {{SIZE}}{{UNIT}};'
                            ],
                        ),
                        array(
                            'name' => 'icon_box_sz',
                            'label' => esc_html__('Box Size', 'mouno' ),
                            'type' => 'slider',
                            'control_type' => 'responsive',
                            'size_units' => [ 'px', 'custom'],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-layout-service .pxl-post-icon:not(.pxl-sub-icon) .pxl-icon' => '--pxl-box-size: {{SIZE}}{{UNIT}};',
                            ],
                        ),
                        array(
                            'name' => 'icon_controls',
                            'control_type' => 'tab',
                            'tabs' => [
                                [
                                    'name' => 'icon_normal',
                                    'label' => esc_html__('Normal', 'mouno' ),
                                    'type' => 'tab',
                                    'controls' => [  
                                        array(
                                            'name' => 'icon_color',
                                            'label' => esc_html('Icon Color', 'mouno'),
                                            'type' => 'color',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-layout-service .pxl-post-icon' => 'color: {{VALUE}}',
                                            ],
                                        ),
                                        array(
                                            'name' => 'icon_color2',
                                            'label' => esc_html('Icon Color 2', 'mouno'),
                                            'type' => 'color',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-layout-service .pxl-post-icon' => '--svg-color: {{VALUE}}',
                                            ],
                                            'description' => esc_html__('Use when svg has 2 different colors', 'mouno'),
                                        ),
                                        array(
                                            'name' => 'icon_bg',
                                            'type' => \Elementor\Group_Control_Background::get_type(),
                                            'control_type' => 'group',
                                            'types' => [ 'classic', 'gradient' ],
                                            'selector' => '{{WRAPPER}} .pxl-layout-service .pxl-post-icon .pxl-icon',
                                            'fields_options' => [
                                                'background' => [
                                                    'label' => __( 'Background', 'mouno' ),
                                                ],
                                            ],
                                        ),
                                        array(
                                            'name' => 'icon_border',
                                            'type' => \Elementor\Group_Control_Border::get_type(),
                                            'separator' => 'before',
                                            'control_type' => 'group', 
                                            'selector' => '{{WRAPPER}} .pxl-layout-service .pxl-post-icon .pxl-icon',
                                        ),
                                        array(
                                            'name'         => 'icon_box_shadow',
                                            'label' => esc_html__( 'Box Shadow', 'mouno' ),
                                            'type'         => \Elementor\Group_Control_Box_Shadow::get_type(),
                                            'control_type' => 'group',
                                            'selector'     => '{{WRAPPER}} .pxl-layout-service .pxl-post-icon .pxl-icon',
                                        ),
                                        array(
                                            'name' => 'icon_border_radius',
                                            'label' => esc_html__('Border Radius', 'mouno' ),
                                            'type' => 'dimensions',
                                            'size_units' => [ 'px', '%' ],
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-layout-service .pxl-post-icon .pxl-icon' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'icon_padding',
                                            'label' => esc_html__('Padding', 'mouno' ),
                                            'type' => 'dimensions',
                                            'size_units' => [ 'px', '%' ],
                                            'control_type' => 'responsive',
                                            'separator' => 'before',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-layout-service .pxl-post-icon .pxl-icon' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                    ],
                                ],
                                [
                                    'name' => 'icon_hover',
                                    'label' => esc_html__('Hover/Active', 'mouno' ),
                                    'type' => 'tab',
                                    'controls' => [  
                                        array(
                                            'name' => 'icon_hover_anim',
                                            'label' => esc_html__('Hover Animation', 'mouno'),
                                            'type' => 'select',
                                            'options' => [
                                                '' => esc_html__('None', 'mouno'), 
                                                'hover-animation-flipX' => esc_html__('Flip X', 'mouno'), 
                                                'hover-animation-flipY' => esc_html__('Flip Y', 'mouno'), 
                                                'hover-animation-shrink-expand' => esc_html__('Shrink & Expand', 'mouno'), 
                                                'hover-animation-grow-normalize' => esc_html__('Grow & Normalize', 'mouno'), 
                                            ],
                                        ),
                                        array(
                                            'name' => 'icon_hover_color',
                                            'label' => esc_html('Icon Color', 'mouno'),
                                            'type' => 'color',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-layout-service:not(.pxl-layout-service4) .pxl-post-item:hover .pxl-post-icon,
                                                {{WRAPPER}} .pxl-layout-service:not(.pxl-layout-service4) .pxl-post-item.active .pxl-post-icon' => 'color: {{VALUE}}',
                                            ],
                                        ),
                                        array(
                                            'name' => 'icon_hover_color2',
                                            'label' => esc_html('Icon Color 2', 'mouno'),
                                            'type' => 'color',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-layout-service:not(.pxl-layout-service4) .pxl-post-item:hover .pxl-post-icon,
                                                {{WRAPPER}} .pxl-layout-service:not(.pxl-layout-service4) .pxl-post-item.active .pxl-post-icon' => '--svg-color: {{VALUE}}',
                                            ],
                                            'description' => esc_html__('Use when svg has 2 different colors', 'mouno'),
                                        ),
                                        array(
                                            'name' => 'icon_hover_bg',
                                            'type' => \Elementor\Group_Control_Background::get_type(),
                                            'control_type' => 'group',
                                            'types' => [ 'classic', 'gradient' ],
                                            'selector' => '{{WRAPPER}} .pxl-layout-service .pxl-post-icon .pxl-icon:before',
                                            'fields_options' => [
                                                'background' => [
                                                    'label' => __( 'Background', 'mouno' ),
                                                ],
                                                'color' => [
                                                    'selectors' => [
                                                        '{{WRAPPER}} .pxl-layout-service:not(.pxl-layout-service4) .pxl-post-item:hover .pxl-post-icon .pxl-icon,
                                                        {{WRAPPER}} .pxl-layout-service:not(.pxl-layout-service4) .pxl-post-item.active .pxl-post-icon .pxl-icon' => 'background-color: {{VALUE}};',
                                                    ],
                                                ],
                                            ],
                                        ),
                                        array(
                                            'name' => 'icon_hover_border',
                                            'type' => \Elementor\Group_Control_Border::get_type(),
                                            'separator' => 'before',
                                            'control_type' => 'group', 
                                            'selector' => '{{WRAPPER}} .pxl-layout-service:not(.pxl-layout-service4) .pxl-post-item:hover .pxl-post-icon .pxl-icon, 
                                            {{WRAPPER}} .pxl-layout-service:not(.pxl-layout-service4) .pxl-post-item.active .pxl-post-icon .pxl-icon',
                                        ),
                                        array(
                                            'name'         => 'icon_hover_box_shadow',
                                            'label' => esc_html__( 'Box Shadow', 'mouno' ),
                                            'type'         => \Elementor\Group_Control_Box_Shadow::get_type(),
                                            'control_type' => 'group',
                                            'selector'     => '{{WRAPPER}} .pxl-layout-service:not(.pxl-layout-service4) .pxl-post-item:hover .pxl-post-icon .pxl-icon,
                                            {{WRAPPER}} .pxl-layout-service:not(.pxl-layout-service4) .pxl-post-item.active .pxl-post-icon .pxl-icon',
                                        ),
                                        array(
                                            'name' => 'icon_hover_border_radius',
                                            'label' => esc_html__('Border Radius', 'mouno' ),
                                            'type' => 'dimensions',
                                            'size_units' => [ 'px', '%' ],
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-layout-service:not(.pxl-layout-service4) .pxl-post-item:hover .pxl-post-icon .pxl-icon,
                                                {{WRAPPER}} .pxl-layout-service:not(.pxl-layout-service4) .pxl-post-item.active .pxl-post-icon .pxl-icon' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'icon_hover_padding',
                                            'label' => esc_html__('Padding', 'mouno' ),
                                            'type' => 'dimensions',
                                            'size_units' => [ 'px', '%' ],
                                            'control_type' => 'responsive',
                                            'separator' => 'before',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-layout-service:not(.pxl-layout-service4) .pxl-post-item:hover .pxl-post-icon .pxl-icon,
                                                {{WRAPPER}} .pxl-layout-service:not(.pxl-layout-service4) .pxl-post-item.active .pxl-post-icon .pxl-icon' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                    ],
                                ],
                            ],
                        ),
                    ),
                ),
                array(
                    'name'     => 'tab_subicon_style',
                    'label'    => esc_html__( 'Subicon', 'mouno' ),
                    'tab'      => 'style',
                    'condition' => [
                        'layout_service' => 'service-1',
                    ],
                    'controls' => array(
                        array(
                            'name' => 'subicon_size',
                            'label' => esc_html__('Icon Size', 'mouno' ),
                            'control_type' => 'responsive',
                            'type' => 'number',
                            'min' => 1,
                            'max' => 10,
                            'description' => esc_html__('Size ratio compared to main icon.', 'mouno'),
                            'selectors' => [
                                '{{WRAPPER}} .pxl-layout-service1 .pxl-post-icon.pxl-sub-icon svg' => 'scale: {{VALUE}};'
                            ],
                        ),
                        array(
                            'name' => 'subicon_controls',
                            'control_type' => 'tab',
                            'tabs' => [
                                [
                                    'name' => 'subicon_normal',
                                    'label' => esc_html__('Normal', 'mouno' ),
                                    'type' => 'tab',
                                    'controls' => [  
                                        array(
                                            'name' => 'subicon_color',
                                            'label' => esc_html('Icon Color', 'mouno'),
                                            'type' => 'color',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-layout-service1 .pxl-post-icon.pxl-sub-icon' => 'color: {{VALUE}}',
                                            ],
                                        ),
                                    ],
                                ],
                                [
                                    'name' => 'subicon_hover',
                                    'label' => esc_html__('Hover/Active', 'mouno' ),
                                    'type' => 'tab',
                                    'controls' => [  
                                        array(
                                            'name' => 'subicon_hover_color',
                                            'label' => esc_html('Icon Color', 'mouno'),
                                            'type' => 'color',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-layout-service1 .pxl-post-item:hover .pxl-post-icon.pxl-sub-icon' => 'color: {{VALUE}}',
                                            ],
                                        ),
                                    ],
                                ],
                            ],
                        ),
                    ),
                ),
                array(
                    'name' => 'tab_title_style',
                    'label' => esc_html__('Title', 'mouno' ),
                    'tab' => 'style',
                    'controls' => array_merge(
                        array(
                            array(
                                'name' => 'title_typography',
                                'type' => \Elementor\Group_Control_Typography::get_type(),
                                'control_type' => 'group',
                                'selector' => '{{WRAPPER}} .pxl-layout-service .pxl-post-title',
                            ),
                            array(
                                'name' => 'title_controls',
                                'control_type' => 'tab',
                                'tabs' => [
                                    [
                                        'name' => 'title_normal',
                                        'label' => esc_html__('Normal', 'mouno' ),
                                        'type' => 'tab',
                                        'controls' => [  
                                            array(
                                                'name' => 'title_color',
                                                'label' => esc_html__('Text Color', 'mouno' ),
                                                'type' => 'color',
                                                'selectors' => [
                                                    '{{WRAPPER}} .pxl-layout-service .pxl-post-title, 
                                                    {{WRAPPER}} .pxl-layout-service .pxl-post-title.hover-3d-cube-flip:before' => 'color: {{VALUE}};',
                                                ],
                                            ),
                                            array(
                                                'name' => 'title_stroke',
                                                'type' => \Elementor\Group_Control_Text_Stroke::get_type(),
                                                'control_type' => 'group',
                                                'selector' => '{{WRAPPER}} .pxl-layout-service .pxl-post-title',
                                            ),
                                            array(
                                                'name' => 'title_text_shadow',
                                                'type' => \Elementor\Group_Control_Text_Shadow::get_type(),
                                                'control_type' => 'group',
                                                'selector' => '{{WRAPPER}} .pxl-layout-service .pxl-post-title',
                                            ),
                                        ],
                                    ],
                                    [
                                        'name' => 'title_hover',
                                        'label' => esc_html__('Hover/Active', 'mouno' ),
                                        'type' => 'tab',
                                        'controls' => [
                                            array(
                                                'name' => 'title_hover_style',
                                                'label' => esc_html__('Hover Style', 'mouno' ),
                                                'type' => 'select',
                                                'groups' => [
                                                    [
                                                        'label' => esc_html__('Default', 'mouno'),
                                                        'options' => [
                                                            'hover-text-default' => esc_html__('Default', 'mouno'),
                                                        ],
                                                    ],
                                                    [
                                                        'label' => esc_html__('Underline', 'mouno'),
                                                        'options' => [
                                                            'hover-text-underline' => esc_html__('Underline', 'mouno'),
                                                            'hover-text-underline--slide-ltr' => esc_html__('Slide LTR', 'mouno'),
                                                            'hover-text-underline--slide-rtl' => esc_html__('Slide RTL', 'mouno'),
                                                        ],
                                                    ],
                                                    [
                                                        'label' => esc_html__('Other', 'mouno'),
                                                        'options' => [
                                                            'hover-3d-cube-flip' => esc_html__('3D Flip', 'mouno'),
                                                            'hover-text-fill' => esc_html__('Text Fill', 'mouno'),
                                                        ],
                                                    ],
                                                ],
                                                'default' => 'hover-text-default',
                                                'condition' => [
                                                    'layout_service!' => ['service-4'],
                                                ],
                                            ),
                                            array(
                                                'name' => 'underline_h',
                                                'label' => esc_html__('Underline Weight(px)', 'mouno'),
                                                'type' => 'slider',
                                                'size_units' => ['px'],
                                                'selectors' => [
                                                    '{{WRAPPER}} .pxl-layout-service .pxl-post-title' => "--pxl-height: {{SIZE}}{{UNIT}};",
                                                ],
                                                'condition' => [
                                                    'title_hover_style' => ['hover-text-underline', 'hover-text-underline--slide-ltr', 'hover-text-underline--slide-rtl'],
                                                ],
                                            ),
                                            array(
                                                'name' => 'title_divider',
                                                'type' => 'divider',
                                                'condition' => [
                                                    'layout_service!' => ['service-4'],
                                                ],
                                            ),
                                            array(
                                                'name' => 'title_hover_color',
                                                'label' => esc_html__('Text Color', 'mouno' ),
                                                'type' => 'color',
                                                'selectors' => [
                                                    '{{WRAPPER}} .pxl-layout-service:not(.pxl-layout-service4) .pxl-post-item:hover .pxl-post-title:not(.hover-3d-cube-flip):not(.hover-text-fill),
                                                    {{WRAPPER}} .pxl-layout-service .pxl-post-item.active .pxl-post-title:not(.hover-3d-cube-flip):not(.hover-text-fill),
                                                    {{WRAPPER}} .pxl-layout-service .pxl-post-title.hover-3d-cube-flip:after,
                                                    {{WRAPPER}} .pxl-layout-service4 .item-hover .pxl-post-title' => 'color: {{VALUE}};',
                                                    '{{WRAPPER}} .pxl-layout-service .pxl-post-item .hover-text-fill'   => '--link-color-hover: {{VALUE}};',
                                                ],
                                            ),
                                            array(
                                                'name' => 'title_hover_stroke',
                                                'type' => \Elementor\Group_Control_Text_Stroke::get_type(),
                                                'control_type' => 'group',
                                                'selector' => '{{WRAPPER}} .pxl-layout-service:not(.pxl-layout-service4) .pxl-post-item:hover .pxl-post-title,
                                                {{WRAPPER}} .pxl-layout-service4 .item-hover .pxl-post-title,
                                                {{WRAPPER}} .pxl-layout-service .pxl-post-item.active .pxl-post-title',
                                            ),
                                            array(
                                                'name' => 'title_hover_text_shadow',
                                                'type' => \Elementor\Group_Control_Text_Shadow::get_type(),
                                                'control_type' => 'group',
                                                'selector' => '{{WRAPPER}} .pxl-layout-service .pxl-post-item:hover .pxl-post-title,
                                                {{WRAPPER}} .pxl-layout-service4 .item-hover .pxl-post-title,
                                                {{WRAPPER}} .pxl-layout-service .pxl-post-item.active .pxl-post-title',
                                            ),
                                        ],
                                    ],
                                ],
                            ),
                        ),
                    ),
                ),

                array(
                    'name' => 'tab_excerpt_style',
                    'label' => esc_html__('Excerpt', 'mouno' ),
                    'tab' => 'style',
                    'condition' => [
                        'show_excerpt!' => '',
                    ],
                    'controls' => array(
                        array(
                            'name' => 'excerpt_typography',
                            'type' => \Elementor\Group_Control_Typography::get_type(),
                            'control_type' => 'group',
                            'selector' => '{{WRAPPER}} .pxl-layout-service .pxl-post-excerpt',
                        ),
                        array(
                            'name' => 'excerpt_controls',
                            'control_type' => 'tab',
                            'tabs' => [
                                [
                                    'name' => 'excerpt_normal',
                                    'label' => esc_html__('Normal', 'mouno' ),
                                    'type' => 'tab',
                                    'controls' => [  
                                        array(
                                            'name' => 'excerpt_color',
                                            'label' => esc_html__('Text Color', 'mouno' ),
                                            'type' => 'color',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-layout-service .pxl-post-excerpt' => 'color: {{VALUE}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'excerpt_text_shadow',
                                            'type' => \Elementor\Group_Control_Text_Shadow::get_type(),
                                            'control_type' => 'group',
                                            'selector' => '{{WRAPPER}} .pxl-layout-service .pxl-post-excerpt',
                                        ),
                                    ],
                                ],
                                [
                                    'name' => 'excerpt_hover',
                                    'label' => esc_html__('Hover/Active', 'mouno' ),
                                    'type' => 'tab',
                                    'controls' => [  
                                        array(
                                            'name' => 'excerpt_hover_color',
                                            'label' => esc_html__('Text Color', 'mouno' ),
                                            'type' => 'color',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-layout-service:not(.pxl-layout-service4) .pxl-post-item:hover .pxl-post-excerpt, 
                                                {{WRAPPER}} .pxl-layout-service4 .item-hover .pxl-post-excerpt,
                                                {{WRAPPER}} .pxl-layout-service .pxl-post-item.active .pxl-post-excerpt' => 'color: {{VALUE}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'excerpt_hover_text_shadow',
                                            'type' => \Elementor\Group_Control_Text_Shadow::get_type(),
                                            'control_type' => 'group',
                                            'selector' => '{{WRAPPER}} .pxl-layout-service:not(.pxl-layout-service4) .pxl-post-item:hover .pxl-post-excerpt, 
                                                {{WRAPPER}} .pxl-layout-service4 .item-hover .pxl-post-excerpt,
                                                {{WRAPPER}} .pxl-layout-service .pxl-post-item.active .pxl-post-excerpt',
                                        ),
                                    ],
                                ],
                            ],
                        ),
                    ),
                ),
                array(
                    'name' => 'tab_btn_style',
                    'label' => esc_html__('Button', 'mouno' ),
                    'tab' => 'style',
                    'condition' => [
                        'show_btn!' => '',
                        'layout_service!' => ['service-5']
                    ],
                    'controls' => array(
                        array(
                            'name' => 'btn_box_size',
                            'label' => esc_html__('Box Size', 'mouno' ),
                            'type' => 'slider',
                            'size_units' => ['px', 'custom'],
                            'control_type' => 'responsive',
                            'selectors' => [
                                '{{WRAPPER}} .pxl-layout-service .pxl-post-btn' => '--pxl-box-size: {{SIZE}}{{UNIT}};',
                            ],
                            'condition' => [
                                'layout_portfolio' => ['portfolio-4'],
                            ],
                        ),
                        array(
                            'name' => 'btn_h',
                            'label' => esc_html__('Height', 'mouno' ),
                            'type' => 'slider',
                            'size_units' => ['px', '%', 'custom'],
                            'control_type' => 'responsive',
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 1000,
                                ],
                            ],
                            'condition' => [
                                'layout_portfolio!' => ['portfolio-4'],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-layout-service .pxl-post-btn' => 'height: {{SIZE}}{{UNIT}};--pxl-height: {{SIZE}}{{UNIT}};',
                            ],
                        ),
                        array(
                            'name' => 'btn_icon_sz',
                            'label' => esc_html__('Icon Size', 'mouno' ),
                            'type' => 'slider',
                            'size_units' => ['px', '%', 'custom'],
                            'control_type' => 'responsive',
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 1000,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-layout-service .pxl-post-btn i ' => 'font-size: {{SIZE}}{{UNIT}};',
                                '{{WRAPPER}} .pxl-layout-service .pxl-post-btn svg' => 'width: {{SIZE}}{{UNIT}}; height: auto;',
                            ],
                        ),
                        array(
                            'name' => 'btn_typography',
                            'type' => \Elementor\Group_Control_Typography::get_type(),
                            'control_type' => 'group',
                            'selector' => '{{WRAPPER}} .pxl-layout-service .pxl-post-btn',
                        ),
                        array(
                            'name' => 'btn_text_shadow',
                            'label' => esc_html__('Text Shadow', 'mouno' ),
                            'type' => \Elementor\Group_Control_Text_Shadow::get_type(),
                            'control_type' => 'group',
                            'selector' => '{{WRAPPER}} .pxl-layout-service .pxl-post-btn',
                        ),
                        array(
                            'name' => 'btn_control',
                            'control_type' => 'tab',
                            'tabs' => [
                                [
                                    'name' => 'btn_normal',
                                    'label' => esc_html__('Normal', 'mouno' ),
                                    'type' => 'tab',
                                    'controls' => [  
                                        array(
                                            'name' => 'btn_color',
                                            'label' => esc_html__('Text Color', 'mouno' ),
                                            'type' => 'color',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-layout-service .pxl-post-btn' => 'color: {{VALUE}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'btn_icon_color',
                                            'label' => esc_html__('Icon Color', 'mouno' ),
                                            'type' => 'color',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-layout-service .pxl-post-btn .pxl-btn-icon' => 'color: {{VALUE}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'btn_bg',
                                            'type' => \Elementor\Group_Control_Background::get_type(),
                                            'control_type' => 'group',
                                            'types' => [ 'classic', 'gradient' ],
                                            'selector' => '{{WRAPPER}} .pxl-layout-service .pxl-post-btn:not(.pxl-btn-split), 
                                            {{WRAPPER}} .pxl-layout-service .pxl-post-btn.pxl-btn-split .pxl-btn-icon, 
                                            {{WRAPPER}} .pxl-layout-service .pxl-post-btn.pxl-btn-split .pxl-btn-text',
                                        ),
                                        array(
                                            'name' => 'btn_border',
                                            'type' => \Elementor\Group_Control_Border::get_type(),
                                            'separator' => 'before',
                                            'control_type' => 'group', 
                                            'selector' => '{{WRAPPER}} .pxl-layout-service .pxl-post-btn:not(.pxl-btn-split), 
                                            {{WRAPPER}} .pxl-layout-service .pxl-post-btn.pxl-btn-split .pxl-btn-icon, 
                                            {{WRAPPER}} .pxl-layout-service .pxl-post-btn.pxl-btn-split .pxl-btn-text',
                                        ),
                                        array(
                                            'name'         => 'btn_box_shadow',
                                            'label' => esc_html__( 'Box Shadow', 'mouno' ),
                                            'type'         => \Elementor\Group_Control_Box_Shadow::get_type(),
                                            'control_type' => 'group',
                                            'selector'     => '{{WRAPPER}} .pxl-layout-service .pxl-post-btn:not(.pxl-btn-split),
                                                {{WRAPPER}} .pxl-layout-service .pxl-post-btn.pxl-btn-split .pxl-btn-text,
                                                {{WRAPPER}} .pxl-layout-service .pxl-post-btn.pxl-btn-split .pxl-btn-icon',
                                        ),
                                        array(
                                            'name' => 'btn_border_radius',
                                            'label' => esc_html__('Border Radius', 'mouno' ),
                                            'type' => 'dimensions',
                                            'size_units' => [ 'px', '%' ],
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-layout-service .pxl-post-btn:not(.pxl-btn-split),
                                                {{WRAPPER}} .pxl-layout-service .pxl-post-btn.pxl-btn-split .pxl-btn-text,
                                                {{WRAPPER}} .pxl-layout-service .pxl-post-btn.pxl-btn-split .pxl-btn-icon' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'btn_padding',
                                            'label' => esc_html__('Padding', 'mouno' ),
                                            'type' => 'dimensions',
                                            'size_units' => [ 'px', '%' ],
                                            'control_type' => 'responsive',
                                            'separator' => 'before',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-layout-service .pxl-post-btn:not(.pxl-btn-split), 
                                                {{WRAPPER}} .pxl-layout-service .pxl-post-btn.pxl-btn-split .pxl-btn-text' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                    ],
                                ],
                                [
                                    'name' => 'btn_hover',
                                    'label' => esc_html__('Hover', 'mouno' ),
                                    'type' => 'tab',
                                    'controls' => [
                                        array(
                                            'name' => 'btn_hover_color',
                                            'label' => esc_html__('Text Color', 'mouno' ),
                                            'type' => 'color',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-layout-service .pxl-post-btn:hover, 
                                                {{WRAPPER}} .pxl-layout-service .hover-parent:hover .pxl-post-btn' => 'color: {{VALUE}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'btn_hover_icon_color',
                                            'label' => esc_html__('Icon Color', 'mouno' ),
                                            'type' => 'color',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-layout-service .pxl-post-btn:hover .pxl-btn-icon,
                                                {{WRAPPER}} .pxl-layout-service .hover-parent:hover .pxl-post-btn .pxl-btn-icon' => 'color: {{VALUE}};',
                                            ],
                                        ),
                                        array(
                                            'name' => '_btn_hover_border_color',
                                            'label' => esc_html__('Border Color', 'mouno' ),
                                            'type' => 'color',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-layout-service .pxl-post-btn:not(.pxl-btn-split):hover,
                                                {{WRAPPER}} .pxl-layout-service .pxl-post-btn.pxl-btn-split:hover .pxl-btn-icon, 
                                                {{WRAPPER}} .pxl-layout-service .pxl-post-btn.pxl-btn-split:hover .pxl-btn-text,
                                                {{WRAPPER}} .pxl-layout-service .hover-parent:hover .pxl-post-btn:not(.pxl-btn-split),
                                                {{WRAPPER}} .pxl-layout-service .hover-parent:hover .pxl-post-btn.pxl-btn-split .pxl-btn-icon, 
                                                {{WRAPPER}} .pxl-layout-service .hover-parent:hover .pxl-post-btn.pxl-btn-split .pxl-btn-text' => 'border-color: {{VALUE}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'btn_hover_bg',
                                            'type' => \Elementor\Group_Control_Background::get_type(),
                                            'control_type' => 'group',
                                            'types' => [ 'classic', 'gradient' ],
                                            'selector' => '{{WRAPPER}} .pxl-layout-service .pxl-post-btn:not(.pxl-btn-split):hover, 
                                            {{WRAPPER}} .pxl-layout-service .pxl-post-btn.pxl-btn-split:hover .pxl-btn-icon, 
                                            {{WRAPPER}} .pxl-layout-service .pxl-post-btn.pxl-btn-split:hover .pxl-btn-text,
                                            {{WRAPPER}} .pxl-layout-service .hover-parent:hover .pxl-post-btn:not(.pxl-btn-split),
                                            {{WRAPPER}} .pxl-layout-service .hover-parent:hover .pxl-post-btn.pxl-btn-split .pxl-btn-icon, 
                                            {{WRAPPER}} .pxl-layout-service .hover-parent:hover .pxl-post-btn.pxl-btn-split .pxl-btn-text',
                                        ),
                                        array(
                                            'name' => 'btn_hover_border',
                                            'type' => \Elementor\Group_Control_Border::get_type(),
                                            'separator' => 'before',
                                            'control_type' => 'group', 
                                            'selector' => '{{WRAPPER}} .pxl-layout-service .pxl-post-btn:not(.pxl-btn-split):hover, 
                                            {{WRAPPER}} .pxl-layout-service .pxl-post-btn.pxl-btn-split:hover .pxl-btn-icon, 
                                            {{WRAPPER}} .pxl-layout-service .pxl-post-btn.pxl-btn-split:hover .pxl-btn-text,
                                            {{WRAPPER}} .pxl-layout-service .hover-parent:hover .pxl-post-btn:not(.pxl-btn-split),
                                            {{WRAPPER}} .pxl-layout-service .hover-parent:hover .pxl-post-btn.pxl-btn-split .pxl-btn-icon, 
                                            {{WRAPPER}} .pxl-layout-service .hover-parent:hover .pxl-post-btn.pxl-btn-split .pxl-btn-text',
                                        ),
                                        array(
                                            'name'         => 'btn_hover_box_shadow',
                                            'label' => esc_html__( 'Box Shadow', 'mouno' ),
                                            'type'         => \Elementor\Group_Control_Box_Shadow::get_type(),
                                            'control_type' => 'group',
                                            'selector'     => '{{WRAPPER}} .pxl-layout-service .pxl-post-btn:not(.pxl-btn-split):hover, 
                                            {{WRAPPER}} .pxl-layout-service .pxl-post-btn.pxl-btn-split:hover .pxl-btn-icon, 
                                            {{WRAPPER}} .pxl-layout-service .pxl-post-btn.pxl-btn-split:hover .pxl-btn-text,
                                            {{WRAPPER}} .pxl-layout-service .hover-parent:hover .pxl-post-btn:not(.pxl-btn-split),
                                            {{WRAPPER}} .pxl-layout-service .hover-parent:hover .pxl-post-btn.pxl-btn-split .pxl-btn-icon, 
                                            {{WRAPPER}} .pxl-layout-service .hover-parent:hover .pxl-post-btn.pxl-btn-split .pxl-btn-text',
                                        ),
                                        array(
                                            'name' => 'btn_hover_border_radius',
                                            'label' => esc_html__('Border Radius', 'mouno' ),
                                            'type' => 'dimensions',
                                            'size_units' => [ 'px', '%' ],
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-layout-service .pxl-post-btn:not(.pxl-btn-split):hover, 
                                                {{WRAPPER}} .pxl-layout-service .pxl-post-btn.pxl-btn-split:hover .pxl-btn-icon, 
                                                {{WRAPPER}} .pxl-layout-service .pxl-post-btn.pxl-btn-split:hover .pxl-btn-text,
                                                {{WRAPPER}} .pxl-layout-service .hover-parent:hover .pxl-post-btn:not(.pxl-btn-split),
                                                {{WRAPPER}} .pxl-layout-service .hover-parent:hover .pxl-post-btn.pxl-btn-split .pxl-btn-icon, 
                                                {{WRAPPER}} .pxl-layout-service .hover-parent:hover .pxl-post-btn.pxl-btn-split .pxl-btn-text' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'btn_hover_padding',
                                            'label' => esc_html__('Padding', 'mouno' ),
                                            'type' => 'dimensions',
                                            'size_units' => [ 'px', '%' ],
                                            'control_type' => 'responsive',
                                            'separator' => 'before',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-layout-service .pxl-post-btn:not(.pxl-btn-split):hover, 
                                                {{WRAPPER}} .pxl-layout-service .pxl-post-btn.pxl-btn-split:hover .pxl-btn-text,
                                                {{WRAPPER}} .pxl-layout-service .hover-parent:hover .pxl-post-btn:not(.pxl-btn-split),
                                                 f{{WRAPPER}} .pxl-layout-service .hover-parent:hover .pxl-post-btn.pxl-btn-split .pxl-btn-text' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                    ],
                                ],
                            ],
                        ),
                    ),
                ),
                array(
                    'name' => 'tab_feature_style',
                    'label' => esc_html__('Feature Text', 'mouno' ),
                    'tab' => 'style',
                    'condition' => [
                        'show_features!' => '',
                        'layout_service' => ['service-5'],
                    ],
                    'controls' => array(
                        array(
                            'name' => 'feature_typography',
                            'type' => \Elementor\Group_Control_Typography::get_type(),
                            'control_type' => 'group',
                            'selector' => '{{WRAPPER}} .pxl-layout-service .pxl-post-features .pxl-feature-item',
                        ),
                        array(
                            'name' => 'feature_controls',
                            'control_type' => 'tab',
                            'tabs' => [
                                [
                                    'name' => 'feature_normal',
                                    'label' => esc_html__('Normal', 'mouno' ),
                                    'type' => 'tab',
                                    'controls' => [  
                                        array(
                                            'name' => 'feature_color',
                                            'label' => esc_html__('Text Color', 'mouno' ),
                                            'type' => 'color',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-layout-service .pxl-post-features .pxl-feature-item' => 'color: {{VALUE}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'feature_text_shadow',
                                            'type' => \Elementor\Group_Control_Text_Shadow::get_type(),
                                            'control_type' => 'group',
                                            'selector' => '{{WRAPPER}} .pxl-layout-service .pxl-post-features .pxl-feature-item',
                                        ),
                                    ],
                                ],
                                [
                                    'name' => 'feature_hover',
                                    'label' => esc_html__('Hover/Active', 'mouno' ),
                                    'type' => 'tab',
                                    'controls' => [  
                                        array(
                                            'name' => 'feature_hover_color',
                                            'label' => esc_html__('Text Color', 'mouno' ),
                                            'type' => 'color',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-layout-service .pxl-post-item:hover .pxl-post-features .pxl-feature-item, 
                                                {{WRAPPER}} .pxl-layout-service .pxl-post-item.active .pxl-post-features .pxl-feature-item' => 'color: {{VALUE}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'feature_hover_text_shadow',
                                            'type' => \Elementor\Group_Control_Text_Shadow::get_type(),
                                            'control_type' => 'group',
                                            'selector' => '{{WRAPPER}} .pxl-layout-service .pxl-post-item:hover .pxl-post-features .pxl-feature-item, 
                                            {{WRAPPER}} .pxl-layout-service .pxl-post-item.active .pxl-post-features .pxl-feature-item',
                                        ),
                                    ],
                                ],
                            ],
                        ),
                    ),
                ),
                array(
                    'name' => 'tab_index_style',
                    'label' => esc_html__('Index', 'mouno' ),
                    'tab' => 'style',
                    'condition' => [
                        'show_index!' => '',
                        'layout_service' => ['service-5'],
                    ],
                    'controls' => array(
                        array(
                            'name' => 'index_typography',
                            'type' => \Elementor\Group_Control_Typography::get_type(),
                            'control_type' => 'group',
                            'selector' => '{{WRAPPER}} .pxl-grid .pxl-post-index',
                        ),
                        array(
                            'name' => 'index_controls',
                            'control_type' => 'tab',
                            'tabs' => [
                                [
                                    'name' => 'index_normal',
                                    'label' => esc_html__('Normal', 'mouno' ),
                                    'type' => 'tab',
                                    'controls' => [  
                                        array(
                                            'name' => 'index_color',
                                            'label' => esc_html__('Text Color', 'mouno' ),
                                            'type' => 'color',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-layout-service .pxl-post-index' => 'color: {{VALUE}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'index_text_shadow',
                                            'type' => \Elementor\Group_Control_Text_Shadow::get_type(),
                                            'control_type' => 'group',
                                            'selector' => '{{WRAPPER}} .pxl-layout-service .pxl-post-index',
                                        ),
                                    ],
                                ],
                                [
                                    'name' => 'index_hover',
                                    'label' => esc_html__('Hover/Active', 'mouno' ),
                                    'type' => 'tab',
                                    'controls' => [  
                                        array(
                                            'name' => 'index_hover_color',
                                            'label' => esc_html__('Text Color', 'mouno' ),
                                            'type' => 'color',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-layout-service .pxl-post-item:hover .pxl-post-index, 
                                                {{WRAPPER}} .pxl-layout-service .pxl-post-item.active .pxl-post-index' => 'color: {{VALUE}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'index_hover_text_shadow',
                                            'type' => \Elementor\Group_Control_Text_Shadow::get_type(),
                                            'control_type' => 'group',
                                            'selector' => '{{WRAPPER}} .pxl-layout-service .pxl-post-item:hover .pxl-post-index, 
                                            {{WRAPPER}} .pxl-layout-service .pxl-post-item.active .pxl-post-index',
                                        ),
                                    ],
                                ],
                            ],
                        ),
                    ),
                ),
                load_more_button_style_options(),
                grid_pagination_style_options(),
                swiper_bullets_pagination_style_options(),
                array(
                    'name' => 'tab_motion_effects',
                    'label' => esc_html__('Motion Effects', 'mouno'),
                    'tab' => 'style',
                    'controls' => array_merge(
                        array(
                            array(
                                'name' => 'scroll_effects',
                                'label' => esc_html__(' Scroll Effects', 'mouno'),
                                'type' => 'switcher',
                                'default' => '',
                                'condition' => [
                                    'layout_service' => ['service-5'],
                                ],
                            ),
                        ),
                        mouno_get_animation_options([
                            'selector' => '{{WRAPPER}} pxl-layout-service .pxl-grid-item, 
                            {{WRAPPER}} pxl-layout-service .pxl-swiper-slide',
                            '{{WRAPPER}} pxl-layout-service .pxl-post-item,'
                        ]),
                    ),
                ),

            ),
        ),
    ),
    mouno_get_class_widget_path()
);