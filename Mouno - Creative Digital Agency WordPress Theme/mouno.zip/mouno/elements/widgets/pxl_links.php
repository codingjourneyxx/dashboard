<?php
pxl_add_custom_widget(
    array(
        'name' => 'pxl_links',
        'title' => esc_html__('Case Links', 'mouno' ),
        'icon' => 'eicon-link',
        'categories' => array('pxltheme-core'),
        'scripts' => array(),
        'params' => array(
            'sections' => array(
                array(
                    'name' => 'tab_link_content',
                    'label' => esc_html__('Links', 'mouno' ),
                    'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
                    'controls' => array(  
                        array(
                            'name' => 'link_style',
                            'label' => esc_html__('Link Style', 'mouno'),
                            'type' => 'select',
                            'default' => 'link-default',
                            'options' => [
                                'link-default' => esc_html__('Default', 'mouno'),
                                'link-underline' => esc_html__('Underline', 'mouno'),
                            ],
                        ),
                        array(
                            'name' => 'underline_h',
                            'label' => esc_html__('Underline Height', 'mouno'),
                            'type' => 'slider',
                            'control_type' => 'responsive',
                            'size_units' => ['px', '%', 'custom'],
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 1000,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-links-wrapper .pxl-links-item .link-underline .pxl-link-text' => '--pxl-height: {{SIZE}}{{UNIT}};',
                            ],
                        ),
                        array(
                            'name' => 'links',
                            'label' => esc_html__('Links', 'mouno' ),
                            'type' => \Elementor\Controls_Manager::REPEATER,
                            'controls' => array(
                                array(
                                    'name' => 'link_icon',
                                    'label' => esc_html__('Icon', 'mouno' ),
                                    'type' => \Elementor\Controls_Manager::ICONS,
                                    'fa4compatibility' => 'icon',
                                ),
                                array(
                                    'name' => 'link_text',
                                    'label' => esc_html__('Text', 'mouno' ),
                                    'type' => \Elementor\Controls_Manager::TEXT,
                                    'label_block' => true,
                                    'default' => esc_html__('Enter link here', 'mouno'),
                                ),
                                array( 
                                    'name' => 'link_url',
                                    'label' => esc_html__('Link', 'mouno' ),
                                    'type' => \Elementor\Controls_Manager::URL,
                                    'default' => [
                                        'url' => '#',
                                    ],
                                ),
                            ),
                            'title_field' => '{{{ link_text }}}',
                            'default' => [
                                [
                                    'link_text' =>  esc_html__('Enter link here', 'mouno'),
                                    'link_url' => [
                                        'url' => '#',
                                    ],
                                ],
                                [
                                    'link_text' =>  esc_html__('Enter link here', 'mouno'),
                                    'link_url' => [
                                        'url' => '#',
                                    ],
                                ],
                                [
                                    'link_text' =>  esc_html__('Enter link here', 'mouno'),
                                    'link_url' => [
                                        'url' => '#',
                                    ],
                                ],
                            ],

                        ),
                    ),
                ),

                array(
                    'name' => 'tab_links_style',
                    'label' => esc_html__('Links', 'mouno'),
                    'tab' => 'style',
                    'controls' => array(
                        array(
                            'name' => 'direction',
                            'label' => esc_html__('Direction', 'mouno'),
                            'type' => 'choose',
                            'default' => 'column',
                            'options' => [
                                'column' => [
                                    'title' => esc_html__('Vertical', 'mouno'),
                                    'icon' => 'eicon-arrow-down',
                                ],
                                'row' => [
                                    'title' => esc_html__('Horizontal', 'mouno'),
                                    'icon' => 'eicon-arrow-right',
                                ],
                            ],
                            'selectors' => [
                                ''
                            ]
                        ),
                        array(
                            'name' => 'align_items',
                            'label' => esc_html__('Align Items', 'mouno'),
                            'type' => \Elementor\Controls_Manager::CHOOSE,
                            'control_type' => 'responsive',
                            'options' => array(
                                'start' =>[
                                    'title' => esc_html__('Start', 'mouno'),
                                    'icon' => 'eicon-align-start-h',
                                ],
                                'center' => [
                                    'title' => esc_html__('Center', 'mouno'),
                                    'icon' => 'eicon-align-center-h'
                                ],
                                'end' => [
                                    'title' => esc_html__('End', 'mouno'),
                                    'icon' => 'eicon-align-end-h',
                                ],
                                'stretch' => [
                                    'title' => esc_html__('Stretch', 'mouno'),
                                    'icon' => 'eicon-align-stretch-h',
                                ],
                            ),
                            'selectors' => [
                                '{{WRAPPER}} .pxl-links-wrapper' => 'align-items: {{VALUE}};'
                            ],
                            'condition' => [
                                'direction!' => 'row',
                            ],
                        ),
                        array(
                            'name' => 'item_spacing',
                            'label' => esc_html__('Item Spacing', 'mouno'),
                            'type' => 'slider',
                            'control_type' => 'responsive',
                            'size_units' => ['px', '%', 'custom'],
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 1000,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-links-wrapper' => '--pxl-gap: {{SIZE}}{{UNIT}};',
                            ],
                        ),

                        array(
                            'name' => 'item_align_items',
                            'label' => esc_html__('Item Vertical Align', 'mouno'),
                            'type' => \Elementor\Controls_Manager::CHOOSE,
                            'control_type' => 'responsive',
                            'separator' => 'before',
                            'options' => array(
                                'start' =>[
                                    'title' => esc_html__('Start', 'mouno'),
                                    'icon' => 'eicon-align-start-v',
                                ],
                                'center' => [
                                    'title' => esc_html__('Center', 'mouno'),
                                    'icon' => 'eicon-align-center-v'
                                ],
                                'end' => [
                                    'title' => esc_html__('End', 'mouno'),
                                    'icon' => 'eicon-align-end-v',
                                ],
                                'stretch' => [
                                    'title' => esc_html__('Stretch', 'mouno'),
                                    'icon' => 'eicon-align-stretch-v',
                                ],
                            ),
                            'selectors' => [
                                '{{WRAPPER}} .pxl-links-wrapper .pxl-links-item .pxl-link' => 'align-items: {{VALUE}};'
                            ],
                        ),
                        array(
                            'name' => 'icon_spacing',
                            'label' => esc_html__('Icon Spacing', 'mouno'),
                            'type' => 'slider',
                            'control_type' => 'responsive',
                            'size_units' => ['px', '%', 'custom'],
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 1000,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-links-wrapper .pxl-links-item .pxl-link' => 'gap: {{SIZE}}{{UNIT}};',
                            ],
                        ),
                    ),
                ),

                array(
                    'name' => 'tab_link_style',
                    'label' => esc_html__('Link', 'mouno'),
                    'tab' => 'style',
                    'controls' => array(
                        array(
                            'name' => 'link_typography',
                            'type' => \Elementor\Group_Control_Typography::get_type(),
                            'control_type' => 'group',
                            'selector' => '{{WRAPPER}} .pxl-links-wrapper .pxl-links-item .pxl-link',
                        ),
                        array(
                            'name' => 'line_h',
                            'label' => esc_html__('Line Height', 'mouno'),
                            'type' => 'slider',
                            'control_type' => 'responsive',
                            'size_units' => ['px', '%', 'custom'],
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 1000,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-links-wrapper .pxl-links-item .link-underline .pxl-link-text:after' => 'height: {{SIZE}}{{UNIT}};',
                            ],
                        ),
                        array(
                            'name' => 'link_controls',
                            'control_type' => 'tab',
                            'tabs' => [
                                [
                                    'name' => 'link_normal',
                                    'label' => esc_html__('Normal', 'mouno' ),
                                    'type' => 'tab',
                                    'controls' => [  
                                        array(
                                            'name' => 'link_color',
                                            'label' => esc_html__('Color', 'mouno' ),
                                            'type' => 'color',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-links-wrapper .pxl-links-item .pxl-link' => 'color: {{VALUE}};',
                                            ],
                                        ),
                                    ],
                                ],
                                [
                                    'name' => 'link_hover',
                                    'label' => esc_html__('Hover', 'mouno' ),
                                    'type' => \Elementor\Controls_Manager::TAB,
                                    'controls' => [
                                        array(
                                            'name' => 'link_hover_style',
                                            'label' => esc_html__('Hover Style', 'mouno' ),
                                            'type' => \Elementor\Controls_Manager::SELECT,
                                            'options' => [
                                                'hover-default' => esc_html__('Default', 'mouno'),
                                                'hover-underline-ltr' => esc_html__('Underline LTR', 'mouno'),
                                                'hover-underline-rtl' => esc_html__('Underline RTL', 'mouno'),
                                                'hover-underline-expand' => esc_html__('Underline Expand', 'mouno'),
                                                'hover-underline-split' => esc_html__('Underline Split', 'mouno'),
                                                'hover-popup-dot' => esc_html__('Pop Up Dot', 'mouno'),
                                            ],
                                            'default' => 'hover-default',
                                        ),
                                        array(
                                            'name' => 'link_color_hover',
                                            'label' => esc_html__('Color', 'mouno' ),
                                            'type' => 'color',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-links-wrapper .pxl-links-item .pxl-link:hover' => 'color: {{VALUE}};',
                                            ],
                                        ),
                                    ],
                                ],
                            ],
                        ),
                    ),
                ),
                array(
                    'name' => 'tab_motion_effects',
                    'label' => esc_html__('Motion Effects', 'mouno' ),
                    'tab' => 'style',
                    'controls' => mouno_get_animation_options([
                        'selector' => '{{WRAPPER}} .pxl-text-marquee-wrapper',
                    ]),
                ),
            ),
        ),
    ),
    mouno_get_class_widget_path(),
);