<?php
pxl_add_custom_widget(
    array(
        'name' => 'pxl_icon_carousel',
        'title' => esc_html__('Case Icon Carousel', 'mouno' ),
        'icon' => 'eicon-carousel',
        'categories' => array('pxltheme-core'),
        'scripts' => array(
            'mouno-swiper',
        ),
        'params' => array(
            'sections' => array(
                array(
                    'name' => 'tab_icon_content',
                    'label' => esc_html__('Icon', 'mouno' ),
                    'tab' => 'content',
                    'controls' => array(   
                        array(
                            'name' => 'icons',
                            'label' => esc_html__('Icons', 'mouno' ),
                            'type' => 'repeater',
                            'controls' => array(
                                array(
                                    'name' => '_icon',
                                    'label' => esc_html__('Icon', 'mouno'),
                                    'type' => 'icons',
                                    'fa4compatibility' => 'icon',
                                ),
                                array(
                                    'name' => 'icon_link',
                                    'label' => esc_html__('Link', 'mouno'),
                                    'type' => 'url',
                                    'label_block' => true,
                                ),
                                array(
                                    'name' => 'current_item_sz',
                                    'label' => esc_html__('Size', 'mouno'),
                                    'type' => 'slider',
                                    'control_type' => 'responsive',
                                    'size_units' => ['px', '%', 'custom'],
                                    'separator' => 'before',
                                    'range' => [
                                        'px' => [
                                            'min' => 0,
                                            'max' => 1000,
                                        ],
                                    ],
                                    'selectors' => [
                                        '{{WRAPPER}} .pxl-icon-carousel .swiper-slide {{CURRENT_ITEM}}' => 'font-size: {{SIZE}}{{UNIT}};',
                                        '{{WRAPPER}} .pxl-icon-carousel .swiper-slide {{CURRENT_ITEM}} svg' => 'height: {{SIZE}}{{UNIT}}; width: auto;',
                                    ],
                                ),
                            ),
                            'default' => [
                                [
                                    '_icon' => [
                                        'value' => [
                                            'url' => content_url('/uploads/2024/11/partner1.svg'),
                                            'id' => 2295,
                                        ],
                                        'library' => 'svg',
                                    ],
                                ],
                                [
                                    '_icon' => [
                                        'value' => [
                                            'url' => content_url('/uploads/2024/11/partner2.svg'),
                                            'id' => 2299,
                                        ],
                                        'library' => 'svg',
                                    ],
                                ],
                                [
                                    '_icon' => [
                                        'value' => [
                                            'url' => content_url('/uploads/2024/11/partner3.svg'),
                                            'id' => 2297,
                                        ],
                                        'library' => 'svg',
                                    ],
                                ],
                            ],
                        ),
                        array(
                            'name' => 'layout_style',
                            'label' => esc_html__('Layout Style', 'mouno'),
                            'type' => 'select',
                            'options' => [
                                'icon-carousel-default' => esc_html__('Default', 'mouno'),
                                'icon-caorousel-style1' => esc_html__('Round Box Border', 'mouno'),
                            ],
                            'default' => 'icon-carousel-default',
                        ),
                        array(
                            'name' => 'icon_align_items',
                            'label' => esc_html__('Align Items', 'mouno'),
                            'type' => 'choose',
                            'control_type' => 'responsive',
                            'options' => array(
                                'start' =>[
                                    'title' => esc_html__('Start', 'mouno'),
                                    'icon' => 'eicon-align-start-v',
                                ],
                                'center' => [
                                    'title' => esc_html__('Center', 'mouno'),
                                    'icon' => 'eicon-align-center-v'
                                ],
                                'end' => [
                                    'title' => esc_html__('End', 'mouno'),
                                    'icon' => 'eicon-align-end-v',
                                ],
                            ),
                            'selectors' => [
                                '{{WRAPPER}} .pxl-icon-carousel .pxl-swiper-slide .pxl-item-icon' => 'align-items: {{VALUE}};'
                            ],
                        ),
                        array(
                            'name' => 'icon_justify_content',
                            'label' => esc_html__('Justify Content', 'mouno' ),
                            'type' => 'choose',
                            'control_type' => 'responsive',
                            'options' => [
                                'start' => [
                                    'title' => esc_html__('Start', 'mouno' ),
                                    'icon' => 'eicon-justify-start-h',
                                ],
                                'center' => [
                                    'title' => esc_html__('Center', 'mouno' ),
                                    'icon' => 'eicon-justify-center-h',
                                ],
                                'end' => [
                                    'title' => esc_html__('End', 'mouno' ),
                                    'icon' => 'eicon-justify-end-h',
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-icon-carousel .pxl-swiper-slide .pxl-item-icon' => 'justify-content: {{VALUE}};',
                            ],
                        ),
                        array(
                            'name' => 'has_divider',
                            'label' => esc_html__('Has Divider', 'mouno'),
                            'type' => 'switcher',
                            'default' => '',
                        ),
                        array(
                            'name' => 'divider_color',
                            'label' => esc_html__('Divider Color', 'mouno'),
                            'type' => 'color',
                            'selectors' => [
                                '{{WRAPPER}} .pxl-swiper .swiper-slide-visible + .swiper-slide-visible' => 'border-color: {{VALUE}};',
                            ],
                        ),
                    ),
                ),
                array(
                    'name' => 'tab_swiper_add_otps',
                    'label' => esc_html__('Addtional Options', 'mouno'),
                    'tab' => 'content',
                    'controls' => array(
                        swiper_controls_options(),
                    ),
                ),
                array(
                    'name' => 'tab_style_icon',
                    'label' => esc_html__('Icon', 'mouno'),
                    'tab' => 'style',
                    'controls' => array(
                        array(
                            'name' => 'box_height',
                            'label' => esc_html__('Box Height', 'mouno'),
                            'type' => 'slider',
                            'control_type' => 'responsive',
                            'size_units' => ['px', 'custom'],
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 1000,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-icon-carousel .pxl-icon-item' => 'height: {{SIZE}}{{UNIT}};',
                            ],
                        ),
                        array(
                            'name' => 'icon_sz',
                            'label' => esc_html__('Icon Size', 'mouno'),
                            'type' => 'slider',
                            'control_type' => 'responsive',
                            'size_units' => ['px', 'custom'],
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 1000,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-icon-carousel .pxl-icon-item svg' => 'height: {{SIZE}}{{UNIT}};width: auto',
                                '{{WRAPPER}} .pxl-icon-carousel .pxl-icon-item' => 'font-size: {{SIZE}}{{UNIT}};'
                            ],
                        ),
                        array(
                            'name' => 'icon_controls',
                            'control_type' => 'tab',
                            'tabs' => [
                                [
                                    'name' => 'icon_normal',
                                    'label' => esc_html__('Normal', 'mouno' ),
                                    'type' => 'tab',
                                    'controls' => [  
                                        array(
                                            'name' => 'icon_color',
                                            'label' => esc_html__('Icon Color', 'mouno' ),
                                            'type' => 'color',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-icon-carousel .pxl-icon-item' => 'color: {{VALUE}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'icon_bg',
                                            'type' => \Elementor\Group_Control_Background::get_type(),
                                            'control_type' => 'group',
                                            'types' => [ 'classic', 'gradient' ],
                                            'selector' => '{{WRAPPER}} .pxl-icon-carousel .pxl-icon-item',
                                        ),
                                        array(
                                            'name' => 'icon_border',
                                            'type' => \Elementor\Group_Control_Border::get_type(),
                                            'separator' => 'before',
                                            'control_type' => 'group', 
                                            'selector' => '{{WRAPPER}} .pxl-icon-carousel .pxl-icon-item',
                                        ),
                                        array(
                                            'name'         => 'icon_box_shadow',
                                            'label' => esc_html__( 'Box Shadow', 'mouno' ),
                                            'type'         => \Elementor\Group_Control_Box_Shadow::get_type(),
                                            'control_type' => 'group',
                                            'selector'     => '{{WRAPPER}} .pxl-icon-carousel .pxl-icon-item',
                                        ),
                                        array(
                                            'name' => 'icon_border_radius',
                                            'label' => esc_html__('Border Radius', 'mouno' ),
                                            'type' => 'dimensions',
                                            'size_units' => [ 'px', '%' ],
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-icon-carousel .pxl-icon-item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'icon_padding',
                                            'label' => esc_html__('Padding', 'mouno' ),
                                            'type' => 'dimensions',
                                            'size_units' => [ 'px', '%' ],
                                            'control_type' => 'responsive',
                                            'separator' => 'before',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-icon-carousel .pxl-icon-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                    ],
                                ],
                                [
                                    'name' => 'icon_hover',
                                    'label' => esc_html__('Hover', 'mouno' ),
                                    'type' => 'tab',
                                    'controls' => [
                                        array(
                                            'name' => 'icon_hover_color',
                                            'label' => esc_html__('Icon Color', 'mouno' ),
                                            'type' => 'color',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-icon-carousel .pxl-icon-item:hover' => 'color: {{VALUE}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'icon_hover_bg',
                                            'type' => \Elementor\Group_Control_Background::get_type(),
                                            'control_type' => 'group',
                                            'types' => [ 'classic', 'gradient' ],
                                            'selector' => '{{WRAPPER}} .pxl-icon-carousel .pxl-icon-item:hover',
                                        ),
                                        array(
                                            'name' => 'icon_hover_anim',
                                            'label' => esc_html__( 'Hover Animation', 'mouno' ),
                                            'separator' => 'before',
                                            'type' => 'hover_animation',
                                        ),
                                        array(
                                            'name' => 'icon_hover_border',
                                            'type' => \Elementor\Group_Control_Border::get_type(),
                                            'separator' => 'before',
                                            'control_type' => 'group', 
                                            'selector' => '{{WRAPPER}} .pxl-icon-carousel .pxl-icon-item:hover',
                                        ),
                                        array(
                                            'name'         => 'icon_hover_box_shadow',
                                            'label' => esc_html__( 'Box Shadow', 'mouno' ),
                                            'type'         => \Elementor\Group_Control_Box_Shadow::get_type(),
                                            'control_type' => 'group',
                                            'selector'     => '{{WRAPPER}} .pxl-icon-carousel .pxl-icon-item:hover',
                                        ),
                                        array(
                                            'name' => 'icon_hover_border_radius',
                                            'label' => esc_html__('Border Radius', 'mouno' ),
                                            'type' => 'dimensions',
                                            'size_units' => [ 'px', '%' ],
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-icon-carousel .pxl-icon-item:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'icon_hover_padding',
                                            'label' => esc_html__('Padding', 'mouno' ),
                                            'type' => 'dimensions',
                                            'size_units' => [ 'px', '%' ],
                                            'control_type' => 'responsive',
                                            'separator' => 'before',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-icon-carousel .pxl-icon-item:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                    ],
                                ],
                            ],
                        ),
                    ),
                ),

                array(
                    'name' => 'tab_motion_effects',
                    'label' => esc_html__('Motion Effects', 'mouno' ),
                    'tab' => 'style',
                    'controls' => mouno_get_animation_options([
                        'selector' => '{{WRAPPER}} .pxl-swiper .swiper-slide',
                    ]),
                ),
            ),
        ),
    ),
    mouno_get_class_widget_path()
);