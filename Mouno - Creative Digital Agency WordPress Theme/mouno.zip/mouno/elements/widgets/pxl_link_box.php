<?php
pxl_add_custom_widget(
    array(
        'name' => 'pxl_link_box',
        'title' => esc_html__('Case Link Box', 'mouno'),
        'icon' => 'eicon-icon-box',
        'categories' => array('pxltheme-core'),
        'scripts' => array(
            'mouno-effect',
        ),
        'params' => array(
            'sections' => array(
                array(
                    'name' => 'tab_content',
                    'label' => esc_html__('Content', 'mouno'),
                    'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
                    'controls' => array(
                        array(
                            'name' => 'style',
                            'label' => esc_html__('Style', 'mouno'),
                            'type' => 'select',
                            'default' => 'link-box-default',
                            'options' => [
                                'link-box-default' => esc_html__('Default', 'mouno'),
                                'link-box-style1' => esc_html__('Style 1', 'mouno'),
                            ],
                        ),
                        array(
                            'name' => '_icon',
                            'label' => esc_html__('Icon', 'mouno'),
                            'type' => \Elementor\Controls_Manager::ICONS,
                            'fa4compatibility' => 'icon',
                            'default' => [
                                'value' => 'fas fa-star',
                                'library' => 'Font Awesome 5 Free',
                            ],
                        ),
                        array(
                            'name' => 'title',
                            'label' => esc_html__('Title', 'mouno'),
                            'type' => 'text',
                            'default' => esc_html__('Link box heading here.', 'mouno'),
                            'label_block' => true,
                        ),
                        array(
                            'name' => 'title_tag',
                            'label' => esc_html__('Title HTML Tag', 'mouno'),
                            'type' => 'select',
                            'default' => 'h4',
                            'options' => [
                                'h1' => esc_html__('H1', 'mouno'),
                                'h2' => esc_html__('H2', 'mouno'),
                                'h3' => esc_html__('H3', 'mouno'),
                                'h4' => esc_html__('H4', 'mouno'),
                                'h5' => esc_html__('H5', 'mouno'),
                                'h6' => esc_html__('H6', 'mouno'),
                                'div' => esc_html__('div', 'mouno'),
                                'p'  => esc_html__('p', 'mouno'),
                                'span' => esc_html__('span', 'mouno'),
                            ],
                        ),
                        array(
                            'name' => 'link',
                            'label' => esc_html__('Link', 'mouno'),
                            'type' => \Elementor\Controls_Manager::URL,
                            'label_block' => true,
                            'default' => [
                                'url' => '#',
                            ],
                        ),
                        array(
                            'name' => 'show_tags',
                            'label' => esc_html__('Show Tags', 'mouno'),
                            'type' => 'switcher',
                            'default' => 'true',
                        ),
                        array(
                            'name' => 'tags',
                            'label' => esc_html__('Tags', 'mouno' ),
                            'type' => \Elementor\Controls_Manager::REPEATER,
                            'condition' => [
                                'show_tags!' => '',
                            ],
                            'controls' => array(
                                array(
                                    'name' => 'tag_name',
                                    'label' => esc_html__('Tag Name', 'mouno' ),
                                    'type' => \Elementor\Controls_Manager::TEXT,
                                ),
                            ),
                            'title_field' => '{{{ tag_name }}}',
                            'default' => [
                                [
                                    'tag_name' =>  esc_html__('Tag 1', 'mouno'),
                                ],
                                [
                                    'tag_name' =>  esc_html__('Tag 2', 'mouno'),
                                ],
                            ],

                        ),
                    ),
                ),
                array(
                    'name' => 'tab_link_box_style',
                    'label' => esc_html__('General', 'mouno'),
                    'tab' => \Elementor\Controls_Manager::TAB_STYLE,
                    'controls' => array(
                        array(
                            'name' => 'icon_position',
                            'label' => esc_html__('Icon Position', 'mouno'),
                            'type' => \Elementor\Controls_Manager::CHOOSE,
                            'control_type' => 'responsive',
                            'options' => array(
                                'row-reverse' =>[
                                    'title' => esc_html__('Left', 'mouno'),
                                    'icon' => 'eicon-h-align-left',
                                ],
                                'row' => [
                                    'title' => esc_html__('Right', 'mouno'),
                                    'icon' => 'eicon-h-align-right',
                                ],
                            ),
                            'selectors' => [
                                '{{WRAPPER}} .pxl-link-box-wrapper' => 'flex-direction: {{VALUE}};'
                            ],
                        ),
                        array(
                            'name' => 'vertical_align',
                            'label' => esc_html__('Vertical Alignment', 'mouno' ),
                            'type' => \Elementor\Controls_Manager::CHOOSE,
                            'control_type' => 'responsive',
                            'options' => [
                                'start' =>  [
                                    'title' => esc_html__('Start', 'mouno'),
                                    'icon' => 'eicon-align-start-v',
                                ],
                                'center' =>  [
                                    'title' => esc_html__('Center', 'mouno'),
                                    'icon' => 'eicon-align-center-v',
                                ],
                                'end' =>  [
                                    'title' => esc_html__('End', 'mouno'),
                                    'icon' => 'eicon-align-end-v',
                                ],
                                'stretch' =>  [
                                    'title' => esc_html__('Stretch', 'mouno'),
                                    'icon' => 'eicon-align-stretch-v',
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-link-box-wrapper' => 'align-items: {{VALUE}};'
                            ],
                        ),
                        array(
                            'name' => 'hoz_align',
                            'label' => esc_html__('Horizontal Alignment', 'mouno' ),
                            'type' => \Elementor\Controls_Manager::CHOOSE,
                            'label_block' => true,
                            'control_type' => 'responsive',
                            'options' => [
                                'start' => [
                                    'title' => esc_html__('Start', 'mouno' ),
                                    'icon' => 'eicon-justify-start-h',
                                ],
                                'center' => [
                                    'title' => esc_html__('Center', 'mouno' ),
                                    'icon' => 'eicon-justify-center-h',
                                ],
                                'end' => [
                                    'title' => esc_html__('End', 'mouno' ),
                                    'icon' => 'eicon-justify-end-h',
                                ],
                                'space-around' => [
                                    'title' => esc_html__('Space Around', 'mouno' ),
                                    'icon' => 'eicon-justify-space-around-h',
                                ],
                                'space-evenly' => [
                                    'title' => esc_html__('Space Evenly', 'mouno' ),
                                    'icon' => 'eicon-justify-space-evenly-h',
                                ],
                                'space-between' => [
                                    'title' => esc_html__('Space Between', 'mouno' ),
                                    'icon' => 'eicon-justify-space-between-h',
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-link-box-wrapper' => 'justify-content: {{VALUE}};',
                            ],
                        ),
                        array(
                            'name' => 'icon_spacing',
                            'label' => esc_html__('Icon Spacing', 'mouno'),
                            'type' => 'slider',
                            'control_type' => 'responsive',
                            'size_units' => ['px', '%', 'custom'],
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 1000,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-link-box-wrapper' => 'gap: {{SIZE}}{{UNIT}};',
                            ],
                        ),
                        array(
                            'name' => 'content_spacing',
                            'label' => esc_html__('Content Spacing', 'mouno'),
                            'type' => 'slider',
                            'control_type' => 'responsive',
                            'size_units' => ['px', '%', 'custom'],
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 1000,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-link-box-wrapper .pxl-link-box-content .pxl-link-box-title' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                            ],
                        ),
                        array(
                            'name' => 'tag_spacing',
                            'label' => esc_html__('Tag Spacing', 'mouno'),
                            'type' => 'slider',
                            'control_type' => 'responsive',
                            'size_units' => ['px', '%', 'custom'],
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 1000,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-link-box-wrapper .pxl-link-box-content .pxl-link-box-tags' => 'gap: {{SIZE}}{{UNIT}};',
                            ],
                        ),
                        array(
                            'name' => 'link_box_control',
                            'control_type' => 'tab',
                            'tabs' => [
                                [
                                    'name' => 'link_box_normal',
                                    'label' => esc_html__('Normal', 'mouno' ),
                                    'type' => 'tab',
                                    'controls' => [  
                                        array(
                                            'name' => 'link_box_color',
                                            'label' => esc_html__('Background Color', 'mouno' ),
                                            'type' => 'color',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-link-box-wrapper' => 'background-color: {{VALUE}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'link_box_border',
                                            'type' => \Elementor\Group_Control_Border::get_type(),
                                            'separator' => 'before',
                                            'control_type' => 'group', 
                                            'selector' => '{{WRAPPER}} .pxl-link-box-wrapper',
                                        ),
                                        array(
                                            'name'         => 'link_box_box_shadow',
                                            'label' => esc_html__( 'Box Shadow', 'mouno' ),
                                            'type'         => \Elementor\Group_Control_Box_Shadow::get_type(),
                                            'control_type' => 'group',
                                            'selector'     => '{{WRAPPER}} .pxl-link-box-wrapper',
                                        ),
                                        array(
                                            'name' => 'link_box_border_radius',
                                            'label' => esc_html__('Border Radius', 'mouno' ),
                                            'type' => \Elementor\Controls_Manager::DIMENSIONS,
                                            'size_units' => [ 'px', '%' ],
                                            'control_type' => 'responsive',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-link-box-wrapper' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'link_box_padding',
                                            'label' => esc_html__('Padding', 'mouno' ),
                                            'type' => \Elementor\Controls_Manager::DIMENSIONS,
                                            'size_units' => [ 'px', '%' ],
                                            'control_type' => 'responsive',
                                            'separator' => 'before',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-link-box-wrapper' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                    ],
                                ],
                                [
                                    'name' => 'link_box_hover',
                                    'label' => esc_html__('Hover', 'mouno' ),
                                    'type' => \Elementor\Controls_Manager::TAB,
                                    'controls' => [
                                        array(
                                            'name' => 'link_box_hover_style',
                                            'label' => esc_html__('Style', 'mouno' ),
                                            'type' => 'select',
                                            'options' => [
                                                'hover-default' => esc_html__('Default', 'mouno'),
                                                'hover-spotlight-scale' => esc_html__('Spotlight', 'mouno'),
                                                'hover-image-show' => esc_html__('Image Show', 'mouno'),
                                            ]
                                        ),
                                        array(
                                            'name' => 'img_show',
                                            'label' => esc_html__('Image Show', 'mouno' ),
                                            'type' => \Elementor\Controls_Manager::MEDIA,
                                            'condition' => [
                                                'link_box_hover_style' => 'hover-image-show',
                                            ],
                                        ),
                                        array(
                                            'name' => 'img_show_w',
                                            'label' => esc_html__('Image Width', 'mouno'),
                                            'type' => 'slider',
                                            'control_type' => 'responsive',
                                            'size_units' => ['px', '%', 'custom'],
                                            'range' => [
                                                'px' => [
                                                    'min' => 0,
                                                    'max' => 1000,
                                                ],
                                            ],
                                            'condition' => [
                                                'link_box_hover_style' => 'hover-image-show',
                                            ],
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-link-box-wrapper.hover-image-show .item-image' => 'width: {{SIZE}}{{UNIT}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'img_show_h',
                                            'label' => esc_html__('Image Width', 'mouno'),
                                            'type' => 'slider',
                                            'control_type' => 'responsive',
                                            'size_units' => ['px', '%', 'custom'],
                                            'range' => [
                                                'px' => [
                                                    'min' => 0,
                                                    'max' => 1000,
                                                ],
                                            ],
                                            'condition' => [
                                                'link_box_hover_style' => 'hover-image-show',
                                            ],
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-link-box-wrapper.hover-image-show .item-image' => 'height: {{SIZE}}{{UNIT}};',
                                            ],
                                        ),
                                        
                                        array(
                                            'name' => 'link_box_hover_color',
                                            'label' => esc_html__('Background Color', 'mouno' ),
                                            'type' => 'color',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-link-box-wrapper:not(.hover-spotlight-scale):hover, 
                                                {{WRAPPER}} .pxl-link-box-wrapper.hover-spotlight-scale .item-spotlight' => 'background-color: {{VALUE}};',
                                            ],
                                        ),
                                        [
                                            'name' => 'transition_duration',
                                            'label' => esc_html__('Transition Duration', 'mouno'),
                                            'type' => \Elementor\Controls_Manager::SLIDER,
                                            'size_units' => ['ms', 's'],
                                            'range' => [
                                                'ms' => [
                                                    'min' => 0,
                                                    'max' => 10000,
                                                    'step' => 50,
                                                ],
                                                's' => [
                                                    'min' => 0,
                                                    'max' => 10,
                                                    'step' => 0.05,
                                                ],
                                            ],
                                            'default' => [
                                                'unit' => 's',
                                            ],
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-link-box-wrapper' => 'transition-duration: {{SIZE}}{{UNIT}};',
                                            ],
                                        ],
                                        array(
                                            'name' => 'link_box_hover_border',
                                            'type' => \Elementor\Group_Control_Border::get_type(),
                                            'separator' => 'before',
                                            'control_type' => 'group', 
                                            'selector' => '{{WRAPPER}} .pxl-link-box-wrapper:hover',
                                        ),
                                        array(
                                            'name'         => 'link_box_hover_box_shadow',
                                            'label' => esc_html__( 'Box Shadow', 'mouno' ),
                                            'type'         => \Elementor\Group_Control_Box_Shadow::get_type(),
                                            'control_type' => 'group',
                                            'selector'     => '{{WRAPPER}} .pxl-link-box-wrapper:hover',
                                        ),
                                        array(
                                            'name' => 'link_box_hover_border_radius',
                                            'label' => esc_html__('Border Radius', 'mouno' ),
                                            'type' => \Elementor\Controls_Manager::DIMENSIONS,
                                            'size_units' => [ 'px', '%' ],
                                            'control_type' => 'responsive',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-link-box-wrapper:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'link_box_hover_padding',
                                            'label' => esc_html__('Padding', 'mouno' ),
                                            'type' => \Elementor\Controls_Manager::DIMENSIONS,
                                            'size_units' => [ 'px', '%' ],
                                            'control_type' => 'responsive',
                                            'separator' => 'before',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-link-box-wrapper:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                    ],
                                ],
                            ],
                        ),
                    ),
                ),
                array(
                    'name' => 'tab_title_style',
                    'label' => esc_html__('Title', 'mouno' ),
                    'tab' => \Elementor\Controls_Manager::TAB_STYLE,
                    'controls' => array(
                        array(
                            'name' => 'title_typography',
                            'type' => \Elementor\Group_Control_Typography::get_type(),
                            'control_type' => 'group',
                            'selector' => '{{WRAPPER}} .pxl-link-box-wrapper.link-box-default .pxl-link-box-title',
                        ),
                        array(
                            'name' => 'title_controls',
                            'control_type' => 'tab',
                            'tabs' => [
                                [
                                    'name' => 'title_normal',
                                    'label' => esc_html__('Normal', 'mouno' ),
                                    'type' => 'tab',
                                    'controls' => [  
                                        array(
                                            'name' => 'title_color',
                                            'label' => esc_html__('Color', 'mouno' ),
                                            'type' => 'color',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-link-box-wrapper .pxl-link-box-title' => 'color: {{VALUE}};',
                                            ],
                                        ),
                                    ],
                                ],
                                [
                                    'name' => 'title_hover',
                                    'label' => esc_html__('Hover', 'mouno' ),
                                    'type' => \Elementor\Controls_Manager::TAB,
                                    'controls' => [
                                        array(
                                            'name' => 'hover_title_color',
                                            'label' => esc_html__('Color', 'mouno' ),
                                            'type' => 'color',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-link-box-wrapper:hover .pxl-link-box-title' => 'color: {{VALUE}};',
                                            ],
                                        ),
                                        [
                                            'name' => 'title_transition_duration',
                                            'label' => esc_html__('Transition Duration', 'mouno'),
                                            'type' => \Elementor\Controls_Manager::SLIDER,
                                            'size_units' => ['ms', 's'],
                                            'range' => [
                                                'ms' => [
                                                    'min' => 0,
                                                    'max' => 10000,
                                                    'step' => 50,
                                                ],
                                                's' => [
                                                    'min' => 0,
                                                    'max' => 10,
                                                    'step' => 0.05,
                                                ],
                                            ],
                                            'default' => [
                                                'unit' => 's',
                                            ],
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-link-box-wrapper' => 'transition-duration: {{SIZE}}{{UNIT}};',
                                            ],
                                        ],
                                    ],
                                ],
                            ],
                        ),
                    ),
                ),
                array(
                    'name' => 'tab_tag_style',
                    'label' => esc_html__('Tag', 'mouno' ),
                    'tab' => \Elementor\Controls_Manager::TAB_STYLE,
                    'controls' => array(
                        array(
                            'name' => 'tag_typography',
                            'type' => \Elementor\Group_Control_Typography::get_type(),
                            'control_type' => 'group',
                            'selector' => '{{WRAPPER}} .pxl-link-box-wrapper .pxl-link-box-tag',
                        ),
                        array(
                            'name' => 'tag_controls',
                            'control_type' => 'tab',
                            'tabs' => [
                                [
                                    'name' => 'tag_normal',
                                    'label' => esc_html__('Normal', 'mouno' ),
                                    'type' => 'tab',
                                    'controls' => [  
                                        array(
                                            'name' => 'tag_color',
                                            'label' => esc_html__('Color', 'mouno' ),
                                            'type' => 'color',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-link-box-wrapper .pxl-link-box-tag' => 'color: {{VALUE}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'tag_bg_color',
                                            'label' => esc_html__('Background Color', 'mouno' ),
                                            'type' => 'color',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-link-box-wrapper .pxl-link-box-tag' => 'background-color: {{VALUE}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'tag_box_border',
                                            'type' => \Elementor\Group_Control_Border::get_type(),
                                            'separator' => 'before',
                                            'control_type' => 'group', 
                                            'selector' => '{{WRAPPER}} .pxl-link-box-wrapper .pxl-link-box-tag',
                                        ),
                                        array(
                                            'name'         => 'tag_box_box_shadow',
                                            'label' => esc_html__( 'Box Shadow', 'mouno' ),
                                            'type'         => \Elementor\Group_Control_Box_Shadow::get_type(),
                                            'control_type' => 'group',
                                            'selector'     => '{{WRAPPER}} .pxl-link-box-wrapper .pxl-link-box-tag',
                                        ),
                                        array(
                                            'name' => 'tag_box_border_radius',
                                            'label' => esc_html__('Border Radius', 'mouno' ),
                                            'type' => \Elementor\Controls_Manager::DIMENSIONS,
                                            'size_units' => [ 'px', '%' ],
                                            'control_type' => 'responsive',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-link-box-wrapper .pxl-link-box-tag' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'tag_box_padding',
                                            'label' => esc_html__('Padding', 'mouno' ),
                                            'type' => \Elementor\Controls_Manager::DIMENSIONS,
                                            'size_units' => [ 'px', '%' ],
                                            'control_type' => 'responsive',
                                            'separator' => 'before',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-link-box-wrapper .pxl-link-box-tag' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                    ],
                                ],
                                [
                                    'name' => 'tag_hover',
                                    'label' => esc_html__('Hover', 'mouno' ),
                                    'type' => \Elementor\Controls_Manager::TAB,
                                    'controls' => [
                                        array(
                                            'name' => 'hover_tag_color',
                                            'label' => esc_html__('Color', 'mouno' ),
                                            'type' => 'color',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-link-box-wrapper:hover .pxl-link-box-tag' => 'color: {{VALUE}};',
                                            ],
                                        ),
                                        [
                                            'name' => 'tag_transition_duration',
                                            'label' => esc_html__('Transition Duration', 'mouno'),
                                            'type' => \Elementor\Controls_Manager::SLIDER,
                                            'size_units' => ['ms', 's'],
                                            'range' => [
                                                'ms' => [
                                                    'min' => 0,
                                                    'max' => 10000,
                                                    'step' => 50,
                                                ],
                                                's' => [
                                                    'min' => 0,
                                                    'max' => 10,
                                                    'step' => 0.05,
                                                ],
                                            ],
                                            'default' => [
                                                'unit' => 's',
                                            ],
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-link-box-wrapper' => 'transition-duration: {{SIZE}}{{UNIT}};',
                                            ],
                                        ],
                                        array(
                                            'name' => 'hover_tag_bg_color',
                                            'label' => esc_html__('Background Color', 'mouno' ),
                                            'type' => 'color',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-link-box-wrapper:hover .pxl-link-box-tag' => 'background-color: {{VALUE}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'hover_tag_box_border',
                                            'type' => \Elementor\Group_Control_Border::get_type(),
                                            'separator' => 'before',
                                            'control_type' => 'group', 
                                            'selector' => '{{WRAPPER}} .pxl-link-box-wrapper:hover .pxl-link-box-tag',
                                        ),
                                        array(
                                            'name'         => 'hover_tag_box_box_shadow',
                                            'label' => esc_html__( 'Box Shadow', 'mouno' ),
                                            'type'         => \Elementor\Group_Control_Box_Shadow::get_type(),
                                            'control_type' => 'group',
                                            'selector'     => '{{WRAPPER}} .pxl-link-box-wrapper:hover .pxl-link-box-tag',
                                        ),
                                        array(
                                            'name' => 'hover_tag_box_border_radius',
                                            'label' => esc_html__('Border Radius', 'mouno' ),
                                            'type' => \Elementor\Controls_Manager::DIMENSIONS,
                                            'size_units' => [ 'px', '%' ],
                                            'control_type' => 'responsive',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-link-box-wrapper:hover .pxl-link-box-tag' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'hover_tag_box_padding',
                                            'label' => esc_html__('Padding', 'mouno' ),
                                            'type' => \Elementor\Controls_Manager::DIMENSIONS,
                                            'size_units' => [ 'px', '%' ],
                                            'control_type' => 'responsive',
                                            'separator' => 'before',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-link-box-wrapper:hover .pxl-link-box-tag' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                    ],
                                ],
                            ],
                        ),
                    ),
                ),
                array(
                    'name' => 'tab_icon_style',
                    'label' => esc_html__('Icon', 'mouno' ),
                    'tab' => \Elementor\Controls_Manager::TAB_STYLE,
                    'controls' => array(
                        array(
                            'name' => 'icon_size',
                            'label' => esc_html__('Size', 'mouno'),
                            'type' => 'slider',
                            'control_type' => 'responsive',
                            'size_units' => ['px', '%', 'custom'],
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 1000,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-link-box-wrapper .pxl-link-box-icon' => 'font-size: {{SIZE}}{{UNIT}};',
                                '{{WRAPPER}} .pxl-link-box-wrapper .pxl-link-box-icon svg' => 'height: {{SIZE}}{{UNIT}}; width: auto',
                            ],
                        ),
                        array(
                            'name' => 'icon_rotate',
                            'label' => esc_html__('Rotate', 'mouno'),
                            'type' => 'number',
                            'min' => -360,
                            'max' => 360,
                            'selectors' => [
                                '{{WRAPPER}} .pxl-link-box-wrapper .pxl-link-box-icon i, 
                                {{WRAPPER}} .pxl-link-box-wrapper .pxl-link-box-icon svg' => 'transform: rotate({{VALUE}}deg);',
                            ],
                        ),
                        array(
                            'name' => 'icon_controls',
                            'control_type' => 'tab',
                            'tabs' => [
                                [
                                    'name' => 'icon_normal',
                                    'label' => esc_html__('Normal', 'mouno' ),
                                    'type' => 'tab',
                                    'controls' => [  
                                        array(
                                            'name' => 'icon_color',
                                            'label' => esc_html__('Color', 'mouno' ),
                                            'type' => 'color',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-link-box-wrapper .pxl-link-box-icon' => 'color: {{VALUE}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'icon_bg_color',
                                            'label' => esc_html__('Background Color', 'mouno' ),
                                            'type' => 'color',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-link-box-wrapper .pxl-link-box-icon' => 'background-color: {{VALUE}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'icon_box_border',
                                            'type' => \Elementor\Group_Control_Border::get_type(),
                                            'separator' => 'before',
                                            'control_type' => 'group', 
                                            'selector' => '{{WRAPPER}} .pxl-link-box-wrapper .pxl-link-box-icon',
                                        ),
                                        array(
                                            'name'         => 'icon_box_box_shadow',
                                            'label' => esc_html__( 'Box Shadow', 'mouno' ),
                                            'type'         => \Elementor\Group_Control_Box_Shadow::get_type(),
                                            'control_type' => 'group',
                                            'selector'     => '{{WRAPPER}} .pxl-link-box-wrapper .pxl-link-box-icon',
                                        ),
                                        array(
                                            'name' => 'icon_box_border_radius',
                                            'label' => esc_html__('Border Radius', 'mouno' ),
                                            'type' => \Elementor\Controls_Manager::DIMENSIONS,
                                            'size_units' => [ 'px', '%' ],
                                            'control_type' => 'responsive',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-link-box-wrapper .pxl-link-box-icon' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'icon_box_padding',
                                            'label' => esc_html__('Padding', 'mouno' ),
                                            'type' => \Elementor\Controls_Manager::DIMENSIONS,
                                            'size_units' => [ 'px', '%' ],
                                            'control_type' => 'responsive',
                                            'separator' => 'before',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-link-box-wrapper .pxl-link-box-icon' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                    ],
                                ],
                                [
                                    'name' => 'icon_hover',
                                    'label' => esc_html__('Hover', 'mouno' ),
                                    'type' => \Elementor\Controls_Manager::TAB,
                                    'controls' => [
                                        array(
                                            'name' => 'hover_icon_color',
                                            'label' => esc_html__('Color', 'mouno' ),
                                            'type' => 'color',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-link-box-wrapper:hover .pxl-link-box-icon' => 'color: {{VALUE}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'hover_icon_bg_color',
                                            'label' => esc_html__('Background Color', 'mouno' ),
                                            'type' => 'color',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-link-box-wrapper:hover .pxl-link-box-icon' => 'background-color: {{VALUE}};',
                                            ],
                                        ),
                                        [
                                            'name' => 'icon_transition_duration',
                                            'label' => esc_html__('Transition Duration', 'mouno'),
                                            'type' => \Elementor\Controls_Manager::SLIDER,
                                            'size_units' => ['ms', 's'],
                                            'range' => [
                                                'ms' => [
                                                    'min' => 0,
                                                    'max' => 10000,
                                                    'step' => 50,
                                                ],
                                                's' => [
                                                    'min' => 0,
                                                    'max' => 10,
                                                    'step' => 0.05,
                                                ],
                                            ],
                                            'default' => [
                                                'unit' => 's',
                                            ],
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-link-box-wrapper' => 'transition-duration: {{SIZE}}{{UNIT}};',
                                            ],
                                        ],
                                        array(
                                            'name' => 'hover_icon_box_border',
                                            'type' => \Elementor\Group_Control_Border::get_type(),
                                            'separator' => 'before',
                                            'control_type' => 'group', 
                                            'selector' => '{{WRAPPER}} .pxl-link-box-wrapper:hover .pxl-link-box-icon',
                                        ),
                                        array(
                                            'name'         => 'hover_icon_box_box_shadow',
                                            'label' => esc_html__( 'Box Shadow', 'mouno' ),
                                            'type'         => \Elementor\Group_Control_Box_Shadow::get_type(),
                                            'control_type' => 'group',
                                            'selector'     => '{{WRAPPER}} .pxl-link-box-wrapper:hover .pxl-link-box-icon',
                                        ),
                                        array(
                                            'name' => 'hover_icon_box_border_radius',
                                            'label' => esc_html__('Border Radius', 'mouno' ),
                                            'type' => \Elementor\Controls_Manager::DIMENSIONS,
                                            'size_units' => [ 'px', '%' ],
                                            'control_type' => 'responsive',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-link-box-wrapper:hover .pxl-link-box-icon' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'hover_icon_box_padding',
                                            'label' => esc_html__('Padding', 'mouno' ),
                                            'type' => \Elementor\Controls_Manager::DIMENSIONS,
                                            'size_units' => [ 'px', '%' ],
                                            'control_type' => 'responsive',
                                            'separator' => 'before',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-link-box-wrapper:hover .pxl-link-box-icon' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                    ],
                                ],
                            ],
                        ),
                    ),
                ),
            ),
        ),
    ),
    mouno_get_class_widget_path()
);
