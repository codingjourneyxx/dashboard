<?php
pxl_add_custom_widget(
    array(
        'name' => 'pxl_index_box',
        'title' => esc_html__('Case Index Box', 'mouno' ),
        'icon' => 'eicon-number-field',
        'categories' => array('pxltheme-core'),
        'params' => array(
            'sections' => array(
                array(
                    'name' => 'tab_index_box_content',
                    'label' => esc_html__('Icon Box', 'mouno' ),
                    'tab' => 'content',
                    'controls' => array(   
                        array(
                            'name' => 'title_tag',
                            'label' => esc_html__('Title HTML Tag', 'mouno'),
                            'type' => 'select',
                            'default' => 'h4',
                            'options' => [
                                'h1' => esc_html__('H1', 'mouno'),
                                'h2' => esc_html__('H2', 'mouno'),
                                'h3' => esc_html__('H3', 'mouno'),
                                'h4' => esc_html__('H4', 'mouno'),
                                'h5' => esc_html__('H5', 'mouno'),
                                'h6' => esc_html__('H6', 'mouno'),
                                'div' => esc_html__('div', 'mouno'),
                                'p'  => esc_html__('p', 'mouno'),
                                'span' => esc_html__('span', 'mouno'),
                            ],
                        ),
                        array(
                            'name' => 'index',
                            'label' => esc_html__('Index', 'mouno'),
                            'type' => 'number',
                        ),
                        array(
                            'name' => 'title',
                            'label' => esc_html__('Title', 'mouno'),
                            'type' => 'text',
                            'label_block' => true,
                        ),
                        array(
                            'name' => 'desc',
                            'label' => esc_html__('Description', 'mouno'),
                            'type' => \Elementor\Controls_Manager::TEXTAREA,
                            'rows' => 10,
                        ),
                        array(
                            'name' => 'link',
                            'label' => esc_html__('Link URL', 'mouno'),
                            'type' => \Elementor\Controls_Manager::URL,
                            'label_block' => true,
                        ),
                    ),
                ),
                array(
                    'name' => 'tab_style_general',
                    'label' => esc_html__('General', 'mouno'),
                    'tab' => \Elementor\Controls_Manager::TAB_STYLE,
                    'controls' => array(
                        array(
                            'name' => 'icon_position',
                            'label' => esc_html__('Icon Position', 'mouno'),
                            'type' => \Elementor\Controls_Manager::CHOOSE,
                            'control_type' => 'responsive',
                            'options' => array(
                                'row' =>[
                                    'title' => esc_html__('Left', 'mouno'),
                                    'icon' => 'eicon-h-align-left',
                                ],
                                'column' => [
                                    'title' => esc_html__('Top', 'mouno'),
                                    'icon' => 'eicon-v-align-top'
                                ],
                                'row-reverse' => [
                                    'title' => esc_html__('Right', 'mouno'),
                                    'icon' => 'eicon-h-align-right',
                                ],
                            ),
                            'selectors' => [
                                '{{WRAPPER}} .pxl-icon-box-carousel .pxl-swiper-slide .pxl-slide-inner' => '--pxl-flex-direction: {{VALUE}};'
                            ],
                        ),
                        array(
                            'name' => 'content_alignment',
                            'label' => esc_html__('Alignment', 'mouno' ),
                            'type' => \Elementor\Controls_Manager::CHOOSE,
                            'control_type' => 'responsive',
                            'options' => [
                                'left' =>  [
                                    'title' => esc_html__('Left', 'mouno'),
                                    'icon' => 'eicon-text-align-left',
                                ],
                                'center' =>  [
                                    'title' => esc_html__('Center', 'mouno'),
                                    'icon' => 'eicon-text-align-center',
                                ],
                                'right' =>  [
                                    'title' => esc_html__('Right', 'mouno'),
                                    'icon' => 'eicon-text-align-right',
                                ],
                                'justify' =>  [
                                    'title' => esc_html__('Justify', 'mouno'),
                                    'icon' => 'eicon-text-align-justify',
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-icon-box-carousel .pxl-swiper-slide .pxl-slide-inner' => 'text-align: {{VALUE}};'
                            ],
                        ),
                        array(
                            'name' => 'max_w',
                            'label' => esc_html__('Max Width', 'mouno'),
                            'type' => 'slider',
                            'control_type' => 'responsive',
                            'size_units' => ['px', '%', 'rem', 'em', 'custom'],
                            'separator' => 'before',
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 1000,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-icon-box-carousel .pxl-swiper-slide .pxl-slide-inner' => 'max-width: {{SIZE}}{{UNIT}};',
                            ],
                        ),
                        array(
                            'name' => 'icon_spacing',
                            'label' => esc_html__('Icon Spacing', 'mouno'),
                            'type' => 'slider',
                            'control_type' => 'responsive',
                            'size_units' => ['px', '%', 'rem', 'em', 'custom'],
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 1000,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-icon-box-carousel .pxl-swiper-slide .pxl-slide-inner' => 'gap: {{SIZE}}{{UNIT}};',
                            ],
                        ),
                        array(
                            'name' => 'content_spacing',
                            'label' => esc_html__('Content Spacing', 'mouno'),
                            'type' => 'slider',
                            'control_type' => 'responsive',
                            'size_units' => ['px', '%', 'rem', 'em', 'custom'],
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 1000,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-icon-box-carousel .pxl-swiper-slide .pxl-slide-inner .pxl-item-title' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                            ],
                        ),
                    ),
                ),
            ),
        ),
    ),
    mouno_get_class_widget_path()
);