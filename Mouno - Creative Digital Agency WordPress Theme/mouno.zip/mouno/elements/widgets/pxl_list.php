<?php
pxl_add_custom_widget(
    array(
        'name' => 'pxl_list',
        'title' => esc_html__('Case List', 'mouno' ),
        'icon' => 'eicon-editor-list-ul',
        'categories' => array('pxltheme-core'),
        'scripts' => array(),
        'params' => array(
            'sections' => array(
                array(
                    'name' => 'tab_list_content',
                    'label' => esc_html__('List', 'mouno' ),
                    'tab' => 'content',
                    'controls' => array(   
                        array(
                            'name' => '_icon',
                            'label' => esc_html__('Icon', 'mouno' ),
                            'type' => 'icons',
                            'fa4compatibility' => 'icon',
                            'default' => [
                                'value' => [
                                    'url' => 'http://mouno.local/wp-content/uploads/2024/12/plus.svg', 
                                    'id' => 4470, 
                                ],
                                'library' => 'svg',
                            ],
                        ),
                        array(
                            'name' => 'list',
                            'label' => esc_html__('List', 'mouno' ),
                            'type' => 'repeater',
                            'controls' => array(
                                array(
                                    'name' => 'text',
                                    'label' => esc_html__('Text', 'mouno' ),
                                    'type' => 'text',
                                    'label_block' => true,
                                ),
                            ),
                            'default' => [
                                [
                                    'text' => esc_html__( 'Lorem ipsum dolor sit' ,'mouno')
                                ],
                                [
                                    'text' => esc_html__( 'Lorem ipsum dolor sit' ,'mouno')
                                ],
                                [
                                    'text' => esc_html__( 'Lorem ipsum dolor sit' ,'mouno')
                                ],
                                
                            ],
                            'title_filed' => '{{{text}}}',
                        ),
                    ),
                ),
                array(
                    'name' => 'tab_list_style',
                    'label' => esc_html__('List', 'mouno' ),
                    'tab' => 'style',
                    'controls' => array( 
                        array(
                            'name' => 'item_align_items',
                            'label' => esc_html__('Item Vertical Align', 'mouno'),
                            'type' => 'choose',
                            'control_type' => 'responsive',
                            'options' => array(
                                'start' =>[
                                    'title' => esc_html__('Start', 'mouno'),
                                    'icon' => 'eicon-align-start-v',
                                ],
                                'center' => [
                                    'title' => esc_html__('Center', 'mouno'),
                                    'icon' => 'eicon-align-center-v'
                                ],
                                'end' => [
                                    'title' => esc_html__('End', 'mouno'),
                                    'icon' => 'eicon-align-end-v',
                                ],
                            ),
                            'selectors' => [
                                '{{WRAPPER}} .pxl-list-wrapper .pxl-list-item' => 'align-items: {{VALUE}};'
                            ],
                        ),
                        array(
                            'name' => 'item_spacing',
                            'label' => esc_html__('Item Spacing', 'mouno'),
                            'type' => 'slider',
                            'control_type' => 'responsive',
                            'size_units' => ['px', '%', 'custom'],
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 1000,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-list-wrapper' => '--pxl-margin-top: {{SIZE}}{{UNIT}};',
                            ],
                        ),
                        array(
                            'name' => 'icon_spacing',
                            'label' => esc_html__('Icon Spacing', 'mouno'),
                            'type' => 'slider',
                            'control_type' => 'responsive',
                            'size_units' => ['px', '%', 'custom'],
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 1000,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-list-wrapper .pxl-list-item' => 'gap: {{SIZE}}{{UNIT}};',
                            ],
                        ),

                        array(
                            'name' => 'list_controls',
                            'control_type' => 'tab',
                            'tabs' => [
                                [
                                    'name' => 'text_normal',
                                    'label' => esc_html__('Text', 'mouno' ),
                                    'type' => 'tab',
                                    'controls' => [  
                                        array(
                                            'name' => 'text_color',
                                            'label' => esc_html__('Color', 'mouno' ),
                                            'type' => 'color',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-list-wrapper .pxl-list-item' => 'color: {{VALUE}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'typography',
                                            'type' => \Elementor\Group_Control_Typography::get_type(),
                                            'control_type' => 'group',
                                            'selector' => '{{WRAPPER}} .pxl-list-wrapper .pxl-list-item',
                                        ),
                                    ],
                                ],
                                [
                                    'name' => 'icon_normal',
                                    'label' => esc_html__('Icon', 'mouno' ),
                                    'type' => 'tab',
                                    'controls' => [
                                        array(
                                            'name' => 'icon_color',
                                            'label' => esc_html__('Color', 'mouno' ),
                                            'type' => 'color',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-list-wrapper .pxl-list-item svg, {{WRAPPER}} .pxl-list-wrapper .pxl-list-item icon' => 'color: {{VALUE}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'icon_sz',
                                            'label' => esc_html__('Icon Size', 'mouno'),
                                            'type' => 'slider',
                                            'control_type' => 'responsive',
                                            'size_units' => ['px', '%', 'custom'],
                                            'range' => [
                                                'px' => [
                                                    'min' => 0,
                                                    'max' => 1000,
                                                ],
                                            ],
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-list-wrapper .pxl-list-item svg' => 'height: {{SIZE}}{{UNIT}};',
                                                '{{WRAPPER}} .pxl-list-wrapper .pxl-list-item i' => 'font-size: {{SIZE}}{{UNIT}};'
                                            ],
                                        ),
                                    ],
                                ],
                            ],
                        ),
                    ),
                ),

                array(
                    'name' => 'tab_list_anim',
                    'label' => esc_html__('Animation', 'mouno'),
                    'tab' => 'style',
                    'controls' => mouno_get_animation_options([
                        // 'selector' => ''
                    ]),
                ),
            ),
        ),
    ),
    mouno_get_class_widget_path()
);