<?php
pxl_add_custom_widget(
    array(
        'name' => 'pxl_circular_text',
        'title' => esc_html__('Case Circular Text', 'mouno' ),
        'icon' => 'eicon-animation-text',
        'categories' => array('pxltheme-core'),
        'scripts' => [
            'circletype',
            'circular-text',
        ],
        'params' => array(
            'sections' => array(
                array(
                    'name' => 'tab_circular_text_content',
                    'label' => esc_html__('Circular Text', 'mouno' ),
                    'tab' => 'content',
                    'controls' => array(
                        array(
                            'name' => 'text',
                            'label' => esc_html__('Text', 'mouno' ),
                            'type' => 'textarea',
                            'rows' => 2,
                            'default' => esc_html__('MOUNO AGENCY . CREATIVE DESIGN AGENCY .', 'mouno'),
                        ),
                        array(
                            'name' => 'icon_type',
                            'type' => 'choose',
                            'label' => esc_html__('Icon Type', 'mouno'),
                            'options' => [
                                '' => [
                                    'title' => esc_html__('None', 'mouno'),
                                    'icon' => 'eicon-ban',
                                ],
                                'icon' => [
                                    'title' => esc_html__('Icon', 'mouno'),
                                    'icon' => 'eicon-upload',
                                ],
                                'img' => [
                                    'title' => esc_html__('Image', 'mouno'),
                                    'icon' => 'eicon-image',
                                ],
                            ],
                            'default' => 'icon',
                        ),
                        array(
                            'name' => 'img',
                            'label' => esc_html__('Image', 'mouno' ),
                            'type' => \Elementor\Controls_Manager::MEDIA,
                            'condition' => [
                                'icon_type' => 'img',
                            ],
                        ),
                        array(
                            'name' => '_icon',
                            'label' => esc_html__('Icon', 'mouno' ),
                            'type' => \Elementor\Controls_Manager::ICONS,
                            'fa4compatibility' => 'icon',
                            'condition' => [
                                'icon_type' => 'icon',
                            ],
                            'default' => [
                                'value' => [
                                    'url' => content_url('wp-content/uploads/2024/11/union1.svg'), 
                                    'id' => 612, 
                                ],
                                'library' => 'svg',
                            ],
                        ),
                    ),
                ),
                array(
                    'name' => 'tab_circular_text_style',
                    'label' => esc_html__('Circular Text', 'mouno' ),
                    'tab' => 'style',
                    'controls' => array(
                        array(
                            'name' => 'bg_color',
                            'label' => esc_html__('Box Color', 'mouno' ),
                            'type' => \Elementor\Controls_Manager::COLOR,
                            'selectors' => [
                                '{{WRAPPER}} .pxl-circular-text-wrapper' => 'background-color: {{VALUE}};',
                            ],
                        ),
                        array(
                            'name' => 'padding',
                            'label' => esc_html__( 'Box Padding', 'mouno' ),
                            'type' => \Elementor\Controls_Manager::DIMENSIONS,
                            'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
                            'control_type' => 'responsive',
                            'selectors' => [
                                '{{WRAPPER}} .pxl-circular-text-wrapper' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            ],
                        ),
                        array(
                            'name' => 'bg_text_color',
                            'label' => esc_html__('Box Text Color', 'mouno' ),
                            'separator' => 'before',
                            'type' => \Elementor\Controls_Manager::COLOR,
                            'selectors' => [
                                '{{WRAPPER}} .pxl-circular-text-wrapper .pxl-circular-text-item' => 'background-color: {{VALUE}};',
                            ],
                        ),
                        array(
                            'name' => 'box_text_padding',
                            'label' => esc_html__( 'Box Text Padding', 'mouno' ),
                            'type' => \Elementor\Controls_Manager::DIMENSIONS,
                            'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
                            'control_type' => 'responsive',
                            'selectors' => [
                                '{{WRAPPER}} .pxl-circular-text-wrapper .pxl-circular-text-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            ],
                        ),
                        array(
                            'name' => 'spin_text',
                            'label' => esc_html__('Spin', 'mouno' ),
                            'type' => \Elementor\Controls_Manager::SELECT,
                            'default' => '0',
                            'options' => [
                                '0'    => esc_html__('None', 'mouno'),
                                '360' => esc_html__('CW', 'mouno'),
                                '-360' => esc_html__('CCW', 'mouno'),
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-circular-text-wrapper .pxl-circular-text-item div' => '--pxl-rotate: {{VALUE}}deg;',
                            ],
                            'default' => '0',
                        ),
                        [
                            'name' => 'anim_duration',
                            'label' => esc_html__('Animation Duration', 'mouno'),
                            'type' => \Elementor\Controls_Manager::SLIDER,
                            'size_units' => ['ms', 's'],
                            'range' => [
                                'ms' => [
                                    'min' => 0,
                                    'max' => 100000,
                                    'step' => 50,
                                ],
                                's' => [
                                    'min' => 0,
                                    'max' => 100,
                                    'step' => 0.05,
                                ],
                            ],
                            'default' => [
                                'size' => 15000,
                                'unit' => 'ms',
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-circular-text-wrapper .pxl-circular-text-item div' => 'animation-duration: {{SIZE}}{{UNIT}}; --webkit-animation-duration: {{SIZE}}{{UNIT}};',
                            ],
                        ],
                        array(
                            'name' => 'circular_text_control',
                            'control_type' => 'tab',
                            'tabs' => [
                                [
                                    'name' => 'circular_text',
                                    'label' => esc_html__('Text', 'mouno' ),
                                    'type' => 'tab',
                                    'controls' => [  
                                        array(
                                            'name' => 'text_color',
                                            'label' => esc_html__('Text Color', 'mouno' ),
                                            'type' => \Elementor\Controls_Manager::COLOR,
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-circular-text-wrapper .pxl-circular-text-item' => 'color: {{VALUE}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'text_typography',
                                            'type' => \Elementor\Group_Control_Typography::get_type(),
                                            'control_type' => 'group',
                                            'selector' => '{{WRAPPER}} .pxl-circular-text-wrapper .pxl-circular-text-item',
                                        ),
                                    ],
                                ],
                                [
                                    'name' => 'circular_text_icon',
                                    'label' => esc_html__('Icon', 'mouno' ),
                                    'type' => \Elementor\Controls_Manager::TAB,
                                    'controls' => [
                                        array(
                                            'name' => 'img_size',
                                            'label' => esc_html__('Image Size', 'mouno' ),
                                            'type' => \Elementor\Controls_Manager::TEXT,
                                            'description' => esc_html__('Ex: "thumbnail", "medium", "large", "full"...Alternatively enter size in pixels. Ex: 200x100 - Width x Height.', 'mouno'),
                                        ),
                                        array(
                                            'name' => 'box_icon_color',
                                            'label' => esc_html__('Box Color', 'mouno' ),
                                            'type' => \Elementor\Controls_Manager::COLOR,
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-circular-text-wrapper .pxl-circular-text-icon' => 'background-color: {{VALUE}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'svg_color',
                                            'label' => esc_html__('Icon Color', 'mouno' ),
                                            'type' => \Elementor\Controls_Manager::COLOR,
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-circular-text-wrapper .pxl-circular-text-icon' => 'color: {{VALUE}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'img_w',
                                            'label' => esc_html__('Width', 'mouno'),
                                            'type' => \Elementor\Controls_Manager::SLIDER,
                                            'size_units' => ['px', '%', 'custom'],
                                            'control_type' => 'responsive',
                                            'range' => [
                                                'px' => [
                                                    'min' => 0,
                                                    'max' => 1000,
                                                ],
                                            ],
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-circular-text-wrapper .pxl-circular-text-icon img, {{WRAPPER}} .pxl-circular-text-wrapper .pxl-circular-text-icon svg' => 'width: {{SIZE}}{{UNIT}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'img_h',
                                            'label' => esc_html__('Height', 'mouno'),
                                            'type' => \Elementor\Controls_Manager::SLIDER,
                                            'size_units' => ['px', '%', 'custom'],
                                            'control_type' => 'responsive',
                                            'range' => [
                                                'px' => [
                                                    'min' => 0,
                                                    'max' => 1000,
                                                ],
                                            ],
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-circular-text-wrapper .pxl-circular-text-icon img, {{WRAPPER}} .pxl-circular-text-wrapper .pxl-circular-text-icon svg' => 'height: {{SIZE}}{{UNIT}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'icon_box_sz',
                                            'label' => esc_html__('Box Size', 'mouno'),
                                            'type' => \Elementor\Controls_Manager::SLIDER,
                                            'size_units' => ['px', '%', 'custom'],
                                            'control_type' => 'responsive',
                                            'range' => [
                                                'px' => [
                                                    'min' => 0,
                                                    'max' => 1000,
                                                ],
                                            ],
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-circular-text-wrapper .pxl-circular-text-icon' => '--pxl-box-size: {{SIZE}}{{UNIT}};',
                                            ],
                                        ),

                                        array(
                                            'name' => 'box_icon_padding',
                                            'label' => esc_html__( 'Box Padding', 'mouno' ),
                                            'type' => \Elementor\Controls_Manager::DIMENSIONS,
                                            'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
                                            'control_type' => 'responsive',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-circular-text-wrapper .pxl-circular-text-icon' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                    ],
                                ],
                            ],
                        ),
                    ),
                ),
            ),
        ),
    ),
);