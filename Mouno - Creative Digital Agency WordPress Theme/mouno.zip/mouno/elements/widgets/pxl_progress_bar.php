<?php
pxl_add_custom_widget(
    array(
        'name' => 'pxl_progress_bar',
        'title' => esc_html__( 'Case Progress Bar', 'mouno' ),
        'icon' => 'eicon-skill-bar',
        'categories' => array('pxltheme-core'),
        'params' => array(
            'sections' => array(
                array(
                    'name' => 'tab_content',
                    'label' => esc_html__( 'Content', 'mouno' ),
                    'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
                    'controls' => array(
                        array(
                            'name' => 'items',
                            'label' => esc_html__( 'Progress Bar', 'mouno' ),
                            'type' => \Elementor\Controls_Manager::REPEATER,
                            'controls' => array(
                                array(
                                    'name' => 'title',
                                    'label' => esc_html__( 'Title', 'mouno' ),
                                    'type' => \Elementor\Controls_Manager::TEXT,
                                    'label_block' => true,
                                ),
                                array(
                                    'name' => 'percent',
                                    'label' => esc_html__( 'Percent', 'mouno' ),
                                    'type' => \Elementor\Controls_Manager::SLIDER,
                                    'default' => [
                                        'size' => 50,
                                        'unit' => '%',
                                    ],
                                    'label_block' => true,
                                ),
                            ),
                            'title_field' => '{{{ title }}}',
                        ),
                    ),
                ),
                array(
                    'name' => 'section_style',
                    'label' => esc_html__('General', 'mouno' ),
                    'tab' => \Elementor\Controls_Manager::TAB_STYLE,
                    'controls' => array( 
                        array(
                            'name' => 'max_width',
                            'label' => esc_html__('Max Width', 'mouno'),
                            'type' => \Elementor\Controls_Manager::SLIDER,
                            'size_units' => ['px', '%', 'rem', 'em', 'custom'],
                            'control_type' => 'responsive',
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 1000,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-progress-bar .pxl-item--inner' => 'max-width: {{SIZE}}{{UNIT}};',
                            ],
                        ),
                        array(
                            'name' => 'item_spacing',
                            'label' => esc_html__('Item Spacing', 'mouno'),
                            'type' => \Elementor\Controls_Manager::SLIDER,
                            'size_units' => ['px', '%', 'rem', 'em', 'custom'],
                            'control_type' => 'responsive',
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 1000,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-progress-bar .pxl-item--single + .pxl-item--single' => 'margin-top: {{SIZE}}{{UNIT}};',
                            ],
                        ),
                    ),
                ),

                array(
                    'name' => 'section_style_progress',
                    'label' => esc_html__('Progress Bar', 'mouno' ),
                    'tab' => \Elementor\Controls_Manager::TAB_STYLE,
                    'controls' => array( 
                        array(
                            'name' => 'track_options',
                            'label' => esc_html__('TRACK', 'mouno'), 
                            'type' => \Elementor\Controls_Manager::HEADING,
                            'separator' => 'after', 
                        ),
                        array(
                            'name' => 'track_bg_color',
                            'label' => esc_html__( 'Backgroud Color', 'mouno' ),
                            'type' => \Elementor\Controls_Manager::COLOR,
                            'selectors' => [
                                '{{WRAPPER}} .pxl-progress-bar .pxl-item--track' => 'background-color: {{VALUE}}',
                            ],
                        ),
                        array(
                            'name' => 'track_spacing_top',
                            'label' => esc_html__('Spacing Top', 'mouno'),
                            'type' => \Elementor\Controls_Manager::SLIDER,
                            'size_units' => ['px', '%', 'rem', 'em', 'custom'],
                            'control_type' => 'responsive',
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 1000,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-progress-bar .pxl-item--track' => 'margin-top: {{SIZE}}{{UNIT}};',
                            ],
                        ),
                        array(
                            'name' => 'divider2',
                            'type' => \Elementor\Controls_Manager::DIVIDER,
                        ),
                        array(
                            'name' => 'fill_options',
                            'label' => esc_html__('FILL', 'mouno'), 
                            'type' => \Elementor\Controls_Manager::HEADING,
                            'separator' => 'after', 
                        ),
                        array(
                            'name' => 'fill_bg_color',
                            'label' => esc_html__( 'Backgroud Color', 'mouno' ),
                            'type' => \Elementor\Controls_Manager::COLOR,
                            'selectors' => [
                                '{{WRAPPER}} .pxl-progress-bar .pxl-item--fill' => 'background-color: {{VALUE}}',
                            ],
                        ),
                    ),
                ),

                array(
                    'name' => 'section_style_title',
                    'label' => esc_html__('Title', 'mouno' ),
                    'tab' => \Elementor\Controls_Manager::TAB_STYLE,
                    'controls' => array( 
                        array(
                            'name' => 'title_color',
                            'label' => esc_html__('Color', 'mouno' ),
                            'type' => \Elementor\Controls_Manager::COLOR,
                            'selectors' => [
                                '{{WRAPPER}} .pxl-progress-bar .pxl-item--title' => 'color: {{VALUE}};',
                            ],
                        ),
                        array(
                            'name' => 'title_typography',
                            'label' => esc_html__('Typography', 'mouno' ),
                            'type' => \Elementor\Group_Control_Typography::get_type(),
                            'control_type' => 'group',
                            'selector' => '{{WRAPPER}} .pxl-progress-bar .pxl-item--title',
                        ),
                    ),
                ),

                array(
                    'name' => 'section_style_percent',
                    'label' => esc_html__('Percent', 'mouno' ),
                    'tab' => \Elementor\Controls_Manager::TAB_STYLE,
                    'controls' => array( 
                        array(
                            'name' => 'percent_color',
                            'label' => esc_html__('Color', 'mouno' ),
                            'type' => \Elementor\Controls_Manager::COLOR,
                            'selectors' => [
                                '{{WRAPPER}} .pxl-progress-bar .pxl-item--percent' => 'color: {{VALUE}};',
                            ],
                        ),
                        array(
                            'name' => 'percent_typography',
                            'label' => esc_html__('Typography', 'mouno' ),
                            'type' => \Elementor\Group_Control_Typography::get_type(),
                            'control_type' => 'group',
                            'selector' => '{{WRAPPER}} .pxl-progress-bar .pxl-item--percent',
                        ),
                    ),
                ),
            ),
        ),
    ),
    mouno_get_class_widget_path()
);