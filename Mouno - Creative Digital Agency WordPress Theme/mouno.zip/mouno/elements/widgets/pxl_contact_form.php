<?php
$contact_forms[0] = 'Choose Form';
if(class_exists('WPCF7')) {
    $cf7 = get_posts('post_type="wpcf7_contact_form"&numberposts=-1');
    if ($cf7) {
        foreach ($cf7 as $cform) {
            $contact_forms[$cform->ID] = $cform->post_title;
        }
    } else {
        $contact_forms[esc_html__('No contact forms found', 'mouno')] = 0;
    }
}

$breakpoints = [
    'xs' => ['label' => esc_html__('Columns: Screen < 575px', 'mouno'), 'media_query' => '--width-xs'],
    'sm' => ['label' => esc_html__('Columns: Screen ≥ 576px', 'mouno'), 'media_query' => '--width-sm'],
    'md' => ['label' => esc_html__('Columns: Screen ≥ 768px', 'mouno'), 'media_query' => '--width-md'],
    'lg' => ['label' => esc_html__('Columns: Screen ≥ 992px', 'mouno'), 'media_query' => '--width-lg'],
    'xl' => ['label' => esc_html__('Columns: Screen ≥ 1200px', 'mouno'), 'media_query' => '--width-xl'],
    'xxl' => ['label' => esc_html__('Columns: Screen ≥ 1400px', 'mouno'), 'media_query' => '--width-xxl'],
];

$configs = [];

foreach ($breakpoints as $key => $breakpoint) {
    $configs[] = [
        'name' => "form_grid_{$key}",
        'label' => $breakpoint['label'],
        'type' => 'select',
        'options' => [
            '' => esc_html__('Default', 'mouno'),
            '100%' => esc_html__('1', 'mouno'),
            '50%' => esc_html__('2', 'mouno'),
            '33.33333%' => esc_html__('3', 'mouno'),
            '25%' => esc_html__('4', 'mouno'),
        ],
        'default' => '',
        'selectors' => [
            "{{WRAPPER}} .wpcf7 form p .wpcf7-form-control-wrap" => "{$breakpoint['media_query']}: {{VALUE}};"
        ],
    ];
}

pxl_add_custom_widget(
    array(
        'name' => 'pxl_contact_form',
        'title' => esc_html__('Case Contact Form', 'mouno'),
        'icon' => 'eicon-form-horizontal',
        'categories' => array('pxltheme-core'),
        'params' => array(
            'sections' => array(
                array(
                    'name' => 'tab_cf_content',
                    'label' => esc_html__('Contact Form', 'mouno'),
                    'tab' => 'content',
                    'controls' => array(
                        array(
                            'name' => 'cf7_id',
                            'label' => esc_html__('Choose Form', 'mouno'),
                            'type' => 'select',
                            'options' => $contact_forms,
                            'default' => '0',
                        ),
                        array(
                            'name' => 'form_id',
                            'label' => esc_html__('Form ID', 'mouno'),
                            'type' => 'text',
                            'placeholder' => esc_html__('Ex: form123456', 'mouno'),
                            'description' => esc_html__('Ids are unique and consist of a string of letters and numbers. Do not use spaces or special characters. Hyphens and underscores are allowed.', 'mouno'),
                        ),
                        array(
                            'name' => 'form_style',
                            'label' => esc_html__('Form Style', 'mouno'),
                            'type' => 'select',
                            'options' => [
                                '' => esc_html__('Default', 'mouno'),
                                'form-style1' => esc_html__('Form Style 1', 'mouno'),
                                'form-style2' => esc_html__('Form Style 2', 'mouno'),
                                'form-style3' => esc_html__('Form Style 3', 'mouno'),
                                'form-style4' => esc_html__('Form Style 4', 'mouno'),
                                'form-style5' => esc_html__('Form Style 5', 'mouno'),
                                'form-custom' => esc_html__('Custom', 'mouno'),
                            ],
                            'default' => '',
                        ),
                        // array(
                        //     'name' => 'form_grid',
                        //     'label' => esc_html__('Column', 'mouno'),
                        //     'type' => 'select',
                        //     'separator' => 'before',
                        //     'control_type' => 'responsive',
                        //     'options' => [
                        //         '' => esc_html__('Default', 'mouno'),
                        //         '100%' => esc_html__('1', 'mouno'),
                        //         '50%' => esc_html__('2', 'mouno'),
                        //         '33.33333%' => esc_html__('3', 'mouno'),
                        //         '25%' => esc_html__('4', 'mouno'),
                        //     ],
                        //     'default' => '',
                        //     'selectors' => [
                        //         '{{WRAPPER}} .wpcf7 form p .wpcf7-form-control-wrap' => 'flex-basis: {{VALUE}};max-width: {{VALUE}};',
                        //     ],
                        // ),
                    ),
                ),
                array(
                    'name' => 'tab_cf7_settings',
                    'label' => esc_html__('Responsive', 'mouno'),
                    'tab' => 'settings' ,
                    'controls' => array_merge(
                        array(
                            array(
                                'name' => 'item_grid_spacing_h',
                                'label' => esc_html__('Horizontal Spacing', 'mouno'),
                                'type' => 'slider',
                                'size_units' => ['px', 'custom'],
                                'range' => [
                                    'px' => [
                                        'min' => 0,
                                        'max' => 1000,
                                    ],
                                ],
                                'selectors' => [
                                    '{{WRAPPER}} .wpcf7 form p' => "--pxl-spacing-inline: {{SIZE}}{{UNIT}};",
                                ],
                            ),
                            array(
                                'name' => 'item_grid_spacing_v',
                                'label' => esc_html__('Vertical Spacing', 'mouno'),
                                'type' => 'slider',
                                'size_units' => ['px', 'custom'],
                                'range' => [
                                    'px' => [
                                        'min' => 0,
                                        'max' => 1000,
                                    ],
                                ],
                                'selectors' => [
                                    '{{WRAPPER}} .wpcf7 form p .wpcf7-form-control-wrap' => "margin-bottom: {{SIZE}}{{UNIT}};",
                                ],
                            ),
                        ),
                        $configs,
                    ),
                ),

                array(
                    'name' => 'tab_input_style',
                    'label' => esc_html__('Field', 'mouno'),
                    'tab' => 'style',
                    'controls' => array(
                        array(
                            'name' => 'textarea_resize',
                            'label' => esc_html__('Textarea Resize', 'mouno'),
                            'type' => 'select',
                            'options' => [
                                '' => esc_html__('Default', 'mouno'),
                                'both' => esc_html__('Both', 'mouno'),
                                'horizontal' => esc_html__('Horizontal', 'mouno'),
                                'vertical' => esc_html__('Vertical', 'mouno'),
                                'none' => esc_html__('None', 'mouno'),
                            ],
                            'default' => '',
                            'selectors' => [
                                '{{WRAPPER}} .wpcf7 form .wpcf7-form-control-wrap textarea' => "resize: {{VALUE}};",
                            ],
                        ),
                        array(
                            'name' => 'textarea_h',
                            'label' => esc_html__('Textarea Height', 'mouno'),
                            'type' => 'slider',
                            'size_units' => ['px', 'custom'],
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 1000,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .wpcf7 form .wpcf7-form-control-wrap textarea' => "height: {{SIZE}}{{UNIT}};",
                            ],
                        ),
                        array(
                            'name' => 'divider2',
                            'type' => 'divider',
                        ),
                        array(
                            'name' => 'icon_color',
                            'label' => esc_html__('Icon Color', 'mouno' ),
                            'type' => 'color',
                            'selectors' => [
                                '{{WRAPPER}} .wpcf7 form i' => 'color: {{VALUE}};',
                            ],
                        ),
                        array(
                            'name' => 'icon_sz',
                            'label' => esc_html__('Icon Size', 'mouno'),
                            'type' => 'slider',
                            'size_units' => ['px', 'custom'],
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 1000,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .wpcf7 form i' => "font-size: {{SIZE}}{{UNIT}};",
                            ],
                        ),
                        array(
                            'name' => 'divider3',
                            'type' => 'divider',
                        ),
                        array(
                            'name' => 'input_h',
                            'label' => esc_html__('Input Height', 'mouno'),
                            'type' => 'slider',
                            'size_units' => ['px', 'custom'],
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 1000,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .wpcf7 form .wpcf7-form-control-wrap input' => "height: {{SIZE}}{{UNIT}};",
                            ],
                        ),
                        array(
                            'name' => 'input_typography',
                            'type' => \Elementor\Group_Control_Typography::get_type(),
                            'control_type' => 'group',
                            'selector' => '{{WRAPPER}} .wpcf7 form .wpcf7-form-control-wrap input, {{WRAPPER}} .wpcf7 form .wpcf7-form-control-wrap textarea',
                        ),
                        array(
                            'name' => 'input_controls',
                            'control_type' => 'tab',
                            'tabs' => [
                                [
                                    'name' => 'input_normal',
                                    'label' => esc_html__('Normal', 'mouno' ),
                                    'type' => 'tab',
                                    'controls' => [  
                                        array(
                                            'name' => 'input_color',
                                            'label' => esc_html__('Text Color', 'mouno' ),
                                            'type' => 'color',
                                            'selectors' => [
                                                '{{WRAPPER}} .wpcf7 form .wpcf7-form-control-wrap input, 
                                                {{WRAPPER}} .wpcf7 form .wpcf7-form-control-wrap textarea' => 'color: {{VALUE}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'input_bg',
                                            'type' => \Elementor\Group_Control_Background::get_type(),
                                            'control_type' => 'group',
                                            'types' => [ 'classic', 'gradient' ],
                                            'selector' => '{{WRAPPER}} .wpcf7 form .wpcf7-form-control-wrap input, 
                                            {{WRAPPER}} .wpcf7 form .wpcf7-form-control-wrap textarea',
                                        ),
                                        array(
                                            'name' => 'input_border',
                                            'type' => \Elementor\Group_Control_Border::get_type(),
                                            'separator' => 'before',
                                            'control_type' => 'group', 
                                            'selector' => '{{WRAPPER}} .wpcf7 form .wpcf7-form-control-wrap input, 
                                            {{WRAPPER}} .wpcf7 form .wpcf7-form-control-wrap textarea',
                                        ),
                                        array(
                                            'name'         => 'input_box_shadow',
                                            'label' => esc_html__( 'Box Shadow', 'mouno' ),
                                            'type'         => \Elementor\Group_Control_Box_Shadow::get_type(),
                                            'control_type' => 'group',
                                            'selector'     => '{{WRAPPER}} .wpcf7 form .wpcf7-form-control-wrap input, 
                                            {{WRAPPER}} .wpcf7 form .wpcf7-form-control-wrap textarea',
                                        ),
                                        array(
                                            'name' => 'input_border_radius',
                                            'label' => esc_html__('Border Radius', 'mouno' ),
                                            'type' => 'dimensions',
                                            'size_units' => [ 'px', '%' ],
                                            'selectors' => [
                                                '{{WRAPPER}} .wpcf7 form .wpcf7-form-control-wrap input, 
                                                {{WRAPPER}} .wpcf7 form .wpcf7-form-control-wrap textarea' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'input_padding',
                                            'label' => esc_html__('Padding', 'mouno' ),
                                            'type' => 'dimensions',
                                            'size_units' => [ 'px', 'custom' ],
                                            'control_type' => 'responsive',
                                            'separator' => 'before',
                                            'selectors' => [
                                                '{{WRAPPER}} .wpcf7 form .wpcf7-form-control-wrap input, 
                                                {{WRAPPER}} .wpcf7 form .wpcf7-form-control-wrap textarea' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                    ],
                                ],
                                [
                                    'name' => 'input_focus',
                                    'label' => esc_html__('Focus/Hover', 'mouno' ),
                                    'type' => 'tab',
                                    'controls' => [
                                        array(
                                            'name' => 'input_focus_color',
                                            'label' => esc_html__('Text Color', 'mouno' ),
                                            'type' => 'color',
                                            'selectors' => [
                                                '{{WRAPPER}} .wpcf7 form .wpcf7-form-control-wrap input:focus,
                                                {{WRAPPER}} .wpcf7 form .wpcf7-form-control-wrap input:hover,
                                                {{WRAPPER}} .wpcf7 form .wpcf7-form-control-wrap textarea:focus,
                                                {{WRAPPER}} .wpcf7 form .wpcf7-form-control-wrap textarea:hover' => 'color: {{VALUE}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'input_focus_bg',
                                            'label' => esc_html__('Background Color', 'mouno' ),
                                            'type' => \Elementor\Group_Control_Background::get_type(),
                                            'control_type' => 'group',
                                            'types' => [ 'classic', 'gradient' ],
                                            'selector' => '{{WRAPPER}} .wpcf7 form .wpcf7-form-control-wrap input:focus,
                                                {{WRAPPER}} .wpcf7 form .wpcf7-form-control-wrap input:hover, 
                                                {{WRAPPER}} .wpcf7 form .wpcf7-form-control-wrap textarea:focus,
                                                {{WRAPPER}} .wpcf7 form .wpcf7-form-control-wrap textarea:hover',
                                        ),
                                        array(
                                            'name'         => 'input_focus_box_shadow',
                                            'label' => esc_html__( 'Box Shadow', 'mouno' ),
                                            'type'         => \Elementor\Group_Control_Box_Shadow::get_type(),
                                            'control_type' => 'group',
                                            'selector'     => '{{WRAPPER}} .wpcf7 form .wpcf7-form-control-wrap input:focus,
                                                    {{WRAPPER}} .wpcf7 form .wpcf7-form-control-wrap input:hover, 
                                                    {{WRAPPER}} .wpcf7 form .wpcf7-form-control-wrap textarea:focus,
                                                    {{WRAPPER}} .wpcf7 form .wpcf7-form-control-wrap textarea:hover',
                                            'separator' => 'before',
                                        ),
                                        array(
                                            'name' => 'input_focus_border',
                                            'type' => \Elementor\Group_Control_Border::get_type(),
                                            'separator' => 'before',
                                            'control_type' => 'group', 
                                            'selector' => '{{WRAPPER}} .wpcf7 form .wpcf7-form-control-wrap input:focus,
                                            {{WRAPPER}} .wpcf7 form .wpcf7-form-control-wrap input:hover,
                                            {{WRAPPER}} .wpcf7 form .wpcf7-form-control-wrap textarea:focus,
                                            {{WRAPPER}} .wpcf7 form .wpcf7-form-control-wrap textarea:hover',
                                        ),
                                        array(
                                            'name' => 'input_focus_border_radius',
                                            'label' => esc_html__('Border Radius', 'mouno' ),
                                            'type' => \Elementor\Controls_Manager::DIMENSIONS,
                                            'size_units' => [ 'px', '%' ],
                                            'selectors' => [
                                                '{{WRAPPER}} .wpcf7 form .wpcf7-form-control-wrap input:focus,{{WRAPPER}} .wpcf7 form .wpcf7-form-control-wrap input:hover, 
                                                {{WRAPPER}} .wpcf7 form .wpcf7-form-control-wrap textarea:focus,
                                                {{WRAPPER}} .wpcf7 form .wpcf7-form-control-wrap textarea:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'input_focus_padding',
                                            'label' => esc_html__('Padding', 'mouno' ),
                                            'type' => \Elementor\Controls_Manager::DIMENSIONS,
                                            'size_units' => [ 'px', '%' ],
                                            'control_type' => 'responsive',
                                            'separator' => 'before',
                                            'selectors' => [
                                                '{{WRAPPER}} .wpcf7 form .wpcf7-form-control-wrap input:focus,{{WRAPPER}} .wpcf7 form .wpcf7-form-control-wrap input:hover,
                                                {{WRAPPER}} .wpcf7 form .wpcf7-form-control-wrap textarea:focus,
                                                {{WRAPPER}} .wpcf7 form .wpcf7-form-control-wrap textarea:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                            ],
                                        ),
                                    ],
                                ],
                            ],
                        ),
                    ),
                ),

                array(
                    'name' => 'tab_btn_style',
                    'label' => esc_html__('Button', 'mouno' ),
                    'tab' => 'style',
                    'condition' => [
                        'use_default_submit!' => '',
                    ],
                    'controls' => array_merge(
                        array(
                            array(
                                'name' => 'btn_h',
                                'label' => esc_html__('Height', 'mouno' ),
                                'type' => 'slider',
                                'size_units' => ['px', 'custom'],
                                'control_type' => 'responsive',
                                'range' => [
                                    'px' => [
                                        'min' => 0,
                                        'max' => 1000,
                                    ],
                                ],
                                'selectors' => [
                                    '{{WRAPPER}} .wpcf7 form .wpcf7-submit' => 'height: {{SIZE}}{{UNIT}};',
                                ],
                            ),
                            array(
                                'name' => 'btn_typography',
                                'type' => \Elementor\Group_Control_Typography::get_type(),
                                'control_type' => 'group',
                                'selector' => '{{WRAPPER}} .wpcf7 form .wpcf7-submit',
                                'separator' => 'before',
                            ),
                            array(
                                'name' => 'btn_text_shadow',
                                'label' => esc_html__('Text Shadow', 'mouno' ),
                                'type' => \Elementor\Group_Control_Text_Shadow::get_type(),
                                'control_type' => 'group',
                                'selector' => '{{WRAPPER}} .wpcf7 form .wpcf7-submit',
                            ),
                            array(
                                'name' => 'btn_controls',
                                'control_type' => 'tab',
                                'tabs' => [
                                    [
                                        'name' => 'btn_normal',
                                        'label' => esc_html__('Normal', 'mouno' ),
                                        'type' => 'tab',
                                        'controls' => [  
                                            array(
                                                'name' => 'btn_color',
                                                'label' => esc_html__('Color', 'mouno' ),
                                                'type' => 'color',
                                                'selectors' => [
                                                    '{{WRAPPER}} .wpcf7 form .wpcf7-submit' => 'color: {{VALUE}};',
                                                ],
                                            ),
                                            array(
                                                'name' => 'btn_bg',
                                                'type' => \Elementor\Group_Control_Background::get_type(),
                                                'control_type' => 'group',
                                                'types' => [ 'classic', 'gradient' ],
                                                'selector' => '{{WRAPPER}} .wpcf7 form .wpcf7-submit',
                                            ),
                                            array(
                                                'name' => 'btn_border',
                                                'type' => \Elementor\Group_Control_Border::get_type(),
                                                'separator' => 'before',
                                                'control_type' => 'group', 
                                                'selector' => '{{WRAPPER}} .wpcf7 form .wpcf7-submit',
                                            ),
                                            array(
                                                'name'         => 'btn_box_shadow',
                                                'label' => esc_html__( 'Box Shadow', 'mouno' ),
                                                'type'         => \Elementor\Group_Control_Box_Shadow::get_type(),
                                                'control_type' => 'group',
                                                'selector'     => '{{WRAPPER}} .wpcf7 form .wpcf7-submit',
                                            ),
                                            array(
                                                'name' => 'btn_border_radius',
                                                'label' => esc_html__('Border Radius', 'mouno' ),
                                                'type' => 'dimensions',
                                                'size_units' => [ 'px', 'custom' ],
                                                'selectors' => [
                                                    '{{WRAPPER}} .wpcf7 form .wpcf7-submit' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                                ],
                                            ),
                                            array(
                                                'name' => 'btn_padding',
                                                'label' => esc_html__('Padding', 'mouno' ),
                                                'type' => 'dimensions',
                                                'size_units' => [ 'px', 'custom' ],
                                                'control_type' => 'responsive',
                                                'separator' => 'before',
                                                'selectors' => [
                                                    '{{WRAPPER}} .wpcf7 form .wpcf7-submit' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                                ],
                                            ),
                                        ],
                                    ],
                                    [
                                        'name' => 'btn_hover',
                                        'label' => esc_html__('Hover', 'mouno' ),
                                        'type' => 'tabs',
                                        'controls' => [
                                            array(
                                                'name' => 'btn_hover_style',
                                                'label' => esc_html__('Hover Style', 'mouno' ),
                                                'type' => 'select',
                                                'options' => [
                                                    'hover-default' => esc_html__('Default', 'mouno'),
                                                    'hover-spotlight-scale' => esc_html__('Spotlight', 'mouno'),
                                                    'hover-parallax' => esc_html__('Parallax', 'mouno'),
                                                ],
                                                'default' => 'hover-default',
                                                'condition' => [
                                                    'btn_type!' => ['pxl-btn-split'],
                                                ],
                                            ),
                                            array(
                                                'name' => 'btn_hove_color',
                                                'label' => esc_html__('Color', 'mouno' ),
                                                'type' => 'color',
                                                'selectors' => [
                                                    '{{WRAPPER}} .wpcf7 form .wpcf7-submit:hover' => 'color: {{VALUE}};',
                                                ],
                                            ),
                                            array(
                                                'name' => 'btn_hover_bg',
                                                'type' => \Elementor\Group_Control_Background::get_type(),
                                                'control_type' => 'group',
                                                'types' => [ 'classic', 'gradient' ],
                                                'selector' => '{{WRAPPER}} .wpcf7 form .wpcf7-submit:hover',
                                            ),
                                            array(
                                                'name' => '_btn_hover_border_color',
                                                'label' => esc_html__('Border Color', 'mouno' ),
                                                'type' => 'color',
                                                'selectors' => [
                                                    '{{WRAPPER}} .wpcf7 form .wpcf7-submit:hover' => 'border-color: {{VALUE}};',
                                                ],
                                            ),
                                            array(
                                                'name' => 'btn_hover_anim',
                                                'label' => esc_html__( 'Hover Animation', 'mouno' ),
                                                'type' => 'hover_animation',
                                            ),
                                            array(
                                                'name' => 'btn_hover_border',
                                                'type' => \Elementor\Group_Control_Border::get_type(),
                                                'separator' => 'before',
                                                'control_type' => 'group', 
                                                'selector' => '{{WRAPPER}} .wpcf7 form .wpcf7-submit:hover',
                                            ),
                                            array(
                                                'name'         => 'btn_hover_box_shadow',
                                                'label' => esc_html__( 'Box Shadow', 'mouno' ),
                                                'type'         => \Elementor\Group_Control_Box_Shadow::get_type(),
                                                'control_type' => 'group',
                                                'selector'     => '{{WRAPPER}} .wpcf7 form .wpcf7-submit:hover',
                                            ),
                                            array(
                                                'name' => 'btn_hover_border_radius',
                                                'label' => esc_html__('Border Radius', 'mouno' ),
                                                'type' => 'dimensions',
                                                'size_units' => [ 'px', 'custom' ],
                                                'selectors' => [
                                                    '{{WRAPPER}} .wpcf7 form .wpcf7-submit:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                                ],
                                            ),
                                            array(
                                                'name' => 'btn_hover_padding',
                                                'label' => esc_html__('Padding', 'mouno' ),
                                                'type' => 'dimensions',
                                                'size_units' => [ 'px', 'custom' ],
                                                'control_type' => 'responsive',
                                                'separator' => 'before',
                                                'selectors' => [
                                                    '{{WRAPPER}} .wpcf7 form .wpcf7-submit:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                                ],
                                            ),
                                        ],
                                    ],
                                ],
                            ),
                        ),
                    ),
                ),
                // array(
                //     'name' => 'tab_cf7_anim',
                //     'label' => esc_html__('Animation', 'mouno'),
                //     'tab' => 'style',
                //     'controls' => mouno_get_animation_options([
                //         'selector' => '{{WRAPPER}} .pxl-icon-wrapper',
                //     ]),
                // ),
            ),
        ),
    ),
    mouno_get_class_widget_path()
);