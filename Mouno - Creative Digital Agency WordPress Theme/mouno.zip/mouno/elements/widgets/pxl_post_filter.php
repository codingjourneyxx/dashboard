<?php
$pt_supports = ['post', 'portfolio', 'service'];
pxl_add_custom_widget(
    array(
        'name'        => 'pxl_post_filter',
        'title'       => esc_html__('Case Post Filter', 'mouno'),
        'icon'        => 'eicon-taxonomy-filter',
        'categories'  => array('pxltheme-core'),
        'scripts' => [
            'pxl-post-grid',
        ],
        'params'      => array(
            'sections' => array(
                array(
                    'name'   => 'tab_source',
                    'label'  => esc_html__('Source', 'mouno'),
                    'tab'    => 'layout',
                    'controls' => array_merge(
                        array(
                            array(
                                'name' => 'filter_default_title',
                                'label' => esc_html__('Filter Default Title', 'mouno' ),
                                'type' => 'text',
                                'default' => esc_html__('All', 'mouno' ),
                            ),
                            array(
                                'name'     => 'filter_post_type',
                                'label'    => esc_html__('Filter Post Type', 'mouno'),
                                'type'     => 'select',
                                'default'  => 'post',
                                'options'  => [
                                    'post'      => 'Post',
                                    'portfolio' => 'Portfolio',
                                    'service'   => 'Service',
                                ],
                            ),
                            array(
                                'name'     => 'filter_style',
                                'label'    => esc_html__('View Style', 'mouno'),
                                'type'     => 'select',
                                'default'  => 'filter-default',
                                'options'  => [
                                    'filter-default' => esc_html__('Filter Default', 'mouno'),
                                ],
                            ),
                        ),
                        mouno_get_filter_term_by_post_type($pt_supports),
                        array(
                            array(
                                'name' => 'justify_content',
                                'label' => esc_html__('Justify Content', 'mouno' ),
                                'type' => 'choose',
                                'separator' => 'before',
                                'control_type' => 'responsive',
                                'options' => [
                                    'start' => [
                                        'title' => esc_html__('Start', 'mouno' ),
                                        'icon' => 'eicon-justify-start-h',
                                    ],
                                    'center' => [
                                        'title' => esc_html__('Center', 'mouno' ),
                                        'icon' => 'eicon-justify-center-h',
                                    ],
                                    'end' => [
                                        'title' => esc_html__('End', 'mouno' ),
                                        'icon' => 'eicon-justify-end-h',
                                    ],
                                    'space-around' => [
                                        'title' => esc_html__('Space Around', 'mouno' ),
                                        'icon' => 'eicon-justify-space-around-h',
                                    ],
                                    'space-evenly' => [
                                        'title' => esc_html__('Space Evenly', 'mouno' ),
                                        'icon' => 'eicon-justify-space-evenly-h',
                                    ],
                                    'space-between' => [
                                        'title' => esc_html__('Space Between', 'mouno' ),
                                        'icon' => 'eicon-justify-space-between-h',
                                    ],
                                ],
                                'label_block' => true,
                                'selectors' => [
                                    '{{WRAPPER}} .pxl-filter-inner' => 'justify-content: {{VALUE}};',
                                ],
                            ),
                            array(
                                'name' => 'item_spacing_hoz',
                                'label' => esc_html__('Column Gap', 'mouno' ),
                                'type' => 'slider',
                                'size_units' => ['px', '%', 'custom'],
                                'control_type' => 'responsive',
                                'range' => [
                                    'px' => [
                                        'min' => 0,
                                        'max' => 500,
                                    ],
                                ],
                                'selectors' => [
                                    '{{WRAPPER}} .pxl-filter-inner' => 'column-gap: {{SIZE}}{{UNIT}};',
                                ],
                            ),
                            array(
                                'name' => 'item_spacing_ver',
                                'label' => esc_html__('Row Gap', 'mouno' ),
                                'type' => 'slider',
                                'size_units' => ['px', '%', 'custom'],
                                'control_type' => 'responsive',
                                'range' => [
                                    'px' => [
                                        'min' => 0,
                                        'max' => 500,
                                    ],
                                ],
                                'selectors' => [
                                    '{{WRAPPER}} .pxl-filter-inner' => 'row-gap: {{SIZE}}{{UNIT}};',
                                ],
                            ),
                        )
                    ),
                ),
                array(
                    'name' => 'tab_filter_style',
                    'tab' => 'style',
                    'label' => esc_html__('Filter', 'mouno'),
                    'controls' => [
                        array(
                            'name' => 'filter_typography',
                            'type' => \Elementor\Group_Control_Typography::get_type(),
                            'control_type' => 'group',
                            'selector' => '{{WRAPPER}} .pxl-filter-inner .filter-item',
                        ),
                        array(
                            'name' => 'filter_controls',
                            'control_type' => 'tab',
                            'tabs' => [
                                [
                                    'name' => 'filter_normal',
                                    'label' => esc_html__('Normal', 'mouno' ),
                                    'type' => 'tab',
                                    'controls' => [  
                                        array(
                                            'name' => 'filter_color',
                                            'label' => esc_html__('Text Color', 'mouno' ),
                                            'type' => 'color',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-filter-inner .filter-item' => 'color: {{VALUE}};',
                                            ],
                                        ),
                                    ],
                                ],
                                [
                                    'name' => 'filter_hover',
                                    'label' => esc_html__('Hover/Active', 'mouno' ),
                                    'type' => \Elementor\Controls_Manager::TAB,
                                    'controls' => [
                                        array(
                                            'name' => 'filter_hover_style',
                                            'label' => esc_html__('Hover Style', 'mouno' ),
                                            'type' => \Elementor\Controls_Manager::SELECT,
                                            'options' => [
                                                'hover-text-default' => esc_html__('Default', 'mouno'),
                                                'hover-underline-ltr' => esc_html__('Underline LTR', 'mouno'),
                                                'hover-underline-rtl' => esc_html__('Underline RTL', 'mouno'),
                                                'hover-underline-expand' => esc_html__('Underline Expand', 'mouno'),
                                                'hover-underline-split' => esc_html__('Underline Split', 'mouno'),
                                            ],
                                            'default' => 'hover-underline-expand',
                                        ),
                                        array(
                                            'name' => 'filter_hover_color',
                                            'label' => esc_html__('Text Color', 'mouno' ),
                                            'type' => 'color',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-filter-inner .filter-item:hover, 
                                                {{WRAPPER}} .pxl-filter-inner .filter-item.active' => 'color: {{VALUE}};',
                                            ],
                                        ),
                                    ],
                                ],
                            ],
                        ),
                    ]
                ),
                array(
                    'name' => 'tab_motion_effects',
                    'label' => esc_html__('Motion Effects', 'mouno' ),
                    'tab' => 'style',
                    'controls' => mouno_get_animation_options([
                        'selector' => '{{WRAPPER}} .pxl-filter-wrapper',
                    ]),
                ),    
            ),
        ),
    ),
    mouno_get_class_widget_path()
);
