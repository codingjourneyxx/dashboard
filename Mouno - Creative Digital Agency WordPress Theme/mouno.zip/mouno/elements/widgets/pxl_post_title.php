<?php
pxl_add_custom_widget(
    array(
        'name' => 'pxl_post_title',
        'title' => esc_html__('Case Post Title', 'mouno' ),
        'icon' => 'eicon-post-title',
        'categories' => array('pxltheme-core'),
        'params' => array(
            'sections' => array(         
                array(
                    'name' => 'tab_post_title_content',
                    'label' => esc_html__('Post Title', 'mouno' ),
                    'tab' => 'content',
                    'controls' => array(
                        array(
                            'name' => 'custom_title',
                            'label' => esc_html__('Custom Title', 'mouno'),
                            'type' => 'switcher',
                            'default' => '',
                        ),
                        array(
                            'name' => 'custom_title_text',
                            'label' => esc_html__('Title Text', 'mouno'),
                            'type' => 'textarea',
                            'row' => 5,
                            'condition' => [
                                'custom_title!' => '',
                            ],
                        ),
                        array(
                            'name' => 'num_of_text_highlight',
                            'label' => esc_html__('Num of Text Highlight', 'mouno' ),
                            'type' => 'number',
                        ),
                        array(
                            'name' => 'title_tag',
                            'label' => esc_html__('Title HTML Tag', 'mouno' ),
                            'type' => 'select',
                            'options' => [
                                'h1' => 'H1',
                                'h2' => 'H2',
                                'h3' => 'H3',
                                'h4' => 'H4',
                                'h5' => 'H5',
                                'h6' => 'H6',
                                'div' => 'div',
                                'p' => 'p',
                                'span' => 'span',
                            ],
                            'default' => 'h1',
                        ),
                    ),
                ),
                array(
                    'name' => 'tab_post_title_style',
                    'label' => esc_html__('Post Title', 'mouno' ),
                    'tab' => 'style',
                    'controls' => array(
                        array(
                            'name' => 'text_align',
                            'label' => esc_html__('Alignment', 'mouno' ),
                            'type' => 'choose',
                            'control_type' => 'responsive',
                            'options' => [
                                'left' =>  [
                                    'title' => esc_html__('Left', 'mouno'),
                                    'icon' => 'eicon-text-align-left',
                                ],
                                'center' =>  [
                                    'title' => esc_html__('Center', 'mouno'),
                                    'icon' => 'eicon-text-align-center',
                                ],
                                'right' =>  [
                                    'title' => esc_html__('Right', 'mouno'),
                                    'icon' => 'eicon-text-align-right',
                                ],
                                'justify' =>  [
                                    'title' => esc_html__('Justify', 'mouno'),
                                    'icon' => 'eicon-text-align-justify',
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-post-title-wrapper' => 'text-align: {{VALUE}};',
                            ],
                        ),
                        array(
                            'name' => 'divider1',
                            'type' => 'divider',
                        ),
                        array(
                            'name' => 'title_controls',
                            'control_type' => 'tab',
                            'tabs' => [
                                [
                                    'name' => 'title_normal',
                                    'label' => esc_html__('Normal', 'mouno' ),
                                    'type' => 'tab',
                                    'controls' => [  
                                        array(
                                            'name'      => 'title_color',
                                            'label'     => esc_html__('Text Color', 'mouno' ),
                                            'type'      => 'color',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-post-title-wrapper .pxl-post-title-item' => 'color: {{VALUE}};',
                                            ],
                                        ),
                                        array(
                                            'name'         => 'title_typography',
                                            'type'         => \Elementor\Group_Control_Typography::get_type(),
                                            'control_type' => 'group',
                                            'separator' => 'before',
                                            'selector'     => '{{WRAPPER}} .pxl-post-title-wrapper .pxl-post-title-item',
                                        ),
                                        array(
                                            'name' => 'title_stroke',
                                            'type' => \Elementor\Group_Control_Text_Stroke::get_type(),
                                            'control_type' => 'group',
                                            'selector' => '{{WRAPPER}} .pxl-post-title-wrapper .pxl-post-title-item',
                                        ),
                                        array(
                                            'name' => 'title_shadow',
                                            'type' => \Elementor\Group_Control_Text_Shadow::get_type(),
                                            'control_type' => 'group',
                                            'selector' => '{{WRAPPER}} .pxl-post-title-wrapper .pxl-post-title-item',
                                        ),
                                    ],
                                ],
                                
                                [
                                    'name' => 'title_highlight',
                                    'label' => esc_html__('Highlight', 'mouno' ),
                                    'type' => 'tab',
                                    'controls' => [
                                        array(
                                            'name'      => 'title_hl_color',
                                            'label'     => esc_html__('Text Color', 'mouno' ),
                                            'type'      => 'color',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-post-title-wrapper .pxl-post-title-item .pxl-text-highlight' => 'color: {{VALUE}};',
                                            ],
                                        ),
                                        array(
                                            'name'         => 'title_hl_typography',
                                            'type'         => \Elementor\Group_Control_Typography::get_type(),
                                            'control_type' => 'group',
                                            'separator' => 'before',
                                            'selector'     => '{{WRAPPER}} .pxl-post-title-wrapper .pxl-post-title-item .pxl-text-highlight',
                                        ),
                                        array(
                                            'name' => 'title_hl_stroke',
                                            'type' => \Elementor\Group_Control_Text_Stroke::get_type(),
                                            'control_type' => 'group',
                                            'selector' => '{{WRAPPER}} .pxl-post-title-wrapper .pxl-post-title-item .pxl-text-highlight',
                                        ),
                                        array(
                                            'name' => 'title_hl_shadow',
                                            'type' => \Elementor\Group_Control_Text_Shadow::get_type(),
                                            'control_type' => 'group',
                                            'selector' => '{{WRAPPER}} .pxl-post-title-wrapper .pxl-post-title-item .pxl-text-highlight',
                                        ),
                                    ],
                                ],
                            ],
                        ),
                    ),
                ),
            ),
        ),
    ),
    mouno_get_class_widget_path()
);