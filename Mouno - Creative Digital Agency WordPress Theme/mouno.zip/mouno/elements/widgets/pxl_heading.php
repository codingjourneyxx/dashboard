<?php
pxl_add_custom_widget(
    array(
        'name' => 'pxl_heading',
        'title' => esc_html__('Case Heading', 'mouno' ),
        'icon' => 'eicon-heading',
        'categories' => array('pxltheme-core'),
        'scripts'    => array(
            'split-text',
            'mouno-effects'
        ),
        'params' => array(
            'sections' => array(
                array(
                    'name' => 'tab_content',
                    'label' => esc_html__('Heading', 'mouno' ),
                    'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
                    'controls' => array(
                        array(
                            'name' => 'view',
                            'label' => esc_html__('View', 'mouno' ),
                            'type' => 'select',
                            'options' => [
                                '' => esc_html__('All', 'mouno'),
                                'only-title' => esc_html__('Only Title', 'mouno'),
                                'only-subtitle' => esc_html__('Only Subtitle', 'mouno'),
                            ],
                            'default' => '',
                        ),
                        array(
                            'name' => 'subtitle_style',
                            'label' => esc_html__('Subtitle Style', 'mouno' ),
                            'type' => \Elementor\Controls_Manager::SELECT,
                            'separator' => 'before',
                            'default' => 'heading-subtitle-default',
                            'options' => [
                                'heading-subtitle-default'   => esc_html__('Default', 'mouno'),
                                'heading-subtitle-primary'   => esc_html__('Primary', 'mouno'),
                                'heading-subtitle-secondary' => esc_html__('Secondary', 'mouno'),
                                'heading-subtitle-button'    => esc_html__('Button', 'mouno'),
                                'heading-subtitle-third'     => esc_html__('Third', 'mouno'),
                                'heading-subtitle-divider'   => esc_html__('Divider', 'mouno'),
                                'heading-subtitle-portfolio' => esc_html__('Portfolio', 'mouno'),
                                'heading-subtitle-custom'    => esc_html__('Custom', 'mouno'),
                            ],
                            'condition' => [
                                'view!' => 'only-title',
                            ],
                        ),
                        array(
                            'name' => 'subtitle',
                            'label' => esc_html__('Subtitle', 'mouno' ),
                            'type' => \Elementor\Controls_Manager::TEXT,
                            'default' => "[highlight text='//'] Enter heading subtitle here",
                            'label_block' => true,
                            'condition' => [
                                'view!' => 'only-title',
                            ],
                        ),
                        array(
                            'name' => 'title_style',
                            'label' => esc_html__('Title Style', 'mouno' ),
                            'type' => \Elementor\Controls_Manager::SELECT,
                            'separator' => 'before',
                            'default' => 'heading-title-default',
                            'options' => [
                                'heading-title-default'      => esc_html__('Default', 'mouno'),
                                'heading-title-primary'      => esc_html__('Heading Primary', 'mouno'),
                                'heading-title-secondary'    => esc_html__('Heading Secondary', 'mouno'),
                                'heading-title-third'        => esc_html__('Heading Third', 'mouno'),
                                'heading-title-fourth'       => esc_html__('Heading Fourth', 'mouno'),
                                'heading-title-fifth'        => esc_html__('Heading Fifth', 'mouno'),
                                'heading-title-underline'    => esc_html__('Underline', 'mouno'),
                                'heading-underline-accent'   => esc_html__('Underline Accent', 'mouno'),
                                'h9'                         => esc_html__('H9', 'mouno'),
                                'h10'                        => esc_html__('H10', 'mouno'),
                                'heading-title-custom'       => esc_html__('Custom', 'mouno'),
                            ],
                            'condition' => [
                                'view!' => 'only-subtitle',
                            ],
                        ),
                        array(
                            'name' => 'underline_h',
                            'label' => esc_html__('Underline Height', 'mouno' ),
                            'type' => 'slider',
                            'control_type' => 'responsive',
                            'size_units' => [ 'px', '%' ],
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 3000,
                                ],
                            ],
                            'condition' => [
                                'title_style' => 'heading-title-underline',
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-heading-wrapper .pxl-heading-title.heading-title-underline' => '--pxl-height: {{SIZE}}{{UNIT}};',
                            ],
                        ),
                        array(
                            'name' => 'underline_w',
                            'label' => esc_html__('Line Width', 'mouno' ),
                            'type' => 'slider',
                            'control_type' => 'responsive',
                            'size_units' => [ 'px', '%' ],
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 3000,
                                ],
                            ],
                            'condition' => [
                                'title_style' => ['heading-underline-accent'],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-heading-wrapper .pxl-heading-title.heading-underline-accent:after' => 'width: {{SIZE}}{{UNIT}};',
                            ],
                        ),
                        array(
                            'name' => 'underline_color',
                            'label' => esc_html__('Line Color', 'mouno' ),
                            'type' => 'color',
                             'selectors' => [
                                '{{WRAPPER}} .pxl-heading-wrapper .pxl-heading-title.heading-underline-accent:after' => 'background-color: {{VALUE}};',
                            ],
                        ),
                        array(
                            'name' => 'title',
                            'label' => esc_html__('Title', 'mouno' ),
                            'type' => \Elementor\Controls_Manager::TEXTAREA,
                            'rows' => 10,
                            'label_block' => true,
                            'default' => esc_html__('Enter heading title here', 'mouno'),
                            'description' => esc_html__('Highlight use shortcode: [highlight text="..."] or [highlight_image img_id="123"]', 'mouno'),
                            'condition' => [
                                'view!' => 'only-subtitle',
                            ],
                        ),
                        array(
                            'name' => 'title_tag',
                            'label' => esc_html__('Title HTML Tag', 'mouno' ),
                            'type' => \Elementor\Controls_Manager::SELECT,
                            'options' => [
                                'h1' => 'H1',
                                'h2' => 'H2',
                                'h3' => 'H3',
                                'h4' => 'H4',
                                'h5' => 'H5',
                                'h6' => 'H6',
                                'div' => 'div',
                                'p' => 'p',
                                'span' => 'span',
                            ],
                            'default' => 'h2',
                            'condition' => [
                                'view!' => 'only-subtitle',
                            ],
                        ),

                        array(
                            'name' => 'text_align',
                            'label' => esc_html__('Alignment', 'mouno' ),
                            'type' => 'choose',
                            'control_type' => 'responsive',
                            'options' => [
                                'left' =>  [
                                    'title' => esc_html__('Left', 'mouno'),
                                    'icon' => 'eicon-text-align-left',
                                ],
                                'center' =>  [
                                    'title' => esc_html__('Center', 'mouno'),
                                    'icon' => 'eicon-text-align-center',
                                ],
                                'right' =>  [
                                    'title' => esc_html__('Right', 'mouno'),
                                    'icon' => 'eicon-text-align-right',
                                ],
                                'justify' =>  [
                                    'title' => esc_html__('Justify', 'mouno'),
                                    'icon' => 'eicon-text-align-justify',
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-heading-wrapper' => 'text-align: {{VALUE}};',
                            ],
                        ),
                        array(
                            'name' => 'max_w',
                            'label' => esc_html__('Max Width', 'mouno' ),
                            'type' => 'slider',
                            'control_type' => 'responsive',
                            'size_units' => [ 'px', '%' ],
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 3000,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}}' => 'max-width: {{SIZE}}{{UNIT}} !important;',
                            ],
                        ),
                        array(
                            'name' => 'spacing',
                            'label' => esc_html__('Spacing', 'mouno' ),
                            'type' => 'slider',
                            'control_type' => 'responsive',
                            'size_units' => [ 'px', '%' ],
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 3000,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-heading-wrapper .pxl-heading-subtitle' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                            ],
                        ),
                    ),


                ),
                array(
                    'name' => 'tab_style_title',
                    'label' => esc_html__('Title', 'mouno' ),
                    'tab' => \Elementor\Controls_Manager::TAB_STYLE,
                    'condition' => [
                        'view!' => 'only-subtitle',
                    ],
                    'controls' => array_merge(
                        array(
                            array(
                                'name' => 'title_wrap',
                                'label' => esc_html__( 'Title Wrap', 'mouno' ),
                                'type' => 'choose',
                                'control_type' => 'responsive',
                                'options' => [
                                    'wrap' => [
                                        'title' => esc_html__( 'Wrap', 'mouno' ),
                                        'icon' => 'eicon-wrap',
                                    ],
                                    'nowrap' => [
                                        'title' => esc_html__( 'Nowrap', 'mouno' ),
                                        'icon' => 'eicon-nowrap',
                                    ],
                                ],
                                'selectors' => [
                                    '{{WRAPPER}} .pxl-heading-wrapper .pxl-heading-title' => 'white-space: {{VALUE}};',
                                ],
                            ),
                            array(
                                'name' => 'title_dir',
                                'label' => esc_html__('Title Direction', 'mouno' ),
                                'type' => 'choose',
                                'options' => [
                                    '' => [
                                        'title' => esc_html__('Horizontal', 'mouno'),
                                        'icon'  => 'eicon-arrow-right'
                                    ],
                                    'vertical-lr' => [
                                        'title' => esc_html__('Vertical', 'mouno'),
                                        'icon'  => 'eicon-arrow-down'
                                    ],
                                ],
                                'control_type' => 'responsive',
                                'selectors' => [
                                    '{{WRAPPER}} .pxl-heading-wrapper .pxl-heading-title' => 'writing-mode: {{VALUE}};',
                                ],
                            ),
                            array(
                                'name' => 'title_rotate',
                                'label' => esc_html__('Rotate', 'mouno' ),
                                'type' => 'number',
                                'control_type' => 'responsive',
                                'selectors' => [
                                    '{{WRAPPER}} .pxl-heading-wrapper .pxl-heading-title' => 'transform: rotate({{VALUE}}deg);',
                                ],
                            ),
                            array(
                                'name' => 'title_h',
                                'label' => esc_html__('Height', 'mouno' ),
                                'type' => 'slider',
                                'control_type' => 'responsive',
                                'size_units' => [ 'px', '%' ],
                                'range' => [
                                    'px' => [
                                        'min' => 0,
                                        'max' => 3000,
                                    ],
                                ],
                                'selectors' => [
                                    '{{WRAPPER}} .pxl-heading-wrapper .pxl-heading-title' => 'height: {{SIZE}}{{UNIT}};',
                                ],
                            ),
                            array(
                                'name' => 'title_controls',
                                'control_type' => 'tab',
                                'tabs' => [
                                    [
                                        'name' => 'title_normal',
                                        'label' => esc_html__('Normal', 'mouno' ),
                                        'type' => 'tab',
                                        'controls' => [  
                                            array(
                                                'name' => 'title_color',
                                                'label' => esc_html__('Text Color', 'mouno' ),
                                                'type' => 'color',
                                                 'selectors' => [
                                                    '{{WRAPPER}} .pxl-heading-wrapper .pxl-heading-title' => 'color: {{VALUE}};',
                                                ],
                                            ),
                                            array(
                                                'name' => 'title_typography',
                                                'type' => \Elementor\Group_Control_Typography::get_type(),
                                                'control_type' => 'group',
                                                'selector' => '{{WRAPPER}} .pxl-heading-wrapper .pxl-heading-title',
                                            ),
                                            array(
                                                'name'         => 'title_box_shadow',
                                                'type'         => \Elementor\Group_Control_Text_Shadow::get_type(),
                                                'control_type' => 'group',
                                                'selector'     => '{{WRAPPER}} .pxl-heading-wrapper .pxl-heading-title'
                                            ),
                                        ],
                                    ],
                                    [
                                        'name' => 'title_highlight',
                                        'label' => esc_html__('Highlight', 'mouno' ),
                                        'type' => \Elementor\Controls_Manager::TAB,
                                        'controls' => [
                                            array(
                                                'name' => 'title_hightlight_color',
                                                'label' => esc_html__('Text Color', 'mouno' ),
                                                'type' => 'color',
                                                'selectors' => [
                                                    '{{WRAPPER}} .pxl-heading-wrapper .pxl-heading-title .pxl-text-highlight' => 'color: {{VALUE}};-webkit-text-stroke-color:{{VALUE}};',
                                                ],
                                            ),
                                            array(
                                                'name' => 'title_hightlight_typography',
                                                'type' => \Elementor\Group_Control_Typography::get_type(),
                                                'control_type' => 'group',
                                                'selector' => '{{WRAPPER}} .pxl-heading-wrapper .pxl-heading-title .pxl-text-highlight',
                                            ),
                                            array(
                                                'name' => 'title_hidden_title',
                                                'label' => esc_html__( 'Hidden Title', 'mouno' ),
                                                'type' => 'choose',
                                                'control_type' => 'responsive',
                                                'separator' => 'before',
                                                'options' => [
                                                    'inline' => [
                                                        'title' => esc_html__( 'Show', 'mouno' ),
                                                        'icon' => 'eicon-preview-thin',
                                                    ],
                                                    'none' => [
                                                        'title' => esc_html__( 'Hide', 'mouno' ),
                                                        'icon' => 'eicon-close',
                                                    ],
                                                ],
                                                'selectors' => [
                                                    '{{WRAPPER}} .pxl-heading-wrapper .pxl-heading-title .pxl-text-hidden' => 'display: {{VALUE}};',
                                                ],
                                            ),
                                        ],
                                    ],
                                ],
                            ),
                            array(
                                'name' => 'title_animation_h',
                                'type' => 'heading',
                                'label' => esc_html__('Animation', 'mouno'),
                                'separator' => 'before',
                            ),
                        ),
                        mouno_get_additional_animation_options([
                            'prefix' => 'title',
                        ]),
                        mouno_get_animation_options([
                            'prefix' => 'title',
                            'selector' => '{{WRAPPER}} .pxl-heading-wrapper .pxl-heading-title',
                            'condition' => [
                                'title_additional_entrance_anim' => '',
                            ],
                        ]),
                    ),
                ),
                array(
                    'name' => 'tab_style_subtitle',
                    'label' => esc_html__('Subtitle', 'mouno' ),
                    'tab' => \Elementor\Controls_Manager::TAB_STYLE,
                    'condition' => [
                        'view!' => 'only-title',
                    ],
                    'controls' => array_merge(
                        array(
                            array(
                                'name' => 'subtitle_control',
                                'control_type' => 'tab',
                                'tabs' => [
                                    [
                                        'name' => 'subtitle_normal',
                                        'label' => esc_html__('Normal', 'mouno' ),
                                        'type' => 'tab',
                                        'controls' => [  
                                            array(
                                                'name' => 'subtitle_color',
                                                'label' => esc_html__('Color', 'mouno' ),
                                                'type' => 'color',
                                                'selectors' => [
                                                    '{{WRAPPER}} .pxl-heading-wrapper .pxl-heading-subtitle' => 'color: {{VALUE}};',
                                                ],
                                            ),
                                            array(
                                                'name' => 'subtitle_box_color',
                                                'label' => esc_html__('Background Color', 'mouno' ),
                                                'type' => 'color',
                                                'selectors' => [
                                                    '{{WRAPPER}} .pxl-heading-wrapper .pxl-heading-subtitle .pxl-subtitle-text' => 'background-color: {{VALUE}};',
                                                ],
                                            ),
                                            array(
                                                'name' => 'subtitle_typography',
                                                'label' => esc_html__('Typography', 'mouno' ),
                                                'type' => \Elementor\Group_Control_Typography::get_type(),
                                                'control_type' => 'group',
                                                'selector' => '{{WRAPPER}} .pxl-heading-wrapper .pxl-heading-subtitle',
                                            ),
                                            array(
                                                'name' => 'subtitle_border',
                                                'type' => \Elementor\Group_Control_Border::get_type(),
                                                'separator' => 'before',
                                                'control_type' => 'group', 
                                                'selector' => '{{WRAPPER}} .pxl-heading-wrapper .pxl-heading-subtitle .pxl-subtitle-text',
                                            ),
                                            array(
                                                'name' => 'subtitle_padding',
                                                'label' => esc_html__('Padding', 'mouno' ),
                                                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                                                'size_units' => [ 'px', '%' ],
                                                'control_type' => 'responsive',
                                                'selectors' => [
                                                    '{{WRAPPER}} .pxl-heading-wrapper .pxl-heading-subtitle .pxl-subtitle-text' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                                ],
                                            ),
                                            array(
                                                'name' => 'subtitle_border_radius',
                                                'label' => esc_html__('Border Radius', 'mouno' ),
                                                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                                                'size_units' => [ 'px', '%' ],
                                                'control_type' => 'responsive',
                                                'selectors' => [
                                                    '{{WRAPPER}} .pxl-heading-wrapper .pxl-heading-subtitle .pxl-subtitle-text' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                                ],
                                            ),
                                        ],
                                    ],
                                    [
                                        'name' => 'subtitle_highlight',
                                        'label' => esc_html__('Highlight', 'mouno' ),
                                        'type' => \Elementor\Controls_Manager::TAB,
                                        'controls' => [
                                            array(
                                                'name' => 'subtitle_hightlight_color',
                                                'label' => esc_html__('Color', 'mouno' ),
                                                'type' => 'color',
                                                'selectors' => [
                                                    '{{WRAPPER}} .pxl-heading-wrapper .pxl-heading-subtitle .pxl-text-highlight' => 'color: {{VALUE}};-webkit-text-PXL-color:{{VALUE}};',
                                                ],
                                            ),
                                            array(
                                                'name' => 'subtitle_hightlight_typography',
                                                'label' => esc_html__('Typography', 'mouno' ),
                                                'type' => \Elementor\Group_Control_Typography::get_type(),
                                                'control_type' => 'group',
                                                'selector' => '{{WRAPPER}} .pxl-heading-wrapper .pxl-heading-subtitle .pxl-text-highlight',
                                            ),
                                        ],
                                    ],
                                ],
                            ),
                        ),
                        mouno_get_additional_animation_options([
                            'prefix' => 'subtitle',
                        ]),
                        mouno_get_animation_options([
                            'prefix' => 'subtitle',
                            'selector' => '{{WRAPPER}} .pxl-heading-wrapper .pxl-heading-subtitle',
                            'condition' => [
                                'subtitle_additional_entrance_anim' => '',
                            ],
                        ]),
                    )
                ),
            ),
        ),
    ),
    mouno_get_class_widget_path()
);