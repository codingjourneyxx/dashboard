<?php
pxl_add_custom_widget(
    array(
        'name' => 'pxl_accordion',
        'title' => esc_html__('Case Accordion', 'mouno' ),
        'icon' => 'eicon-accordion',
        'categories' => array('pxltheme-core'),
        'scripts' => array(
            'mouno-accordion',
        ),
        'params' => array(
            'sections' => array(
                array(
                    'name' => 'tab_accordion_layout',
                    'label' => esc_html__('Layout', 'mouno'),
                    'tab' => 'layout',
                    'controls' => array(
                        array(
                            'name' => 'layout',
                            'label' => esc_html__('Layout', 'mouno'),
                            'type' => 'layoutcontrol',
                            'default' => '1',
                            'options' => array(
                                '1' => array(
                                    'label' => esc_html__('Layout 1', 'mouno'),
                                    'image' => get_template_directory_uri() . '/elements/assets/img/pxl_accordion/layout1.jpg',
                                ),
                            ),
                        ),
                    ),
                ),

                array(
                    'name' => 'tab_accordion_content',
                    'label' => esc_html__('Accordion', 'mouno' ),
                    'tab' => 'content',
                    'controls' => array(   
                        array(
                            'name' => 'layout1_style',
                            'label' => esc_html__('Layout Style', 'mouno'),
                            'type' => 'select',
                            'default' => 'accordion-default',
                            'options' => [
                                'accordion-default' => esc_html__('Default', 'mouno'),
                                'accordion-style1' => esc_html__('Style 1', 'mouno'),
                            ],
                        ),
                        array(
                            'name' => 'title_tag',
                            'label' => esc_html__('Title HTML Tag', 'mouno'),
                            'type' => 'select',
                            'default' => 'h4',
                            'options' => [
                                'h1' => esc_html__('H1', 'mouno'),
                                'h2' => esc_html__('H2', 'mouno'),
                                'h3' => esc_html__('H3', 'mouno'),
                                'h4' => esc_html__('H4', 'mouno'),
                                'h5' => esc_html__('H5', 'mouno'),
                                'h6' => esc_html__('H6', 'mouno'),
                                'div' => esc_html__('div', 'mouno'),
                                'p'  => esc_html__('p', 'mouno'),
                                'span' => esc_html__('span', 'mouno'),
                            ],
                        ),
                        array(
                            'name' => 'active',
                            'label' => esc_html__('Active', 'mouno' ),
                            'type' => 'number',
                            'min' => 1,
                            'default' => 1,
                        ),
                        array(
                            'name' => 'accordion',
                            'label' => esc_html__('Accordion', 'mouno' ),
                            'type' => \Elementor\Controls_Manager::REPEATER,
                            'controls' => array(
                                array(
                                    'name' => 'title',
                                    'label' => esc_html__('Title', 'mouno' ),
                                    'type' => 'text',
                                    'label_block' => true, 
                                    'default' => esc_html__('Accordion Title Here', 'mouno'),
                                ),
                                array(
                                    'name' => 'content',
                                    'type' => \Elementor\Controls_Manager::WYSIWYG,
                                    'default' => esc_html__('Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris tempus nisl vitae magna pulvinar laoreet nu llam erat ipsum, mattis nec mollis ac, accumsan a enim.', 'mouno'),
                                    'description' => 'Highlight text width shortcode: [highlight text="..."]',
                                ),
                            ),
                            'title_field' => '{{{title}}}',
                            'default' => [
                                [
                                    'title' => esc_html__('Accordion Title Here', 'mouno'),
                                    'content' => esc_html__('Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris tempus nisl vitae magna pulvinar laoreet nu llam erat ipsum, mattis nec mollis ac, accumsan a enim.', 'mouno'),
                                ],
                                [
                                    'title' => esc_html__('Accordion Title Here', 'mouno'),
                                    'content' => esc_html__('Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris tempus nisl vitae magna pulvinar laoreet nu llam erat ipsum, mattis nec mollis ac, accumsan a enim.', 'mouno'),
                                ],
                                [
                                    'title' => esc_html__('Accordion Title Here', 'mouno'),
                                    'content' => esc_html__('Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris tempus nisl vitae magna pulvinar laoreet nu llam erat ipsum, mattis nec mollis ac, accumsan a enim.', 'mouno'),
                                ],
                            ],
                        ),
                        array(
                            'name' => 'max_w',
                            'label' => esc_html__('Max Width', 'mouno' ),
                            'type' => 'slider',
                            'control_type' => 'responsive',
                            'size_units' => [ 'px', '%' ],
                            'range' => [
                                'px' => [
                                    'min' => 0,
                                    'max' => 3000,
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}}' => 'max-width: {{SIZE}}{{UNIT}} !important;',
                            ],
                        ),
                    ),

                ),

                array(
                    'name' => 'tab_accordion_style',
                    'label' => esc_html__('Accordion', 'mouno' ),
                    'tab' => 'style',
                    'controls' => array(
                        array(
                            'name' => 'item_border',
                            'type' => \Elementor\Group_Control_Border::get_type(),
                            'control_type' => 'group', 
                            'selector' => '{{WRAPPER}} .pxl-accordion-wrapper .pxl-accordion-item + .pxl-accordion-item',
                        ),
                        array(
                            'name' => 'item_padding',
                            'label' => esc_html__('Padding', 'mouno' ),
                            'type' => \Elementor\Controls_Manager::DIMENSIONS,
                            'size_units' => [ 'px', '%' ],
                            'control_type' => 'responsive',
                            'selectors' => [
                                '{{WRAPPER}} .pxl-accordion-wrapper .pxl-accordion-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            ],
                        ),
                    ),
                ),
                
                array(
                    'name' => 'tab_title_style',
                    'label' => esc_html__('Title', 'mouno' ),
                    'tab' => 'style',
                    'controls' => array(
                        array(
                            'name' => 'title_color',
                            'label' => esc_html__('Text Color', 'mouno' ),
                            'type' => 'color',
                            'selectors' => [
                                '{{WRAPPER}} .pxl-accordion-wrapper .pxl-accordion-header .pxl-accordion-title' => 'color: {{VALUE}};',
                            ],
                        ),
                        array(
                            'name' => 'title_typography',
                            'type' => \Elementor\Group_Control_Typography::get_type(),
                            'control_type' => 'group',
                            'selector' => '{{WRAPPER}} .pxl-accordion-wrapper .pxl-accordion-header .pxl-accordion-title',
                        ),
                    ),
                ),
                array(
                    'name' => 'tab_action_icon_style',
                    'label' => esc_html__('Icon Status', 'mouno' ),
                    'tab' => 'style',
                    'controls' => array(    
                        array(
                            'name' => 'icon_action_open_box_sz',
                            'label' => esc_html__('Box Size', 'mouno'),
                            'type' => 'slider',
                            'control_type' => 'responsive' ,
                            'size_units' => ['px', '%', 'custom'],
                            'range' => [
                                'px' => [
                                    'min' => 0, 
                                    'max' => 1000
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-accordion-wrapper .pxl-accordion-header .pxl-accordion-action' => '--pxl-box-size: {{SIZE}}{{UNIT}};',
                            ],
                        ),
                        array(
                            'name' => 'icon_action_open_border_radius',
                            'label' => esc_html__('Border Radius', 'mouno' ),
                            'type' => \Elementor\Controls_Manager::DIMENSIONS,
                            'size_units' => [ 'px', '%' ],
                            'control_type' => 'responsive',
                            'selectors' => [
                                '{{WRAPPER}} .pxl-accordion-wrapper .pxl-accordion-header .pxl-accordion-action' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            ],
                        ),                    
                        array(
                            'name' => 'icon_action_controls',
                            'control_type' => 'tab',
                            'tabs' => [
                                [
                                    'name' => 'icon_action_open',
                                    'label' => esc_html__('Open', 'mouno' ),
                                    'type' => 'tab',
                                    'controls' => [  
                                        array(
                                            'name' => 'icon_action_open_color',
                                            'label' => esc_html__('Icon Color', 'mouno' ),
                                            'type' => 'color',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-accordion-wrapper .pxl-accordion-header .pxl-accordion-action::before,
                                                {{WRAPPER}}  .pxl-accordion-wrapper .pxl-accordion-header .pxl-accordion-action::after' => 'background-color: {{VALUE}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'icon_action_open_box_bg',
                                            'label' => esc_html__('Box Color', 'mouno' ),
                                            'type' => \Elementor\Group_Control_Background::get_type(),
                                            'control_type' => 'group',
                                            'types' => [ 'classic', 'gradient' ],
                                            'selector' => '{{WRAPPER}} .pxl-accordion-wrapper .pxl-accordion-header .pxl-accordion-action',
                                        ),
                                        array(
                                            'name' => 'icon_action_open_border',
                                            'type' => \Elementor\Group_Control_Border::get_type(),
                                            'separator' => 'before',
                                            'control_type' => 'group', 
                                            'selector' => '{{WRAPPER}} .pxl-accordion-wrapper .pxl-accordion-header .pxl-accordion-action',
                                        ),
                                    ],
                                ],
                                [
                                    'name' => 'icon_action_close',
                                    'label' => esc_html__('Close', 'mouno' ),
                                    'type' => 'tab',
                                    'controls' => [
                                        array(
                                            'name' => 'icon_action_close_color',
                                            'label' => esc_html__('Icon Color', 'mouno' ),
                                            'type' => 'color',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-accordion-wrapper .pxl-accordion-item.active .pxl-accordion-header .pxl-accordion-action::before,
                                                {{WRAPPER}}  .pxl-accordion-wrapper .pxl-accordion-item.active .pxl-accordion-header .pxl-accordion-action::after' => 'background-color: {{VALUE}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'icon_action_close_box_bg',
                                            'label' => esc_html__('Box Color', 'mouno' ),
                                            'type' => \Elementor\Group_Control_Background::get_type(),
                                            'control_type' => 'group',
                                            'types' => [ 'classic', 'gradient' ],
                                            'selector' => '{{WRAPPER}} .pxl-accordion-wrapper .pxl-accordion-item.active .pxl-accordion-header .pxl-accordion-action',
                                        ),
                                        array(
                                            'name' => 'icon_action_close_border',
                                            'type' => \Elementor\Group_Control_Border::get_type(),
                                            'separator' => 'before',
                                            'control_type' => 'group', 
                                            'selector' => '{{WRAPPER}} .pxl-accordion-wrapper .pxl-accordion-item.active .pxl-accordion-header .pxl-accordion-action',
                                        ),
                                    ],
                                ],
                            ],
                        ),
                    ),
                ),

                array(
                    'name' => 'tab_action_content_style',
                    'label' => esc_html__('Content', 'mouno' ),
                    'tab' => 'style',
                    'controls' => array(    
                        array(
                            'name' => 'content_color',
                            'label' => esc_html__('Text Color', 'mouno' ),
                            'type' => 'color',
                            'selectors' => [
                                '{{WRAPPER}} .pxl-accordion-wrapper .pxl-accordion-content p' => 'color: {{VALUE}};',
                            ],
                        ),
                        array(
                            'name' => 'content_typography',
                            'type' => \Elementor\Group_Control_Typography::get_type(),
                            'control_type' => 'group',
                            'selector' => '{{WRAPPER}} .pxl-accordion-wrapper .pxl-accordion-content p',
                        ),
                        array(
                            'name' => 'content_max_w',
                            'label' => esc_html__('Max W', 'mouno'),
                            'type' => 'slider',
                            'control_type' => 'responsive' ,
                            'size_units' => ['px', '%', 'custom'],
                            'range' => [
                                'px' => [
                                    'min' => 0, 
                                    'max' => 1000
                                ],
                            ],
                            'selectors' => [
                                '{{WRAPPER}} .pxl-accordion-wrapper .pxl-accordion-content p' => 'gap: {{SIZE}}{{UNIT}};',
                            ],
                        ),
                        array(
                            'name' => 'content_padding',
                            'label' => esc_html__('Padding', 'mouno' ),
                            'type' => \Elementor\Controls_Manager::DIMENSIONS,
                            'size_units' => [ 'px', '%' ],
                            'control_type' => 'responsive',
                            'selectors' => [
                                '{{WRAPPER}} .pxl-accordion-wrapper .pxl-accordion-content p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                            ],
                        ),
                        array(
                            'name' => 'link_controls',
                            'control_type' => 'tab',
                            'tabs' => [
                                [
                                    'name' => 'link_normal',
                                    'label' => esc_html__('Link', 'mouno' ),
                                    'type' => 'tab',
                                    'controls' => [  
                                        array(
                                            'name' => 'link_color',
                                            'label' => esc_html__('Text Color', 'mouno' ),
                                            'type' => 'color',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-accordion-wrapper .pxl-accordion-content p a' => 'color: {{VALUE}};',
                                            ],
                                        ),
                                        array(
                                            'name' => 'link_typography',
                                            'type' => \Elementor\Group_Control_Typography::get_type(),
                                            'control_type' => 'group',
                                            'selector' => '{{WRAPPER}} .pxl-accordion-wrapper .pxl-accordion-content p a',
                                        ),
                                    ],
                                ],
                                [
                                    'name' => 'link_hover',
                                    'label' => esc_html__('Hover', 'mouno' ),
                                    'type' => 'tab',
                                    'controls' => [
                                        array(
                                            'name' => 'link_hover_color',
                                            'label' => esc_html__('Text Color', 'mouno' ),
                                            'type' => 'color',
                                            'selectors' => [
                                                '{{WRAPPER}} .pxl-accordion-wrapper .pxl-accordion-content p a:hover' => 'color: {{VALUE}};',
                                            ],
                                        ),
                                    ],
                                ],
                            ],
                        ),
                    ),
                ),

                array(
                    'name' => 'tab_accordion_anim',
                    'label' => esc_html__('Animation', 'mouno'),
                    'tab' => 'style',
                    'controls' => mouno_get_animation_options([
                        // 'selector' => ''
                    ]),
                ),
            ),
        ),
    ),
    mouno_get_class_widget_path()
);