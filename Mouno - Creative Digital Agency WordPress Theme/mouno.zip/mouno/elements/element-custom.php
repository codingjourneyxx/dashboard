<?php 
/*
    General Custom Options
*/
add_action( 'elementor/element/container/section_layout/after_section_end', 'mouno_element_custom_options', 1, 1 ); 
function mouno_element_custom_options( \Elementor\Element_Base $el ) {
    $el->start_controls_section(
        'el_custom_opts',
        [
            'label' => esc_html__( 'Mouno Custom Options', 'mouno' ),
            'tab' => \Elementor\Controls_Manager::TAB_LAYOUT,
        ]
    );

    $el->add_responsive_control(
        'el_backdrop_filter',
        [
            'label' => esc_html__( 'Backdrop Filter', 'mouno' ),
            'type' => \Elementor\Controls_Manager::SLIDER,  
            'size_units' => [ 'px', 'custom'],
            'selectors' => [
                '{{WRAPPER}}' => 'backdrop-filter: blur({{SIZE}}{{UNIT}})',
            ],
        ]
    );
    
    $el->add_responsive_control(
        'el_position',
        [
            'label' => esc_html__( 'Position', 'mouno' ),
            'type' => \Elementor\Controls_Manager::SELECT,
            'default' => '',
            'options' => [
                ''         => esc_html__('Default', 'mouno'),
                'static'   => esc_html__('Static', 'mouno'),
                'relative' => esc_html__('Relative', 'mouno'),
                'absolute' => esc_html__('Absolute', 'mouno'),
                'fixed'    => esc_html__('Fixed', 'mouno'),
                'sticky'   => esc_html__('Sticky', 'mouno'),
            ],
            'selectors_dictionary' => [
                '1' => 'static',
                '2' => 'relative',
                '3' => 'absolute' ,
                '4' => 'fixed',
                '5' => 'sticky',
            ],
            'selectors' => [
                '{{WRAPPER}}' => 'position: {{VALUE}}; ',
                // '#smooth-wrapper {{WRAPPER}}' => 'will-change: unset !important;transform: none !important;'
            ],
        ]
    );
    // 
    $el->add_control(
        'el_popover_position',
        [
            'label' => esc_html__( 'Controls Position', 'mouno' ),
            'type' => \Elementor\Controls_Manager::POPOVER_TOGGLE,
            'label_off' => esc_html__( 'Default', 'mouno' ),
            'label_on' => esc_html__( 'Custom', 'mouno' ),
            'return_value' => 'yes',
            'condition' => [
                'el_position' => ['absolute', 'fixed', 'sticky'],
            ],
        ],
    );
    $el->start_popover();
    $el->add_responsive_control(
        'el_offset_t',
        [
            'label' => esc_html__('Top', 'mouno' ),
            'type' => \Elementor\Controls_Manager::SLIDER,
            'size_units' => [ 'px', '%', 'custom' ],
            'range' => [
                'px' => [
                    'min' => 1,
                    'max' => 1000,
                ],
            ],
            'selectors' => [
                '{{WRAPPER}}' => 'top: {{SIZE}}{{UNIT}};;',
            ],
        ]
    );
    $el->add_responsive_control(
        'el_offset_r',
        [
            'label' => esc_html__('Right', 'mouno' ),
            'type' => \Elementor\Controls_Manager::SLIDER,
            'size_units' => [ 'px', '%', 'custom' ],
            'range' => [
                'px' => [
                    'min' => 1,
                    'max' => 1000,
                ],
            ],
            'selectors' => [
                '{{WRAPPER}}' => 'right: {{SIZE}}{{UNIT}};',
                
            ],
        ]
    );
    $el->add_responsive_control(
        'el_offset_b',
        [
            'label' => esc_html__('Bottom', 'mouno' ),
            'type' => \Elementor\Controls_Manager::SLIDER,
            'size_units' => [ 'px', '%', 'custom' ],
            'range' => [
                'px' => [
                    'min' => 1,
                    'max' => 1000,
                ],
            ],
            'selectors' => [
                '{{WRAPPER}}' => 'bottom: {{SIZE}}{{UNIT}};',
            ],
        ]
    );
    $el->add_responsive_control(
        'el_offset_l',
        [
            'label' => esc_html__('Left', 'mouno' ),
            'type' => \Elementor\Controls_Manager::SLIDER,
            'size_units' => [ 'px', '%', 'custom' ],
            'range' => [
                'px' => [
                    'min' => 1,
                    'max' => 1000,
                ],
            ],
            'selectors' => [
                '{{WRAPPER}}' => 'left: {{SIZE}}{{UNIT}};',
            ],
        ]
    );

    $el->end_popover();
    // 
    $el->add_responsive_control(
        'el_max_w',
        [
            'label' => esc_html__('Max Width', 'mouno' ),
            'type' => \Elementor\Controls_Manager::SLIDER,
            'size_units' => [ 'px', '%', 'custom' ],
            'range' => [
                'px' => [
                    'min' => 0,
                    'max' => 1000,
                ],
            ],
            'selectors' => [
                '{{WRAPPER}}' => 'max-width: {{SIZE}}{{UNIT}};',
            ],
        ]
    );

    $el->add_responsive_control(
        'el_min_w',
        [
            'label' => esc_html__('Min Width', 'mouno' ),
            'type' => \Elementor\Controls_Manager::SLIDER,
            'size_units' => [ 'px', '%', 'custom' ],
            'range' => [
                'px' => [
                    'min' => 0,
                    'max' => 1000,
                ],
            ],
            'selectors' => [
                '{{WRAPPER}}' => 'min-width: {{SIZE}}{{UNIT}};',
            ],
        ]
    );
    $el->end_controls_section();
}

/*
    Background Parallax
*/
add_action( 'elementor/element/container/section_layout/after_section_end', 'mouno_element_custom_background_parallax', 1, 1 ); 
function mouno_element_custom_background_parallax( \Elementor\Element_Base $el ) {
    $el->start_controls_section(
        'el_custom_bg_parallax',
        [
            'label' => esc_html__( 'Mouno Background Parallax', 'mouno' ),
            'tab' => \Elementor\Controls_Manager::TAB_LAYOUT,
        ]
    );
    $el->add_control(
        'el_bg_parallax_img',
        [
            'label' => esc_html__( 'Background', 'mouno' ),
            'type' => \Elementor\Controls_Manager::MEDIA,
            'selectors' => [
                '{{WRAPPER}} .e-con-background-parallax' => 'background-image: url( {{URL}} );',
            ],
        ]
    );
    $el->add_responsive_control(
        'el_bg_parallax_position',
        [
            'label' => esc_html__( 'Background Position', 'mouno' ),
            'type'         => \Elementor\Controls_Manager::SELECT,
            'options'      => array(
                ''              => esc_html__( 'Default', 'mouno' ),
                'center center' => esc_html__( 'Center Center', 'mouno' ),
                'center left'   => esc_html__( 'Center Left', 'mouno' ),
                'center right'  => esc_html__( 'Center Right', 'mouno' ),
                'top center'    => esc_html__( 'Top Center', 'mouno' ),
                'top left'      => esc_html__( 'Top Left', 'mouno' ),
                'top right'     => esc_html__( 'Top Right', 'mouno' ),
                'bottom center' => esc_html__( 'Bottom Center', 'mouno' ),
                'bottom left'   => esc_html__( 'Bottom Left', 'mouno' ),
                'bottom right'  => esc_html__( 'Bottom Right', 'mouno' ),
                'custom'       => esc_html__( 'Custom', 'mouno' ),
            ),
            'default'      => '',
            'selectors_dictionary' => [
                '1' => 'center center' , 
                '2' => 'center left' , 
                '3' => 'center right' , 
                '4' => 'top center' , 
                '5' => 'top left' , 
                '6' => 'top right' ,
                '7' => 'bottom center' , 
                '8' => 'bottom left' , 
                '9' => 'bottom right' , 
            ],
            'selectors' => [
                '{{WRAPPER}} .e-con-background-parallax' => 'background-position: {{VALUE}};',
            ],
            'condition' => [
                'el_bg_parallax_img[url]!' => ''
            ],        
        ],
    );
    $el->add_control(
        'el_bg_parallax_popover_position',
        [
            'label' => esc_html__( 'Background Custom Position', 'mouno' ),
            'type' => \Elementor\Controls_Manager::POPOVER_TOGGLE,
            'label_off' => esc_html__( 'Default', 'mouno' ),
            'label_on' => esc_html__( 'Custom', 'mouno' ),
            'return_value' => 'yes',
            'separator' => 'after',
            'condition' => [
                'el_bg_parallax_position'  => 'custom',
            ],
        ]
    );
    $el->start_popover();
    $el->add_responsive_control(
        'el_bg_parallax_position_x',
        [
            'label' => esc_html__( 'X Position', 'mouno' ),
            'type' => \Elementor\Controls_Manager::SLIDER,  
            'size_units' => [ 'px', 'em', '%', 'vw' ],
            'default' => [
                'unit' => 'px',
                'size' => 0,
            ],
            'selectors' => [
                '{{WRAPPER}} .e-con-background-parallax' => 'background-position: {{SIZE}}{{UNIT}} {{el_bg_parallax_position_y.SIZE}}{{el_bg_parallax_position_y.UNIT}}',
            ],
            'condition' => [
                'el_bg_parallax_position'  => 'custom',
            ],
        ]
    );
    $el->add_responsive_control(
        'el_bg_parallax_position_y',
        [
            'label' => esc_html__( 'Y Position', 'mouno' ),
            'type' => \Elementor\Controls_Manager::SLIDER,  
            'size_units' => [ 'px', 'em', '%', 'vw' ],
            'default' => [
                'unit' => 'px',
                'size' => 0,
            ],
            'selectors' => [
                '{{WRAPPER}} .e-con-background-parallax' => 'background-position: {{el_bg_parallax_position_x.SIZE}}{{el_bg_parallax_position_x.UNIT}} {{SIZE}}{{UNIT}}',
            ],
            'condition' => [
                'el_bg_parallax_position'  => 'custom',
            ],
        ]
    );
    $el->end_popover();
    $el->add_responsive_control(
        'el_bg_parallax_size',
        [
            'label'    => esc_html__( 'Background Size', 'mouno' ),
            'type'     => \Elementor\Controls_Manager::SELECT,
            'options'  => array(
                ''        => esc_html__( 'Default', 'mouno' ),
                'auto'    => esc_html__( 'Auto', 'mouno' ),
                'cover'   => esc_html__( 'Cover', 'mouno' ),
                'contain' => esc_html__( 'Contain', 'mouno' ),
                'custom' => esc_html__( 'Custom', 'mouno' ),
            ),
            'default'   => '',
            'selectors_dictionary' => [
                '1' => 'auto' , 
                '2' => 'cover' , 
                '3' => 'contain' , 
            ],
            'selectors' => [
                '{{WRAPPER}} .e-con-background-parallax' => 'background-size: {{VALUE}};',
            ],
            'condition' => [
                'el_bg_parallax_img[url]!' => ''
            ]        
        ]
    );
    $el->add_responsive_control(
        'el_bg_parallax_size_custom',
        [
            'label' => esc_html__( 'Background Custom Size', 'mouno' ),
            'type' => \Elementor\Controls_Manager::SLIDER,  
            'size_units' => [ 'px', 'em', '%', 'vw' ],
            'separator' => 'after',
            'default' => [
                'size' => 100,
                'unit' => '%',
            ],
            'selectors' => [
                '{{WRAPPER}} .e-con-background-parallax' => 'background-size: {{SIZE}}{{UNIT}} auto',
            ],
            'condition' => [
                'el_bg_parallax_size' => [ 'custom' ],
            ],
        ]
    );
    $el->add_control(
        'el_bg_parallax_popover_effects',
        [
            'label' => esc_html__( 'Parallax Effects', 'mouno' ),
            'type' => \Elementor\Controls_Manager::POPOVER_TOGGLE,
            'label_off' => esc_html__( 'Default', 'mouno' ),
            'label_on' => esc_html__( 'Custom', 'mouno' ),
            'return_value' => 'yes',
            'condition'     => [
                'el_bg_parallax_img[url]!' => ''
            ] 
        ]
    );
    $el->start_popover();
    $el->add_control(
        'el_bg_parallax_effect_opacity',
        [
            'label' => esc_html__( 'Opacity', 'mouno' ),
            'type' => 'number',
            'default' => 1,
            'min' => 0,
            'max' => 1,
            'step' => 0.1,
        ]
    );
    $el->add_control(
        'el_bg_parallax_effect_translate_dir',
        [
            'label' => esc_html__( 'Translate Direction', 'mouno' ),
            'type' => \Elementor\Controls_Manager::SELECT,
            'options' => [
                'x' => esc_html__('X', 'mouno'), 
                'y' => esc_html__('Y', 'mouno'), 
            ],
            'default' => 'y',
        ],
    );
    $el->add_control(
        'el_bg_parallax_effect_x',
        [
            'label' => esc_html__( 'TranslateX', 'mouno' ),
            'type' => 'slider',
            'size_units' => ['px'],
            'range' => [
                'px' => [
                    'min' => -1000,
                    'max' => 1000,
                ],
            ],
            'default' => [
                'unit' => 'px',
                'size' => 100,
            ],
            'condition' => [
                'el_bg_parallax_effect_translate_dir' => 'x',
            ],
        ],
    );
    $el->add_control(
        'el_bg_parallax_effect_y',
        [
            'label' => esc_html__( 'TranslateY', 'mouno' ),
            'type' => 'slider',
            'size_units' => ['px'],
            'range' => [
                'px' => [
                    'min' => -1000,
                    'max' => 1000,
                ],
            ],
            'default' => [
                'unit' => 'px',
                'size' => 200,
            ],
            'condition' => [
                'el_bg_parallax_effect_translate_dir' => 'y',
            ],
        ],
    );
    $el->add_control(
        'el_bg_parallax_effect_rotate',
        [
            'label' => esc_html__( 'Rotate', 'mouno' ),
            'type' => 'number',
            'min' => -360,
            'max' => 360,
            'default' => 0,
            'placeholder' => esc_html__('Ex: 50', 'mouno'),
        ]
    );
    $el->add_control(
        'el_bg_parallax_effect_scale',
        [
            'label' => esc_html__( 'Scale', 'mouno' ),
            'type' => 'number',
            'default' => 1,
            'min' => -2,
            'max' => 2,
            'step' => 0.1,
            'placeholder' => esc_html__('Ex: 1.2', 'mouno'),
        ]
    );
    $el->end_popover(); 
    $el->end_controls_section();
}

/*
    Template
*/
add_action( 'elementor/element/container/section_layout/after_section_end', 'mouno_element_custom_template', 1, 1 ); 
function mouno_element_custom_template( \Elementor\Element_Base $el ) {
    $post_type = get_post_type();
    if($post_type !== 'pxl-template') return;
    $el->start_controls_section(
        'pxl_tempalte_opts',
        [
            'label' => esc_html__( 'Mouno Templates', 'mouno' ),
            'tab' => \Elementor\Controls_Manager::TAB_LAYOUT,
        ],
    );
    $el->add_control(
        'act_when_called',
        [
            'label' => esc_html__('Action when Called', 'mouno'),
            'type'  => \Elementor\Controls_Manager::SWITCHER,
            'deffault' => '',
            'description' => esc_html__('This element will be displayed when called from an action you have created.', 'mouno'),

        ],
    );
    $el->add_group_control(
        \Elementor\Group_Control_Background::get_type(),
        [
            'name' => 'tempalte_overlay_background',
            'types' => [ 'classic', 'gradient', 'video' ],
            'fields_options' => [
                'background' => [
                    'label' => __( 'Overlay Type', 'mouno' ),
                ],
            ],
            'selector' => '{{WRAPPER}} .pxl-template-overlay',
        ],
    );
    $el->end_controls_section();
}

/*
    Overlay
*/
add_action( 'elementor/element/container/section_layout/after_section_end', 'mouno_element_custom_overlay', 1, 1 ); 
function mouno_element_custom_overlay( \Elementor\Element_Base $el ) {
    $el->start_controls_section(
        'el_custom_overlay',
        [
            'label' => esc_html__( 'Mouno Overlay', 'mouno' ),
            'tab' => \Elementor\Controls_Manager::TAB_LAYOUT,
        ],
    );

    $el->add_control(
        'el_number_layer_overlay',
        [
            'label' => esc_html__( 'Number of Overlay', 'mouno' ),
            'type' => 'select',
            'options' => [
                ''  => 'None',
                '1' => 'One Layer',
                'multiple' => 'Multilayer',
            ],
            'default' => '',
        ],
    );

    $el->add_control(
        'el_overlay_effects',
        [
            'label' => esc_html__( 'Effect', 'mouno' ),
            'type' => 'select',
            'options' => [
                ''  => 'None',
                'cursor-spotlight' => 'Cursor Spotlight',
            ],
            'default' => '',
            'condition' => [
                'el_number_layer_overlay!' => '',
            ],
        ],
    );

    // Onelayer
    $el->add_group_control(
        \Elementor\Group_Control_Background::get_type(),
        [
            'name' => 'el_bg_overlay',
            'types' => [ 'classic', 'gradient'],
            'fields_options' => [
                'background' => [
                    'label' => __( 'Background', 'mouno' ),
                ],
                'color' => [
                    'selectors' => [
                        '{{WRAPPER}} .e-con-overlay' => '--pxl-background-color: {{VALUE}};',
                    ],
                ],
            ],
            'selector' => '{{WRAPPER}} .e-con-overlay',
            'condition' => [
                'el_number_layer_overlay' => '1',
            ],
        ]
    );
    $el->add_control(
        'el_divider3', 
        [ 
            'type' => \Elementor\Controls_Manager::DIVIDER,
            'condition' => [
                'el_number_layer_overlay' => '1',
            ],
        ],
    );
    $el->add_responsive_control(
        'el_overlay_opacity',
        [
            'label' => esc_html__('Opacity', 'mouno'),
            'type' => \Elementor\Controls_Manager::SLIDER,
            'size_units' => ['%', 'custom'],
            'default' => [
                'unit' => '%',
                'size' => 50,
            ],
            'range' => [
                '%' => [
                    'min' => 0,
                    'max' => 100,
                ],
            ],
            'selectors' => [
                '{{WRAPPER}} .e-con-overlay' => 'opacity: {{SIZE}}{{UNIT}};',
            ],
            'condition' => [
                'el_number_layer_overlay' => '1',
            ],
        ],
    );
    $el->add_group_control(
        \Elementor\Group_Control_Css_Filter::get_type(),
        [
            'name' => 'el_overlay_css_filters',
            'selector' => '{{WRAPPER}} .e-con-overlay',
            'condition' => [
                'el_number_layer_overlay' => '1',
            ],
        ]
    );
    $el->add_control(
        'el_overlay_size',
        [
            'label' => esc_html__( 'Size', 'mouno' ),
            'type' => \Elementor\Controls_Manager::POPOVER_TOGGLE,
            'default' => '',
            'condition' => [
                'el_number_layer_overlay' => '1',
            ],
        ]
    );
    $el->start_popover();
        $el->add_responsive_control(
            'el_overlay_width',
            [
                'label' => esc_html__('Width', 'mouno'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .e-con-overlay' => 'width: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'el_number_layer_overlay' => '1',
                ],
            ],
        );
        $el->add_responsive_control(
            'el_overlay_height',
            [
                'label' => esc_html__('Height', 'mouno'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .e-con-overlay' => 'height: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'el_number_layer_overlay' => '1',
                ],
            ],
        );
    $el->end_popover();
    $el->add_control(
        'el_overlay_border_radius',
        [
            'label' => esc_html__( 'Border Radius', 'mouno' ),
            'type' => \Elementor\Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', '%', 'custom' ],
            'selectors' => [
                '{{WRAPPER}} .e-con-overlay' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
            'condition' => [
                'el_number_layer_overlay' => '1',
            ],
        ]
    );
    $el->add_control(
        'el_divider4', 
        [ 
            'type' => \Elementor\Controls_Manager::DIVIDER,
            'condition' => [
                'el_number_layer_overlay' => '1',
            ],
        ],
    );
    $el->add_control(
        'el_overlay_position',
        [
            'label' => esc_html__( 'Position', 'mouno' ),
            'type' => \Elementor\Controls_Manager::POPOVER_TOGGLE,
            'default' => '',
            'condition' => [
                'el_number_layer_overlay' => '1',
            ],
        ],
    );
    $el->start_popover();

        $el->add_responsive_control(
            'el_overlay_t',
            [
                'label' => esc_html__('Top', 'mouno' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px','%', 'custom' ],
                'range' => [
                    'px' => [
                        'min' => 1,
                        'max' => 1000,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .e-con-overlay' => 'top: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'el_number_layer_overlay' => '1',
                ],
            ]
        );
        $el->add_responsive_control(
            'el_overlay_r',
            [
                'label' => esc_html__('Right', 'mouno' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px','%', 'custom' ],
                'range' => [
                    'px' => [
                        'min' => 1,
                        'max' => 1000,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .e-con-overlay' => 'right: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $el->add_responsive_control(
            'el_overlay_b',
            [
                'label' => esc_html__('Bottom', 'mouno' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px','%', 'custom' ],
                'range' => [
                    'px' => [
                        'min' => 1,
                        'max' => 1000,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .e-con-overlay' => 'bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $el->add_responsive_control(
            'el_overlay_l',
            [
                'label' => esc_html__('Left', 'mouno' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px','%','em','rem', 'custom' ],
                'range' => [
                    'px' => [
                        'min' => 1,
                        'max' => 1000,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .e-con-overlay' => 'left: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
    $el->end_popover();

    // Multilayer
    $item = new \Elementor\Repeater();
    $item->add_group_control(
        \Elementor\Group_Control_Background::get_type(),
        [
            'name' => 'el_bg_overlay',
            'types' => [ 'classic', 'gradient'],
            'selector' => '{{WRAPPER}} {{CURRENT_ITEM}}',
            'exclude' => ['image'],
        ],
    );
    $item->add_control(
        'el_divider6', 
        [ 'type' => \Elementor\Controls_Manager::DIVIDER]
    );
    $item->add_responsive_control(
        'el_item_overlay_opacity',
        [
            'label' => esc_html__('Opacity', 'mouno'),
            'type' => \Elementor\Controls_Manager::SLIDER,
            'size_units' => ['%', 'custom'],
            'default' => [
                'unit' => '%',
                'size' => 50,
            ],
            'range' => [
                '%' => [
                    'min' => 0,
                    'max' => 100,
                ],
            ],
            'selectors' => [
                '{{WRAPPER}} {{CURRENT_ITEM}}' => 'opacity: {{SIZE}}{{UNIT}};',
            ],
        ],
    );
    $item->add_group_control(
        \Elementor\Group_Control_Css_Filter::get_type(),
        [
            'name' => 'el_item_overlay_css_filters',
            'selector' => '{{WRAPPER}} {{CURRENT_ITEM}}',
        ]
    );
    $item->add_control(
        'el_item_overlay_size',
        [
            'label' => esc_html__( 'Size', 'mouno' ),
            'type' => \Elementor\Controls_Manager::POPOVER_TOGGLE,
            'default' => '',
        ]
    );
    $item->start_popover();
        $item->add_responsive_control(
            'el_item_overlay_width',
            [
                'label' => esc_html__('Width', 'mouno'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} {{CURRENT_ITEM}}' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ],
        );
        $item->add_responsive_control(
            'el_item_overlay_height',
            [
                'label' => esc_html__('Height', 'mouno'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} {{CURRENT_ITEM}}' => 'height: {{SIZE}}{{UNIT}};',
                ],
            ],
        );
    $item->end_popover();
    $item->add_control(
        'el_item_overlay_border_radius',
        [
            'label' => esc_html__( 'Border Radius', 'mouno' ),
            'type' => \Elementor\Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
            'selectors' => [
                '{{WRAPPER}} {{CURRENT_ITEM}}' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ]
    );
    $item->add_control(
        'el_divider5', 
        [ 'type' => \Elementor\Controls_Manager::DIVIDER]
    );
    $item->add_control(
        'el_item_overlay_position',
        [
            'label' => esc_html__( 'Position', 'mouno' ),
            'type' => \Elementor\Controls_Manager::POPOVER_TOGGLE,
            'default' => '',
        ]
    );
    $item->start_popover();

        $item->add_responsive_control(
            'el_item_overlay_t',
            [
                'label' => esc_html__('Top', 'mouno' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px','%', 'custom' ],
                'range' => [
                    'px' => [
                        'min' => 1,
                        'max' => 1000,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} {{CURRENT_ITEM}}' => 'top: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $item->add_responsive_control(
            'el_item_overlay_r',
            [
                'label' => esc_html__('Right', 'mouno' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px','%', 'custom' ],
                'range' => [
                    'px' => [
                        'min' => 1,
                        'max' => 1000,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} {{CURRENT_ITEM}}' => 'right: {{SIZE}}{{UNIT}};',
                    
                ],
            ]
        );
        $item->add_responsive_control(
            'el_item_overlay_b',
            [
                'label' => esc_html__('Bottom', 'mouno' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px','%', 'custom' ],
                'range' => [
                    'px' => [
                        'min' => 1,
                        'max' => 1000,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} {{CURRENT_ITEM}}' => 'bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $item->add_responsive_control(
            'el_item_overlay_l',
            [
                'label' => esc_html__('Left', 'mouno' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px','%', 'custom' ],
                'range' => [
                    'px' => [
                        'min' => 1,
                        'max' => 1000,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} {{CURRENT_ITEM}}' => 'left: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
    $item->end_popover();
    $el->add_control(
        'el_overlays',
        [
            'label'   => esc_html__( 'Overlays', 'mouno' ),
            'type' => \Elementor\Controls_Manager::REPEATER,
            'fields' => $item->get_controls(),
            'default' => [],
            'condition' => [
                'el_number_layer_overlay' => 'multiple',
            ],
        ],
    );
    $el->end_controls_section();
};

/*
    Layers
*/
add_action( 'elementor/element/container/section_layout/after_section_end', 'mouno_element_custom_layers', 1, 1 ); 
function mouno_element_custom_layers( \Elementor\Element_Base $el ) {
    $el->start_controls_section(
        'el_custom_layers',
        [
            'label' => esc_html__( 'Mouno Layers', 'mouno' ),
            'tab' => \Elementor\Controls_Manager::TAB_LAYOUT,
        ],
    );
    $item = new \Elementor\Repeater();
    $item->add_control(
        'el_bg_parallax_img',
        [
            'label' => esc_html__( 'Image', 'mouno' ),
            'type' => 'media',
        ]
    );
    $item->add_control(
        'el_divider6', 
        [ 'type' => \Elementor\Controls_Manager::DIVIDER]
    );
    $item->add_responsive_control(
        'el_layer_opacity',
        [
            'label' => esc_html__('Opacity', 'mouno'),
            'type' => \Elementor\Controls_Manager::SLIDER,
            'size_units' => ['%', 'custom'],
            'default' => [
                'unit' => '%',
                'size' => 50,
            ],
            'range' => [
                '%' => [
                    'min' => 0,
                    'max' => 100,
                ],
            ],
            'selectors' => [
                '{{WRAPPER}} {{CURRENT_ITEM}}' => 'opacity: {{SIZE}}{{UNIT}};',
            ],
        ],
    );
    $item->add_group_control(
        \Elementor\Group_Control_Css_Filter::get_type(),
        [
            'name' => 'el_layer_css_filters',
            'selector' => '{{WRAPPER}} {{CURRENT_ITEM}}',
        ]
    );
    $item->add_control(
        'el_layer_size',
        [
            'label' => esc_html__( 'Size', 'mouno' ),
            'type' => \Elementor\Controls_Manager::POPOVER_TOGGLE,
            'default' => '',
        ]
    );
    $item->start_popover();
        $item->add_responsive_control(
            'el_layer_width',
            [
                'label' => esc_html__('Width', 'mouno'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} {{CURRENT_ITEM}}' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ],
        );
        $item->add_responsive_control(
            'el_layer_height',
            [
                'label' => esc_html__('Height', 'mouno'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} {{CURRENT_ITEM}}' => 'height: {{SIZE}}{{UNIT}};',
                ],
            ],
        );
    $item->end_popover();
    $item->add_control(
        'el_layer_border_radius',
        [
            'label' => esc_html__( 'Border Radius', 'mouno' ),
            'type' => \Elementor\Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
            'selectors' => [
                '{{WRAPPER}} {{CURRENT_ITEM}}' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ]
    );
    $item->add_control(
        'el_divider5', 
        [ 'type' => \Elementor\Controls_Manager::DIVIDER]
    );
    $item->add_control(
        'el_layer_position',
        [
            'label' => esc_html__( 'Position', 'mouno' ),
            'type' => \Elementor\Controls_Manager::POPOVER_TOGGLE,
            'default' => '',
        ]
    );
    $item->start_popover();
        $item->add_responsive_control(
            'el_layer_t',
            [
                'label' => esc_html__('Top', 'mouno' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px','%', 'custom' ],
                'range' => [
                    'px' => [
                        'min' => 1,
                        'max' => 1000,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 0,
                ],
                'selectors' => [
                    '{{WRAPPER}} {{CURRENT_ITEM}}' => 'top: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $item->add_responsive_control(
            'el_layer_r',
            [
                'label' => esc_html__('Right', 'mouno' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px','%', 'custom' ],
                'range' => [
                    'px' => [
                        'min' => 1,
                        'max' => 1000,
                    ],
                ],
                'default' => [
                    'unit' => 'custom',
                    'size' => 'auto',
                ],
                'selectors' => [
                    '{{WRAPPER}} {{CURRENT_ITEM}}' => 'right: {{SIZE}}{{UNIT}};',
                    
                ],
            ]
        );
        $item->add_responsive_control(
            'el_layer_b',
            [
                'label' => esc_html__('Bottom', 'mouno' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px','%', 'custom' ],
                'range' => [
                    'px' => [
                        'min' => 1,
                        'max' => 1000,
                    ],
                ],
                'default' => [
                    'unit' => 'custom',
                    'size' => 'auto',
                ],
                'selectors' => [
                    '{{WRAPPER}} {{CURRENT_ITEM}}' => 'bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $item->add_responsive_control(
            'el_layer_l',
            [
                'label' => esc_html__('Left', 'mouno' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px','%', 'custom' ],
                'range' => [
                    'px' => [
                        'min' => 1,
                        'max' => 1000,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 0,
                ],
                'selectors' => [
                    '{{WRAPPER}} {{CURRENT_ITEM}}' => 'left: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
    $item->end_popover();
    $el->add_control(
        'el_layers',
        [
            'label'   => esc_html__( 'Layers', 'mouno' ),
            'type' => \Elementor\Controls_Manager::REPEATER,
            'fields' => $item->get_controls(),
            'default' => [],
        ],
    );
    $el->end_controls_section();
};

/*
    Class Render
*/
add_filter( 'pxl_custom_class', 'mouno_e_con_class_render', 1, 2);
function mouno_e_con_class_render($classes, $settings) {
    $classes = '';
    if(!empty($settings['act_when_called'])) {
        $classes .= 'pxl-template-main';
    }
    return $classes;
}

/*
    HTML Before Content Render
*/
add_filter( 'pxl_element_container/before-render', 'mouno_element_before_render', 1, 2) ;
function mouno_element_before_render($output, $settings) {
    // Background parallax
    if(!empty($settings['el_bg_parallax_img']['url'])){
        wp_enqueue_script( 'mouno-parallax' );
        $x = (!empty($settings['el_bg_parallax_effect_x']) && isset($settings['el_bg_parallax_effect_x'])) ? ($settings['el_bg_parallax_effect_x']['size'] ?? 0) : 0;
        $y = (!empty($settings['el_bg_parallax_effect_y']) && isset($settings['el_bg_parallax_effect_y'])) ? ($settings['el_bg_parallax_effect_y']['size'] ?? 0) : 0;
        $rotate      = (!empty($settings['el_bg_parallax_effect_rotate'])) ? $settings['el_bg_parallax_effect_rotate'] : 0;
        $scale       = (!empty($settings['el_bg_parallax_effect_scale'])) ? $settings['el_bg_parallax_effect_scale'] : 1;
        $opacity     = (!empty($settings['el_bg_parallax_effect_opacity'])) ? $settings['el_bg_parallax_effect_opacity'] : 1;
        $effects = [
            'x'          => $x,
            'y'          => $y,
            'rotate'     => $rotate,
            'scale'      => $scale,
            'opacity'    => $opacity
        ];
        $data_parallax = json_encode($effects);
        $output .= '<div class="e-con-background-parallax" data-parallax="'.esc_attr($data_parallax).'"></div>';
    }
    
    // Overlay
    if($settings['el_number_layer_overlay'] == '1') {
        $output .= '<div class="e-con-overlay '.$settings['el_overlay_effects'].'"></div>';
    }else{
        $is_overlays = isset($settings['el_overlays']) && !empty($settings['el_overlays']) && count($settings['el_overlays']) || false;
        if($is_overlays) {
            foreach($settings['el_overlays'] as $key => $overlay) {
                $output .= '<div class="e-con-overlay elementor-repeater-item-'.esc_attr($overlay['_id']).'"></div>';
            }
        }
    }
    // Layers
    $is_layers = isset($settings['el_layers']) && !empty($settings['el_layers']) && count($settings['el_layers']) || false;
    if($is_layers) {
        foreach($settings['el_layers'] as $key => $layer) {
            $output .= '<span class="e-con-layer elementor-repeater-item-'.esc_attr($layer['_id']).'"></span>';
        }
    }
    return $output;
}

/*
    HTML After Content Render
*/
// add_filter( 'pxl_element_container/after-render', 'mouno_element_after_render', 1, 2) ;
// function mouno_element_after_render($output, $settings) {
//     return $output;
// }