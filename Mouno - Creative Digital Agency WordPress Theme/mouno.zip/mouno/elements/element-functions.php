<?php 

/**
 * Swipper Lib
*/
if(!function_exists('mouno_elements_scripts')){
    add_action( 'wp_enqueue_scripts', 'mouno_elements_scripts');
    function mouno_elements_scripts() {  
        $theme = wp_get_theme( get_template() );
        wp_register_script( 'split-text', get_template_directory_uri() . '/assets/js/gsap/SplitText.min.js', array( 'jquery' ), '3.12.5', true );

        wp_register_script( 'pxl-nice-scroll', get_template_directory_uri() . '/assets/js/libs/nice-scroll.min.js', array( 'jquery' ), '3.7.6', true );

        wp_register_script('pxl-post-grid', get_template_directory_uri() . '/elements/assets/js/grid.js', [ 'isotope', 'jquery' ], $theme->get( 'Version' ), true);
        wp_localize_script('pxl-post-grid', 'main_data', array( 'ajax_url' => admin_url( 'admin-ajax.php' ), 'wpnonce' => wp_create_nonce( '_ajax_nonce' ) ) );
        wp_register_script('mouno-counter', get_template_directory_uri() . '/elements/assets/js/counter.js', [ 'jquery' ], $theme->get( 'Version' ), true);
        wp_register_script('mouno-accordion', get_template_directory_uri() . '/elements/assets/js/accordion.js', [ 'jquery' ], $theme->get( 'Version' ), true);
        wp_localize_script('mouno-accordion', 'accordion_data', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'wpnonce'  => wp_create_nonce('_ajax_nonce')
        ]);
        wp_register_script('mouno-tabs', get_template_directory_uri() . '/elements/assets/js/tabs.js', [ 'jquery' ], $theme->get( 'Version' ), true);
        wp_register_script('mouno-countdown', get_template_directory_uri() . '/elements/assets/js/countdown.js', [ 'jquery' ], $theme->get( 'Version' ), true);
        wp_register_script('pxl-pie-chart', get_template_directory_uri() . '/assets/js/libs/pie-chart.min.js', [ 'jquery' ], $theme->get( 'Version' ), true);
        wp_enqueue_script('mouno-elementor', get_template_directory_uri() . '/elements/assets/js/elementor.js', [ 'jquery' ], $theme->get( 'Version' ), true);
        // New add
        wp_register_script('circular-text', get_template_directory_uri() . '/elements/assets/js/circular-text.js', [ 'jquery' ], $theme->get( 'Version' ), true);
        wp_register_script('mouno-parallax', get_template_directory_uri() . '/elements/assets/js/parallax.js', [ 'jquery' ], $theme->get( 'Version' ), true);
        wp_register_script('mouno-effects', get_template_directory_uri() . '/elements/assets/js/effects.js', [ 'jquery' ], $theme->get( 'Version' ), true);
        wp_localize_script('mouno-effects', 'effects_data', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'wpnonce'  => wp_create_nonce('_ajax_nonce')
        ]);
        wp_register_script('mouno-swiper', get_template_directory_uri() . '/elements/assets/js/swiper.js', [ 'jquery' ], $theme->get( 'Version' ), true);
    }
}

/**
 * Extra Elementor Icons
*/
if(!function_exists('mouno_register_custom_icon_library')){
    add_filter('elementor/icons_manager/native', 'mouno_register_custom_icon_library');
    function mouno_register_custom_icon_library($tabs){
        $custom_tabs = [
            'pxl_icon1' => [
                'name' => 'flaticon',
                'label' => esc_html__( 'Mouno', 'mouno' ),
                'url' => false,
                'enqueue' => false,
                'prefix' => 'flaticon-',
                'displayPrefix' => 'flaticon',
                'labelIcon' => 'flaticon-it',
                'ver' => '1.0.0',
                'fetchJson' => get_template_directory_uri() . '/assets/fonts/flaticon/flaticon-08.js',
                'native' => true,
            ],

        ];
        $tabs = array_merge($custom_tabs, $tabs);
        return $tabs;
    }
}

// if()

 
/**
 * Get class widget path
*/
if(!function_exists('mouno_get_class_widget_path')){
    function mouno_get_class_widget_path(){
        $upload_dir = wp_upload_dir();
        $cls_path = $upload_dir['basedir'].'/elementor-widget/';
        if(!is_dir($cls_path)) {
            wp_mkdir_p( $cls_path );
        }
        return $cls_path;
    }
}

/**
 * Get post type options
*/
function mouno_get_post_type_options($pt_supports=[]){
    $post_types = get_post_types([
        'public'   => true,
    ], 'objects');
    $excluded_post_type = [
        'page',
        'attachment',
        'revision',
        'nav_menu_item',
        'custom_css',
        'customize_changeset',
        'oembed_cache',
        'e-landing-page',
        'header',
        'footer',
        'mega-menu',
        'elementor_library'
    ];

    $result_some = [];
    $result_any = [];
    if (!is_array($post_types))
        return $result;
    foreach ($post_types as $post_type) {
        if (!$post_type instanceof WP_Post_Type)
            continue;
        if (in_array($post_type->name, $excluded_post_type))
            continue;

        if(!empty($pt_supports) && in_array($post_type->name, $pt_supports)){
            $result_some[$post_type->name] = $post_type->labels->singular_name;
        }else{
            $result_any[$post_type->name] = $post_type->labels->singular_name;
        }
    }

    if(!empty($pt_supports))
        return $result_some;
    else   
        return $result_any;
}

// 
function mouno_get_post_layout($pt_supports = [], $condition = []) {
    $post_types  = mouno_get_post_type_options($pt_supports); 
    $result = [];
    if (!is_array($post_types))
        return $result;
    foreach ($post_types as $name => $label) {
        $condition['post_type'] = [$name];
        $result[] = array(
            'name'     => 'layout_'.$name,
            'label'    => sprintf(esc_html__( 'Select Template of %s', 'mouno' ), $label),
            'type'     => 'layoutcontrol',
            'default' => $name.'-1',
            'options'  => mouno_get_layout_options($name),
            'condition' => $condition,
        );
    }
    return $result;  
}
function mouno_get_layout_options($post_type){
    $option_layouts = [];
    switch ($post_type) {
        case 'portfolio':
            $option_layouts = [
                'portfolio-1' => [
                    'label' => esc_html__( 'Layout 1', 'mouno' ),
                    'image' => get_template_directory_uri() . '/elements/templates/pxl_portfolio/img-layout/portfolio-1.webp'
                ],
                'portfolio-2' => [
                    'label' => esc_html__( 'Layout 2', 'mouno' ),
                    'image' => get_template_directory_uri() . '/elements/templates/pxl_portfolio/img-layout/portfolio-2.webp'
                ],
                'portfolio-3' => [
                    'label' => esc_html__( 'Layout 3', 'mouno' ),
                    'image' => get_template_directory_uri() . '/elements/templates/pxl_portfolio/img-layout/portfolio-3.webp'
                ],
                'portfolio-4' => [
                    'label' => esc_html__( 'Layout 4', 'mouno' ),
                    'image' => get_template_directory_uri() . '/elements/templates/pxl_portfolio/img-layout/portfolio-4.webp'
                ],
                'portfolio-5' => [
                    'label' => esc_html__( 'Layout 5', 'mouno' ),
                    'image' => get_template_directory_uri() . '/elements/templates/pxl_portfolio/img-layout/portfolio-5.webp'
                ],
            ];
            break;
        case 'post':  
            $option_layouts = [
                'post-1' => [
                    'label' => esc_html__( 'Layout 1', 'mouno' ),
                    'image' => get_template_directory_uri() . '/elements/templates/pxl_post/img-layout/post-1.webp'
                ],
                'post-2' => [
                    'label' => esc_html__( 'Layout 2', 'mouno' ),
                    'image' => get_template_directory_uri() . '/elements/templates/pxl_post/img-layout/post-2.webp'
                ],
                'post-3' => [
                    'label' => esc_html__( 'Layout 3', 'mouno' ),
                    'image' => get_template_directory_uri() . '/elements/templates/pxl_post/img-layout/post-3.webp'
                ],
                'post-4' => [
                    'label' => esc_html__( 'Layout 3', 'mouno' ),
                    'image' => get_template_directory_uri() . '/elements/templates/pxl_post/img-layout/post-4.webp'
                ],
            ];
            break;
        case 'service':
            $option_layouts = [
                'service-1' => [
                    'label' => esc_html__( 'Service 1', 'mouno' ),
                    'image' => get_template_directory_uri() . '/elements/templates/pxl_service/img-layout/service-1.webp'
                ],
                'service-2' => [
                    'label' => esc_html__( 'Service 2', 'mouno' ),
                    'image' => get_template_directory_uri() . '/elements/templates/pxl_service/img-layout/service-2.webp'
                ],
                'service-3' => [
                    'label' => esc_html__( 'Service 3', 'mouno' ),
                    'image' => get_template_directory_uri() . '/elements/templates/pxl_service/img-layout/service-3.webp'
                ],
                'service-4' => [
                    'label' => esc_html__( 'Service 4', 'mouno' ),
                    'image' => get_template_directory_uri() . '/elements/templates/pxl_service/img-layout/service-4.webp'
                ],
                'service-5' => [
                    'label' => esc_html__( 'Service 5', 'mouno' ),
                    'image' => get_template_directory_uri() . '/elements/templates/pxl_service/img-layout/service-5.webp'
                ],
            ];
            break;
        case 'team':
            $option_layouts = [
                'team-1' => [
                    'label' => esc_html__( 'Layout 1', 'mouno' ),
                    'image' => get_template_directory_uri() . '/elements/templates/pxl_team/img-layout/team-1.webp'
                ],
                'team-2' => [
                    'label' => esc_html__( 'Layout 2', 'mouno' ),
                    'image' => get_template_directory_uri() . '/elements/templates/pxl_team/img-layout/team-2.webp'
                ],
                'team-3' => [
                    'label' => esc_html__( 'Layout 3', 'mouno' ),
                    'image' => get_template_directory_uri() . '/elements/templates/pxl_team/img-layout/team-3.webp'
                ],
            ];
            break;

    }
    return $option_layouts;
}

function mouno_get_term_by_post_type($pt_supports = [], $args=[]){
    $args = wp_parse_args($args, ['condition' => 'post_type', 'custom_condition' => []]); 
    $post_types  = mouno_get_post_type_options($pt_supports); 
    $result = [];
    if (!is_array($post_types))
        return $result;
    foreach ($post_types as $name => $label) {
         
        $taxonomy = get_object_taxonomies($name, 'names');
        
        if($name == 'post') $taxonomy = ['category'];

        $result[] = array(
            'name'     => 'source_'.$name,
            'label'    => sprintf(esc_html__( 'Select Term of %s', 'mouno' ), $label),
            'type'     => \Elementor\Controls_Manager::SELECT2,
            'multiple' => true,
            'options'  => pxl_get_grid_term_options($name,$taxonomy),
            'condition' => array_merge(
                [
                    $args['condition'] => [$name]
                ],
                $args['custom_condition']
            )
        );
    }
    return $result;
}

function mouno_get_ids_by_post_type($pt_supports = [], $args = []){
    $args = wp_parse_args($args, ['condition' => 'post_type', 'custom_condition' => []]);
    $post_types = mouno_get_post_type_options($pt_supports);
    $result = [];
    if (!is_array($post_types))
        return $result;
    foreach ($post_types as $name => $label) {

        $posts = mouno_list_post($name, false);
 
        $result[] = array(
            'name' => 'source_' . $name . '_post_ids',
            'label' => sprintf(esc_html__('Select posts', 'mouno'), $label),
            'type'     => \Elementor\Controls_Manager::SELECT2,
            'multiple' => true,
            'options' => $posts,
            'condition' => array_merge(
                [
                    $args['condition'] => [$name]
                ],
                $args['custom_condition']
            )
        );
    }

    return $result;
}

function mouno_get_filter_term_by_post_type($pt_supports = [], $args = []) {
    $args = wp_parse_args($args, ['condition' => 'filter_post_type', 'custom_condition' => []]); 
    $post_types  = mouno_get_post_type_options($pt_supports); 
    $result = [];
    if (!is_array($post_types))
        return $result;
    foreach ($post_types as $name => $label) {
        $taxonomy = get_object_taxonomies($name, 'names');
        if($name == 'post') $taxonomy = ['category'];
        $result[] = array(
            'name'     => 'source_'.$name,
            'label'    => sprintf(esc_html__( 'Select Term of %s', 'mouno' ), $label),
            'type'     => \Elementor\Controls_Manager::SELECT2,
            'multiple' => true,
            'options'  => pxl_get_grid_term_options($name,$taxonomy),
            'condition' => array_merge(
                [
                    $args['condition'] => [$name]
                ],
                $args['custom_condition']
            )
        );
    }

    return $result;
}

/* Icon render */ 
function mouno_elementor_icon_render( $settings, $args = []){
    $args = wp_parse_args($args, [
        'prefix'     => '',   
        'id'         => 'selected_icon',
        'loop'       => false,
        'tag'        => 'div',   
        'wrap_class' => '',
        'class'      => '',
        'style'      => '',
        'before'     => '',
        'after'      => '',
        'atts'       => [],
        'animate_data' => '',
        'default_icon'    => [
            'value'   => '',
            'library' => ''
        ],
        'echo' => true
    ]);
    if($args['loop']) {
        $icon = $args['id'];
    } else {
        $icon = $settings[$args['id']];
    }
    if(empty($icon['value'])) $icon = $args['default_icon'];
    if (empty($icon['value'])) return;

    if ( 'svg' === $icon['library'] ){
        $args['before'] = '<span class="'.$args['wrap_class'].' '.$args['class'].'" data-settings="'. esc_attr($args['animate_data']).'">';
        $args['after']  = '</span>';
    }
    ob_start();
    printf('%s', $args['before']);
    ?>
    <?php \Elementor\Icons_Manager::render_icon( $icon, array_merge(
            [ 
                'aria-hidden' => 'true', 
                'class'       => trim(implode(' ', ['pxl-icon', $args['class'], $args['wrap_class']])),
                'style'       => $args['style']  
            ],
            $args['atts']
        ), $args['tag']); ?>
    <?php
    printf('%s', $args['after']);

    if($args['echo']){
        echo ob_get_clean();
    } else {
        return ob_get_clean();
    }
}

/**
 * Animation List
*/
function mouno_entrance_anim_group() {
    return [
        [
            'label' => esc_html__( 'None', 'mouno' ),
            'options' => [
                '' => esc_html__( 'None', 'mouno' ),
            ],
        ],
        [
            'label' => esc_html__( 'Fading', 'mouno' ),
            'options' => [
                'wow fadeIn'       => esc_html__( 'Fade In', 'mouno' ),
                'wow fadeInUp'     => esc_html__( 'Fade In Up', 'mouno' ),
                'wow fadeInRight'  => esc_html__( 'Fade In Right', 'mouno' ),
                'wow fadeInDown'   => esc_html__( 'Fade In Down', 'mouno' ),
                'wow fadeInLeft'   => esc_html__( 'Fade In Left', 'mouno' ),
            ],
        ],
        [
            'label' => esc_html__( 'Zooming', 'mouno' ),
            'options' => [
                'wow zoomIn'       => esc_html__( 'Zoom In', 'mouno' ),
                'wow zoomInUp'     => esc_html__( 'Zoom In Up', 'mouno' ),
                'wow zoomInRight'  => esc_html__( 'Zoom In Right', 'mouno' ),
                'wow zoomInDown'   => esc_html__( 'Zoom In Down', 'mouno' ),
                'wow zoomInLeft'   => esc_html__( 'Zoom In Left', 'mouno' ),
                'wow zoomInUpLeft' => esc_html__( 'Zoom In Up Left', 'mouno' ),
                'wow zoomInUpRight'=> esc_html__( 'Zoom In Up Right', 'mouno' ),
                'wow zoomInDownLeft'=> esc_html__( 'Zoom In Down Left', 'mouno' ),
                'wow zoomInDownRight'=> esc_html__( 'Zoom In Down Right', 'mouno' ),
            ],
        ],
        [
            'label' => esc_html__( 'Bouncing', 'mouno' ),
            'options' => [
                'wow bounceIn'       => esc_html__( 'Bounce In', 'mouno' ),
                'wow bounceInUp'     => esc_html__( 'Bounce In Up', 'mouno' ),
                'wow bounceInRight'  => esc_html__( 'Bounce In Right', 'mouno' ),
                'wow bounceInDown'   => esc_html__( 'Bounce In Down', 'mouno' ),
                'wow bounceInLeft'   => esc_html__( 'Bounce In Left', 'mouno' ),
            ],
        ],
        [
            'label' => esc_html__( 'Sliding', 'mouno' ),
            'options' => [
                'wow slideUp'      => esc_html__( 'Slide Up', 'mouno' ),
                'wow slideRight'   => esc_html__( 'Slide Right', 'mouno' ),
                'wow slideDown'    => esc_html__( 'Slide Down', 'mouno' ),
                'wow slideLeft'    => esc_html__( 'Slide Left', 'mouno' ),
            ],
        ],
        [
            'label' => esc_html__( 'Rotating', 'mouno' ),
            'options' => [
                'wow rotateIn'       => esc_html__( 'Rotate In', 'mouno' ),
                'wow rotateInUp'     => esc_html__( 'Rotate In Up', 'mouno' ),
                'wow rotateInRight'  => esc_html__( 'Rotate In Right', 'mouno' ),
                'wow rotateInDown'   => esc_html__( 'Rotate In Down', 'mouno' ),
                'wow rotateInLeft'   => esc_html__( 'Rotate In Left', 'mouno' ),
            ],
        ],
        [
            'label' => esc_html__( 'Reveal', 'mouno' ),
            'options' => [
                'wow revealIn'       => esc_html__( 'Reveal In', 'mouno' ),
                'wow revealInUp'     => esc_html__( 'Reveal In Up', 'mouno' ),
                'wow revealInRight'  => esc_html__( 'Reveal In Right', 'mouno' ),
                'wow revealInDown'   => esc_html__( 'Reveal In Down', 'mouno' ),
                'wow revealInLeft'   => esc_html__( 'Reveal In Left', 'mouno' ),
                'wow revealInVertical' => esc_html__('Reveal In Vertical', 'mouno'),
                'wow revealInHorizontal' => esc_html__('Reveal In Horizontal', 'mouno')
            ],
        ],
        [
            'label' => esc_html__( 'Reveal Image', 'mouno' ),
            'options' => [
                'wow revealImageIn'       => esc_html__( 'Reveal In', 'mouno' ),
                'wow revealImageInUp'     => esc_html__( 'Reveal In Up', 'mouno' ),
                'wow revealImageInRight'  => esc_html__( 'Reveal In Right', 'mouno' ),
                'wow revealImageInDown'   => esc_html__( 'Reveal In Down', 'mouno' ),
                'wow revealImageInLeft'   => esc_html__( 'Reveal In Left', 'mouno' ),
                'wow revealImageInVertical' => esc_html__('Reveal In Vertical', 'mouno'),
                'wow revealImageInHorizontal' => esc_html__('Reveal In Horizontal', 'mouno')
            ],
        ],
        [
            'label' => esc_html__( 'Rolling', 'mouno' ),
            'options' => [
                'wow rollingInTop'    => 'Rolling In Top',
                'wow rollingInRight'  => 'Rolling In Right',
                'wow rollingInBottom' => 'Rolling In Bottom',
                'wow rollingInLeft'   => 'Rolling In Left',
            ],
        ],
        [
            'label' => esc_html__( 'Rolling Bounce', 'mouno' ),
            'options' => [
                'wow rollingBounce ttb'  => 'Rolling Bouce TTB',
                'wow rollingBounce rtl'  => 'Rolling Bouce RTL',
                'wow rollingBounce btt'  => 'Rolling Bouce BTT',
                'wow rollingBounce ltr'  => 'Rolling Bouce LTR',
                'wow rollingIn right'    => 'Rolling Right',
                'wow rollingIn left'     => 'Rolling Left',
            ],
        ],


    ];
}
function mouno_exit_animation() {
    $options = [
        '' => 'None',
    ];
    return $options;
}

// Custom New
// Render link to elementor option
if(!function_exists('mouno_render_link_attributes')){
    function mouno_render_link_attributes($link) {
        $ouput = null;
        if (isset($link['url']) && !empty($link['url'])) {
            $ouput = 'href="' . esc_url($link['url']) . '"';
            if ($link['is_external']) {
                $ouput .= ' target="_blank"';
            }
            if ($link['nofollow']) {
                $ouput .= ' rel="nofollow"';
            }
            if (!empty($link['custom_attributes'])) {
                $custom_attributes = explode(',', $link["custom_attributes"]);
                foreach ($custom_attributes as $attr) {
                    list($key, $value) = explode('|', $attr);
                    $ouput .= ' ' . esc_attr($key) . '="' . esc_attr($value) . '"';
                }
            }
        }
        return $ouput;
    }
}

/*
    Animation options
*/
if (!function_exists('mouno_get_animation_options')) {
    function mouno_get_animation_options($args = []) {
        $prefix = isset($args['prefix']) && !empty($args['prefix']) ? $args['prefix'] . '_' : '';
        $condition = isset($args['condition']) ? $args['condition'] : [];
        $selector = isset($args['selector']) ? $args['selector'] : null;

        $options = [
            [
                'name' => $prefix . 'entrance_anim',
                'label' => esc_html__('Entrance Animation', 'mouno'),
                'type' => 'select',
                'groups' => mouno_entrance_anim_group(),
                'default' => '',
                'condition' => $condition,
            ],
            [
                'name' => $prefix . 'anim_duration',
                'label' => esc_html__('Animation Duration(ms)', 'mouno'),
                'type' => 'number',
                'condition' => array_merge(
                    [
                        $prefix . 'entrance_anim!' => '',
                    ],
                    $condition,
                ),
                'selectors' => [
                    $selector => 'animation-duration: {{VALUE}}ms; --webkit-animation-duration: {{VALUE}}ms;',
                ],
            ],
            [
                'name' => $prefix . 'anim_delay',
                'label' => esc_html__('Animation Delay(ms)', 'mouno'),
                'type' => 'number',
                'condition' => array_merge(
                    [
                        $prefix . 'entrance_anim!' => '',
                    ],
                    $condition,
                ),
                'selectors' => [
                    $selector => 'animation-delay: {{VALUE}}ms; --webkit-animation-delay: {{VALUE}}ms;',
                ],
            ],
        ];
        return $options;
    }
}


if (!function_exists('mouno_get_additional_animation_options')) {
    function mouno_get_additional_animation_options($args=[]) {
        $prefix = isset($args['prefix']) ? $args['prefix'].'_' : '';

        $options = [
            [
                'name' => $prefix . 'additional_entrance_anim',
                'label' => esc_html__('Additional Animation', 'mouno'),
                'type' => 'switcher',
                'default' => '',
            ],
            [
                'name' => $prefix . 'text_entrance_anim',
                'label' => esc_html__('Text Animation', 'mouno'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    '' => esc_html__('None', 'mouno'),
                    'split-text text-effect-rotate-in rotate-x visibility-hidden' => esc_html__('RotateX In', 'mouno'),
                    'split-text text-effect-rotate-in rotate-y visibility-hidden' => esc_html__('RotateY In', 'mouno'),
                    'split-text text-effect-slide-in slide-ttb visibility-hidden' => esc_html__('Slide TTB', 'mouno'),
                    'split-text text-effect-slide-in slide-btt visibility-hidden' => esc_html__('Slide BTT', 'mouno'),
                    'split-text text-effect-slide-in slide-ltr visibility-hidden' => esc_html__('Slide LTR', 'mouno'),
                    'split-text text-effect-slide-in slide-rtl visibility-hidden' => esc_html__('Slide RTL', 'mouno'),
                    'split-text text-effect-fade-in visibility-hidden' => esc_html__('Fade In', 'mouno'),
                    'split-text text-effect-fade-in fade-in-top visibility-hidden' => esc_html__('Fade In Top', 'mouno'),
                    'split-text text-effect-fade-in fade-in-right visibility-hidden' => esc_html__('Fade In Right', 'mouno'),
                    'split-text text-effect-fade-in fade-in-bottom visibility-hidden' => esc_html__('Fade In Bottom', 'mouno'),
                    'split-text text-effect-fade-in fade-in-left visibility-hidden' => esc_html__('Fade In Left', 'mouno'),
                    'split-text text-effect-reveal visibility-hidden' => esc_html__('Reveal', 'mouno'),
                ],
                'default' => '',
                'condition' => [
                    $prefix . 'additional_entrance_anim!' => '',
                ],
            ],
            [
                'name' => $prefix . 'anim_works_in',
                'label' => esc_html__('Animation Works In', 'mouno'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    '' => esc_html__('Lines', 'mouno'),
                    'split-into-word' => esc_html__('Words', 'mouno',),
                    'split-into-char' => esc_html__('Chars', 'mouno',),
                ],
                'default' => '',
                'condition' => [
                    $prefix . 'additional_entrance_anim!' => '',
                    $prefix . 'text_entrance_anim!' => '',
                ],
            ],
            [
                'name' => $prefix . 'gsap_stagger',
                'label' => esc_html__('Stagger', 'mouno'),
                'type' => 'number',
                'min' => 0,
                'max' => 1,
                'step' => 0.1,
                'condition' => [
                    $prefix . 'additional_entrance_anim!' => '',
                    $prefix . 'text_entrance_anim!' => '',
                ],
            ],
            [
                'name' => $prefix . 'gsap_duration',
                'label' => esc_html__('Duration', 'mouno'),
                'type' => 'number',
                'min' => 0,
                'max' => 20,
                'condition' => [
                    $prefix . 'additional_entrance_anim!' => '',
                    $prefix . 'text_entrance_anim!' => '',
                ],
            ],
            [
                'name' => $prefix . 'gsap_delay',
                'label' => esc_html__('Delay', 'mouno'),
                'type' => 'number',
                'min' => 0,
                'max' => 20,
                'condition' => [
                    $prefix . 'additional_entrance_anim!' => '',
                    $prefix . 'text_entrance_anim!' => '',
                ],
            ],
        ];

        return $options;
    }
}

// Element Position Options
if(!function_exists('mouno_position_options')) {
    function mouno_position_options($args = []) {
        $prefix = isset($args['prefix']) ? $args['prefix'].'_' : '';
        $condition = isset($args['condition']) ? $args['condition'] : [];
        $selector = isset($args['selector']) ? $args['selector'] : '';
        $options = [
            // [

            // ]
            [
                'name' => $prefix.'popover_toggle_position',
                'label' => esc_html__( 'Position', 'mouno' ),
                'type' => 'popover_toggle',
                'default' => '',
                'condition' => $condition,
            ],
            [
                'name' => $prefix.'pxl_start_popover',
                'type' => 'pxl_start_popover',
            ],
            [
                'name' => $prefix.'offset_t',
                'label' => esc_html__('Top', 'mouno' ),
                'type' => 'slider',
                'size_units' => [ 'px', 'custom' ],
                'control_type' => 'responsive',
                'range' => [
                    'px' => [
                        'min' => 1,
                        'max' => 1000,
                    ],
                ],
                'selectors' => [
                    $selector => 'top: {{SIZE}}{{UNIT}};',
                ],
                'condition' => $condition,
            ],
            [
                'name' => $prefix.'offset_r' ,
                'label' => esc_html__('Right', 'mouno' ),
                'type' => 'slider',
                'size_units' => [ 'px', 'custom' ],
                'control_type' => 'responsive',
                'range' => [
                    'px' => [
                        'min' => 1,
                        'max' => 1000,
                    ],
                ],
                'selectors' => [
                    $selector => 'right: {{SIZE}}{{UNIT}};',
                ],
                'condition' => $condition,
            ],
            [
                'name' => $prefix.'offset_b' ,
                'label' => esc_html__('Bottom', 'mouno' ),
                'type' => 'slider',
                'size_units' => [ 'px', 'custom' ],
                'control_type' => 'responsive',
                'range' => [
                    'px' => [
                        'min' => 1,
                        'max' => 1000,
                    ],
                ],
                'selectors' => [
                    $selector => 'bottom: {{SIZE}}{{UNIT}};',
                ],
                'condition' => $condition,
            ],
            [
                'name' => $prefix.'offset_l' ,
                'label' => esc_html__('Left', 'mouno' ),
                'type' => 'slider',
                'size_units' => [ 'px', 'custom' ],
                'control_type' => 'responsive',
                'range' => [
                    'px' => [
                        'min' => 1,
                        'max' => 1000,
                    ],
                ],
                'selectors' => [
                    $selector => 'left: {{SIZE}}{{UNIT}};',
                ],
                'condition' => $condition,
            ],
            [
                'name' => $prefix.'pxl_end_popover',
                'type' => 'pxl_end_popover',
            ],
        ];
        return $options;
    }
}

// Render Post Grid
function mouno_render_post_grid($grid_args = []) {
    extract($grid_args);
    if ($filter == 'enable'): ?>
        <div class="pxl-grid-filter pxl-filter-wrapper <?php echo esc_attr($filter_type) ?>">
            <button class="filter-item active" data-filter="*"></button>
            <?php foreach ($categories as $category): ?>
                <?php 
                    $category_arr = explode('|', $category); 
                    $term = get_term_by('slug',$category_arr[0], $category_arr[1]); 
                ?>
                <button class="filter-item" data-filter="<?php echo esc_attr('.'.$term->slug); ?>">
                    <?php echo esc_html($term->name); ?>
                </button>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
    <div class="<?php echo esc_attr($grid_class); ?>">
        <?php mouno_get_post_grid($posts, $load_more); ?>
        <?php if(!is_null($grid_sizer)) : ?>
            <div class="grid-sizer <?php echo esc_attr($grid_sizer); ?>"></div>
        <?php endif; ?>
    </div>
    <?php if ($pagination == 'pagination') : ?>
        <div class="pxl-grid-pagination">
            <?php mouno()->page->get_pagination($query, true); ?>
        </div>
    <?php endif; 
    if (!empty($next_link) && $pagination === 'loadmore') : ?>
        <div class="pxl-load-more-wrapper <?php echo esc_attr($divider_el ?? ''); ?>">
            <button type="button" class="btn pxl-load-more-button <?php echo esc_attr($load_more_style); ?>">
                <?php if($load_more_style === 'load-more-button-default') : ?>
                    <span class="pxl-load-more-icon pxl-btn-icon">
                        <?php pxl_print_html($load_more_icon); ?>
                    </span>
                <?php else: ?>
                    <span class="pxl-load-more-icon pxl-btn-icon icon-duplicated">
                        <?php pxl_print_html($load_more_icon); ?>
                    </span>
                    <span class="pxl-load-more-text pxl-btn-text">
                        <?php echo esc_html($load_more_text); ?>
                    </span>
                    <span class="pxl-load-more-icon pxl-btn-icon icon-main">
                        <?php pxl_print_html($load_more_icon); ?>
                    </span>
                <?php endif; ?>
                <!-- <span class="pxl-load-more-loader"></span> -->
            </button>
        </div>
    <?php endif;
}

// Get Icon Service
function mouno_get_service_icon($post_id) {
    global $wp_filesystem;
    if(!isset($post_id) || empty($post_id)) return;
    $icon_content = '';
    $icon_type = get_post_meta($post_id, 'service_icon_type', true);
    $icon_normal = get_post_meta($post_id, 'service_icon_font', '');
    $icon_img = get_post_meta($post_id, 'service_icon_img', true); 

    if (!empty($icon_normal) && $icon_type === 'icon') {
        $icon_normal = implode(' ', $icon_normal);
        $icon_content = '<i class="' . $icon_normal . '"></i>';
        return $icon_content;
    }

    if (!empty($icon_img) && $icon_type === 'image') {
        if((pathinfo($icon_img['url'], PATHINFO_EXTENSION) === 'svg')) {
            $icon_urls = explode('uploads', $icon_img['url']);
            $upload_dir = wp_upload_dir();
            $icon_path = $upload_dir['basedir']. $icon_urls[1] ;
            $icon_content = $wp_filesystem->get_contents( $icon_path );
        }else {
            $icon_content = mouno_get_image_by_size([
                'img_id' => $icon_img['id'] ?? '',
                'img_dimension' => 'full',
                'attr' => [
                    'class' => 'service-icon',
                ],
            ]);
        }
        
    }
    return $icon_content;
}

// Get team social 
function mouno_get_team_social($post_id = null, $class = null) {
    if(is_null($post_id)) return;
    $social = get_post_meta($post_id, 'team_social', true);
    $output = null;
    if(!empty($social) && is_array($social)) {
        foreach($social as $key => $value) {
            switch($value) {
                case '_facebook' :
                    $output .= '<span class="pxl-social-item" >
                                    <a class="pxl-social-link '.$class.'" href="'.get_post_meta($post_id, 'link_social_facebook', true).'">
                                        <svg width="12" height="21" viewBox="0 0 12 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M10.8405 11.5278H7.9108V20.2778H4.00455V11.5278H0.801429V7.93409H4.00455V5.16065C4.00455 2.03565 5.87955 0.277839 8.73111 0.277839C10.0983 0.277839 11.5436 0.551276 11.5436 0.551276V3.63721H9.94205C8.37955 3.63721 7.9108 4.57471 7.9108 5.59034V7.93409H11.3874L10.8405 11.5278Z" fill="currentcolor"/>
                                        </svg>
                                    </a>
                                </span>';
                    break;
                case '_twitter' :
                    $output .= '<span class="pxl-social-item">
                                    <a class="pxl-social-link '.$class.'" href="'.get_post_meta($post_id, 'link_social_twitter', true).'">
                                        <svg width="12" height="10" viewBox="0 0 12 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M9.16305 0.0498047H10.8499L7.1649 4.24355L11.5 9.9498H8.1054L5.44725 6.48865L2.4052 9.9498H0.7167L4.65855 5.46455L0.5 0.0498047H3.9804L6.3839 3.2134L9.16305 0.0498047ZM8.57125 8.9444H9.50625L3.4722 1.0024H2.469L8.57125 8.9444Z" fill="currentcolor"/>
                                        </svg>
                                    </a>
                                </span>';
                    break;
                case '_instagram' :
                    $output .= '<span class="pxl-social-item">
                                    <a class="pxl-social-link '.$class.'" href="'.get_post_meta($post_id, 'link_social_instagram', true).'">
                                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M10.2215 5.47506C12.8465 5.47506 15.0132 7.64172 15.0132 10.2667C15.0132 12.9334 12.8465 15.0584 10.2215 15.0584C7.55485 15.0584 5.42985 12.9334 5.42985 10.2667C5.42985 7.64172 7.55485 5.47506 10.2215 5.47506ZM10.2215 13.3917C11.9299 13.3917 13.3049 12.0167 13.3049 10.2667C13.3049 8.55839 11.9299 7.18339 10.2215 7.18339C8.47152 7.18339 7.09652 8.55839 7.09652 10.2667C7.09652 12.0167 8.51318 13.3917 10.2215 13.3917ZM16.3049 5.30839C16.3049 5.93339 15.8049 6.43339 15.1799 6.43339C14.5549 6.43339 14.0549 5.93339 14.0549 5.30839C14.0549 4.68339 14.5549 4.18339 15.1799 4.18339C15.8049 4.18339 16.3049 4.68339 16.3049 5.30839ZM19.4715 6.43339C19.5549 7.97506 19.5549 12.6001 19.4715 14.1417C19.3882 15.6417 19.0549 16.9334 17.9715 18.0584C16.8882 19.1417 15.5549 19.4751 14.0549 19.5584C12.5132 19.6417 7.88818 19.6417 6.34652 19.5584C4.84652 19.4751 3.55485 19.1417 2.42985 18.0584C1.34652 16.9334 1.01318 15.6417 0.92985 14.1417C0.846517 12.6001 0.846517 7.97506 0.92985 6.43339C1.01318 4.93339 1.34652 3.60006 2.42985 2.51672C3.55485 1.43339 4.84652 1.10006 6.34652 1.01672C7.88818 0.93339 12.5132 0.93339 14.0549 1.01672C15.5549 1.10006 16.8882 1.43339 17.9715 2.51672C19.0549 3.60006 19.3882 4.93339 19.4715 6.43339ZM17.4715 15.7667C17.9715 14.5584 17.8465 11.6417 17.8465 10.2667C17.8465 8.93339 17.9715 6.01672 17.4715 4.76672C17.1382 3.97506 16.5132 3.30839 15.7215 3.01672C14.4715 2.51672 11.5549 2.64172 10.2215 2.64172C8.84652 2.64172 5.92985 2.51672 4.72152 3.01672C3.88818 3.35006 3.26318 3.97506 2.92985 4.76672C2.42985 6.01672 2.55485 8.93339 2.55485 10.2667C2.55485 11.6417 2.42985 14.5584 2.92985 15.7667C3.26318 16.6001 3.88818 17.2251 4.72152 17.5584C5.92985 18.0584 8.84652 17.9334 10.2215 17.9334C11.5549 17.9334 14.4715 18.0584 15.7215 17.5584C16.5132 17.2251 17.1799 16.6001 17.4715 15.7667Z" fill="currentcolor"/>
                                        </svg>
                                    </a>
                                </span>';
                    break;
                case '_pinterest' :
                    $output .= '<span class="pxl-social-item">
                                    <a class="pxl-social-link '.$class.'" href="'.get_post_meta($post_id, 'link_social_pinterest', true).'">
                                        <svg width="16" height="21" viewBox="0 0 16 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M8.92789 0.801032C12.5998 0.801032 15.9591 3.34009 15.9591 7.20728C15.9591 10.8401 14.0841 14.9026 9.94352 14.9026C8.92789 14.9026 7.71695 14.3948 7.20914 13.4963C6.34977 17.012 6.38883 17.5588 4.43571 20.2541C4.24039 20.3323 4.27946 20.3323 4.16227 20.176C4.08414 19.4338 4.00602 18.7307 4.00602 17.9885C4.00602 15.6057 5.09977 12.1292 5.64664 9.82447C5.33414 9.19947 5.25602 8.49634 5.25602 7.83228C5.25602 4.70728 8.92789 4.23853 8.92789 6.81665C8.92789 8.34009 7.8732 9.7854 7.8732 11.2698C7.8732 12.2463 8.73258 12.9495 9.70914 12.9495C12.4045 12.9495 13.2248 9.08228 13.2248 7.01197C13.2248 4.23853 11.2716 2.71509 8.57633 2.71509C5.49039 2.71509 3.10758 4.94166 3.10758 8.06665C3.10758 9.59009 4.04508 10.3713 4.04508 10.7229C4.04508 11.0354 3.81071 12.0901 3.42008 12.0901C2.48258 12.0901 0.959145 10.5276 0.959145 7.79322C0.959145 3.45728 4.90446 0.801032 8.92789 0.801032Z" fill="currentcolor"/>
                                        </svg>
                                    </a>
                                </span>';
                    break;
                case '_youtube' :
                    $output .= '<span class="pxl-social-item">
                                    <a class="pxl-social-link '.$class.'" href="'.get_post_meta($post_id, 'link_social_pinterest', true).'">
                                        <svg width="23" height="17" viewBox="0 0 23 17" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M22.4302 2.80839C22.9302 4.55839 22.9302 8.30839 22.9302 8.30839C22.9302 8.30839 22.9302 12.0167 22.4302 13.8084C22.1802 14.8084 21.3885 15.5584 20.4302 15.8084C18.6385 16.2667 11.5552 16.2667 11.5552 16.2667C11.5552 16.2667 4.43018 16.2667 2.63851 15.8084C1.68018 15.5584 0.888509 14.8084 0.638509 13.8084C0.138509 12.0167 0.138509 8.30839 0.138509 8.30839C0.138509 8.30839 0.138509 4.55839 0.638509 2.80839C0.888509 1.80839 1.68018 1.01672 2.63851 0.766723C4.43018 0.266723 11.5552 0.266723 11.5552 0.266723C11.5552 0.266723 18.6385 0.266723 20.4302 0.766723C21.3885 1.01672 22.1802 1.80839 22.4302 2.80839ZM9.22184 11.6834L15.1385 8.30839L9.22184 4.93339V11.6834Z" fill="currentcolor"/>
                                        </svg>
                                    </a>
                                </span>';
                    break;
                case '_linkedin' :
                    break;
            }
        }
    }
    return $output;
}
// Image Dimension Options
if(!function_exists('image_dimension_options')) {
    function image_dimension_options($args = []) {
        $condition = isset($args['condition']) ? $args['condition'] : [];
        $options = [
            array(
                'name' => 'img_dimension',
                'label' => esc_html__('Image Dimension', 'mouno'),
                'type' => 'select',
                'options' => [
                    ''              => esc_html__('Default', 'mouno'),
                    'thumbnail'     => esc_html__('Thumbnail', 'mouno'),
                    'thumb'         => esc_html__('Thumb (Alias of Thumbnail)', 'mouno'),
                    'medium'        => esc_html__('Medium', 'mouno'),
                    'medium_large'  => esc_html__('Medium Large', 'mouno'),
                    'large'         => esc_html__('Large', 'mouno'),
                    'full'          => esc_html__('Full (Original)', 'mouno'),
                    'custom'        => esc_html__('Custom', 'mouno'),
                ],
                'default' => '',
                'condition' => $condition,
            ),
            array(
                'name' => 'custom_img_dimension',
                'label' => esc_html__( 'Dimension Custom', 'mouno' ),
                'type' => 'image_dimensions',
                'description' => esc_html__( 'Crop the original image size to any custom size. Set custom width or height to keep the original size ratio.', 'mouno' ),
                'condition' => array_merge(
                    [
                        'img_dimension' => 'custom',
                    ],
                    $condition
                ),
            ),
        ];
        return $options;
    }
}

// Grid Options
function grid_controls_options($args = []) {
    $filter = isset($args['filter']) ? $args['filter'] : false;
    $condition = isset($args['condition']) ? $args['condition'] : [];
    $selectors = isset($args['selectors']) ? $args['selectors'] : null;
    $options = [];
    if($filter) {
        $options = [
            array(
                'name' => 'filter',
                'label' => esc_html__('Filter', 'mouno' ),
                'type' => 'select',
                'default' => 'disable',
                'options' => [
                    'enable'  => esc_html__('Enable', 'mouno' ),
                    'disable' => esc_html__('Disable', 'mouno' ),
                ],
            ),
            array(
                'name'    => 'filter_type',
                'label'   => esc_html__('Filter Type', 'mouno' ),
                'type'    => 'select',
                'default' => 'normal',
                'options' => [
                    'normal'  => esc_html__('Normal', 'mouno' ),
                    'ajax' => esc_html__('Ajax', 'mouno' ),
                ],
                'condition' => [
                    'filter' => 'enable',
                ],
            ),
            array(
                'name' => 'filter_divider',
                'type' => 'divider',
            ),
        ];
    }
    $options = array_merge(
        array(
            array(
                'name' => 'grid_masonry',
                'label' => esc_html__('Grid Masonry', 'mouno'),
                'type' => 'select',
                'default' => '',
                'options' => [
                    ''        => esc_html__('None', 'mouno'),
                    'masonry' => esc_html__('Mansory', 'mouno'),
                    'fitRows' => esc_html__('Fit Rows', 'mouno'),
                ],
                'description' => esc_html__('Use fit rows for layouts with the same height but different width', 'mouno'),
            ),
            array(
                'name' => 'grid_sizer_width',
                'label' => esc_html__('Grid Sizer Width', 'mouno' ),
                'type' => 'slider',
                'separator' => 'before',
                'control_type' => 'responsive',
                'size_units' => ['%', 'custom'],
                'default' => [
                    'size' => '50',
                    'unit' => '%',
                ],
                'range' => [
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .pxl-grid .pxl-grid-inner .grid-sizer' => 'flex: 0 0 {{SIZE}}{{UNIT}}; max-width: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'grid_masonry' => 'fitRows', 
                ],
            ),
            array(
                'name' => 'masonry_items',
                'label' => esc_html__('Masonry Items', 'mouno'),
                'type' => 'repeater',
                'condition' => [
                    'grid_masonry!' => '',
                ],
                'controls' => [
                    array(
                        'name' => 'img_dimension_m',
                        'label' => esc_html__('Image Dimension', 'mouno'),
                        'type' => 'select',
                        'options' => [
                            'thumbnail'     => esc_html__('Thumbnail', 'mouno'),
                            'thumb'         => esc_html__('Thumb (Alias of Thumbnail)', 'mouno'),
                            'medium'        => esc_html__('Medium', 'mouno'),
                            'medium_large'  => esc_html__('Medium Large', 'mouno'),
                            'large'         => esc_html__('Large', 'mouno'),
                            'full'          => esc_html__('Full (Original)', 'mouno'),
                            'custom'        => esc_html__('Custom', 'mouno'),
                        ],
                        'default' => 'full',
                    ),
                    array(
                        'name' => 'custom_img_dimension_m',
                        'label' => esc_html__( 'Dimension Custom', 'mouno' ),
                        'type' => 'image_dimensions',
                        'description' => esc_html__( 'Crop the original image size to any custom size. Set custom width or height to keep the original size ratio.', 'mouno' ),
                        'condition' => array(
                            'img_dimension_m' => 'custom',
                        ),
                    ),
                    array(
                        'name' => 'column_masonry',
                        'label' => esc_html__('Columm', 'mouno' ),
                        'type' => 'slider',
                        'separator' => 'before',
                        'control_type' => 'responsive',
                        'size_units' => ['%', 'px', 'custom'],
                        'default' => [
                            'size' => '50',
                            'unit' => '%',
                        ],
                        'range' => [
                            '%' => [
                                'min' => 0,
                                'max' => 100,
                            ],
                        ],
                        'selectors' => [
                            '{{WRAPPER}} .pxl-grid .pxl-grid-item{{CURRENT_ITEM}}' => 'flex: 0 0 {{SIZE}}{{UNIT}}; max-width: {{SIZE}}{{UNIT}};',
                        ],
                    ),
                    array(
                        'name' => 'height_masonry',
                        'label' => esc_html__('Height', 'mouno' ),
                        'type' => 'slider',
                        'separator' => 'before',
                        'control_type' => 'responsive',
                        'size_units' => ['%', 'px', 'custom'],
                        'default' => [
                            'size' => 'auto',
                            'unit' => 'custom',
                        ],
                        'selectors' => [
                            '{{WRAPPER}} .pxl-grid .pxl-grid-item{{CURRENT_ITEM}}' => 'height: {{SIZE}}{{UNIT}};',
                        ],
                    ),
                ],
            ),
            array(
                'name' => 'divider_grid_1',
                'type' => 'divider',
            ),
        ),
        $options,
        array(
            array(
                'name' => 'grid_controls',
                'control_type' => 'tab',
                'tabs' => [
                    [
                        'name' => 'grid_options',
                        'label' => esc_html__('Options', 'mouno' ),
                        'type' => 'tab',
                        'controls' => array(
                            array(
                                'name' => 'grid_justify_content',
                                'label' => esc_html__('Justify Content', 'mouno'),
                                'type' => 'choose',
                                'control_type' => 'responsive',
                                'options' => array(
                                    'start' => [
                                        'title' => esc_html__('Start', 'mouno' ),
                                        'icon' => 'eicon-justify-start-h',
                                    ],
                                    'center' => [
                                        'title' => esc_html__('Center', 'mouno' ),
                                        'icon' => 'eicon-justify-center-h',
                                    ],
                                    'end' => [
                                        'title' => esc_html__('End', 'mouno' ),
                                        'icon' => 'eicon-justify-end-h',
                                    ],
                                ),
                                'selectors' => [
                                    '{{WRAPPER}} .pxl-grid .pxl-grid-inner' => 'justify-content: {{VALUE}};'
                                ],
                            ),
                            array(
                                'name' => 'spacing_inline',
                                'label' => esc_html__('Spacing Inline(px)', 'mouno' ),
                                'type' => 'slider',
                                'control_type' => 'responsive',
                                'size_units' => ['px'],
                                'selectors' => [
                                    '{{WRAPPER}} .pxl-grid .pxl-grid-inner' => '--pxl-spacing-inline: {{SIZE}}{{UNIT}};',
                                ],
                            ),
                            array(
                                'name' => 'spacing_block',
                                'label' => esc_html__('Spacing Block(px)', 'mouno' ),
                                'type' => 'slider',
                                'control_type' => 'responsive',
                                'size_units' => ['px'],
                                'selectors' => [
                                    '{{WRAPPER}} .pxl-grid .pxl-grid-inner' => '--pxl-spacing-block: {{SIZE}}{{UNIT}};',
                                ],
                            ),
                            array(
                                'name' => 'grid_pagination',
                                'label' => esc_html__('Pagination', 'mouno' ),
                                'type' => 'select',
                                'separator' => 'before',
                                'default' => '',
                                'options' => [
                                    ''     => esc_html__('Disable', 'mouno' ),
                                    'pagination' => esc_html__('Pagination', 'mouno' ),
                                    'loadmore'  => esc_html__('Loadmore', 'mouno' ),
                                ],
                            ),
                            array(
                                'name' => 'pagination_justify_content',
                                'label' => esc_html__('Justify Content', 'mouno'),
                                'type' => 'choose',
                                'control_type' => 'responsive',
                                'options' => array(
                                    'start' => [
                                        'title' => esc_html__('Start', 'mouno' ),
                                        'icon' => 'eicon-justify-start-h',
                                    ],
                                    'center' => [
                                        'title' => esc_html__('Center', 'mouno' ),
                                        'icon' => 'eicon-justify-center-h',
                                    ],
                                    'end' => [
                                        'title' => esc_html__('End', 'mouno' ),
                                        'icon' => 'eicon-justify-end-h',
                                    ],
                                ),
                                'selectors' => [
                                    '{{WRAPPER}} .pxl-grid .pxl-grid-pagination .pxl-pagination-wrap' => 'justify-content: {{VALUE}};'
                                ],
                                'condition' => [
                                    'grid_pagination' => 'pagination',
                                ],
                            ),
                            array(
                                'name' => 'pagination_gap',
                                'label' => esc_html__('Gap', 'mouno'),
                                'type' => 'slider',
                                'size_units' => ['px', 'custom'],
                                'control_type' => 'responsive',
                                'range' => [
                                    'px' => [
                                        'min' => 0,
                                        'max' => 1000,
                                    ],
                                ],
                                'selectors' => [
                                    '{{WRAPPER}} .pxl-grid .pxl-grid-pagination .pxl-pagination-wrap' => "gap: {{SIZE}}{{UNIT}};",
                                ],
                                'condition' => [
                                    'grid_pagination' => 'pagination',
                                ],
                            ),
                            array(
                                'name' => 'pagination_spacing',
                                'label' => esc_html__('Spacing Top', 'mouno'),
                                'type' => 'slider',
                                'size_units' => ['px', 'custom'],
                                'control_type' => 'responsive',
                                'range' => [
                                    'px' => [
                                        'min' => 0,
                                        'max' => 1000,
                                    ],
                                ],
                                'selectors' => [
                                    '{{WRAPPER}} .pxl-grid .pxl-grid-pagination' => "margin-top: {{SIZE}}{{UNIT}};",
                                ],
                                'condition' => [
                                    'grid_pagination' => 'pagination',
                                ],
                            ),
                            array(
                                'name' => 'load_more_style',
                                'label' => esc_html__('Load More Style', 'mouno'),
                                'type' => 'select',
                                'options' => [
                                    'load-more-button-default' => esc_html__('Default', 'mouno'),
                                    'pxl-btn-split'            => esc_html__('Split Button', 'mouno'),
                                ],
                                'default' => 'load-more-button-default',
                                'condition' => [
                                    'grid_pagination' => 'loadmore',
                                ],                            
                            ),
                            array(
                                'name' => 'btn_load_more_justify_content',
                                'label' => esc_html__('Justify Content', 'mouno'),
                                'type' => 'choose',
                                'control_type' => 'responsive',
                                'options' => array(
                                    'start' => [
                                        'title' => esc_html__('Start', 'mouno' ),
                                        'icon' => 'eicon-justify-start-h',
                                    ],
                                    'center' => [
                                        'title' => esc_html__('Center', 'mouno' ),
                                        'icon' => 'eicon-justify-center-h',
                                    ],
                                    'end' => [
                                        'title' => esc_html__('End', 'mouno' ),
                                        'icon' => 'eicon-justify-end-h',
                                    ],
                                ),
                                'condition' => [
                                    'grid_pagination' => 'loadmore',
                                ],
                                'selectors' => [
                                    '{{WRAPPER}} .pxl-button-wrapper' => 'justify-content: {{VALUE}};'
                                ],
                            ),
                            array(
                                'name' => 'load_more_icon',
                                'label' => esc_html__('Load More Icon', 'mouno'),
                                'type' => 'icons',
                                'fa4compatibility' => 'icon',
                                'default' => [
                                    'value' => [
                                        'url' => content_url('/uploads/2025/02/arrow-long-down.svg'),
                                        'id'  => 10135
                                    ],
                                    'library' => 'svg',
                                ],
                                'condition' => [
                                    'grid_pagination' => 'loadmore',
                                ],
                            ),
                            array(
                                'name' => 'load_more_text',
                                'type' => 'text',
                                'label' => esc_html__('Load More Text', 'mouno'),
                                'condition' => [
                                    'grid_pagination' => 'loadmore',
                                    'loadmore_style'  => 'pxl-btn-split',
                                ],
                            ),
                            array(
                                'name' => 'loadmore_spacing',
                                'label' => esc_html__('Load More Spacing', 'mouno' ),
                                'type' => 'slider',
                                'control_type' => 'responsive',
                                'size_units' => ['px', 'custom'],
                                'range' => [
                                    'px' => [
                                        'max' => 1000,
                                    ],
                                ],
                                'selectors' => [
                                    '{{WRAPPER}} .pxl-grid .pxl-load-more-wrapper' => 'margin-top: {{SIZE}}{{UNIT}};',
                                ],
                                'condition' => [
                                    'grid_pagination' => 'loadmore',
                                ],
                            ),
                            array(
                                'name' => 'show_divider_el',
                                'label' => esc_html__('Divider', 'mouno'),
                                'type' => 'switcher',
                                'separator' => 'before',
                                'default' => '',
                                'condition' => [
                                    'grid_pagination' => 'loadmore',
                                ],
                            ),
                            array(
                                'name' => 'divider_el_color',
                                'type' => \Elementor\Group_Control_Background::get_type(),
                                'control_type' => 'group',
                                'types' => [ 'classic', 'gradient' ],
                                'selector' => '{{WRAPPER}} .pxl-grid .pxl-load-more-wrapper:before, {{WRAPPER}} .pxl-grid .pxl-load-more-wrapper:after',
                                'condition' => [
                                    'show_divider_el!' => '',
                                    'grid_pagination' => 'loadmore',
                                ],
                            ),
                        ),
                    ],
                    [
                        'name' => 'grid_responsive',
                        'label' => esc_html__('Responsive', 'mouno' ),
                        'type' => 'tab',
                        'condition' => [
                            'layout_type' => 'grid',
                        ],
                        'controls' => [
                            array(
                                'name' => 'column_xs',
                                'label' => esc_html__('Column(<576px)', 'mouno' ),
                                'type' => 'select',
                                'default' => '',
                                'options' => [
                                    ''  => 'Default',
                                    '1' => '1',
                                    '2' => '2',
                                    '3' => '3',
                                    '4' => '4',
                                    '6' => '6',
                                ],
                            ),
                            array(
                                'name' => 'column_sm',
                                'label' => esc_html__('Column(≥576px)', 'mouno' ),
                                'type' => 'select',
                                'default' => '',
                                'options' => [
                                    ''  => 'Default',
                                    '1' => '1',
                                    '2' => '2',
                                    '3' => '3',
                                    '4' => '4',
                                    '6' => '6',
                                ],
                            ),
                            array(
                                'name' => 'column_md',
                                'label' => esc_html__('Column(≥768px)', 'mouno' ),
                                'type' => 'select',
                                'default' => '',
                                'options' => [
                                    ''  => 'Default',
                                    '1' => '1',
                                    '2' => '2',
                                    '3' => '3',
                                    '4' => '4',
                                    '6' => '6',
                                ],
                            ),
                            array(
                                'name' => 'column_lg',
                                'label' => esc_html__('Column(≥992px)', 'mouno' ),
                                'type' => 'select',
                                'default' => '',
                                'options' => [
                                    ''  => 'Default',
                                    '1' => '1',
                                    '2' => '2',
                                    '3' => '3',
                                    '4' => '4',
                                    '6' => '6',
                                ],
                            ),
                            array(
                                'name' => 'column_xl',
                                'label' => esc_html__('Column(≥1200px)', 'mouno' ),
                                'type' => 'select',
                                'default' => '',
                                'options' => [
                                    ''  => 'Default',
                                    '1' => '1',
                                    '2' => '2',
                                    '3' => '3',
                                    '4' => '4',
                                    '5' => '5',
                                    '6' => '6',
                                ],
                            ),
                            array(
                                'name' => 'column_xxl',
                                'label' => esc_html__('Column(≥1400px)', 'mouno' ),
                                'type' => 'select',
                                'default' => '',
                                'options' => [
                                    ''  => 'Default',
                                    '1' => '1',
                                    '2' => '2',
                                    '3' => '3',
                                    '4' => '4',
                                    '5' => '5',
                                    '6' => '6',
                                ],
                            ),
                        ],
                    ],
                ],
            )
        ),
    );
    return $options;
}

// Swiper Options
function swiper_controls_options($args = []) {
    $condition = isset($args['condition']) ? $args['condition'] : [];
    return array(
        'name' => 'swiper_controls',
        'control_type' => 'tab',
        'tabs' => [
            [
                'name' => 'swiper_options',
                'label' => esc_html__('Options', 'mouno' ),
                'type' => 'tab',
                'condition' => [
                    'layout_type' => 'carousel',
                ],
                'controls' => [  
                    array(
                        'name' => 'effect',
                        'label' => esc_html__('Effect', 'mouno' ),
                        'type' => 'select',
                        'options' => array(
                            'slide' => esc_html__('Slide', 'mouno' ),
                            'fade' => esc_html__('Fade', 'mouno' ),
                            'cube' => esc_html__('Cube', 'mouno' ),
                            'coverflow' => esc_html__('Coverflow', 'mouno' ),
                            'flip' => esc_html__('Flip', 'mouno' ),
                        ),
                        'default' => 'slide',
                    ),
                    array(
                        'name' => 'swiper_divider',
                        'type' => 'divider',
                    ),
                    array(
                        'name' => 'allow_touch_move',
                        'label' => esc_html__('Allow Touch Move', 'mouno'),
                        'type' => 'switcher',
                        'default' => 'true',
                    ),
                    array(
                        'name' => 'mousewheel',
                        'label' => esc_html__('Mousewheel', 'mouno'),
                        'type' => 'switcher',
                        'default' => '',
                    ),
                    array(
                        'name' => 'autoplay',
                        'label' => esc_html__('Autoplay', 'mouno'),
                        'type' => 'switcher',
                        'default' => '',
                    ),
                    array(
                        'name' => 'disable_on_interaction',
                        'label' => esc_html__('Pause on Interaction', 'mouno'),
                        'type' => 'switcher',
                        'default' => '',
                        'condition' => [
                            'autoplay!' => '',
                        ],
                    ),
                    array(
                        'name' => 'delay',
                        'label' => esc_html__('Delay', 'mouno'),
                        'type' => 'number',
                        'default' => 3000,
                        'condition' => [
                            'autoplay!' => '',
                        ],
                    ),
                    array(
                        'name' => 'loop',
                        'label' => esc_html__('Infinite Loop', 'mouno'),
                        'type' => 'switcher',
                        'default' => '',
                    ),
                    array(
                        'name' => 'speed',
                        'label' => esc_html__('Animation Speed', 'mouno'),
                        'type' => 'number',
                        'default' => 300,
                    ),
                    array(
                        'name' => 'space_between',
                        'label' => esc_html__('Space Between', 'mouno'),
                        'type' => 'number',
                        'default' => 0,
                        'condition' => [
                            'effect!' => 'fade',
                        ],
                    ),
                    array(
                        'name' => 'swiper_pagination',
                        'type' => 'select',
                        'label' => esc_html__('Pagination', 'mouno'),
                        'separator' => 'before',
                        'options' => [
                            ''            => esc_html__('None', 'mouno'),
                            'bullets'     => esc_html__('Bullets', 'mouno'),
                            'progressbar' => esc_html__('Progressbar', 'mouno'),
                            'fraction'    => esc_html__('Fraction', 'mouno'),
                        ],
                    ),
                    array(
                        'name' => 'swiper_navigation',
                        'label' => esc_html__('Navigation', 'mouno'),
                        'type' => 'switcher',
                        'default' => '',
                    ),
                    array(
                        'name' => 'use_swiper_nav_widget',
                        'label' => esc_html__('Use Navigation Widget', 'mouno'),
                        'type' => 'switcher',
                        'default' => '',
                        'condition' => [
                            'swiper_navigation!' => '',
                        ],
                    ),
                    array(
                        'name' => 'nav_id',
                        'type' => 'text',
                        'label' => esc_html__('Enter ID Your Navigation', 'mouno'),
                        'condition' => [
                            'swiper_navigation!' => '',
                            'use_swiper_nav_widget!' => ''
                        ],
                        'description' => esc_html__('You need to enter the unique ID you created from the navigation carousel widget, and the navigation with this ID will function as a navigation carousel.', 'mouno'),
                    ),
                    array(
                        'name' => 'swiper_nav_spacing',
                        'label' => esc_html__('Spacing', 'mouno'),
                        'type' => 'slider',
                        'control_type' => 'responsive',
                        'size_units' => ['px', 'custom'],
                        'range' => [
                            'px' => [
                                'min' => 0,
                                'max' => 1000,
                            ],
                        ],
                        'selectors' => [
                            '{{WRAPPER}} .swiper-navigation' => 'margin-top: {{SIZE}}{{UNIT}};',
                        ],
                    ),
                    array(
                        'name' => 'nav_btn_style',
                        'label' => esc_html__('Button Style', 'mouno' ),
                        'type' => 'select',
                        'options' => array(
                            'swiper-button-default' => esc_html__('Default', 'mouno' ),
                            'swiper-button-primary' => esc_html__('Primary', 'mouno' ),
                        ),
                        'default' => 'swiper-button-default',
                        'condition' => [
                            'swiper_navigation!' => '',
                            'use_swiper_nav_widget' => ''
                        ],
                    ),
                    array(
                        'name' => 'nav_btn_icon_prev',
                        'label' => esc_html__('Button Icon Prev', 'mouno' ),
                        'type' => 'icons',
                        'fa4compatibility' => 'icon',
                        'default' => [
                            'value' => [
                                'url' => content_url('/uploads/2024/11/arrow-long-left.svg'),
                                'id' => 1046,
                            ],
                            'library' => 'svg',
                        ],
                        'condition' => [
                            'swiper_navigation!' => '',
                            'use_swiper_nav_widget' => ''
                        ],
                    ),
                    array(
                        'name' => 'nav_btn_icon_next',
                        'label' => esc_html__('Button Icon Next', 'mouno' ),
                        'type' => 'icons',
                        'fa4compatibility' => 'icon',
                        'default' => [
                            'value' => [
                                'url' => content_url('/uploads/2024/11/arrow-long-right.svg'),
                                'id' => 1047,
                            ],
                            'library' => 'svg',
                        ],
                        'condition' => [
                            'swiper_navigation!' => '',
                            'use_swiper_nav_widget' => ''
                        ],
                    ),
                ],
            ],
            [
                'name' => 'swiper_responsive',
                'label' => esc_html__('Responsive', 'mouno' ),
                'type' => 'tab',
                'controls' => [
                    array(
                        'name' => 'slides_per_view',
                        'label' => esc_html__('Slides Per View', 'mouno' ),
                        'type' => 'select',
                        'default' => '',
                        'options' => [
                            ''  => 'Auto',
                            '1' => '1',
                            '2' => '2',
                            '3' => '3',
                            '4' => '4',
                            '6' => '6',
                        ],
                    ),
                    array(
                        'name' => 'slides_per_view_xs',
                        'label' => esc_html__('Slides Per View(<576px)', 'mouno' ),
                        'type' => 'select',
                        'default' => '',
                        'options' => [
                            ''  => 'Default',
                            '1' => '1',
                            '2' => '2',
                            '3' => '3',
                            '4' => '4',
                            '6' => '6',
                        ],
                    ),
                    array(
                        'name' => 'slides_per_view_sm',
                        'label' => esc_html__('Slides Per View(≥576px)', 'mouno' ),
                        'type' => 'select',
                        'default' => '',
                        'options' => [
                            ''  => 'Default',
                            '1' => '1',
                            '2' => '2',
                            '3' => '3',
                            '4' => '4',
                            '6' => '6',
                        ],
                    ),
                    array(
                        'name' => 'slides_per_view_md',
                        'label' => esc_html__('Slides Per View(≥768px)', 'mouno' ),
                        'type' => 'select',
                        'default' => '',
                        'options' => [
                            ''  => 'Default',
                            '1' => '1',
                            '2' => '2',
                            '3' => '3',
                            '4' => '4',
                            '6' => '6',
                        ],
                    ),
                    array(
                        'name' => 'slides_per_view_lg',
                        'label' => esc_html__('Slides Per View(≥992px)', 'mouno' ),
                        'type' => 'select',
                        'default' => '',
                        'options' => [
                            ''  => 'Default',
                            '1' => '1',
                            '2' => '2',
                            '3' => '3',
                            '4' => '4',
                            '6' => '6',
                        ],
                    ),
                    array(
                        'name' => 'slides_per_view_xl',
                        'label' => esc_html__('Slides Per View(≥1200px)', 'mouno' ),
                        'type' => 'select',
                        'default' => '',
                        'options' => [
                            ''  => 'Default',
                            '1' => '1',
                            '2' => '2',
                            '3' => '3',
                            '4' => '4',
                            '5' => '5',
                            '6' => '6',
                        ],
                    ),
                    array(
                        'name' => 'slides_per_view_xxl',
                        'label' => esc_html__('Slides Per View(≥1400px)', 'mouno' ),
                        'type' => 'select',
                        'default' => '',
                        'options' => [
                            ''  => 'Default',
                            '1' => '1',
                            '2' => '2',
                            '3' => '3',
                            '4' => '4',
                            '5' => '5',
                            '6' => '6',
                        ],
                    ),
                ],
            ],
        ],
    );
}

// Swiper Navigation Style Options
function swiper_navigation_style_options() {
    $options = array_merge(
        array(
            array(
                'name' => 'swiper_nav_layout_h',
                'label' => esc_html__('Layout', 'mouno'),
                'type' => 'heading',
            ),
            array(
                'name' => 'swiper_nav_justify_content',
                'label' => esc_html__('Justify Content', 'mouno'),
                'type' => 'choose',
                'control_type' => 'responsive',
                'options' => array(
                    'start' => [
                        'title' => esc_html__('Start', 'mouno' ),
                        'icon' => 'eicon-justify-start-h',
                    ],
                    'center' => [
                        'title' => esc_html__('Center', 'mouno' ),
                        'icon' => 'eicon-justify-center-h',
                    ],
                    'end' => [
                        'title' => esc_html__('End', 'mouno' ),
                        'icon' => 'eicon-justify-end-h',
                    ],
                ),
                'selectors' => [
                    '{{WRAPPER}} .swiper-navigation' => 'justify-content: {{VALUE}};'
                ],
            ),
            array(
                'name' => 'nav_gap',
                'label' => esc_html__('Gap', 'mouno' ),
                'type' => 'slider',
                'control_type' => 'responsive',
                'size_units' => [ 'px', 'custom'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .pxl-swiper .swiper-navigation' => 'gap: {{SIZE}}{{UNIT}};',
                ],
            ),
            array(
                'name' => 'swiper_nav_position',
                'label' => esc_html__('Position', 'mouno'),
                'type' => 'select',
                'options' => [
                    '' => esc_html__('Default', 'mouno'),
                    'relative' => esc_html__('Relative', 'mouno'),
                    'absolute' => esc_html__('Absolute', 'mouno'),
                    'static' => esc_html__('Static', 'mouno'),
                ],
                'selectors' => [
                    '{{WRAPPER}} .pxl-swiper .swiper-navigation' => 'position: {{VALUE}};',
                ],
            ),
        ),
        mouno_position_options([
            'prefix' => 'swiper_nav',
            'selector' => '{{WRAPPER}} .pxl-swiper .swiper-navigation',
            'condition' => [
                'swiper_nav_position' => 'absolute'
            ]
        ]),
        array(
            array(
                'name' => 'divider1',
                'type' => 'divider',
            ),
            array(
                'name' => 'swiper_nav_btn_h',
                'label' => esc_html__('Button', 'mouno'),
                'type' => 'heading',
            ),
            array(
                'name' => 'swiper_btn_box_sz',
                'label' => esc_html__('Box Size', 'mouno' ),
                'type' => 'slider',
                'size_units' => ['px', 'custom'],
                'control_type' => 'responsive',
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .swiper-navigation .pxl-swiper-button' => '--pxl-box-size: {{SIZE}}{{UNIT}};',
                ],
            ),
            array(
                'name' => 'swiper_btn_typography',
                'type' => \Elementor\Group_Control_Typography::get_type(),
                'control_type' => 'group',
                'selector' => '{{WRAPPER}} .swiper-navigation .pxl-swiper-button',
            ),
            array(
                'name' => 'swiper_btn_text_shadow',
                'label' => esc_html__('Text Shadow', 'mouno' ),
                'type' => \Elementor\Group_Control_Text_Shadow::get_type(),
                'control_type' => 'group',
                'selector' => '{{WRAPPER}} .swiper-navigation .pxl-swiper-button',
            ),
            array(
                'name' => 'swiper_btn_controls',
                'control_type' => 'tab',
                'tabs' => [
                    [
                        'name' => 'swiper_btn_normal',
                        'label' => esc_html__('Normal', 'mouno' ),
                        'type' => 'tab',
                        'controls' => [  
                            array(
                                'name' => 'swiper_btn_color',
                                'label' => esc_html__('Color', 'mouno' ),
                                'type' => 'color',
                                'selectors' => [
                                    '{{WRAPPER}} .swiper-navigation .pxl-swiper-button' => 'color: {{VALUE}};',
                                ],
                            ),
                            array(
                                'name' => 'swiper_btn_bg',
                                'type' => \Elementor\Group_Control_Background::get_type(),
                                'control_type' => 'group',
                                'types' => [ 'classic', 'gradient' ],
                                'selector' => '{{WRAPPER}} .swiper-navigation .pxl-swiper-button',
                            ),
                            array(
                                'name' => 'swiper_btn_border',
                                'type' => \Elementor\Group_Control_Border::get_type(),
                                'separator' => 'before',
                                'control_type' => 'group', 
                                'selector' => '{{WRAPPER}} .swiper-navigation .pxl-swiper-button',
                            ),
                            array(
                                'name'         => 'swiper_btn_box_shadow',
                                'label' => esc_html__( 'Box Shadow', 'mouno' ),
                                'type'         => \Elementor\Group_Control_Box_Shadow::get_type(),
                                'control_type' => 'group',
                                'selector'     => '{{WRAPPER}} .swiper-navigation .pxl-swiper-button',
                            ),
                            array(
                                'name' => 'swiper_btn_border_radius',
                                'label' => esc_html__('Border Radius', 'mouno' ),
                                'type' => 'dimensions',
                                'size_units' => [ 'px', 'custom' ],
                                'selectors' => [
                                    '{{WRAPPER}} .swiper-navigation .pxl-swiper-button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                ],
                            ),
                            array(
                                'name' => 'swiper_btn_padding',
                                'label' => esc_html__('Padding', 'mouno' ),
                                'type' => 'dimensions',
                                'size_units' => [ 'px', 'custom' ],
                                'control_type' => 'responsive',
                                'separator' => 'before',
                                'selectors' => [
                                    '{{WRAPPER}} .swiper-navigation .pxl-swiper-button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                ],
                            ),
                        ],
                    ],
                    [
                        'name' => 'swiper_btn_hover',
                        'label' => esc_html__('Hover', 'mouno' ),
                        'type' => 'tabs',
                        'controls' => [
                            array(
                                'name' => 'swiper_btn_hover_style',
                                'label' => esc_html__('Hover Style', 'mouno' ),
                                'type' => 'select',
                                'options' => [
                                    'hover-button-default' => esc_html__('Default', 'mouno'),
                                    'hover-scaley-fill' => esc_html__('Grow Height', 'mouno'),
                                ],
                                'default' => 'hover-default',
                            ),
                            array(
                                'name' => 'swiper_btn_hove_color',
                                'label' => esc_html__('Color', 'mouno' ),
                                'type' => 'color',
                                'selectors' => [
                                    '{{WRAPPER}} .swiper-navigation .pxl-swiper-button:hover' => 'color: {{VALUE}};',
                                ],
                            ),
                            array(
                                'name' => 'swiper_btn_hover_bg',
                                'type' => \Elementor\Group_Control_Background::get_type(),
                                'control_type' => 'group',
                                'types' => [ 'classic', 'gradient' ],
                                'selector' => '{{WRAPPER}} .swiper-navigation .pxl-swiper-button:hover',
                            ),
                            array(
                                'name' => '_swiper_btn_hover_border_color',
                                'label' => esc_html__('Border Color', 'mouno' ),
                                'type' => 'color',
                                'selectors' => [
                                    '{{WRAPPER}} .swiper-navigation .pxl-swiper-button:hover' => 'border-color: {{VALUE}};',
                                ],
                            ),
                            array(
                                'name' => 'swiper_btn_hover_border',
                                'type' => \Elementor\Group_Control_Border::get_type(),
                                'separator' => 'before',
                                'control_type' => 'group', 
                                'selector' => '{{WRAPPER}} .swiper-navigation .pxl-swiper-button:hover',
                            ),
                            array(
                                'name'         => 'swiper_btn_hover_box_shadow',
                                'label' => esc_html__( 'Box Shadow', 'mouno' ),
                                'type'         => \Elementor\Group_Control_Box_Shadow::get_type(),
                                'control_type' => 'group',
                                'selector'     => '{{WRAPPER}} .swiper-navigation .pxl-swiper-button:hover',
                            ),
                            array(
                                'name' => 'swiper_btn_hover_border_radius',
                                'label' => esc_html__('Border Radius', 'mouno' ),
                                'type' => 'dimensions',
                                'size_units' => [ 'px', 'custom' ],
                                'selectors' => [
                                    '{{WRAPPER}} .swiper-navigation .pxl-swiper-button:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                ],
                            ),
                            array(
                                'name' => 'swiper_btn_hover_padding',
                                'label' => esc_html__('Padding', 'mouno' ),
                                'type' => 'dimensions',
                                'size_units' => [ 'px', 'custom' ],
                                'control_type' => 'responsive',
                                'separator' => 'before',
                                'selectors' => [
                                    '{{WRAPPER}} .swiper-navigation .pxl-swiper-button:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                ],
                            ),
                        ],
                    ],
                ],
            ),
        ),
    );
    return [
        'name' => 'tab_swiper_navigation_style',
        'tab' => 'style',
        'label' => esc_html__('Navigation', 'mouno'), 
        'controls' => $options,
        'condition' => [
            'swiper_navigation!' => '',
            'use_swiper_nav_widget' => ''
        ],
    ];
}

// Source Post Settings
function mouno_source_post_settings($post_type) {
    return array(
        'name' => 'tab_source',
        'label' => esc_html__('Source', 'mouno' ),
        'tab' => 'settings',
        'controls' => array_merge(
            array(
                array(
                    'name'     => 'select_post_by',
                    'label'    => esc_html__( 'Select posts by', 'mouno' ),
                    'type'     => 'select',
                    'multiple' => true,
                    'options'  => [
                        'term_selected' => esc_html__( 'Terms selected', 'mouno' ),
                        'post_selected' => esc_html__( 'Posts selected ', 'mouno' ),
                    ],
                    'default'  => 'term_selected',
                    'description' => esc_html__('If using filter you need to Select posts by terms.', 'mouno'),
                ) 
            ),
            mouno_get_term_by_post_type($post_type, ['custom_condition' => ['select_post_by' => 'term_selected']]),
            mouno_get_ids_by_post_type($post_type, ['custom_condition' => ['select_post_by' => 'post_selected']]),
            array(
                array(
                    'name' => 'orderby',
                    'label' => esc_html__('Order By', 'mouno' ),
                    'type' => 'select',
                    'default' => 'date',
                    'options' => [
                        'date' => esc_html__('Date', 'mouno' ),
                        'ID' => esc_html__('ID', 'mouno' ),
                        'author' => esc_html__('Author', 'mouno' ),
                        'title' => esc_html__('Title', 'mouno' ),
                        'rand' => esc_html__('Random', 'mouno' ),
                    ],
                ),
                array(
                    'name' => 'order',
                    'label' => esc_html__('Sort Order', 'mouno' ),
                    'type' => 'select',
                    'default' => 'desc',
                    'options' => [
                        'desc' => esc_html__('Descending', 'mouno' ),
                        'asc' => esc_html__('Ascending', 'mouno' ),
                    ],
                ),
                array(
                    'name' => 'limit',
                    'label' => esc_html__('View Posts', 'mouno' ),
                    'type' => 'number',
                    'default' => 6,
                ),
            ),
        ),
    );
}

// Parallax Params
if(!function_exists('mouno_parallax_options')) {
    function mouno_parallax_options($args = []) {
        $prefix = isset($args['prefix']) ? $args['prefix'].'_' : '';
        $condition = isset($args['condition']) ? $args['condition'] : [];
        $options = [
            [
                'name' => $prefix.'popover_toggle_parallax',
                'label' => esc_html__( 'Parallax Params', 'mouno' ),
                'type' => 'popover_toggle',
                'default' => '',
                'condition' => $condition,
            ],
            [
                'name' => $prefix.'pxl_start_popover',
                'type' => 'pxl_start_popover',
            ],
            [
                'name' => $prefix.'parallax_x',
                'label' => esc_html__('X', 'mouno' ),
                'control_type' => 'responsive',
                'type' => 'number',
            ],
            [
                'name' => $prefix.'parallax_y',
                'label' => esc_html__('Y', 'mouno' ),
                'control_type' => 'responsive',
                'type' => 'number',
            ],
            [
                'name' => $prefix.'parallax_opacity',
                'label' => esc_html__('Opacity', 'mouno' ),
                'control_type' => 'responsive',
                'type' => 'number',
                'min' => 0,
                'max' => 1,
                'step' => 0.01,
            ],
            [
                'name' => $prefix.'parallax_rotate',
                'label' => esc_html__('Rotate', 'mouno' ),
                'control_type' => 'responsive',
                'type' => 'number',
            ],
            [
                'name' => $prefix.'parallax_scale',
                'label' => esc_html__('Scale', 'mouno' ),
                'control_type' => 'responsive',
                'type' => 'number',
            ],
            [
                'name' => $prefix.'pxl_start_popover',
                'type' => 'pxl_end_popover',
            ],
        ];
        return $options;
    }
}

// Grid Pagination Options Style  
function grid_pagination_style_options() {
    return [
        'name' => 'tab_grid_pagination_style',
        'label' => esc_html__('Pagination', 'mouno'),
        'tab' => 'style',
        'condition' => [
            'grid_pagination' => 'pagination',
        ],
        'controls' => [
            array(
                'name' => 'pagination_box_sz',
                'label' => esc_html__('Box Size', 'mouno' ),
                'type' => 'slider',
                'size_units' => ['px', 'custom'],
                'control_type' => 'responsive',
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 500,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .pxl-grid .pxl-grid-pagination .pxl-pagination-wrap .page-numbers' => '--pxl-box-size: {{SIZE}}{{UNIT}};',
                ],
            ),
            array(
                'name' => 'pagination_typography',
                'type' => \Elementor\Group_Control_Typography::get_type(),
                'control_type' => 'group',
                'selector' => '{{WRAPPER}} .pxl-grid .pxl-grid-pagination .pxl-pagination-wrap .page-numbers',
            ),
            array(
                'name' => 'divider_pagination_1',
                'type' => 'divider',
            ),
            array(
                'name' => 'pagination_controls',
                'control_type' => 'tab',
                'tabs' => [
                    [
                        'name' => 'pagination_normal',
                        'label' => esc_html__('Normal', 'mouno' ),
                        'type' => 'tab',
                        'controls' => [  
                            array(
                                'name' => 'pagination_color',
                                'label' => esc_html__('Text Color', 'mouno' ),
                                'type' => 'color',
                                'selectors' => [
                                    '{{WRAPPER}} .pxl-grid .pxl-grid-pagination .pxl-pagination-wrap .page-numbers' => 'color: {{VALUE}};',
                                ],
                            ),
                            array(
                                'name' => 'pagination_bg',
                                'type' => \Elementor\Group_Control_Background::get_type(),
                                'control_type' => 'group',
                                'types' => [ 'classic', 'gradient' ],
                                'selector' => '{{WRAPPER}} .pxl-grid .pxl-grid-pagination .pxl-pagination-wrap .page-numbers',
                            ),
                            array(
                                'name' => 'pagination_border',
                                'type' => \Elementor\Group_Control_Border::get_type(),
                                'separator' => 'before',
                                'control_type' => 'group', 
                                'selector' => '{{WRAPPER}} .pxl-grid .pxl-grid-pagination .pxl-pagination-wrap .page-numbers',
                            ),
                            array(
                                'name'         => 'pagination_box_shadow',
                                'label' => esc_html__( 'Box Shadow', 'mouno' ),
                                'type'         => \Elementor\Group_Control_Box_Shadow::get_type(),
                                'control_type' => 'group',
                                'selector'     => '{{WRAPPER}} .pxl-grid .pxl-grid-pagination .pxl-pagination-wrap .page-numbers',
                            ),
                            array(
                                'name' => 'pagination_border_radius',
                                'label' => esc_html__('Border Radius', 'mouno' ),
                                'type' => 'dimensions',
                                'size_units' => [ 'px', 'custom' ],
                                'selectors' => [
                                    '{{WRAPPER}} .pxl-grid .pxl-grid-pagination .pxl-pagination-wrap .page-numbers' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                ],
                            ),
                        ],
                    ],
                    [
                        'name' => 'pagination_hover',
                        'label' => esc_html__('Hover/Current', 'mouno' ),
                        'type' => 'tabs',
                        'controls' => [
                            array(
                                'name' => 'pagination_hove_color',
                                'label' => esc_html__('Text Color', 'mouno' ),
                                'type' => 'color',
                                'selectors' => [
                                    '{{WRAPPER}} .pxl-grid .pxl-grid-pagination .pxl-pagination-wrap .page-numbers:hover' => 'color: {{VALUE}};',
                                ],
                            ),
                            array(
                                'name' => '_pagination_hover_border_color',
                                'label' => esc_html__('Border Color', 'mouno' ),
                                'type' => 'color',
                                'selectors' => [
                                    '{{WRAPPER}} .pxl-grid .pxl-grid-pagination .pxl-pagination-wrap .page-numbers:hover' => 'border-color: {{VALUE}};',
                                ],
                            ),
                            array(
                                'name' => 'pagination_hover_bg',
                                'type' => \Elementor\Group_Control_Background::get_type(),
                                'control_type' => 'group',
                                'types' => [ 'classic', 'gradient' ],
                                'selector' => '{{WRAPPER}} .pxl-grid .pxl-grid-pagination .pxl-pagination-wrap .page-numbers:hover',
                            ),
                            array(
                                'name' => 'pagination_hover_border',
                                'type' => \Elementor\Group_Control_Border::get_type(),
                                'separator' => 'before',
                                'control_type' => 'group', 
                                'selector' => '{{WRAPPER}} .pxl-grid .pxl-grid-pagination .pxl-pagination-wrap .page-numbers:hover'
                            ),
                            array(
                                'name'         => 'pagination_hover_box_shadow',
                                'label' => esc_html__( 'Box Shadow', 'mouno' ),
                                'type'         => \Elementor\Group_Control_Box_Shadow::get_type(),
                                'control_type' => 'group',
                                'selector'     => '{{WRAPPER}} .pxl-grid .pxl-grid-pagination .pxl-pagination-wrap .page-numbers:hover'
                            ),
                            array(
                                'name' => 'pagination_hover_border_radius',
                                'label' => esc_html__('Border Radius', 'mouno' ),
                                'type' => 'dimensions',
                                'size_units' => [ 'px', 'custom' ],
                                'selectors' => [
                                    '{{WRAPPER}} .pxl-grid .pxl-grid-pagination .pxl-pagination-wrap .page-numbers:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                ],
                            ),
                        ],
                    ],
                ],
            ),
        ],
    ];
}

// Bullets Pagination Carousel Style Options
function swiper_bullets_pagination_style_options() {
    return [
        'name' => 'tab_bullets_pagination_style',
        'label' => esc_html__('Bullets', 'mouno'),
        'tab' => 'style',
        'condition' => [
            'swiper_pagination' => 'bullets',
        ],
        'controls' => [
            array(
                'name' => 'bullet_w',
                'label' => esc_html__('Width', 'mouno' ),
                'type' => 'slider',
                'size_units' => ['px', 'custom'],
                'control_type' => 'responsive',
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 500,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .pxl-swiper .swiper-pagination.swiper-pagination-bullets .swiper-pagination-bullet' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ),
            array(
                'name' => 'bullet_h',
                'label' => esc_html__('Height', 'mouno' ),
                'type' => 'slider',
                'size_units' => ['px', 'custom'],
                'control_type' => 'responsive',
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 500,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .pxl-swiper .swiper-pagination.swiper-pagination-bullets .swiper-pagination-bullet' => 'height: {{SIZE}}{{UNIT}};',
                ],
            ),
            array(
                'name' => 'divider_bullet_1',
                'type' => 'divider',
            ),
            array(
                'name' => 'bullet_controls',
                'control_type' => 'tab',
                'tabs' => [
                    [
                        'name' => 'bullet_normal',
                        'label' => esc_html__('Normal', 'mouno' ),
                        'type' => 'tab',
                        'controls' => [  
                            array(
                                'name' => 'bullet_color',
                                'label' => esc_html__('Text Color', 'mouno' ),
                                'type' => 'color',
                                'selectors' => [
                                    '{{WRAPPER}} .pxl-swiper .swiper-pagination.swiper-pagination-bullets .swiper-pagination-bullet' => 'color: {{VALUE}};',
                                ],
                            ),
                            array(
                                'name' => 'bullet_bg',
                                'type' => \Elementor\Group_Control_Background::get_type(),
                                'control_type' => 'group',
                                'types' => [ 'classic', 'gradient' ],
                                'selector' => '{{WRAPPER}} .pxl-swiper .swiper-pagination.swiper-pagination-bullets .swiper-pagination-bullet',
                            ),
                            array(
                                'name' => 'bullet_border',
                                'type' => \Elementor\Group_Control_Border::get_type(),
                                'separator' => 'before',
                                'control_type' => 'group', 
                                'selector' => '{{WRAPPER}} .pxl-swiper .swiper-pagination.swiper-pagination-bullets .swiper-pagination-bullet',
                            ),
                            array(
                                'name'         => 'bullet_box_shadow',
                                'label' => esc_html__( 'Box Shadow', 'mouno' ),
                                'type'         => \Elementor\Group_Control_Box_Shadow::get_type(),
                                'control_type' => 'group',
                                'selector'     => '{{WRAPPER}} .pxl-swiper .swiper-pagination.swiper-pagination-bullets .swiper-pagination-bullet',
                            ),
                            array(
                                'name' => 'bullet_border_radius',
                                'label' => esc_html__('Border Radius', 'mouno' ),
                                'type' => 'dimensions',
                                'size_units' => [ 'px', 'custom' ],
                                'selectors' => [
                                    '{{WRAPPER}} .pxl-swiper .swiper-pagination.swiper-pagination-bullets .swiper-pagination-bullet' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                ],
                            ),
                        ],
                    ],
                    [
                        'name' => 'bullet_hover',
                        'label' => esc_html__('Hover/Current', 'mouno' ),
                        'type' => 'tabs',
                        'controls' => [
                            array(
                                'name' => 'bullet_hove_color',
                                'label' => esc_html__('Text Color', 'mouno' ),
                                'type' => 'color',
                                'selectors' => [
                                    '{{WRAPPER}} .pxl-swiper .swiper-pagination.swiper-pagination-bullets .swiper-pagination-bullet:hover' => 'color: {{VALUE}};',
                                ],
                            ),
                            array(
                                'name' => '_bullet_hover_border_color',
                                'label' => esc_html__('Border Color', 'mouno' ),
                                'type' => 'color',
                                'selectors' => [
                                    '{{WRAPPER}} .pxl-swiper .swiper-pagination.swiper-pagination-bullets .swiper-pagination-bullet:hover' => 'border-color: {{VALUE}};',
                                ],
                            ),
                            array(
                                'name' => 'bullet_hover_bg',
                                'type' => \Elementor\Group_Control_Background::get_type(),
                                'control_type' => 'group',
                                'types' => [ 'classic', 'gradient' ],
                                'selector' => '{{WRAPPER}} .pxl-swiper .swiper-pagination.swiper-pagination-bullets .swiper-pagination-bullet:hover',
                            ),
                            array(
                                'name' => 'bullet_hover_border',
                                'type' => \Elementor\Group_Control_Border::get_type(),
                                'separator' => 'before',
                                'control_type' => 'group', 
                                'selector' => '{{WRAPPER}} .pxl-swiper .swiper-pagination.swiper-pagination-bullets .swiper-pagination-bullet:hover'
                            ),
                            array(
                                'name'         => 'bullet_hover_box_shadow',
                                'label' => esc_html__( 'Box Shadow', 'mouno' ),
                                'type'         => \Elementor\Group_Control_Box_Shadow::get_type(),
                                'control_type' => 'group',
                                'selector'     => '{{WRAPPER}} .pxl-swiper .swiper-pagination.swiper-pagination-bullets .swiper-pagination-bullet:hover'
                            ),
                            array(
                                'name' => 'bullet_hover_border_radius',
                                'label' => esc_html__('Border Radius', 'mouno' ),
                                'type' => 'dimensions',
                                'size_units' => [ 'px', 'custom' ],
                                'selectors' => [
                                    '{{WRAPPER}} .pxl-swiper .swiper-pagination.swiper-pagination-bullets .swiper-pagination-bullet:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                ],
                            ),
                        ],
                    ],
                ],
            ),
        ],
    ];
}

// Load More Button Style Options
function load_more_button_style_options() {
    $options = [
        'name' => 'tab_load_more_btn_style',
        'tab' => 'style',
        'label' => esc_html__('Load More', 'mouno'),
        'condition' => [
            'grid_pagination' => 'loadmore',
        ],
        'controls' => [
            array(
                'name' => 'btn_load_more_icon_translate_y',
                'label' => esc_html__('Icon Translate Y', 'mouno'),
                'type' => 'slider',
                'control_type' => 'responsive' ,
                'size_units' => ['px', 'custom'],
                'range' => [
                    'px' => [
                        'min' => 0, 
                        'max' => 1000
                    ],
                ],
                'condition' => [
                    'load_more_style' => ['load-more-button-default'],
                ],
                'selectors' => [
                    '{{WRAPPER}} .pxl-load-more-wrapper .pxl-load-more-button' => '--pxl-translate-y: {{SIZE}}{{UNIT}};',
                ],
            ),
            array(
                'name' => 'btn_load_more_icon_sz',
                'label' => esc_html__('Icon Size', 'mouno'),
                'type' => 'slider',
                'control_type' => 'responsive' ,
                'size_units' => ['px', 'custom'],
                'range' => [
                    'px' => [
                        'min' => 0, 
                        'max' => 1000
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .pxl-load-more-wrapper .pxl-load-more-button .pxl-btn-icon' => 'font-size: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .pxl-load-more-wrapper .pxl-load-more-button .pxl-btn-icon svg' => 'height: {{SIZE}}{{UNIT}}; width : auto;',
                ],
            ),
            array(
                'name' => 'btn_load_more_h',
                'label' => esc_html__('Height', 'mouno' ),
                'type' => 'slider',
                'size_units' => ['px', 'custom'],
                'control_type' => 'responsive',
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                    ],
                ],
                'condition' => [
                    'load_more_style' => ['pxl-btn-split'],
                ],
                'selectors' => [
                    '{{WRAPPER}} .pxl-load-more-wrapper .pxl-load-more-button' => 'height: {{SIZE}}{{UNIT}};--pxl-height: {{SIZE}}{{UNIT}};',
                ],
            ),
            array(
                'name' => 'btn_load_more_box_size',
                'label' => esc_html__('Box Size', 'mouno' ),
                'type' => 'slider',
                'size_units' => ['px' , 'custom'],
                'control_type' => 'responsive',
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                    ],
                ],
                'condition' => [
                    'load_more_style' => ['load-more-button-default'],
                ],
                'selectors' => [
                    '{{WRAPPER}} .pxl-load-more-wrapper .pxl-load-more-button' => '--pxl-box-size: {{SIZE}}{{UNIT}};',
                ],
            ),
            array(
                'name' => 'btn_load_more_divider2',
                'type' => 'divider',
            ),
            array(
                'name' => 'btn_load_more_typography',
                'type' => \Elementor\Group_Control_Typography::get_type(),
                'control_type' => 'group',
                'selector' => '{{WRAPPER}} .pxl-load-more-wrapper .pxl-load-more-button',
            ),
            array(
                'name' => 'btn_load_more_text_shadow',
                'label' => esc_html__('Text Shadow', 'mouno' ),
                'type' => \Elementor\Group_Control_Text_Shadow::get_type(),
                'control_type' => 'group',
                'selector' => '{{WRAPPER}} .pxl-load-more-wrapper .pxl-load-more-button',
            ),
            array(
                'name' => 'btn_load_more_controls',
                'control_type' => 'tab',
                'tabs' => [
                    [
                        'name' => 'btn_load_more_normal',
                        'label' => esc_html__('Normal', 'mouno' ),
                        'type' => 'tab',
                        'controls' => [  
                            array(
                                'name' => 'btn_load_more_color',
                                'label' => esc_html__('Color', 'mouno' ),
                                'type' => 'color',
                                'selectors' => [
                                    '{{WRAPPER}} .pxl-load-more-wrapper .pxl-load-more-button' => 'color: {{VALUE}};',
                                ],
                            ),
                            array(
                                'name' => 'btn_load_more_icon_border_style',
                                'label' => esc_html__( 'Border Style', 'mouno' ),
                                'type' => 'select',
                                'default' => '',
                                'options' => [
                                    '' => esc_html__( 'Default', 'mouno' ),
                                    'none' => esc_html__( 'None', 'mouno' ),
                                    'solid'  => esc_html__( 'Solid', 'mouno' ),
                                    'dashed' => esc_html__( 'Dashed', 'mouno' ),
                                    'dotted' => esc_html__( 'Dotted', 'mouno' ),
                                    'double' => esc_html__( 'Double', 'mouno' ),
                                ],
                                'condition' => [
                                    'load_more_style' => ['load-more-button-default'],
                                ],
                                'selectors' => [
                                    '{{WRAPPER}} .pxl-load-more-wrapper .pxl-load-more-button' => 'border-style: {{VALUE}};',
                                ],
                            ),
                            array(
                                'name' => 'btn_load_more_border_color',
                                'label' => esc_html__('Border Color', 'mouno' ),
                                'type' => 'color',
                                'condition' => [
                                    'load_more_style' => ['load-more-button-default'],
                                ],
                                'selectors' => [
                                    '{{WRAPPER}} .pxl-load-more-wrapper .pxl-load-more-button' => 'border-top-color: {{VALUE}};border-right-color: {{VALUE}};',
                                ],
                            ),
                            array(
                                'name' => 'btn_load_more_border_inner_color',
                                'label' => esc_html__('Border Inner Color', 'mouno' ),
                                'type' => 'color',
                                'condition' => [
                                    'load_more_style' => ['load-more-button-default'],
                                ],
                                'selectors' => [
                                    '{{WRAPPER}} .pxl-load-more-wrapper .pxl-load-more-button:before' => 'border-color: {{VALUE}};',
                                ],
                            ),
                            array(
                                'name' => 'btn_load_more_bg',
                                'type' => \Elementor\Group_Control_Background::get_type(),
                                'control_type' => 'group',
                                'types' => [ 'classic', 'gradient' ],
                                'selector' => '{{WRAPPER}} .pxl-load-more-wrapper .pxl-load-more-button:not(.pxl-btn-split),
                                {{WRAPPER}} .pxl-load-more-wrapper .btn.pxl-btn-split .pxl-btn-icon, 
                                {{WRAPPER}} .pxl-load-more-wrapper .btn.pxl-btn-split .pxl-btn-text',

                            ),
                            array(
                                'name' => '_btn_load_more_border',
                                'type' => \Elementor\Group_Control_Border::get_type(),
                                'separator' => 'before',
                                'control_type' => 'group', 
                                'selector' => '{{WRAPPER}} .pxl-load-more-wrapper .pxl-load-more-button:not(.pxl-btn-split),
                                {{WRAPPER}} .pxl-load-more-wrapper .btn.pxl-btn-split .pxl-btn-icon, 
                                {{WRAPPER}} .pxl-load-more-wrapper .btn.pxl-btn-split .pxl-btn-text',                            ),
                            array(
                                'name'         => 'btn_load_more_box_shadow',
                                'label' => esc_html__( 'Box Shadow', 'mouno' ),
                                'type'         => \Elementor\Group_Control_Box_Shadow::get_type(),
                                'control_type' => 'group',
                                'selector' => '{{WRAPPER}} .pxl-load-more-wrapper .pxl-load-more-button:not(.pxl-btn-split),
                                {{WRAPPER}} .pxl-load-more-wrapper .btn.pxl-btn-split .pxl-btn-icon, 
                                {{WRAPPER}} .pxl-load-more-wrapper .btn.pxl-btn-split .pxl-btn-text',                            ),
                            array(
                                'name' => 'btn_load_more_border_radius',
                                'label' => esc_html__('Border Radius', 'mouno' ),
                                'type' => 'dimensions',
                                'size_units' => [ 'px', 'custom' ],
                                'selectors' => [
                                    '{{WRAPPER}} .pxl-load-more-wrapper .pxl-load-more-button:not(.pxl-btn-split),
                                    {{WRAPPER}} .pxl-load-more-wrapper .btn.pxl-btn-split .pxl-btn-icon, 
                                    {{WRAPPER}} .pxl-load-more-wrapper .btn.pxl-btn-split .pxl-btn-text' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                ],
                            ),
                            array(
                                'name' => 'btn_load_more_padding',
                                'label' => esc_html__('Padding', 'mouno' ),
                                'type' => 'dimensions',
                                'size_units' => [ 'px', 'custom' ],
                                'control_type' => 'responsive',
                                'separator' => 'before',
                                'selectors' => [
                                    '{{WRAPPER}} .pxl-load-more-wrapper .pxl-load-more-button:not(.pxl-btn-split),
                                    {{WRAPPER}} .pxl-load-more-wrapper .btn.pxl-btn-split .pxl-btn-text' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                ],
                            ),
                        ],
                    ],
                    [
                        'name' => 'btn_load_more_hover',
                        'label' => esc_html__('Hover', 'mouno' ),
                        'type' => 'tabs',
                        'controls' => [
                            array(
                                'name' => 'btn_load_more_hover_color',
                                'label' => esc_html__('Color', 'mouno' ),
                                'type' => 'color',
                                'selectors' => [
                                    '{{WRAPPER}} .pxl-load-more-wrapper .pxl-load-more-button:hover' => 'color: {{VALUE}};',
                                ],
                            ),
                            array(
                                'name' => 'btn_load_more_hover_border_color',
                                'label' => esc_html__('Border Color', 'mouno' ),
                                'type' => 'color',
                                'selectors' => [
                                    '{{WRAPPER}} .pxl-load-more-wrapper .load-more-button-default:hover' => 'border-top-color: {{VALUE}};border-right-color: {{VALUE}};',
                                ],
                            ),
                            array(
                                'name' => 'btn_load_more_hover_border_inner_color',
                                'label' => esc_html__('Border Inner Color', 'mouno' ),
                                'type' => 'color',
                                'condition' => [
                                    'load_more_style' => ['load-more-button-default'],
                                ],
                                'selectors' => [
                                    '{{WRAPPER}} .pxl-load-more-wrapper .pxl-load-more-button:hover:before' => 'border-color: {{VALUE}};',
                                ],
                            ),
                            array(
                                'name' => 'btn_load_more_hover_bg',
                                'type' => \Elementor\Group_Control_Background::get_type(),
                                'control_type' => 'group',
                                'types' => [ 'classic', 'gradient' ],
                                'selector' => '{{WRAPPER}} .pxl-load-more-wrapper .pxl-load-more-button:hover',
                            ),
                            array(
                                'name'         => 'btn_load_more_hover_box_shadow',
                                'label' => esc_html__( 'Box Shadow', 'mouno' ),
                                'type'         => \Elementor\Group_Control_Box_Shadow::get_type(),
                                'control_type' => 'group',
                                'selector'     => '{{WRAPPER}} .pxl-load-more-wrapper .pxl-load-more-button:hover',
                            ),
                            array(
                                'name' => 'btn_load_more_hover_border_radius',
                                'label' => esc_html__('Border Radius', 'mouno' ),
                                'type' => 'dimensions',
                                'size_units' => [ 'px', 'custom' ],
                                'selectors' => [
                                    '{{WRAPPER}} .pxl-load-more-wrapper .pxl-load-more-button:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                ],
                            ),
                            array(
                                'name' => 'btn_load_more_hover_padding',
                                'label' => esc_html__('Padding', 'mouno' ),
                                'type' => 'dimensions',
                                'size_units' => [ 'px', 'custom' ],
                                'control_type' => 'responsive',
                                'separator' => 'before',
                                'selectors' => [
                                    '{{WRAPPER}} .pxl-load-more-wrapper .pxl-load-more-button:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                                ],
                            ),
                        ],
                    ],
                ],
            ),
        ]

    ];
    return $options;
}