<?php 
 
if(!function_exists('mouno_get_post_grid')){
    function mouno_get_post_grid($posts = [], $settings = []){ 
        if (empty($posts) || !is_array($posts) || empty($settings) || !is_array($settings)) {
            return false;
        }
        switch ($settings['layout']) {
            case 'post-1':
                mouno_get_post_layout1($posts, $settings);
                break;
            case 'post-2':
                mouno_get_post_layout2($posts, $settings);
                break;
            case 'post-3':
                mouno_get_post_layout3($posts, $settings);
                break;
            case 'service-1':
                mouno_get_service_layout1($posts, $settings);
                break;
            case 'service-2':
                mouno_get_service_layout2($posts, $settings);
                break;
            case 'service-3':
                mouno_get_service_layout3($posts, $settings);
                break;
            case 'service-4':
                mouno_get_service_layout4($posts, $settings);
                break;
            case 'service-5':
                mouno_get_service_layout5($posts, $settings);
                break;
            case 'portfolio-1':
                mouno_get_portfolio_layout1($posts, $settings);
                break;
            case 'portfolio-2':
                mouno_get_portfolio_layout2($posts, $settings);
                break;
            case 'portfolio-3':
                mouno_get_portfolio_layout3($posts, $settings);
                break;
            case 'portfolio-4':
                mouno_get_portfolio_layout4($posts, $settings);
                break;
            case 'portfolio-5':
                mouno_get_portfolio_layout5($posts, $settings);
                break;
            case 'team-1':
                mouno_get_team_layout1($posts, $settings);
                break;
            case 'team-2':
                mouno_get_team_layout2($posts, $settings);
                break;
            case 'team-3':
                mouno_get_team_layout3($posts, $settings);
                break;
            default:
                return false;
                break;
        }
    }
}

function mouno_get_post_featured_image($post_id, $size = 'full'){
    $thumbnail = null;
    if (has_post_thumbnail($post_id) && wp_get_attachment_image_src(get_post_thumbnail_id($post_id), false)) {
        $img_id = get_post_thumbnail_id($post_id);
        $get_img = pxl_get_image_by_size( array(
            'attach_id'  => $img_id,
            'thumb_size' => $size,
        ) );
        $thumbnail = $get_img['thumbnail'];
    }
    return $thumbnail;
}

// Post
function mouno_get_post_layout1($posts = [], $settings = []){ 
    extract($settings);
    $item_class = "pxl-grid-item col-xxl-{$column_xxl} col-xl-{$column_xl} col-lg-{$column_lg} col-md-{$column_md} col-sm-{$column_sm} col-{$column_xs} {$anim}";
    if (is_array($posts)):
        foreach ($posts as $key => $post):
            $filter_class = !empty($tax) ? pxl_get_term_of_post_to_class($post->ID, array_unique($tax)) : '';
            $thumbnail = mouno_get_image_by_size([
                'img_dimension' => $img_dimension ,
                'attr' => [
                    'class' => 'pxl-image-featured',
                ],
            ], $post->ID);
            $author_id = get_post_field ('post_author', $post->ID);
        ?>
            <div class="<?php echo esc_attr($item_class.' '.$filter_class); ?>"  
            <?php if($checked_anim == true): ?> data-wow-delay="<?php echo esc_attr(($key * $anim_delay).'ms'); ?>" <?php endif; ?>>
                <div class="pxl-post-item hover-parent">
                    <span class="pxl-post-featured <?php echo esc_attr($featured_hover_style); ?>">
                        <a href="<?php echo esc_url(get_permalink($post->ID)); ?>" class="pxl-featured-link">
                            <?php echo wp_kses_post($thumbnail); ?>
                        </a>
                    </span>
                    <div class="pxl-post-content ">
                        <?php if($show_date == true) : ?>
                            <div class="pxl-post-date"><?php echo get_the_date('d M Y', $post->ID); ?></div>
                        <?php endif; ?>
                        <<?php echo esc_attr($title_tag); ?> class="pxl-post-title <?php echo esc_attr($title_hover_style); ?>"
                        <?php if($title_hover_style == 'hover-3d-cube-flip') : ?> data-text="<?php echo esc_attr(get_the_title($post->ID)); ?>" <?php endif; ?>>
                            <span class="pxl-title-text">
                                <?php echo esc_html(get_the_title($post->ID)); ?>
                            </span>
                        </<?php echo esc_attr($title_tag); ?>>
                        <?php if($show_author == true) : ?>
                            <span class="pxl-post-author">
                                <a href="<?php echo esc_url(get_author_posts_url($author_id)); ?>" class="pxl-author-link">
                                    <?php echo esc_attr('BY '.get_the_author_meta('display_name', $author_id)); ?>
                                </a>
                            </span>
                        <?php endif; ?>
                        <a href="<?php echo esc_url(get_permalink($post->ID)); ?>" class="pxl-box-link"></a>
                    </div>
                </div>
            </div>
        <?php endforeach;
    endif;
}
function mouno_get_post_layout2($posts = [], $settings = []){ 
    extract($settings);
    $item_class = "pxl-grid-item col-xxl-{$column_xxl} col-xl-{$column_xl} col-lg-{$column_lg} col-md-{$column_md} col-sm-{$column_sm} col-{$column_xs} {$anim}";
    if (is_array($posts)):
        foreach ($posts as $key => $post):
            $filter_class = !empty($tax) ? pxl_get_term_of_post_to_class($post->ID, array_unique($tax)) : '';
            $thumbnail = mouno_get_image_by_size([
                'img_dimension' => $img_dimension ,
                'attr' => [
                    'class' => 'pxl-image-featured',
                ],
            ], $post->ID);
            $author_id = get_post_field ('post_author', $post->ID);
        ?>
            <div class="<?php echo esc_attr($item_class.' '.$filter_class); ?>"  <?php if($checked_anim == true): ?> data-wow-delay="<?php echo esc_attr(($key * $anim_delay).'ms'); ?>" <?php endif; ?>>
                <div class="pxl-post-item hover-parent">
                    <span class="pxl-post-featured <?php echo esc_attr($featured_hover_style); ?>">
                        <a href="<?php echo esc_url(get_permalink($post->ID)); ?>" class="pxl-featured-link">
                            <?php echo wp_kses_post($thumbnail); ?>
                        </a>
                    </span>
                    <div class="pxl-post-content">
                        <<?php echo esc_attr($title_tag); ?> class="pxl-post-title <?php echo esc_attr($title_hover_style); ?>"
                        <?php if($title_hover_style == 'hover-3d-cube-flip') : ?> data-text="<?php echo esc_attr(get_the_title($post->ID)); ?>" <?php endif; ?>>
                            <span class="pxl-title-text">
                                <?php echo esc_html(get_the_title($post->ID)); ?>
                            </span>
                        </<?php echo esc_attr($title_tag); ?>>
                        <div class="pxl-post-meta">
                            <?php if($show_date == true) : ?>
                                <span class="pxl-post-date">
                                    <?php echo get_the_date('F d, Y', $post->ID); ?>
                                </span>
                            <?php endif; ?>
                            <?php if($show_category == true) : ?>
                                <span class="pxl-post-separator"><?php echo esc_html__('/', 'mouno'); ?></span>
                                <span class="pxl-post-category">
                                    <?php the_terms( $post->ID, 'category', '', ',' ); ?>
                                </span>
                            <?php endif; ?>
                        </div>
                        <a href="<?php echo esc_url(get_permalink($post->ID)); ?>" class="pxl-box-link"></a>
                    </div>
                </div>
            </div>
        <?php endforeach;
    endif;
}
function mouno_get_post_layout3($posts = [], $settings = []){ 
    extract($settings);
    $item_class = "pxl-grid-item col-xxl-{$column_xxl} col-xl-{$column_xl} col-lg-{$column_lg} col-md-{$column_md} col-sm-{$column_sm} col-{$column_xs} {$anim}";
    if (is_array($posts)):
        foreach ($posts as $key => $post):
            $filter_class = !empty($tax) ? pxl_get_term_of_post_to_class($post->ID, array_unique($tax)) : '';
            $thumbnail = mouno_get_image_by_size([
                'img_dimension' => $img_dimension ,
                'attr' => [
                    'class' => 'pxl-image-featured',
                ],
            ], $post->ID);
            $author_id = get_post_field ('post_author', $post->ID);
        ?>
            <div class="<?php echo esc_attr($item_class.' '.$filter_class); ?>"  
            <?php if($checked_anim == true): ?> data-wow-delay="<?php echo esc_attr(($key * $anim_delay).'ms'); ?>" <?php endif; ?>>
                <div class="pxl-post-item hover-parent">
                    <div class="pxl-post-featured <?php echo esc_attr($featured_hover_style); ?>">
                        <a href="<?php echo esc_url(get_permalink($post->ID)); ?>" class="pxl-featured-link">
                            <?php echo wp_kses_post($thumbnail); ?>
                        </a>
                    </div>
                    <div class="pxl-post-content ">
                        <?php if($show_date == true) : ?>
                            <div class="pxl-post-date"><?php echo get_the_date('d M Y', $post->ID); ?></div>
                        <?php endif; ?>
                        <<?php echo esc_attr($title_tag); ?> class="pxl-post-title <?php echo esc_attr($title_hover_style); ?>"
                        <?php if($title_hover_style == 'hover-3d-cube-flip') : ?> data-text="<?php echo esc_attr(get_the_title($post->ID)); ?>" <?php endif; ?>>
                            <span class="pxl-title-text">
                                <?php echo esc_html(get_the_title($post->ID)); ?>
                            </span>
                        </<?php echo esc_attr($title_tag); ?>>
                        <?php if($show_author == true) : ?>
                            <span class="pxl-post-author">
                                <a href="<?php echo esc_url(get_author_posts_url($author_id)); ?>" class="pxl-author-link">
                                    <?php echo esc_attr('BY '.get_the_author_meta('display_name', $author_id)); ?>
                                </a>
                            </span>
                        <?php endif; ?>
                        <a href="<?php echo esc_url(get_permalink($post->ID)); ?>" class="pxl-box-link"></a>
                    </div>
                </div>
            </div>
        <?php endforeach;
    endif;
}

// Portfolio
function mouno_get_portfolio_layout1($posts = [], $settings = []){ 
    extract($settings);
    $item_class = "pxl-grid-item col-xxl-{$column_xxl} col-xl-{$column_xl} col-lg-{$column_lg} col-md-{$column_md} col-sm-{$column_sm} col-{$column_xs}";
    if (is_array($posts)):
        foreach ($posts as $key => $post):
            $filter_class = !empty($tax) ? pxl_get_term_of_post_to_class($post->ID, array_unique($tax)) : '';
            if(!empty($masonry_items) && isset($masonry_items[$key])) {
                $img_dimension_tmp = $img_dimension;
                $img_dimension = $masonry_items[$key]['img_dimension_m'];
                if($img_dimension == 'custom') {
                    $custom_img_dimension = $masonry_items[$key]['custom_img_dimension_m'];
                    $img_dimension = !empty($custom_img_dimension['width']) || !empty($custom_img_dimension['height']) ? $custom_img_dimension : $img_dimension_tmp;
                }
                $item_class = "pxl-grid-item elementor-repeater-item-".$masonry_items[$key]['_id'];
                if($masonry == 'masonry') {
                    $item_class .= " col-xxl-{$column_xxl} col-xl-{$column_xl} col-lg-{$column_lg} col-md-{$column_md} col-sm-{$column_sm} col-{$column_xs}";
                }
            }
            $thumbnail = mouno_get_image_by_size([
                'img_dimension' => $img_dimension ,
                'attr' => [
                    'class' => 'pxl-post-featured',
                ],
            ], $post->ID);
            $col_num = $key % 3;
            $col_class = ($key < 3 && $col_num == 1) || ($key >=3 && $col_num == 0) ? 'column-even' : null;
            if($scrolling_effects == 'parallax') {
                $parallax_params = [
                    'x' => 0,
                    'y' => $col_class === 'column-even' ? 90 : -90,
                    'rotate' => 0,
                    'scale' => 1,
                    'opacity' => 1,
                ];
                $parallax_params = json_encode($parallax_params);
            }
        ?>
            <div class="<?php echo esc_attr($item_class .' '.$filter_class.' '.$col_class.' '.$anim); ?>"
            <?php if($checked_anim == true): ?> data-wow-delay="<?php echo esc_attr(($key * $anim_delay).'ms'); ?>" <?php endif; ?>>
                <div <?php if(isset($parallax_params)) : ?> data-parallax="<?php echo esc_attr($parallax_params); ?>" <?php endif; ?>>
                    <div class="pxl-post-item hover-parent <?php echo esc_attr($featured_hover_style); ?>">
                        <div class="pxl-post-featured ">
                            <?php echo wp_kses_post($thumbnail); ?>
                        </div>
                        <div class="pxl-post-content tilt-item <?php echo esc_html($box_content_follow_cursor); ?>">
                            <<?php echo esc_attr($title_tag); ?> class="pxl-post-title <?php echo esc_attr($title_hover_style); ?>"
                            <?php if($title_hover_style == 'hover-3d-cube-flip') : ?> data-text="<?php echo esc_attr(get_the_title($post->ID)); ?>" <?php endif; ?>>
                                <span class="pxl-title-text">
                                    <?php echo esc_html(get_the_title($post->ID)); ?>
                                </span>
                            </<?php echo esc_attr($title_tag); ?>>
                            <?php if($show_category == true) : ?>
                                <div class="pxl-post-category">
                                    <?php the_terms( $post->ID, 'portfolio-category', '', '' ); ?>
                                </div>
                            <?php endif; ?>
                        </div>
                        <a href="<?php echo esc_url(get_permalink($post->ID)); ?>" class="pxl-box-link" ></a>
                    </div>
                </div>
            </div>
        <?php endforeach;
    endif;
}
function mouno_get_portfolio_layout2($posts = [], $settings = []){ 
    extract($settings);
    $item_class = "pxl-grid-item col-12";
    if (is_array($posts)):
        foreach ($posts as $key => $post):
            $filter_class = !empty($tax) ? pxl_get_term_of_post_to_class($post->ID, array_unique($tax)) : '';
            $thumbnail = mouno_get_image_by_size([
                'img_dimension' => $img_dimension ,
                'attr' => [
                    'class' => 'pxl-post-featured no-lazyload',
                ],
            ], $post->ID);
            $index = $key + 1;
        ?>
            <div class="<?php echo esc_attr($item_class .' '.$filter_class.' '.$anim); ?>">
                <div class="pxl-post-item hover-parent" >
                    <div class="pxl-post-featured <?php echo esc_attr($featured_hover_style); ?>" 
                    <?php if($featured_hover_style=='hover-image-distortion-transition') : ?> data-displacement="<?php echo esc_attr($displacement_url); ?>" <?php endif; ?>>
                        <a href="<?php echo esc_url(get_permalink($post->ID)); ?>" class="pxl-featured-link">
                            <?php pxl_print_html($thumbnail); ?>
                        </a>                            
                    </div>
                    <div class="pxl-post-content">
                        <?php if($show_order == true) : ?>
                            <span class="pxl-post-order"><?php echo esc_html('P'.$index); ?></span>
                        <?php endif; ?>
                        <?php if($show_index == true) : ?>
                            <span class="pxl-post-index"><?php echo esc_html(($index < 10) ? '0'.$index : $index); ?></span>
                        <?php endif; ?>
                        <<?php echo esc_attr($title_tag); ?> class="pxl-post-title <?php echo esc_attr($title_hover_style); ?>"
                        <?php if($title_hover_style == 'hover-3d-cube-flip') : ?> data-text="<?php echo esc_attr(get_the_title($post->ID)); ?>" <?php endif; ?>>
                            <a href="<?php echo esc_url(get_permalink($post->ID)); ?>" class="pxl-title-link">
                                <?php echo esc_html(get_the_title($post->ID)); ?>
                            </a>
                        </<?php echo esc_attr($title_tag); ?>>
                        <div class="pxl-content-group">
                            <div class="pxl-post-category">
                                <?php the_terms( $post->ID, 'portfolio-category', '', ' ' ) ?>
                            </div>
                            <div class="pxl-content-right">
                                <p class="pxl-post-excerpt">
                                    <?php echo wp_trim_words( $post->post_excerpt, $num_words, $more = null); ?>
                                </p>
                                <a href="<?php echo esc_url(get_permalink($post->ID)); ?>" class="btn pxl-post-btn">
                                    <span class="pxl-btn-text" data-text="<?php echo esc_attr($btn_text); ?>"><?php echo esc_html($btn_text); ?></span>
                                    <span class="pxl-btn-icon">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="34" height="13" viewBox="0 0 34 13" fill="none">
                                            <path fill-rule="evenodd" clip-rule="evenodd" d="M27.1221 12.6931C27.1386 12.7329 27.1628 12.7691 27.1933 12.7996C27.2238 12.8301 27.26 12.8543 27.2998 12.8708C27.3396 12.8873 27.3823 12.8958 27.4254 12.8958C27.4686 12.8958 27.5113 12.8873 27.5511 12.8708C27.5909 12.8543 27.6271 12.8301 27.6576 12.7996L33.5638 6.89334C33.5944 6.86287 33.6186 6.82668 33.6351 6.78684C33.6516 6.74701 33.6601 6.70431 33.6601 6.66119C33.6601 6.61807 33.6516 6.57537 33.6351 6.53554C33.6186 6.49571 33.5944 6.45952 33.5638 6.42904L27.6576 0.522795C27.6271 0.492308 27.5909 0.468125 27.5511 0.451627C27.5113 0.435128 27.4686 0.426636 27.4254 0.426636C27.3823 0.426636 27.3396 0.435128 27.2998 0.451626C27.26 0.468125 27.2238 0.492308 27.1933 0.522795C27.1628 0.553281 27.1386 0.589473 27.1221 0.629305C27.1056 0.669137 27.0971 0.711829 27.0971 0.754943C27.0971 0.798057 27.1056 0.840749 27.1221 0.880581C27.1386 0.920413 27.1628 0.956605 27.1933 0.987092L32.5393 6.33307L20.3548 6.33307V6.32263H0.0322266V7.00005H20.3548V6.98932L32.5393 6.98932L27.1933 12.3353C27.1628 12.3658 27.1386 12.402 27.1221 12.4418C27.1056 12.4816 27.0971 12.5243 27.0971 12.5674C27.0971 12.6106 27.1056 12.6533 27.1221 12.6931Z" fill="currentcolor"/>
                                        </svg>
                                    </span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach;
    endif;
}
function mouno_get_portfolio_layout3($posts = [], $settings = []){ 
    extract($settings);
    if (is_array($posts)):
        foreach ($posts as $key => $post):
            $filter_class = !empty($tax) ? pxl_get_term_of_post_to_class($post->ID, array_unique($tax)) : '';
            $thumbnail_url = null;
            $img_attrs = [
                'class' => 'pxl-featured-image no-lazyload',
            ];
            if($featured_hover_style == 'hover-image-distortion-warp' || $featured_hover_style == 'hover-image-distortion-wave') {
                $img_attrs['data-sampler'] = 'texture0';
            }
            $thumbnail = mouno_get_image_by_size([
                'img_dimension' => $img_dimension ,
                'attr' => $img_attrs
            ], $post->ID);
            $index = $key + 1;
            $active_class = ($index == $item_active) ? 'active' : '';
        ?>
            <div class="<?php echo esc_attr('pxl-grid-item col-12 '.$filter_class.' '.$anim); ?>" style="z-index: <?php echo esc_attr($key); ?>" 
            <?php if($checked_anim == true): ?> data-wow-delay="<?php echo esc_attr(($key * $anim_delay).'ms'); ?>" <?php endif; ?>>
                <div class="pxl-post-item hover-parent pxl-accordion-item <?php echo esc_attr($active_class); ?>">
                    <div class="pxl-post-content">
                        <?php if($show_index == true) : ?>
                            <span class="pxl-post-index"><?php echo esc_html('0'.$index); ?></span>
                        <?php endif; ?>
                        <div class="pxl-post-group">
                            <div class="pxl-accorrdion-header">
                                <<?php echo esc_attr($title_tag); ?> class="pxl-post-title <?php echo esc_attr($title_hover_style); ?>"
                                <?php if($title_hover_style == 'hover-3d-cube-flip') : ?> data-text="<?php echo esc_attr(get_the_title($post->ID)); ?>" <?php endif; ?>>
                                    <a href="<?php echo esc_url(get_permalink($post->ID)); ?>" class="pxl-title-link">
                                        <?php echo esc_html(get_the_title($post->ID)); ?>
                                    </a>
                                </<?php echo esc_attr($title_tag); ?>>
                            </div>
                            <div class="pxl-accordion-content">
                                <div class="pxl-accordion-details">
                                    <?php if($show_excerpt == true) : ?>
                                        <p class="pxl-post-excerpt">
                                            <?php echo wp_trim_words( $post->post_excerpt, $num_words, $more = null); ?>
                                        </p>
                                    <?php endif; ?>
                                    <?php if($show_btn == true) : ?>
                                        <a href="<?php echo esc_url(get_permalink($post->ID)); ?>" class="btn pxl-post-btn pxl-btn-split">
                                            <span class="pxl-btn-icon icon-duplicated">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" viewBox="0 0 30 30" fill="none">
                                                    <path d="M21.5657 19.3518L21.4975 9.87206C21.4975 9.46287 21.1793 9.1446 20.7701 9.1446L11.2903 9.0764C10.8811 9.0764 10.5628 9.39467 10.5628 9.80386C10.5628 10.2131 10.8811 10.5313 11.2903 10.5313L18.9969 10.5995L9.33525 20.2612C9.06246 20.534 9.06246 20.9886 9.33525 21.2614C9.60805 21.5342 10.0855 21.5569 10.3583 21.2842L20.0653 11.5771L20.1335 19.3746C20.1335 19.5564 20.2245 19.7383 20.3609 19.8747C20.4973 20.0111 20.6791 20.102 20.8837 20.0793C21.2475 20.0793 21.5885 19.7383 21.5657 19.3518Z" fill="currentcolor"/>
                                                </svg>
                                            </span>
                                            <span class="pxl-btn-text"><?php echo esc_html($btn_text); ?></span>
                                            <span class="pxl-btn-icon icon-main">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" viewBox="0 0 30 30" fill="none">
                                                    <path d="M21.5657 19.3518L21.4975 9.87206C21.4975 9.46287 21.1793 9.1446 20.7701 9.1446L11.2903 9.0764C10.8811 9.0764 10.5628 9.39467 10.5628 9.80386C10.5628 10.2131 10.8811 10.5313 11.2903 10.5313L18.9969 10.5995L9.33525 20.2612C9.06246 20.534 9.06246 20.9886 9.33525 21.2614C9.60805 21.5342 10.0855 21.5569 10.3583 21.2842L20.0653 11.5771L20.1335 19.3746C20.1335 19.5564 20.2245 19.7383 20.3609 19.8747C20.4973 20.0111 20.6791 20.102 20.8837 20.0793C21.2475 20.0793 21.5885 19.7383 21.5657 19.3518Z" fill="currentcolor"/>
                                                </svg>
                                            </span>
                                        </a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="pxl-post-featured <?php echo esc_attr($featured_hover_style); ?>">
                        <a href="<?php echo esc_url(get_permalink($post->ID)); ?>" class="pxl-featured-link">            
                            <?php pxl_print_html($thumbnail); ?>
                        </a>
                    </div>
                </div>
            </div>
        <?php endforeach;
    endif;
}
function mouno_get_portfolio_layout4($posts = [], $settings = []){ 
    extract($settings);
    $item_class = "pxl-grid-item col-xxl-{$column_xxl} col-xl-{$column_xl} col-lg-{$column_lg} col-md-{$column_md} col-sm-{$column_sm} col-{$column_xs} {$anim}";
    if (is_array($posts)):
        foreach ($posts as $key => $post):
            $filter_class = !empty($tax) ? pxl_get_term_of_post_to_class($post->ID, array_unique($tax)) : '';
            if(!empty($masonry_items) && isset($masonry_items[$key])) {
                $img_dimension_tmp = $img_dimension;
                $img_dimension = $masonry_items[$key]['img_dimension_m'];
                if($img_dimension == 'custom') {
                    $custom_img_dimension = $masonry_items[$key]['custom_img_dimension_m'];
                    $img_dimension = !empty($custom_img_dimension['width']) || !empty($custom_img_dimension['height']) ? $custom_img_dimension : $img_dimension_tmp;
                }
                $item_class = "pxl-grid-item elementor-repeater-item-".$masonry_items[$key]['_id'];
                if($masonry == 'masonry') {
                    $item_class .= " col-xxl-{$column_xxl} col-xl-{$column_xl} col-lg-{$column_lg} col-md-{$column_md} col-sm-{$column_sm} col-{$column_xs}";
                }
            }
            $thumbnail = mouno_get_image_by_size([
                'img_dimension' => $img_dimension ,
                'attr' => [
                    'class' => 'pxl-post-featured',
                ],
            ], $post->ID);
        ?>
            <div class="<?php echo esc_attr('pxl-grid-item '.$filter_class.' '.$item_class.' '.$anim); ?>">
                <div class="pxl-post-item hover-parent">
                    <div class="pxl-post-content">
                        <<?php echo esc_attr($title_tag); ?> class="pxl-post-title <?php echo esc_attr($title_hover_style); ?>"
                        <?php if($title_hover_style == 'hover-3d-cube-flip') : ?> data-text="<?php echo esc_attr(get_the_title($post->ID)); ?>" <?php endif; ?>>
                            <span class="pxl-title-text">
                                <?php echo esc_html(get_the_title($post->ID)); ?>
                            </span>
                        </<?php echo esc_attr($title_tag); ?>>
                        <div class="pxl-post-category">
                            <?php the_terms($post->ID, 'portfolio-category', '', ''); ?>
                        </div>
                        <?php if($is_btn_as_cursor != true) : ?>
                            <a href="<?php echo esc_url(get_permalink($post->ID)); ?>" class="btn pxl-post-btn">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16">
                                    <path d="M15.673 12.8892L15.5877 1.03948C15.5877 0.527983 15.1899 0.130152 14.6784 0.130152L2.82871 0.0449023C2.31721 0.0449024 1.91938 0.442734 1.91938 0.954232C1.91938 1.46573 2.31721 1.86356 2.82871 1.86356L12.4619 1.94881L0.384887 14.0258C0.0438887 14.3668 0.0438887 14.9352 0.384887 15.2762C0.725886 15.6172 1.32263 15.6456 1.66363 15.3046L13.7975 3.17072L13.8828 12.9176C13.8828 13.1449 13.9964 13.3723 14.1669 13.5428C14.3374 13.7133 14.5647 13.8269 14.8205 13.7985C15.2752 13.7985 15.7014 13.3723 15.673 12.8892Z" fill="currentcolor"/>
                                </svg>
                            </a>
                        <?php endif; ?>
                        <a href="<?php echo esc_url(get_permalink($post->ID)); ?>" class="pxl-box-link"></a>
                    </div>   
                    <div class="pxl-post-featured <?php echo esc_attr($featured_hover_style); ?>" 
                    <?php if($featured_hover_style=='hover-image-distortion-transition') : ?> data-displacement="<?php echo esc_attr($displacement_url); ?>" <?php endif; ?>>
                        <a href="<?php echo esc_url(get_permalink($post->ID)); ?>" class="pxl-featured-link">
                            <?php pxl_print_html($thumbnail); ?>
                        </a>                            
                    </div>
                </div>

            </div>
        <?php endforeach;
    endif;
}
function mouno_get_portfolio_layout5($posts = [], $settings = []){ 
    extract($settings);
    if (is_array($posts)):
        foreach ($posts as $key => $post):
            $filter_class = !empty($tax) ? pxl_get_term_of_post_to_class($post->ID, array_unique($tax)) : '';
            if(!empty($masonry_items) && isset($masonry_items[$key])) {
                $img_dimension_tmp = $img_dimension;
                $img_dimension = $masonry_items[$key]['img_dimension_m'];
                if($img_dimension == 'custom') {
                    $custom_img_dimension = $masonry_items[$key]['custom_img_dimension_m'];
                    $img_dimension = !empty($custom_img_dimension['width']) || !empty($custom_img_dimension['height']) ? $custom_img_dimension : $img_dimension_tmp;
                }
                $item_class = "pxl-grid-item elementor-repeater-item-".$masonry_items[$key]['_id'];
                if($masonry == 'masonry') {
                    $item_class .= " col-xxl-{$column_xxl} col-xl-{$column_xl} col-lg-{$column_lg} col-md-{$column_md} col-sm-{$column_sm} col-{$column_xs}";
                }
            }
            $thumbnail = mouno_get_image_by_size([
                'img_dimension' => $img_dimension ,
                'attr' => [
                    'class' => 'pxl-post-featured',
                ],
            ], $post->ID);
        ?>
            <div class="<?php echo esc_attr($item_class .' '.$filter_class.' '.$anim); ?>"
            <?php if($checked_anim == true): ?> data-wow-delay="<?php echo esc_attr(($key * $anim_delay).'ms'); ?>" <?php endif; ?>>
                <div class="pxl-post-item <?php echo esc_attr($featured_hover_style); ?>">
                    <div class="pxl-post-featured ">
                        <?php echo wp_kses_post($thumbnail); ?>
                    </div>
                    <div class="pxl-post-content tilt-item <?php echo esc_html($box_content_follow_cursor); ?>">
                        <<?php echo esc_attr($title_tag); ?> class="pxl-post-title <?php echo esc_attr($title_hover_style); ?>"
                        <?php if($title_hover_style == 'hover-3d-cube-flip') : ?> data-text="<?php echo esc_attr(get_the_title($post->ID)); ?>" <?php endif; ?>>
                            <span class="pxl-title-text">
                                <?php echo esc_html(get_the_title($post->ID)); ?>
                            </span>
                        </<?php echo esc_attr($title_tag); ?>>
                        <?php if($show_category == true) : ?>
                            <div class="pxl-post-category">
                                <?php the_terms( $post->ID, 'portfolio-category', '', '' ); ?>
                            </div>
                        <?php endif; ?>
                    </div>
                    <a href="<?php echo esc_url(get_permalink($post->ID)); ?>" class="pxl-box-link" ></a>
                </div>
            </div>
        <?php endforeach;
    endif;
}

// Service
function mouno_get_service_layout1($posts = [], $settings = []) {
    extract($settings);
    $item_class = "pxl-grid-item col-xxl-{$column_xxl} col-xl-{$column_xl} col-lg-{$column_lg} col-md-{$column_md} col-sm-{$column_sm} col-{$column_xs} {$anim}";
    if (is_array($posts)):
        foreach ($posts as $key => $post):
            $filter_class = !empty($tax) ? pxl_get_term_of_post_to_class($post->ID, array_unique($tax)) : '';
            $icon = mouno_get_service_icon($post->ID);
        ?>
            <div class="<?php echo esc_attr($item_class.' '.$filter_class); ?>"
            <?php if($checked_anim) : ?> data-wow-delay="<?php echo esc_attr(($anim_delay * $key).'ms'); ?>" <?php endif; ?>>
                <div class="pxl-post-item hover-parent <?php echo esc_attr($box_hover_style); ?>" 
                <?php if(!is_null($direction_hover)) : ?> data-direction="<?php echo esc_attr($direction_hover); ?>" <?php endif; ?>>
                    <span class="pxl-post-icon pxl-sub-icon">
                        <?php pxl_print_html(mouno_get_service_icon($post->ID)); ?>
                    </span>
                    <div class="pxl-post-content">
                        <?php if($show_icon) : ?>
                            <div class="pxl-post-icon pxl-main-icon">
                                <?php pxl_print_html(mouno_get_service_icon($post->ID)); ?>
                            </div>
                        <?php endif; ?>
                        <<?php echo esc_attr($title_tag); ?> class="pxl-post-title <?php echo esc_attr($title_hover_style); ?>"
                        <?php if($title_hover_style == 'hover-3d-cube-flip') : ?> data-text="<?php echo esc_attr(get_the_title($post->ID)); ?>" <?php endif; ?>>
                            <span class="pxl-title-text">
                                <?php echo esc_html(get_the_title($post->ID)); ?>
                            </span>
                        </<?php echo esc_attr($title_tag); ?>>
                        <?php if($show_excerpt) : ?>
                            <p class="pxl-post-excerpt">
                                <?php echo wp_trim_words( $post->post_excerpt, $num_words, $more = null); ?>
                            </p>
                        <?php endif; ?>
                        <?php if($show_btn) : ?>
                            <span class="btn pxl-post-btn pxl-btn-link pxl-btn-link1">
                                <span class="pxl-btn-text"><?php echo esc_html($btn_text); ?></span>
                                <span class="pxl-btn-icon">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="13" viewBox="0 0 14 13" fill="none" color="inherit">
                                        <path d="M13 6.14286L7.85714 11.2857M13 6.14286L7.85714 1M13 6.14286L1 6.14286" stroke="currentcolor" stroke-width="1.71429" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>
                                </span>
                            </span>
                        <?php endif; ?>
                    </div>
                    <a href="<?php echo esc_url(get_permalink($post->ID)); ?>" class="pxl-item-link"></a>
                </div>
            </div>
        <?php endforeach;
    endif;
}

function mouno_get_service_layout2($posts = [], $settings = []) {
    extract($settings);
    $item_class = "pxl-grid-item col-12 {$anim}";
    if (is_array($posts)):
        foreach ($posts as $key => $post):
            $filter_class = !empty($tax) ? pxl_get_term_of_post_to_class($post->ID, array_unique($tax)) : '';
        ?>
            <div class="<?php echo esc_attr($item_class .' '.$filter_class); ?>"
            <?php if($checked_anim) : ?> data-wow-delay="<?php echo esc_attr(($anim_delay * $key).'ms'); ?>" <?php endif; ?>>
                <div class="pxl-post-item hover-parent <?php echo esc_attr($box_hover_style); ?>" 
                <?php if(in_array($box_hover_style, ['hover-translate3d-direction', 'hover-rotate3d-direction'])) : ?> data-direction="vertical" <?php endif; ?>>
                    <span class="item-hover direction-item"></span>
                    <?php if($show_icon) : ?>
                        <div class="pxl-post-icon">
                            <span class="pxl-icon">
                                <?php pxl_print_html(mouno_get_service_icon($post->ID)); ?>
                            </span>
                        </div>
                    <?php endif; ?>
                    <div class="pxl-post-content">
                        <div class="pxl-post-group">
                            <<?php echo esc_attr($title_tag); ?> class="pxl-post-title <?php echo esc_attr($title_hover_style); ?>"
                            <?php if($title_hover_style == 'hover-3d-cube-flip') : ?> data-text="<?php echo esc_attr(get_the_title($post->ID)); ?>" <?php endif; ?>>
                                <span class="pxl-title-text">
                                    <?php echo esc_html(get_the_title($post->ID)); ?>
                                </span>
                            </<?php echo esc_attr($title_tag); ?>>
                            <?php if($show_excerpt) : ?>
                                <p class="pxl-post-excerpt">
                                    <?php echo wp_trim_words( $post->post_excerpt, $num_words, $more = null); ?>
                                </p>
                            <?php endif; ?>
                        </div>
                        <?php if($show_btn) : ?>
                            <span class="btn pxl-post-btn">
                                <svg xmlns="http://www.w3.org/2000/svg" width="17" height="17" viewBox="0 0 17 17" fill="none">
                                    <path d="M3.25158 1.49396C3.2517 1.6759 3.32402 1.85036 3.45268 1.97902C3.58133 2.10767 3.75579 2.18 3.93774 2.18011L13.9315 2.18092L0.862997 15.2494C0.734238 15.3781 0.661902 15.5528 0.661902 15.7349C0.661902 15.917 0.734238 16.0916 0.862997 16.2204C0.991756 16.3491 1.16639 16.4215 1.34848 16.4215C1.53058 16.4215 1.70521 16.3491 1.83397 16.2204L14.9024 3.15189L14.9032 13.1456C14.9095 13.3234 14.9846 13.4918 15.1126 13.6154C15.2405 13.7389 15.4115 13.808 15.5894 13.808C15.7673 13.808 15.9382 13.7389 16.0662 13.6154C16.1942 13.4918 16.2693 13.3234 16.2755 13.1456L16.2755 1.49396C16.2754 1.31201 16.2031 1.13755 16.0745 1.0089C15.9458 0.880247 15.7713 0.807919 15.5894 0.807806L3.93774 0.807804C3.75579 0.807917 3.58133 0.880245 3.45268 1.0089C3.32402 1.13755 3.2517 1.31201 3.25158 1.49396Z" fill="currentcolor"/>
                                </svg>
                            </span>
                        <?php endif; ?>
                    </div>
                    <a href="<?php echo esc_url(get_permalink($post->ID)); ?>" class="pxl-box-link"></a>
                </div>
            </div>
        <?php endforeach;
    endif;
}

function mouno_get_service_layout3($posts = [], $settings = []) {
    extract($settings);
    $item_class = "pxl-grid-item col-xxl-{$column_xxl} col-xl-{$column_xl} col-lg-{$column_lg} col-md-{$column_md} col-sm-{$column_sm} col-{$column_xs} {$anim}";
    if (is_array($posts)):
        foreach ($posts as $key => $post):
            $filter_class = !empty($tax) ? pxl_get_term_of_post_to_class($post->ID, array_unique($tax)) : '';
            $icon = mouno_get_service_icon($post->ID);
        ?>
            <div class="<?php echo esc_attr($item_class.' '.$filter_class); ?>"
            <?php if($checked_anim) : ?> data-wow-delay="<?php echo esc_attr(($anim_delay * $key).'ms'); ?>" <?php endif; ?>>
                <div class="pxl-post-item hover-parent <?php echo esc_attr($box_hover_style); ?>" 
                <?php if(!is_null($direction_hover)) : ?> data-direction="<?php echo esc_attr($direction_hover); ?>" <?php endif; ?>>                            
                    <div class="pxl-post-inner box-item">
                        <?php if($show_icon == true) : ?>
                            <div class="pxl-post-icon <?php echo esc_attr($icon_hover_anim); ?>">
                                <?php pxl_print_html(mouno_get_service_icon($post->ID)); ?>
                            </div>
                        <?php endif; ?>
                        <div class="pxl-post-content">
                            <<?php echo esc_attr($title_tag); ?> class="pxl-post-title <?php echo esc_attr($title_hover_style); ?>"
                            <?php if($title_hover_style == 'hover-3d-cube-flip') : ?> data-text="<?php echo esc_attr(get_the_title($post->ID)); ?>" <?php endif; ?>>
                                <span class="pxl-title-text">
                                    <?php echo esc_html(get_the_title($post->ID)); ?>
                                </span>
                            </<?php echo esc_attr($title_tag); ?>>
                            <?php if($show_excerpt == true) : ?>
                                <p class="pxl-post-excerpt">
                                    <?php echo wp_trim_words( $post->post_excerpt, $num_words, $more = null); ?>
                                </p>
                            <?php endif; ?>
                        </div>
                        <?php if($show_btn == true) : ?>
                            <span class="btn pxl-post-btn">
                                <svg xmlns="http://www.w3.org/2000/svg" width="32" height="31" viewBox="0 0 32 31" fill="none">
                                    <path d="M22.3953 19.9075L22.3242 10.0328C22.3242 9.60653 21.9927 9.275 21.5665 9.275L11.6917 9.20396C11.2655 9.20396 10.9339 9.53549 10.9339 9.96174C10.9339 10.388 11.2655 10.7195 11.6917 10.7195L19.7194 10.7906L9.65519 20.8547C9.37103 21.1389 9.37103 21.6125 9.65519 21.8967C9.93936 22.1809 10.4366 22.2045 10.7208 21.9204L20.8324 11.8088L20.9034 19.9312C20.9034 20.1207 20.9981 20.3101 21.1402 20.4522C21.2823 20.5943 21.4717 20.689 21.6849 20.6653C22.0638 20.6653 22.419 20.3101 22.3953 19.9075Z" fill="currentcolor"/>
                                </svg>
                            </span>
                        <?php endif; ?>
                    </div>
                    <a href="<?php echo esc_url(get_permalink($post->ID)); ?>" class="pxl-box-link"></a>
                </div>
            </div>
        <?php endforeach;
    endif;
}

function mouno_get_service_layout4($posts = [], $settings = []) {
    extract($settings);
    $item_class = "pxl-grid-item col-xxl-{$column_xxl} col-xl-{$column_xl} col-lg-{$column_lg} col-md-{$column_md} col-sm-{$column_sm} col-{$column_xs} {$anim}";
    if (is_array($posts)):
        foreach ($posts as $key => $post):
            $filter_class = !empty($tax) ? pxl_get_term_of_post_to_class($post->ID, array_unique($tax)) : '';
            $thumbnail_url = get_the_post_thumbnail_url($post->ID);
            $index = ($key < 9) ? '0'.($key + 1) : ($key + 1);
            $title = get_the_title($post->ID);    
            if($break_title_line == true) {
                $title_split = explode(' ', $title);
                $i = 0;
                $title = '';
                while($i < count($title_split)) {
                    if($break_title_from == $i) {
                        $title .= '<span class="pxl-text-highlight">';
                    }
                    $title .= $title_split[$i].' ';
                    $i++;
                }
                if($break_title_from < count($title_split)) {
                    $title .= '</span>';
                }
            }
        ?>
            <div class="<?php echo esc_attr($item_class.' '.$filter_class); ?>"
            <?php if($checked_anim) : ?> data-wow-delay="<?php echo esc_attr(($anim_delay * $key).'ms'); ?>" <?php endif; ?>>
                <div class="pxl-post-item <?php echo esc_attr($box_hover_style); ?>"
                <?php if(!is_null($direction_hover)) : ?> data-direction="<?php echo esc_attr($direction_hover); ?>" <?php endif; ?>>
                    <span class="pxl-post-index"><?php echo esc_html($index); ?></span>
                    <div class="pxl-post-inner">
                        <?php if($show_icon) : ?>
                            <div class="pxl-post-icon ">
                                <?php pxl_print_html(mouno_get_service_icon($post->ID)); ?>
                            </div>
                        <?php endif; ?>
                        <div class="pxl-post-content">
                            <<?php echo esc_attr($title_tag); ?> class="pxl-post-title">
                                <span class="pxl-title-text">
                                    <?php pxl_print_html($title); ?>
                                </span>
                            </<?php echo esc_attr($title_tag); ?>>
                            <?php if($show_excerpt) : ?>
                                <p class="pxl-post-excerpt">
                                    <?php echo wp_trim_words( $post->post_excerpt, $num_words, $more = null); ?>
                                </p>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="item-hover direction-item" style="background-image:url(<?php echo esc_url($thumbnail_url); ?>)">
                        <div class="pxl-post-inner">
                            <div class="pxl-post-content">
                                <<?php echo esc_attr($title_tag); ?> class="pxl-post-title">
                                    <a href="<?php echo esc_url(get_permalink($post->ID)); ?>" class="pxl-title-text">
                                        <?php pxl_print_html($title); ?>
                                    </a>
                                </<?php echo esc_attr($title_tag); ?>>
                                <?php if($show_excerpt) : ?>
                                    <p class="pxl-post-excerpt">
                                        <?php echo wp_trim_words( $post->post_excerpt, 1000, $more = null); ?>
                                    </p>
                                <?php endif; ?>
                            </div>
                            <?php if($show_btn) : ?>
                                <a href="<?php echo esc_url(get_permalink($post->ID)); ?>" class="btn pxl-post-btn pxl-btn-split">
                                    <span class="pxl-btn-icon icon-duplicated">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" viewBox="0 0 30 30" fill="none">
                                            <path d="M21.5648 19.3518L21.4966 9.87206C21.4966 9.46287 21.1783 9.1446 20.7691 9.1446L11.2893 9.0764C10.8801 9.0764 10.5619 9.39467 10.5619 9.80386C10.5619 10.2131 10.8801 10.5313 11.2893 10.5313L18.9959 10.5995L9.33428 20.2612C9.06148 20.534 9.06148 20.9886 9.33428 21.2614C9.60708 21.5342 10.0845 21.5569 10.3573 21.2842L20.0644 11.5771L20.1326 19.3746C20.1326 19.5564 20.2235 19.7383 20.3599 19.8747C20.4963 20.0111 20.6782 20.102 20.8828 20.0793C21.2465 20.0793 21.5875 19.7383 21.5648 19.3518Z" fill="currentcolor"/>
                                        </svg>
                                    </span>
                                    <span class="pxl-btn-text"><?php echo esc_html($btn_text); ?></span>
                                    <span class="pxl-btn-icon icon-main">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" viewBox="0 0 30 30" fill="none">
                                            <path d="M21.5648 19.3518L21.4966 9.87206C21.4966 9.46287 21.1783 9.1446 20.7691 9.1446L11.2893 9.0764C10.8801 9.0764 10.5619 9.39467 10.5619 9.80386C10.5619 10.2131 10.8801 10.5313 11.2893 10.5313L18.9959 10.5995L9.33428 20.2612C9.06148 20.534 9.06148 20.9886 9.33428 21.2614C9.60708 21.5342 10.0845 21.5569 10.3573 21.2842L20.0644 11.5771L20.1326 19.3746C20.1326 19.5564 20.2235 19.7383 20.3599 19.8747C20.4963 20.0111 20.6782 20.102 20.8828 20.0793C21.2465 20.0793 21.5875 19.7383 21.5648 19.3518Z" fill="currentcolor"/>
                                        </svg>
                                    </span>
                                </a>
                            <?php endif; ?>
                        </div>
                        <span class="pxl-post-index"><?php echo esc_html($index); ?></span>
                        <a href="<?php echo esc_url(get_permalink($post->ID)); ?>" class="pxl-box-link"></a>
                    </div>
                </div>
            </div>
        <?php endforeach;
    endif;
}


function mouno_get_service_layout5($posts = [], $settings = []) {
    extract($settings);
    $item_class = "pxl-grid-item col-xxl-{$column_xxl} col-xl-{$column_xl} col-lg-{$column_lg} col-md-{$column_md} col-sm-{$column_sm} col-{$column_xs} {$anim}";
    if (is_array($posts)):
        foreach ($posts as $key => $post):
            $filter_class = !empty($tax) ? pxl_get_term_of_post_to_class($post->ID, array_unique($tax)) : '';
            $features = get_post_meta($post->ID, 'service_features_list', true);
            $index = $key + 1;
            $active = ($service_active == ($key + 1)) ? 'active' : '';
        ?>
            <div class="<?php echo esc_attr($item_class .' '.$filter_class); ?>"
            <?php if($checked_anim) : ?> data-wow-delay="<?php echo esc_attr(($anim_delay * $key).'ms'); ?>" <?php endif; ?>>
                <div class="pxl-post-item pxl-accordion-item <?php echo esc_attr($active); ?>">
                    <div class="pxl-post-header pxl-accordion-header  <?php echo esc_attr($box_hover_style); ?>"
                    <?php if(!is_null($direction_hover)) : ?> data-direction="<?php echo esc_attr($direction_hover); ?>" <?php endif; ?>>
                        <?php if($show_index == 'true') : ?>
                            <span class="pxl-post-index"><?php echo esc_html('0'.$index); ?></span>
                        <?php  endif; ?>
                        <<?php echo esc_attr($title_tag); ?> class="pxl-post-title <?php echo esc_attr($title_hover_style); ?>"
                        <?php if($title_hover_style == 'hover-3d-cube-flip') : ?> data-text="<?php echo esc_attr(get_the_title($post->ID)); ?>" <?php endif; ?>>
                            <span class="pxl-title-text">
                                <?php echo esc_html(get_the_title($post->ID)); ?>
                            </span>
                        </<?php echo esc_attr($title_tag); ?>>
                        <?php if($show_icon == ' true') : ?>
                            <div class="pxl-post-icon">
                                <span class="pxl-icon">
                                    <?php pxl_print_html(mouno_get_service_icon($post->ID)); ?>
                                </span>
                            </div>
                        <?php endif; ?>
                        <a href="<?php echo esc_url(get_permalink($post->ID)); ?>" class="pxl-box-link"></a>
                    </div>
                    <div class="pxl-post-content pxl-accordion-content">
                        <div class="pxl-accordion-details">
                            <?php if($show_excerpt == 'true') : ?>
                                <p class="pxl-post-excerpt">
                                    <?php echo wp_trim_words( $post->post_excerpt, $num_words, $more = null); ?>
                                </p>
                            <?php endif; ?>
                            <?php if(is_array($features) && $show_features == 'true') : ?>
                                <ul class="pxl-post-features">
                                    <?php foreach($features as $feature) : ?>
                                        <li class="pxl-feature-item">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="13" viewBox="0 0 16 13" fill="none">
                                                <path d="M1 8.66016C1 8.66016 2.5 8.66016 4.5 12.1602C4.5 12.1602 10.059 2.99316 15 1.16016" stroke="currentcolor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                            </svg>
                                            <span class="pxl-feature-text"><?php echo esc_html($feature); ?></span>
                                        </li>
                                    <?php endforeach; ?>
                                </ul>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach;
    endif;
}

// Team
function mouno_get_team_layout1($posts = [], $settings = []){ 
    extract($settings);
    $item_class = "pxl-grid-item col-xxl-{$column_xxl} col-xl-{$column_xl} col-lg-{$column_lg} col-md-{$column_md} col-sm-{$column_sm} col-{$column_xs} ".$anim;
    if (is_array($posts)):
        foreach ($posts as $key => $post):
            $position = get_post_meta($post->ID, 'team_position', true);
            $thumbnail = mouno_get_image_by_size([
                'img_dimension' => $img_dimension ,
                'attr' => [
                    'class' => 'pxl-featured-image no-lazyload' ,
                ]
            ], $post->ID);
            $social_share_content = mouno_get_team_social($post->ID);
        ?>
            <div class="<?php echo esc_attr($item_class); ?>" 
            <?php if($checked_anim == true) : ?> data-wow-delay="<?php echo esc_attr(($key * $anim_delay).'ms'); ?>" <?php endif; ?>>                
                <div class="pxl-post-item hover-parent">
                    <div class="pxl-post-featured <?php echo esc_attr($featured_hover_style); ?>">
                        <a href="<?php echo esc_url(get_permalink($post->ID)); ?>" class="pxl-featured-link">
                            <?php echo wp_kses_post($thumbnail); ?>
                        </a>
                        <div class="pxl-post-socials <?php echo esc_attr($show_social_style); ?>">
                            <?php pxl_print_html($social_share_content); ?>
                        </div>
                    </div>
                    <div class="pxl-post-content">
                        <<?php echo esc_attr($title_tag); ?> class="pxl-post-title <?php echo esc_attr($title_hover_style); ?>" 
                        <?php if($title_hover_style == 'hover-3d-cube-flip') : ?> data-text="<?php echo esc_attr(get_the_title($post->ID)); ?>" <?php endif; ?>>
                            <span class="pxl-title-text">
                                <?php echo esc_html(get_the_title($post->ID)); ?>
                            </span>
                        </<?php echo esc_attr($title_tag); ?>>
                        <span class="pxl-post-position"><?php echo esc_html($position); ?></span>
                        <a href="<?php echo esc_url(get_permalink($post->ID)); ?>" class="pxl-box-link"></a>
                    </div>
                </div>
            </div>
        <?php endforeach;
    endif;
}
function mouno_get_team_layout2($posts = [], $settings = []){ 
    extract($settings);
    $item_class = "pxl-grid-item col-xxl-{$column_xxl} col-xl-{$column_xl} col-lg-{$column_lg} col-md-{$column_md} col-sm-{$column_sm} col-{$column_xs} ".$anim;
    if (is_array($posts)):
        foreach ($posts as $key => $post):
            $position = get_post_meta($post->ID, 'team_position', true) ?? '';
            $thumbnail = mouno_get_image_by_size([
                'img_dimension' => $img_dimension ,
                'attr' => [
                    'class' => 'pxl-featured-image no-lazyload' ,
                ]
            ], $post->ID);  
            $social_share_content = mouno_get_team_social($post->ID);
        ?>
            <div class="<?php echo esc_attr($item_class); ?>" 
            <?php if($checked_anim == true) : ?> data-wow-delay="<?php echo esc_attr(($key * $anim_delay).'ms'); ?>" <?php endif; ?>>                
                <div class="pxl-post-item hover-parent">
                    <div class="pxl-post-featured <?php echo esc_attr($featured_hover_style); ?>">
                        <a href="<?php echo esc_url(get_permalink($post->ID)); ?>" class="pxl-featured-link">
                            <?php echo wp_kses_post($thumbnail); ?>
                        </a>
                        <div class="pxl-post-socials <?php echo esc_attr($show_social_style); ?>">
                            <?php pxl_print_html($social_share_content); ?>
                        </div>
                    </div>
                    <div class="pxl-post-content">
                        <<?php echo esc_attr($title_tag); ?> class="pxl-post-title <?php echo esc_attr($title_hover_style); ?>" 
                        <?php if($title_hover_style == 'hover-3d-cube-flip') : ?> data-text="<?php echo esc_attr(get_the_title($post->ID)); ?>" <?php endif; ?>>
                            <span class="pxl-title-text">
                                <?php echo esc_html(get_the_title($post->ID)); ?>
                            </span>
                        </<?php echo esc_attr($title_tag); ?>>
                        <span class="pxl-post-position"><?php echo esc_html($position); ?></span>
                        <a href="<?php echo esc_url(get_permalink($post->ID)); ?>" class="pxl-box-link"></a>
                    </div>
                </div>
            </div>
        <?php endforeach;
    endif;
}
function mouno_get_team_layout3($posts = [], $settings = []){ 
    extract($settings);
    $item_class = "pxl-grid-item col-xxl-{$column_xxl} col-xl-{$column_xl} col-lg-{$column_lg} col-md-{$column_md} col-sm-{$column_sm} col-{$column_xs}";
    if (is_array($posts)):
        if(isset($parallax_params)) {
            if (is_string($parallax_params)) {
                $parallax_params = json_decode($parallax_params, true);
            }
            $parallax_y = $parallax_params['y'];
        }
        foreach ($posts as $key => $post):
            $position = get_post_meta($post->ID, 'team_position', true);
            $thumbnail = mouno_get_image_by_size([
                'img_dimension' => $img_dimension ,
                'attr' => [
                    'class' => 'pxl-featured-image ' ,
                ]
            ], $post->ID);
            $social_share_content = mouno_get_team_social($post->ID);
            
            $col_num = $key % 3; 
            $col_class = 'column-' . ($col_num + 1);
            if(isset($parallax_params)) {
                if (is_string($parallax_params)) {
                    $parallax_params = json_decode($parallax_params, true);
                }
                $parallax_params['y'] = ($col_class == 'column-2') ? (-1 * $parallax_y) : $parallax_y;
                $parallax_params = json_encode($parallax_params);
            }
        ?>
            <div class="parallax-fit-position <?php echo esc_attr($item_class.' '.$col_class); ?>" 
            <?php if(isset($parallax_params)) : ?> data-parallax="<?php echo esc_attr($parallax_params); ?>" <?php endif; ?> >
                <div class="pxl-post-item hover-parent  <?php echo esc_attr($anim); ?>" 
                <?php if($checked_anim == true) : ?> data-wow-delay="<?php echo esc_attr(($key * $anim_delay).'ms'); ?>" <?php endif; ?>>
                    <div class="pxl-post-featured <?php echo esc_attr($featured_hover_style); ?>">
                        <a href="<?php echo esc_url(get_permalink($post->ID)); ?>" class="pxl-featured-link">
                            <?php echo wp_kses_post($thumbnail); ?>
                        </a>
                        <div class="pxl-post-socials <?php echo esc_attr($show_social_style); ?>">
                            <?php pxl_print_html($social_share_content); ?>
                        </div>
                    </div>
                    <div class="pxl-post-content">
                        <<?php echo esc_attr($title_tag); ?> class="pxl-post-title <?php echo esc_attr($title_hover_style); ?>" 
                        <?php if($title_hover_style == 'hover-3d-cube-flip') : ?> data-text="<?php echo esc_attr(get_the_title($post->ID)); ?>" <?php endif; ?>>
                            <span class="pxl-title-text">
                                <?php echo esc_html(get_the_title($post->ID)); ?>
                            </span>
                        </<?php echo esc_attr($title_tag); ?>>
                        <span class="pxl-post-position"><?php echo esc_html($position); ?></span>
                        <a href="<?php echo esc_url(get_permalink($post->ID)); ?>" class="pxl-box-link"></a>
                    </div>
                </div>
            </div>
        <?php endforeach;
    endif;
}

add_action( 'wp_ajax_mouno_load_more_post_grid', 'mouno_load_more_post_grid' );
add_action( 'wp_ajax_nopriv_mouno_load_more_post_grid', 'mouno_load_more_post_grid' );
function mouno_load_more_post_grid(){
    try{
        if(!isset($_POST['settings'])){
            throw new Exception(__('Something went wrong while requesting. Please try again!', 'mouno'));
        }
    
        $settings = isset($_POST['settings']) ? $_POST['settings'] : null;
       
        $source = isset($settings['source']) ? $settings['source'] : '';
        $term_slug = isset($settings['term_slug']) ? $settings['term_slug'] : '';
        if( !empty($term_slug) && $term_slug !='*'){
            $term_slug = str_replace('.', '', $term_slug);
            $source = [$term_slug.'|'.$settings['tax'][0]]; 
        }
        if( isset($_POST['handler_click']) && sanitize_text_field(wp_unslash( $_POST[ 'handler_click' ] )) == 'filter'){
            set_query_var('paged', 1);
            $settings['paged'] = 1;
        }else{
            set_query_var('paged', $settings['paged']);
        }
        extract(pxl_get_posts_of_grid($settings['post_type'], [
                'source' => $source,
                'orderby' => isset($settings['orderby'])?$settings['orderby']:'date',
                'order' => isset($settings['order'])?$settings['order']:'desc',
                'limit' => isset($settings['limit'])?$settings['limit']:'6',
                'post_ids' => isset($settings['post_ids'])?$settings['post_ids']: [],
                'post_not_in' => isset($settings['post_not_in'])?$settings['post_not_in']: [],
            ],
            $settings['tax']
        ));

        ob_start();
            mouno_get_post_grid($posts, $settings);
        $html = ob_get_clean();

        $pagin_html = '';
        if( isset($settings['pagination']) && $settings['pagination'] == 'pagination' ){ 
            ob_start();
                mouno()->page->get_pagination( $query,  true );
            $pagin_html = ob_get_clean();
        }
        wp_send_json(
            array(
                'status' => true,
                'message' => esc_attr__('Load Successfully!', 'mouno'),
                'data' => array(
                    'html' => $html,
                    'pagin_html' => $pagin_html,
                    'paged' => $settings['paged'],
                    'posts' => $posts,
                    'max' => $max,
                ),
            )
        );
    }
    catch (Exception $e){
        wp_send_json(array('status' => false, 'message' => $e->getMessage()));
    }
    die;
}