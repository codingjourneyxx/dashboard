<?php 
    $img_url = null;
    if(isset($settings['shape_img']) && $settings['shape_type'] === 'img') {
        $get_img = pxl_get_image_by_size([
            'attach_id'  => $settings['shape_img']['id'],
            'thumb_size' => 'full',
        ]);
        $img_url = $get_img ? $get_img['url'] : $settings['shape_img']['url'];
    }
    switch($settings['shape_style']) {
        case 'shape-rounded-corner': 
            $shape_content = '<svg class="pxl-shape-item" viewBox="0 0 770 640" xmlns="http://www.w3.org/2000/svg">
                <pattern id="imgPattern" patternUnits="objectBoundingBox" width="1" height="1">
                    <image href="'.$img_url.'" x="0" y="0" width="770" height="640" preserveAspectRatio="xMidYMid meet"/>
                </pattern>
                <path d="M 50 0 H 720 A 50 50 0 0 1 770 50 V 293 A 50 50 0 0 1 720 343 H 370 Q 320 343 320 393 V 590 A 50 50 0 0 1 270 640H 50 A 50 50 0 0 1 0 590 V 50 A 50 50 0 0 1 50 0 Z" fill="url(#imgPattern)"/>
            </svg>';
            break;
        default :
            $shape_content = !is_null($img_url) ? '<div class="pxl-shape-item '.$settings['shape_style'].'" style="background-image: url('.$img_url.')"></div>' : '<div class="pxl-shape-item '.$settings['shape_style'].'" ></div>';
            break;
    }
?>

<div class="pxl-shape-wrapper">
    <?php pxl_print_html($shape_content); ?>
</div>
