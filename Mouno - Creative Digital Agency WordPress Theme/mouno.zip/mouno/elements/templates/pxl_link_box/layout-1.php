<?php 
    $is_tags = isset($settings['tags']) && !empty($settings['tags']) && count($settings['tags']) || false;
    if(isset($settings['img_show'])) {
        $get_img = pxl_get_image_by_size([
            'attach_id'  => $settings['img_show']['id'],
            'thumb_size' => 'full',
        ]);
        $img_url = $get_img ? $get_img['url'] : $settings['img_show']['url'];
    }
?>
<div class="pxl-link-box-wrapper <?php echo esc_attr($settings['style'].' '.$settings['link_box_hover_style']); ?>" <?php if(isset($img_url)) : ?> data-image-url="<?php echo esc_url($img_url); ?>" <?php endif; ?> >
    <div class="pxl-link-box-content">
        <<?php echo esc_attr($settings['title_tag']); ?> class="pxl-link-box-title">
            <?php echo esc_html($settings['title']); ?>
        </<?php echo esc_attr($settings['title_tag']); ?>>
        <?php if(!empty($settings['show_tags']) && $is_tags) : ?>
            <ul class="pxl-link-box-tags">
                <?php foreach($settings['tags'] as $key => $tag) : ?>
                    <li class="pxl-link-box-tag">
                        <span class="pxl-link-box-tag__name"><?php echo esc_html($tag['tag_name']); ?></span>
                    </li>
                <?php endforeach; ?>
            </ul>
        <?php endif; ?>
    </div>
    <div class="pxl-link-box-icon">
        <?php \Elementor\Icons_Manager::render_icon( $settings['_icon'], [ 'aria-hidden' => 'true', 'class' => '' ], 'i' ); ?>
    </div>
    <a <?php pxl_print_html(mouno_render_link_attributes($settings['link'])); ?> class="pxl-item-link"></a>
</div>