<?php 
    $html_id = pxl_get_element_id($settings);

    $col_xxl = $widget->get_setting('col_xxl', 3);
    $col_xl = $widget->get_setting('col_xl', 3);
    $col_lg = $widget->get_setting('col_lg', 3);
    $col_md = $widget->get_setting('col_md', 3);
    $col_sm = $widget->get_setting('col_sm', 2);
    $col_xs = $widget->get_setting('col_xs', 1);
    $pause_on_hover = $widget->get_setting('pause_on_hover', false);
    $autoplay = $widget->get_setting('autoplay', false);
    $delay = $widget->get_setting('delay', 5000);
    $slide_to_scroll = $widget->get_setting('slide_to_scroll', 1);
    $infinite = $widget->get_setting('infinite', false);
    $speed = $widget->get_setting('speed', 1000);
    $arrows = $widget->get_setting('arrows', false);
    $arrow_style = $widget->get_setting('arrow_style', '');
    $arrow_hover_style = $widget->get_setting('arrow_hover_style', 'swiper-arrow-hover1');

    $pagination = $widget->get_setting('pagination_carousel_type', '');
    $space_between = $widget->get_setting('space_between', 30);

    $opts = [
        'slide_direction'               => 'horizontal',
        'slide_percolumn'               => 1, 
        'slide_effect'                  => 'slide', 
        'slides_to_show'                => 'auto',
        'slides_to_scroll'              => (int)$slide_to_scroll,
        'arrow'                         => $arrows,
        'pagination'                    => !empty($pagination) || false,
        'pagination_type'               => $pagination,
        'autoplay'                      => $autoplay,
        'pause_on_hover'                => $pause_on_hover,
        'pause_on_interaction'          => true,
        'delay'                         => $delay,
        'loop'                          => $infinite,
        'speed'                         => $speed,
        'space_between'                 => $space_between,
        'slides_to_show_xxl'            => (int)$col_xxl,  
        'slides_to_show_xl'             => (int)$col_xl,
        'slides_to_show_lg'             => (int)$col_lg, 
        'slides_to_show_md'             => (int)$col_md, 
        'slides_to_show_sm'             => (int)$col_sm, 
        'slides_to_show_xs'             => (int)$col_xs, 
    ];
    $widget->add_render_attribute( 'carousel', [
        'class'         => 'pxl-swiper-container',
        'dir'           => is_rtl() ? 'rtl' : 'ltr',
        'data-settings' => wp_json_encode($opts),
    ]);
    $is_icon_boxs = isset($settings['icon_boxs']) && !empty($settings['icon_boxs']) && count($settings['icon_boxs']) || false;
    $anim = $widget->get_setting('entrance_anim', '');
    $anim_delay = $widget->get_setting('anim_delay', ['size' => 0]);
?>



<div class="pxl-swiper-slider pxl-icon-box-carousel pxl-icon-box-carousel1 <?php echo esc_attr($settings['layout_style']); ?>">
    <div class="pxl-carousel-inner">
        <div <?php pxl_print_html($widget->get_render_attribute_string( 'carousel' )); ?>>
            <div class="pxl-swiper-wrapper">
                <?php if($is_icon_boxs) : ?>
                    <?php foreach($settings['icon_boxs'] as $key => $icon_box) : ?>
                        <?php 
                            $index = $key + 1;   
                            $wow_delay = !empty($anim) ? ($key * $anim_delay['size']).'s' : null; 
                        ?>
                        <div class="pxl-swiper-slide <?php echo esc_attr($anim); ?>" <?php if(!is_null($wow_delay)) : ?> data-wow-delay="<?php echo esc_attr($wow_delay); ?>" <?php endif; ?>>
                            <div class="pxl-icon-box-wrapper">
                                <div class="pxl-icon-box-icon">
                                    <?php if(!empty($icon_box['link']['url']) && $icon_box['icon_type'] === 'icon') : ?>
                                        <a <?php mouno_render_link_attributes($icon_box['link']); ?> class="pxl-icon-link pxl-icon-inner">
                                            <?php \Elementor\Icons_Manager::render_icon( $icon_box['_icon'], [ 'aria-hidden' => 'true', 'class' => '' ], 'i' ); ?>
                                        </a>
                                    <?php elseif(empty($icon_box['link']['url']) && $icon_box['icon_type'] === 'icon'): ?>
                                        <span class="pxl-icon-inner"><?php \Elementor\Icons_Manager::render_icon( $icon_box['_icon'], [ 'aria-hidden' => 'true', 'class' => '' ], 'i' ); ?></span>
                                    <?php elseif($icon_box['icon_type'] === 'index'): ?>
                                        <span class="pxl-icon-inner"><?php echo esc_html($index); ?></span>
                                    <?php endif; ?>
                                </div>
                                <div class="pxl-icon-box-content">
                                    <<?php echo esc_attr($settings['title_tag']); ?> class="pxl-icon-box-title">
                                        <span class="pxl-title-text"><?php echo esc_html($icon_box['title']); ?></span>
                                    </<?php echo esc_attr($settings['title_tag']); ?>>
                                    <p class="pxl-icon-box-description"><?php echo esc_html($icon_box['desc']); ?></p>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>

    </div>
</div>