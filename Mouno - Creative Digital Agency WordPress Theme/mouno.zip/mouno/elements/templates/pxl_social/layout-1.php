<div class="pxl-social-wrapper">
    <a <?php pxl_print_html(mouno_render_link_attributes($settings['social_url'])); ?> class="pxl-social-item">
        <span class="pxl-social-icon">
            <?php \Elementor\Icons_Manager::render_icon( $settings['social_icon'], [ 'aria-hidden' => 'true', 'class' => '' ], 'i' ); ?>
        </span>
        <span class="pxl-social-label"><?php echo esc_html($settings['social_label']); ?></span>
    </a>
</div>