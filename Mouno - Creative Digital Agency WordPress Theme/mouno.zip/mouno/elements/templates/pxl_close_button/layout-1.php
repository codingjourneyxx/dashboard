<span class="pxl-close-button-wrapper">
    <a href="#" class="btn pxl-close-button"></a>
</span>