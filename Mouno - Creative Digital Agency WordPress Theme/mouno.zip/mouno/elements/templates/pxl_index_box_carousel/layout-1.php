<?php 
$html_id = pxl_get_element_id($settings);
$items = $widget->get_setting('index_boxs', []);
if(!empty($items)) : 
    $effect                 = $widget->get_setting('effect', 'slide');
    $autoplay               = $widget->get_setting('autoplay', false);
    $disable_on_interaction = $widget->get_setting('disable_on_interaction', false);
    $delay                  = $widget->get_setting('delay', 5000);
    $loop                   = $widget->get_setting('loop', false);
    $speed                  = $widget->get_setting('speed', 500);
    $space_between          = $widget->get_setting('space_between', 20);
    $pagination             = $widget->get_setting('swiper_pagination', '');
    $navigation             = $widget->get_setting('swiper_navigation', false);
    $slides_per_view        = $widget->get_setting('slides_per_view', 'auto');
    $slides_per_view_xs     = $widget->get_setting('slides_per_view_xs', 1);
    $slides_per_view_sm     = $widget->get_setting('slides_per_view_sm', 2);
    $slides_per_view_md     = $widget->get_setting('slides_per_view_md', 3);
    $slides_per_view_lg     = $widget->get_setting('slides_per_view_lg', 3);
    $slides_per_view_xl     = $widget->get_setting('slides_per_view_xl', 3);
    $slides_per_view_xxl    = $widget->get_setting('slides_per_view_xxl', 3);

    $swiperParams           = [
        'effect'                 => $effect, 
        'direction'              => 'horizontal', 
        'autoplay'               => (bool)$autoplay,
        'disable_on_interaction' => (bool)$disable_on_interaction,
        'delay'                  => $delay,
        'loop'                   => (bool)$loop,
        'speed'                  => $speed,
        'space_between'          => $space_between,
        'pagination'             => $pagination,
        'navigation'             => (bool)$navigation,
        'slides_per_view'        => $slides_per_view,
        'slides_per_view_xs'     => (int)$slides_per_view_xs,
        'slides_per_view_sm'     => (int)$slides_per_view_sm,
        'slides_per_view_md'     => (int)$slides_per_view_md,
        'slides_per_view_lg'     => (int)$slides_per_view_lg,
        'slides_per_view_xl'     => (int)$slides_per_view_xl,
        'slides_per_view_xxl'    => (int)$slides_per_view_xxl,
    ];

    $swiperParams = json_encode($swiperParams);
    $nav_btn_icon_prev  = $widget->get_setting('nav_btn_icon_prev', []);
    $nav_btn_icon_next  = $widget->get_setting('nav_btn_icon_next', []);
    $nav_id = $widget->get_setting('nav_id', '');
    $nav_hidden_class = !empty($nav_id) ? 'swiper-navigation-hidden' : null;
    $nav_btn_style = $widget->get_setting('nav_btn_style', 'swiper-button-default');

    $anim = $widget->get_setting('entrance_anim', '');
    $anim_delay = $widget->get_setting('anim_delay', 0);
    $checked_anim = (!empty($anim) && $anim_delay != 0) || false;
?>
    <div class="pxl-swiper pxl-index-box-carousel pxl-index-box-carousel1">
        <div class="swiper-container" data-swiper = "<?php echo esc_attr($swiperParams); ?>">
            <div class="swiper-wrapper">
                <?php foreach($items as $key => $item) : ?>
                    <?php 
                        $index = $key + 1;  
                        $title   = $item['title'] ?? '';                
                        $desc = $item['desc'] ?? '';
                        $link_attr = mouno_render_link_attributes($item['link']);
                    ?>
                    <div class="swiper-slide <?php echo esc_attr($anim); ?>" 
                    <?php if($checked_anim == true): ?> data-wow-delay="<?php echo esc_attr(($key * $anim_delay).'ms'); ?>" <?php endif; ?>>
                        <div class="pxl-index-box-item">
                            <div class="pxl-index-box-index">
                                <span class="pxl-index-number"><?php echo esc_html($index); ?></span>
                            </div>
                            <div class="pxl-index-box-content">
                                <<?php echo esc_attr($settings['title_tag']); ?> class="pxl-index-box-title">
                                    <span class="pxl-title-text"><?php echo esc_html($title); ?></span>
                                </<?php echo esc_attr($settings['title_tag']); ?>>
                                <p class="pxl-index-box-description"><?php echo esc_html($desc); ?></p>
                            </div>
                            <?php if(!is_null($link_attr)) : ?>
                                <a <?php pxl_print_html($link_attr); ?> class="pxl-box-link"></a>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php if(!empty($pagination)) : ?>
            <div class="swiper-pagination"></div>
        <?php endif; ?>
        <?php if($navigation) : ?>
            <div class="swiper-navigation <?php echo esc_attr($navigation_hidden_class); ?>" <?php if(!empty($nav_id)) : ?> data-navigation-id="<?php echo esc_attr($nav_id); ?>" <?php endif; ?>>
                <div class="pxl-swiper-button swiper-button-prev">
                    <span class="pxl-icon icon-prev">
                        <?php \Elementor\Icons_Manager::render_icon( $nav_btn_icon_prev, [ 'aria-hidden' => 'true', 'class' => 'pxl-button-icon' ], 'i' ); ?>
                    </span>
                </div>
                <div class="pxl-swiper-button swiper-button-next">
                    <span class="pxl-icon icon-next">
                        <?php \Elementor\Icons_Manager::render_icon( $nav_btn_icon_next, [ 'aria-hidden' => 'true', 'class' => 'pxl-button-icon' ], 'i' ); ?>
                    </span>
                </div>
            </div>
        <?php endif; ?>
    </div>
<?php endif;
