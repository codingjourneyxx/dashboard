<?php 
    $btn_text = $widget->get_setting('btn_text', 'Search');
    $btn_style = $widget->get_setting('btn_style', 'pxl-search-button1');
    $popup_template_id = (int)$widget->get_setting('popup_template', 0);
    $template_id = '#';
    if($popup_template_id > 0) {
        if(!has_action( 'pxl_anchor_target_popup_'.$popup_template_id)){
            add_action( 'pxl_anchor_target_popup_'.$popup_template_id, 'mouno_hook_anchor_popup' );
        }
        $template_id .= 'popup-template-'.$popup_template_id;
    }
?>
<span class="pxl-search-button-wrapper">
    <a href="<?php echo esc_attr($template_id); ?>" class="btn pxl-search-button pxl-cta-button <?php echo esc_attr($btn_style); ?>">
        <span class="pxl-btn-icon">
            <?php \Elementor\Icons_Manager::render_icon( $settings['btn_icon'], [ 'aria-hidden' => 'true', 'class' => '' ], 'i' ); ?>
        </span>
        <span class="pxl-btn-text">
            <?php echo esc_attr($btn_text); ?>
        </span>
    </a>
</span>