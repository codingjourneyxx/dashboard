<?php
$menu_style = $widget->get_setting('menu_style', 'menu-default');
$menu_hover_style = $widget->get_setting('menu_hover_style', 'hover-text-default');
add_filter('nav_menu_link_attributes', function($attrs, $item, $args, $depth) use (&$menu_hover_style, &$menu_style) {
    if($depth === 0 && ($menu_hover_style === 'hover-translate3d-direction' || $menu_hover_style === 'hover-popup-dot' || $menu_hover_style === 'hover-text-default')) {
        $attrs['class'] = $menu_hover_style;
        if($menu_hover_style === 'hover-translate3d-direction') {
            $attrs['data-direction'] = 'horizontal';
        }
    }
    return $attrs;
}, 10, 4);
$primary_menu = mouno()->get_page_opt('p_menu');
$menu = !empty($primary_menu) ? $primary_menu : $settings['menu'];
$menu_attrs = [];
$menu_class = 'pxl-menu-primary '.$menu_style;
$link_before = '<span class="hover-item direction-item"></span><span class="pxl-menu-text';
$link_after = '</span>';
if($menu_style !== 'menu-panel') {
    $link_after = '</span><i class="eicon-angle-right pxl-menu-icon"></i>';
}
if($menu_hover_style !== 'hover-translate3d-direction' && $menu_hover_style !== 'hover-popup-dot' && $menu_hover_style !== 'hover-text-default') {
    $link_before .= ' '.esc_attr($menu_hover_style);
}
$link_before .= '">';
if(!empty($menu)) {
    $menu_attrs = [
        'theme_location' => 'primary',
        'menu_class'   => $menu_class,
        'walker'       => class_exists( 'PXL_Mega_Menu_Walker' ) ? new PXL_Mega_Menu_Walker : '',
        'link_before'  => $link_before,
        'link_after'   => $link_after,
        'menu'         => wp_get_nav_menu_object($menu)
    ];
}elseif(has_nav_menu( 'primary' )) {
    $menu_attrs = array(
        'theme_location' => 'primary',
        'menu_class'     => $menu_class,
        'link_before'  => $link_before,
        'link_after'     => $link_after,
        'walker'         => class_exists( 'PXL_Mega_Menu_Walker' ) ? new PXL_Mega_Menu_Walker : '',
    );
}

?>
<div class="pxl-navigation-menu-wrapper" >
    <?php wp_nav_menu($menu_attrs); ?>
    <?php if($menu_style === 'menu-panel') : ?>
        <!-- <div class="pxl-navigation-menu-bar">
            <span class="pxl-navigation-menu-progress"></span>
        </div> -->
    <?php endif; ?>
</div>