<div class="pxl-test">
    <div id="wrap-texture">
      <!-- div that will hold our WebGL canvas -->
      <div id="canvas"></div>
    
      <!-- div used to create our plane -->
      <div class="plane">
    
        <!-- images that will be used as textures by our plane -->
        <img data-sampler="texture0" id="texture0" src="https://images.unsplash.com/photo-1515372039744-b8f02a3ae446?ixlib=rb-1.2.1&q=85&fm=jpg&crop=entropy&cs=srgb&ixid=eyJhcHBfaWQiOjE0NTg5fQ" crossorigin="anonymous" />
      </div>
    </div>
</div>

<script id="vs" type="x-shader/x-vertex">
    #ifdef GL_ES
    precision mediump float;
    #endif
    
    // those are the mandatory attributes that the lib sets
    attribute vec3 aVertexPosition;
    attribute vec2 aTextureCoord;

    // those are mandatory uniforms that the lib sets and that contain our model view and projection matrix
    uniform mat4 uMVMatrix;
    uniform mat4 uPMatrix;

    uniform mat4 texture0Matrix;

    // if you want to pass your vertex and texture coords to the fragment shader
    varying vec3 vVertexPosition;
    varying vec2 vTextureCoord;

    void main() {
        vec3 vertexPosition = aVertexPosition;

        gl_Position = uPMatrix * uMVMatrix * vec4(vertexPosition, 1.0);
  
        // set the varyings
        vTextureCoord = (texture0Matrix * vec4(aTextureCoord, 0., 1.)).xy;
        vVertexPosition = vertexPosition;
    }
</script>
<script id="fs" type="x-shader/x-fragment">
    #ifdef GL_ES
    precision mediump float;
    #endif

    #define PI2 6.28318530718
    #define PI 3.14159265359
    #define S(a,b,n) smoothstep(a,b,n)

    uniform float uTime;
    uniform float uProgress;
    uniform vec2 uReso;
    uniform vec2 uMouse;
    
    // get our varyings
    varying vec3 vVertexPosition;
    varying vec2 vTextureCoord;

    // the uniform we declared inside our javascript

    // our texture sampler (default name, to use a different name please refer to the documentation)
    uniform sampler2D texture0;

    // http://www.flong.com/texts/code/shapers_exp/
    float exponentialEasing (float x, float a){

      float epsilon = 0.00001;
      float min_param_a = 0.0 + epsilon;
      float max_param_a = 1.0 - epsilon;
      a = max(min_param_a, min(max_param_a, a));

      if (a < 0.5){
        // emphasis
        a = 2.0 * a;
        float y = pow(x, a);
        return y;
      } else {
        // de-emphasis
        a = 2.0 * (a-0.5);
        float y = pow(x, 1.0 / (1.-a));
        return y;
      }
    }
  
    void main(){
        vec2 uv = vTextureCoord;

        float progress = uProgress;
       
        float d = exponentialEasing(length( uv - .5 ), progress) - 1.0 + progress * 0.75; 

        vec2 centerInterp = (uv - 0.5) * d;
      
        vec2 r = centerInterp * (progress * 0.6 + 0.4) + uv;
        vec2 g = centerInterp * (progress * 0.9 + 0.1) + uv;
        vec2 b = centerInterp * (progress * 0.9 + 0.1) + uv;
      
        vec4 color = vec4( texture2D( texture0, r).r , texture2D( texture0, g ).g, texture2D( texture0, b).b , 1.); 

        gl_FragColor = color;         
    }
</script>