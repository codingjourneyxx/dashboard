<?php 
    $post_type = $widget->get_setting('filter_post_type', 'post');
    $categories = $settings['source_'.$post_type];
    if(empty($categories)) {
        $terms = pxl_get_grid_term_options($post_type);
        $categories = [];
        if(!empty($terms)) {
            foreach($terms as $name => $label) {
                $categories[] = $name;
            }
        }
    }
    $entrance_anim = $widget->get_setting('entrance_anim', '');
?>
<div class="pxl-filter-wrapper pxl-filter-widget <?php echo esc_attr($entrance_anim); ?>">
    <div class="pxl-filter-inner <?php echo esc_attr($settings['filter_style']); ?>">
        <button class="filter-item active <?php echo esc_attr($settings['filter_hover_style']); ?>" data-filter="*"><?php echo esc_html($settings['filter_default_title']); ?></button>
        <?php foreach ($categories as $category): ?>
            <?php 
                $category_arr = explode('|', $category); 
                $term = get_term_by('slug',$category_arr[0], $category_arr[1]); 
            ?>
            <button class="filter-item <?php echo esc_attr($settings['filter_hover_style']); ?>" data-filter="<?php echo esc_attr('.'.$term->slug); ?>">
                <?php echo esc_html($term->name); ?>
            </button>
        <?php endforeach; ?>
    </div>
</div>