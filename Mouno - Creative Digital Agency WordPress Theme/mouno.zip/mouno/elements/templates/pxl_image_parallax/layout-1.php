<?php 
$html_id = pxl_get_element_id($settings);
$img_sz = $widget->get_setting('img_size', 'full');

$effect = $widget->get_setting('img_effect', '');
$translateX = $widget->get_setting('parallax_x', ['size' => 0, 'unit'=>'px']);
$translateY = $widget->get_setting('parallax_y', ['size' => 0, 'unit'=>'px']);
$rotate = $widget->get_setting('parallax_rotate', 0);
$scale = $widget->get_setting('parallax_scale', 1);
$opacity = $widget->get_setting('parallax_opacity', 1);

$get_img = pxl_get_image_by_size([
    'attach_id'  => $settings['img']['id'],
    'thumb_size' => $img_sz,
]);
$img = $get_img ? $get_img['thumbnail'] : '<img height="auto" width="100%" src="' . $settings['img']['url']  . '">';

$parallax_effects = [
    'translateX' => $translateX['size'],
    'translateY' => 200,
    'rotate'     => $rotate,
    'scale'      => $scale,
    'opacity'    => $opacity,
];

$data_parallax = json_encode($parallax_effects);
$tag = !empty($settings['link_url']) ? 'a' : 'span';

?>
<div id="<?php echo esc_attr($html_id); ?>" class="pxl-image-parallax-wrapper">
    <<?php echo esc_attr($tag); ?> <?php pxl_print_html(mouno_render_link_attributes($settings['link_url'])); ?> class="pxl-image-parallax-item <?php echo esc_attr($effect); ?>"  data-parallax="<?php echo esc_attr($data_parallax); ?>">
        <?php pxl_print_html($img); ?>
    </<?php echo esc_attr($tag); ?>>
</div>
