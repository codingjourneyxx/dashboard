<?php  
    $divider_el = $widget->get_setting('divider_el', '');
?>
<span class="pxl-divider-wrapper <?php echo esc_attr($divider_el); ?>">
    <hr class="pxl-divider-item">
    <?php if(!empty($divider_el)) : ?>
        <?php if($divider_el === 'title') : ?>
            <?php 
                $title_tag = $widget->get_setting('title_tag', 'span');
                $divider_title = $widget->get_setting('divider_title', 'Divider');
                $divider_title = $widget->parse_text_editor( $divider_title );    
            ?>
            <<?php echo esc_attr($title_tag); ?> class="pxl-divider-element pxl-divider-title">
                <?php pxl_print_html($divider_title); ?>
            </<?php echo esc_attr($title_tag); ?>>
        <?php else: ?>
            <span class="pxl-divider-element pxl-divider-icon">
                <?php \Elementor\Icons_Manager::render_icon( $settings['divider_icon'], [ 'aria-hidden' => 'true', 'class' => 'pxl-icon' ], 'i' ); ?>
            </span>
        <?php endif; ?>
        <hr class="pxl-divider-item">
    <?php endif; ?>
</span>