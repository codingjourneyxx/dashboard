<?php 
    $is_social_icons = isset($settings['social_icons']) && !empty($settings['social_icons']) && count($settings['social_icons']) || false;
?>
<div class="pxl-social-icons-wrapper">
    <?php if($is_social_icons) : ?>
        <?php foreach($settings['social_icons'] as $social) : ?>
            <span class="pxl-social-icons-item">
                <a <?php pxl_print_html(mouno_render_link_attributes($social['social_link'])); ?> class="pxl-social-icons-link <?php echo esc_attr($settings['social_icon_hover_style'].' '.$settings['social_icon_style']); ?>">
                    <?php \Elementor\Icons_Manager::render_icon( $social['social_icon'], [ 'aria-hidden' => 'true', 'class' => '' ], 'i' ); ?>
                </a>
            </span>
        <?php endforeach; ?>
    <?php endif; ?>
</div>