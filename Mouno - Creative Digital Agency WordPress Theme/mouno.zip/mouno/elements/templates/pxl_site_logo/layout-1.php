<?php
$get_img  = pxl_get_image_by_size( array(
    'attach_id'  => $settings['logo']['id'],
    'thumb_size' => 'full',
) );
$logo_img = $get_img ? $get_img['thumbnail'] : '<img width="100" height="auto" src="'.$settings['logo']['url'].'">' ;
if($get_img && pathinfo($get_img['url'], PATHINFO_EXTENSION) === 'svg') {
    global $wp_filesystem;
    $logo_urls = explode('uploads', $get_img['url']);
    $upload_dir = wp_upload_dir();
    $logo_path = $upload_dir['basedir']. $logo_urls[1] ;
    $logo_img = $wp_filesystem->get_contents( $logo_path );
}

?>
<div class="pxl-site-logo-wrapper">
    <span class="pxl-site-logo">
        <a class="pxl-site-logo-link" <?php pxl_print_html(mouno_render_link_attributes($settings['logo_link'])); ?>>
            <?php pxl_print_html($logo_img); ?>
        </a>
    </span>
</div>
