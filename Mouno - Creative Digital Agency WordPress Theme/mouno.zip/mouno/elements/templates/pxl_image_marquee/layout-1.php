<?php 
    $images = $widget->get_setting('images', []);
    $img_dimension = $widget->get_setting('img_dimension', 'full');
    $custom_img_dimension = $widget->get_setting('custom_img_dimension', []);
    $marquee_direction = $widget->get_setting('direction', '');
?>

<div class="pxl-image-marquee-wrapper <?php echo esc_attr($marquee_direction); ?>">
    <span class="pxl-image-marquee-item main">
        <?php if(!empty($images)) : 
            foreach($images as $image) : 
                $thumbnail = mouno_get_image_by_size([
                    'img_id' => $image['id'],
                    'img_dimension' => ($img_dimension !== 'custom') ? $img_dimension : $custom_img_dimension,
                    'attr' => [
                        'class' => 'pxl-image',
                    ]
                ]);
                pxl_print_html($thumbnail);
            endforeach;
        endif; ?>
    </span>
    <?php if(!empty($settings['duplicate'])) : ?>
        <span class="pxl-image-marquee-item duplicated ">
            <?php if(!empty($images)) : 
                foreach($images as $image) : 
                    $thumbnail = mouno_get_image_by_size([
                        'img_id' => $image['id'],
                        'img_dimension' => ($img_dimension !== 'custom') ? $img_dimension : $custom_img_dimension,
                        'attr' => [
                            'class' => 'pxl-image',
                        ]
                    ]);
                    pxl_print_html($thumbnail);
                endforeach;
            endif; ?>
        </span>
    <?php endif; ?>
</div>