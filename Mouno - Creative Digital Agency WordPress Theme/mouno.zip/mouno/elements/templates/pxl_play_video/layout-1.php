<?php 
    $btn_icon = $widget->get_setting('btn_icon', []);
    $video_link = $widget->get_setting('video_link', []);
    $link_attrs = mouno_render_link_attributes($video_link);
    $bg_hover_effect = $widget->get_setting('bg_hover_effect', '');
    // $btn_hover_anim = $widget->get_setting('btn_hover_anim', '');
    // $elementor_anim_class = !empty($btn_hover_anim) ? 'elementor-animation-'.$btn_hover_anim : null;
    $btn_style = $widget->get_setting('btn_style', 'pxl-button-play-default');
?>
<div class="pxl-play-video-wrapper <?php //echo esc_attr($bg_hover_effect); ?>">
    <span class="pxl-play-video-background"></span>
    <a <?php pxl_print_html($link_attrs); ?> class="btn pxl-play-video-button pxl-action-popup <?php echo esc_attr($btn_style); ?>">
        <span class="pxl-btn-icon">
            <?php \Elementor\Icons_Manager::render_icon( $btn_icon, [ 'aria-hidden' => 'true', 'class' => '' ], 'i' ); ?>
        </span>
    </a>
</div>