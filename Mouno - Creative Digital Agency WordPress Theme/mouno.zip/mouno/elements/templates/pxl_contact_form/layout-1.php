<?php
if(class_exists('WPCF7')) : ?>
    <?php if($settings['cf7_id'] != 0) : ?>
        <?php echo do_shortcode('[contact-form-7 id="'.esc_attr($settings['cf7_id']).'"  html_class="'.$settings['form_id']. ' pxl-wpcf7-'.esc_attr($settings['cf7_id'].' '.$settings['form_style']).'"]'); ?>
    <?php else : ?>
        <div class="pxl-notification"><?php echo esc_html('Choose Your Form'); ?></div>
    <?php endif; ?>
<?php endif; ?>
