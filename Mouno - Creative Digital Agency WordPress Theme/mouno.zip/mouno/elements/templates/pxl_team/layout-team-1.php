<?php
$html_id = pxl_get_element_id($settings);
$post_type = $widget->get_setting('post_type', 'service');
$tax = [$post_type.'-category'];

$layout = $widget->get_setting('layout_'.$post_type, 'service-1');
$select_post_by = $widget->get_setting('select_post_by', '');
$post_ids = ($select_post_by === 'post_selected') ? $widget->get_setting('source_'.$post_type.'_post_ids', '') : [];
$source = ($select_post_by === 'term_selected') ? $widget->get_setting('source_'.$post_type , '') : [];
$orderby = $widget->get_setting('orderby', 'date');
$order = $widget->get_setting('order', 'desc');
$limit = $widget->get_setting('limit', 6);
extract(pxl_get_posts_of_grid( 
    $post_type, 
    [
        'source' => $source, 
        'orderby' => $orderby, 
        'order' => $order, 
        'limit' => $limit, 
        'post_ids' => $post_ids
    ],
));

if( count($posts) <= 0) : ?>
    <div class="pxl-no-post-grid"><?php echo esc_html__( 'No Post Found', 'mouno' ); ?></div>
    <?php return;
endif;

$filter = $widget->get_setting('filter', 'disable');
$filter_type = $widget->get_setting('filter_type', 'normal');

$anim = $widget->get_setting('entrance_anim', '');
$anim_delay = $widget->get_setting('anim_delay', 0);
$checked_anim = (!empty($anim) && $anim_delay != 0) || false;

$title_tag = $widget->get_setting('title_tag', 'h5');
$img_dimension = $widget->get_setting('img_dimension', 'custom');
if($img_dimension === 'custom') {
    $custom_img_dimension = $widget->get_setting('custom_img_dimension', []);
    $img_dimension = !empty($custom_img_dimension['width']) || !empty($custom_img_dimension['height']) ? $custom_img_dimension : ['width' => 767, 'height' => 982];
}

$featured_hover_style = $widget->get_setting('featured_hover_style', 'hover-image-default');
$title_hover_style = $widget->get_setting('title_hover_style', 'hover-text-default');
$show_social_style = $widget->get_setting('show_social_style', 'show-social-default');

$show_social   = (bool)$widget->get_setting('show_social', '');
$show_position = (bool)$widget->get_setting('show_position', '');

$classes = 'pxl-grid pxl-team-grid pxl-layout-team pxl-layout-team1';
if($settings['layout_type'] === 'grid') : 
    $column_xxl = $settings['column_xxl'] == '5' ? 'pxl5' : 12 / intval($widget->get_setting('column_xxl', 4));
    $column_xl  = $settings['column_xl'] == '5' ? 'pxl5' : 12 / intval($widget->get_setting('column_xl', 4));
    $column_lg  = 12 / intval($widget->get_setting('column_lg', 3));
    $column_md  = 12 / intval($widget->get_setting('column_md', 3));
    $column_sm  = 12 / intval($widget->get_setting('column_sm', 2));
    $column_xs  = 12 / intval($widget->get_setting('column_xs', 1));
    $pagination = $widget->get_setting('grid_pagination', '');
    $load_more_style = $widget->get_setting('load_more_style', 'load-more-button-default');
    $load_more_text = $widget->get_setting('load_more_text', 'Load More');
    $load_more_icon = $widget->get_setting('load_more_icon', []);
    ob_start();
    \Elementor\Icons_Manager::render_icon( $load_more_icon, [ 'aria-hidden' => 'true', 'class' => '' ], 'i' );
    $load_more_icon = ob_get_clean();
    $show_divider_el = (bool)$widget->get_setting('show_divider_el', '');
    $grid_class = trim('pxl-grid-inner row');
    $load_more  = [
        'tax'                  => $tax,
        'post_type'            => $post_type,   
        'layout'               => $layout,
        'startPage'            => $paged,
        'maxPages'             => $max,
        'total'                => $total,
        'perpage'              => $limit,
        'nextLink'             => $next_link,
        'source'               => $source,
        'orderby'              => $orderby,
        'order'                => $order,
        'limit'                => $limit,
        'post_ids'             => $post_ids,
        'column_xxl'           => $column_xxl,
        'column_xl'            => $column_xl,
        'column_lg'            => $column_lg,
        'column_md'            => $column_md,
        'column_sm'            => $column_sm,
        'column_xs'            => $column_xs,
        'pagination'           => $pagination, 
        'featured_hover_style' => $featured_hover_style,
        'title_hover_style'    => $title_hover_style,
        'show_social_style'    => $show_social_style,
        'anim'                 => $anim,
        'anim_delay'           => $anim_delay,
        'show_social'          => $show_social,
        'show_position'        => $show_position,
        'img_dimension'        => $img_dimension,
        'checked_anim'         => $checked_anim,
        'title_tag'            => $title_tag,
        'parallax_params'      => $parallax_params ?? null,
    ];
    $wrap_attrs = [
        'id'               => $html_id,
        'class'            => $classes,
        'data-start-page'  => $paged,
        'data-max-pages'   => $max,
        'data-total'       => $total,
        'data-perpage'     => $limit,
        'data-next-link'   => $next_link,
        'data-loadmore'    => !empty($pagination) ? json_encode($load_more) : null,
    ];
    $widget->add_render_attribute( 'wrapper', $wrap_attrs );

    $grid_args = [
        'select_post_by'       => $select_post_by,
        'filter'               => $filter,
        'filter_type'          => $filter_type,
        'load_more_style'      => $load_more_style,
        'load_more_text'       => $load_more_text,
        'load_more_icon'       => $load_more_icon,
        'grid_class'           => $grid_class,
        'load_more'            => $load_more,
        'grid_sizer'           => null,
        'pagination'           => $pagination,
        'posts'                => $posts,
        'query'                => $query,
        'next_link'            => $next_link,
        'categories'           => $categories,
        'divider_el'           => $show_divider_el ? 'has-divider' : null,
    ];    
?>
    <div <?php pxl_print_html($widget->get_render_attribute_string( 'wrapper' )) ?>>
        <?php mouno_render_post_grid($grid_args); ?>
        <span class="pxl-grid-loader"></span>
    </div>
<?php else: 
    wp_enqueue_script('mouno-swiper');
    $effect                 = $widget->get_setting('effect', 'slide');
    $autoplay               = $widget->get_setting('autoplay', false);
    $disable_on_interaction = $widget->get_setting('disable_on_interaction', false);
    $delay                  = $widget->get_setting('delay', 5000);
    $loop                   = $widget->get_setting('loop', false);
    $speed                  = $widget->get_setting('speed', 500);
    $space_between          = $widget->get_setting('space_between', 32);
    $pagination             = $widget->get_setting('swiper_pagination', '');
    $navigation             = $widget->get_setting('swiper_navigation', false);
    $slides_per_view        = $widget->get_setting('slides_per_view', 'auto');
    $slides_per_view_xs     = $widget->get_setting('slides_per_view_xs', 1);
    $slides_per_view_sm     = $widget->get_setting('slides_per_view_sm', 2);
    $slides_per_view_md     = $widget->get_setting('slides_per_view_md', 3);
    $slides_per_view_lg     = $widget->get_setting('slides_per_view_lg', 3);
    $slides_per_view_xl     = $widget->get_setting('slides_per_view_xl', 4);
    $slides_per_view_xxl    = $widget->get_setting('slides_per_view_xxl', 4);
    $swiperParams           = [
        'effect'                 => $effect, 
        'direction'              => 'horizontal', 
        'autoplay'               => (bool)$autoplay,
        'disable_on_interaction' => (bool)$disable_on_interaction,
        'delay'                  => $delay,
        'loop'                   => (bool)$loop,
        'speed'                  => $speed,
        'space_between'          => $space_between,
        'pagination'             => $pagination,
        'navigation'             => (bool)$navigation,
        'slides_per_view'        => $slides_per_view,
        'slides_per_view_xs'     => (int)$slides_per_view_xs,
        'slides_per_view_sm'     => (int)$slides_per_view_sm,
        'slides_per_view_md'     => (int)$slides_per_view_md,
        'slides_per_view_lg'     => (int)$slides_per_view_lg,
        'slides_per_view_xl'     => (int)$slides_per_view_xl,
        'slides_per_view_xxl'    => (int)$slides_per_view_xxl,
    ];

    $swiperParams = json_encode($swiperParams);
    $nav_btn_icon_prev  = $widget->get_setting('nav_btn_icon_prev', []);
    $nav_btn_icon_next  = $widget->get_setting('nav_btn_icon_next', []);
    $nav_id = $widget->get_setting('nav_id', '');
    $nav_hidden_class = !empty($nav_id) ? 'swiper-navigation-hidden' : null;
    $nav_btn_style = $widget->get_setting('nav_btn_style', 'swiper-button-default');
?>
    <div class="pxl-swiper pxl-team-carousel pxl-layout-team pxl-layout-team1">
        <div class="swiper-container" data-swiper = "<?php echo esc_attr($swiperParams); ?>">
            <div class="swiper-wrapper">
                <?php foreach($posts as $key => $post) : 
                    $position = get_post_meta($post->ID, 'team_position', true);
                    $thumbnail = mouno_get_image_by_size([
                        'img_dimension' => $img_dimension ,
                        'attr' => [
                            'class' => 'pxl-featured-image no-lazyload' ,
                        ]
                    ], $post->ID);
                    $social_share_content = mouno_get_team_social($post->ID);
                ?>
                <div class="swiper-slide <?php echo esc_attr($anim); ?>"
                <?php if($checked_anim) : ?> data-wow-delay="<?php echo esc_attr(($key * $anim_delay).'ms'); ?>" <?php endif; ?>>
                    <div class="pxl-post-item hover-parent">
                        <div class="pxl-post-featured <?php echo esc_attr($featured_hover_style); ?>">
                            <a href="<?php echo esc_url(get_permalink($post->ID)); ?>" class="pxl-featured-link">
                                <?php echo wp_kses_post($thumbnail); ?>
                            </a>
                            <div class="pxl-post-socials <?php echo esc_attr($show_social_style); ?>">
                                <?php pxl_print_html($social_share_content); ?>
                            </div>
                        </div>
                        <div class="pxl-post-content">
                            <<?php echo esc_attr($title_tag); ?> class="pxl-post-title <?php echo esc_attr($title_hover_style); ?>" 
                            <?php if($title_hover_style == 'hover-3d-cube-flip') : ?> data-text="<?php echo esc_attr(get_the_title($post->ID)); ?>" <?php endif; ?>>
                                <span class="pxl-title-text">
                                    <?php echo esc_html(get_the_title($post->ID)); ?>
                                </span>
                            </<?php echo esc_attr($title_tag); ?>>
                            <span class="pxl-post-position"><?php echo esc_html($position); ?></span>
                            <a href="<?php echo esc_url(get_permalink($post->ID)); ?>" class="pxl-box-link"></a>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php if(!empty($pagination)) : ?>
            <div class="swiper-pagination"></div>
        <?php endif; ?>
        <?php if($navigation) : ?>
            <div class="swiper-navigation <?php echo esc_attr($nav_hidden_class); ?>" 
            <?php if(!empty($nav_id)) : ?> data-navigation-id="<?php echo esc_attr($nav_id); ?>" <?php endif; ?>>
                <div class="pxl-swiper-button swiper-button-prev <?php echo esc_attr($nav_btn_style); ?>">
                    <span class="pxl-icon icon-prev">
                        <?php \Elementor\Icons_Manager::render_icon( $nav_btn_icon_prev, [ 'aria-hidden' => 'true', 'class' => 'pxl-button-icon' ], 'i' ); ?>
                    </span>
                </div>
                <div class="pxl-swiper-button swiper-button-next <?php echo esc_attr($nav_btn_style); ?>">
                    <span class="pxl-icon icon-next">
                        <?php \Elementor\Icons_Manager::render_icon( $nav_btn_icon_next, [ 'aria-hidden' => 'true', 'class' => 'pxl-button-icon' ], 'i' ); ?>
                    </span>
                </div>
            </div>
        <?php endif; ?>
    </div>
<?php endif; ?>