<?php
$html_id = pxl_get_element_id($settings);
$post_type = $widget->get_setting('post_type', 'team');
$tax = [$post_type.'-category'];

$layout = $widget->get_setting('layout_'.$post_type, 'team-1');
$select_post_by = $widget->get_setting('select_post_by', '');
$post_ids = ($select_post_by === 'post_selected') ? $widget->get_setting('source_'.$post_type.'_post_ids', '') : [];
$source = ($select_post_by === 'term_selected') ? $widget->get_setting('source_'.$post_type , '') : [];
$orderby = $widget->get_setting('orderby', 'date');
$order = $widget->get_setting('order', 'desc');
$limit = $widget->get_setting('limit', 6);
extract(pxl_get_posts_of_grid( 
    $post_type, 
    [
        'source' => $source, 
        'orderby' => $orderby, 
        'order' => $order, 
        'limit' => $limit, 
        'post_ids' => $post_ids
    ],
));

if( count($posts) <= 0) : ?>
    <div class="pxl-no-post-grid"><?php echo esc_html__( 'No Post Found', 'mouno' ); ?></div>;
    <?php return; ?>
<?php endif;

$featured_hover_style = $widget->get_setting('featured_hover_style', 'hover-image-default');
$title_hover_style = $widget->get_setting('title_hover_style', 'hover-text-default');
$show_social_style = $widget->get_setting('show_social_style', 'show-social-default');

$scrolling_effect = $widget->get_setting('scrolling_effect', '');
$anim = $widget->get_setting('entrance_anim', '');
$anim_delay = $widget->get_setting('anim_delay', 0);
$checked_anim = (!empty($anim) && $anim_delay != 0) || false;

$title_tag = $widget->get_setting('title_tag', 'h3');
$img_dimension = $widget->get_setting('img_dimension', 'full');
if($img_dimension === 'custom') {
    $img_dimension = $widget->get_setting('custom_img_dimension', ['width' => 767, 'height' => 1045]);
}
$show_social   = (bool)$widget->get_setting('show_social', '');
$show_position = (bool)$widget->get_setting('show_position', '');
$classes = '';
if($scrolling_effect === 'parallax') {
    $parallax_params = [
        'x' => $widget->get_setting('parallax_x', 0),
        'y' => $widget->get_setting('parallax_y', 0),
        'scale' => $widget->get_setting('parallax_scale', 0),
        'rotate' => $widget->get_setting('parallax_rotate', 0),
        'opacity' => $widget->get_setting('parallax_opacity', 0),
    ];
}
?>

<?php if($settings['layout_type'] === 'grid') : ?>
    <?php 
        $classes .= ' pxl-grid pxl-team-grid pxl-layout-team pxl-layout-team3';
        $column_xxl = $settings['column_xxl'] == '5' ? 'pxl-xxl5' : 12 / intval($widget->get_setting('column_xxl', 3));
        $column_xl  = $settings['column_xl'] == '5' ? 'pxl-xl5' : 12 / intval($widget->get_setting('column_xl', 3));
        $column_lg  = 12 / intval($widget->get_setting('column_lg', 3));
        $column_md  = 12 / intval($widget->get_setting('column_md', 2));
        $column_sm  = 12 / intval($widget->get_setting('column_sm', 2));
        $column_xs  = 12 / intval($widget->get_setting('column_xs', 1));
        $pagination = $widget->get_setting('grid_pagination', '');
        $load_more  = [
            'tax'                  => $tax,
            'post_type'            => $post_type,   
            'layout'               => $layout,
            'startPage'            => $paged,
            'maxPages'             => $max,
            'total'                => $total,
            'perpage'              => $limit,
            'nextLink'             => $next_link,
            'source'               => $source,
            'orderby'              => $orderby,
            'order'                => $order,
            'limit'                => $limit,
            'post_ids'             => $post_ids,
            'column_xxl'           => $column_xxl,
            'column_xl'            => $column_xl,
            'column_lg'            => $column_lg,
            'column_md'            => $column_md,
            'column_sm'            => $column_sm,
            'column_xs'            => $column_xs,
            'pagination'           => $pagination, 
            'featured_hover_style' => $featured_hover_style,
            'title_hover_style'    => $title_hover_style,
            'show_social_style'    => $show_social_style,
            'anim'                 => $anim,
            'anim_delay'           => $anim_delay,
            'scrolling_effect'    => $scrolling_effect,
            'show_social'          => $show_social,
            'show_position'        => $show_position,
            'img_dimension'        => $img_dimension,
            'checked_anim'         => $checked_anim,
            'title_tag'            => $title_tag,
            'parallax_params'      => $parallax_params ?? null,
        ];
        $wrap_attrs = [
            'id'               => $html_id,
            'class'            => $classes,
            'data-start-page'  => $paged,
            'data-max-pages'   => $max,
            'data-total'       => $total,
            'data-perpage'     => $limit,
            'data-next-link'   => $next_link,
            'data-loadmore'    => !empty($pagination) ? json_encode($load_more) : null,
        ];
        $widget->add_render_attribute( 'wrapper', $wrap_attrs );

        $grid_args = [
            'select_post_by'  => $select_post_by,
            'filter'          => false,
            'grid_class'      => 'pxl-grid-inner row',
            'load_more'       => $load_more,
            'grid_sizer'      => null,
            'posts'           => $posts,
            'query'           => $query,
            'next_link'       => $next_link,
            'categories'      => $categories, 
            'pagination'      => $pagination,
        ];    
    ?>
    <div <?php pxl_print_html($widget->get_render_attribute_string( 'wrapper' )) ?>>
        <?php mouno_render_post_grid($grid_args); ?>
        <span class="pxl-grid-loader"></span>
    </div>
<?php else: ?>
    <div class="pxl-notification">
        <?php echo esc_html__("This layout doesn's support carousel.", 'mouno'); ?>
    </div>
<?php endif; ?>