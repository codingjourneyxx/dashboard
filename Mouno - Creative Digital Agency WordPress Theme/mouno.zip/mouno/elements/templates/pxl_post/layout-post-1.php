<?php
$html_id = pxl_get_element_id($settings);
$post_type = $widget->get_setting('post_type', 'post');
$tax = ['category'];

$layout = $widget->get_setting('layout_'.$post_type, 'post-1');
$select_post_by = $widget->get_setting('select_post_by', '');
$post_ids = ($select_post_by === 'post_selected') ? $widget->get_setting('source_'.$post_type.'_post_ids', '') : [];
$source = ($select_post_by === 'term_selected') ? $widget->get_setting('source_'.$post_type , '') : [];
$orderby = $widget->get_setting('orderby', 'date');
$order = $widget->get_setting('order', 'desc');
$limit = $widget->get_setting('limit', 6);
extract(pxl_get_posts_of_grid( 
    $post_type, 
    [
        'source' => $source, 
        'orderby' => $orderby, 
        'order' => $order, 
        'limit' => $limit, 
        'post_ids' => $post_ids
    ],
));

if( count($posts) <= 0) : ?>
    <div class="pxl-no-post-grid"><?php echo esc_html__( 'No Post Found', 'mouno' ); ?></div>
    <?php return;
endif;

$filter = $widget->get_setting('filter', 'disable');
$filter_type = $widget->get_setting('filter_type', 'normal');

$layout_style = $widget->get_setting('layout1_style', 'layout-post-default');
$anim = $widget->get_setting('entrance_anim', '');
$anim_delay = $widget->get_setting('anim_delay', 0);
$checked_anim = (!empty($anim) && $anim_delay != 0) || false;

$title_tag = $widget->get_setting('title_tag', 'h5');
$img_dimension = $widget->get_setting('img_dimension', 'custom');
$custom_img_dimension = $widget->get_setting('custom_img_dimension', []);
if($img_dimension === 'custom' && empty($custom_img_dimension['width']) && empty($custom_img_dimension['height'])) {
    switch($layout_style) {
        case 'layout-post-style1' :
            $img_dimension =  ['width' => 767, 'height' => 572];
            break;
        default : 
            $img_dimension =  ['width' => 767, 'height' => 558];
            break;
    }
}

$featured_hover_style = $widget->get_setting('featured_hover_style' , 'hover-image-default');
$title_hover_style = $widget->get_setting('title_hover_style', 'hover-text-default');
$displacement_img     = $widget->get_setting('displacement_img', ['url' => '']);
$show_date   = (bool)$widget->get_setting('show_date', '');
$show_author = (bool)$widget->get_setting('show_author', '');

if($settings['layout_type'] === 'grid') : 
    $masonry    = (bool)$widget->get_setting('grid_masonry', '');
    $masonry    = ($masonry || $filter === 'enable')  ? 'pxl-grid-masonry' : null;
    $column_xxl = $widget->get_setting('column_xxl', 1);
    $column_xl  = $widget->get_setting('column_xl', 1);
    $column_lg  = $widget->get_setting('column_lg', 1);
    $column_md  = $widget->get_setting('column_md', 1);
    $column_sm  = $widget->get_setting('column_sm', 1);
    $column_xs  = $widget->get_setting('column_xs', 1);
    if($column_xxl == 1 && $column_xl == 1 && $column_lg == 1 && $column_md == 1 && $column_sm == 1 && $column_xs == 1){
        switch($layout_style) {
            case 'layout-post-style2':
            case 'layout-post-style1':
                $column_xxl = $column_xxl == '5' ? 'pxl-xxl5' : (int)12 /  2;
                $column_xl  = $column_xl  == '5' ? 'pxl-xl5'  : (int)12 / 2;
                $column_lg  = (int)12 / 2;
                $column_md  = (int)12 / 2;
                $column_sm  = (int)12 / 1;
                $column_xs  = (int)12 / 1;
                break;
            default : 
                $column_xxl = $column_xxl == '5' ? 'pxl-xxl5' : (int)12 /  3;
                $column_xl  = $column_xl  == '5' ? 'pxl-xl5'  : (int)12 / 3;
                $column_lg  = (int)12 / 3;
                $column_md  = (int)12 / 2;
                $column_sm  = (int)12 / 2;
                $column_xs  = (int)12 / 1;
                break;
        }
    }
    $pagination = $widget->get_setting('grid_pagination', '');
    $load_more_style = $widget->get_setting('load_more_style', 'load-more-button-default');
    $load_more_text = $widget->get_setting('load_more_text', 'Load More');
    $load_more_icon = $widget->get_setting('load_more_icon', []);
    ob_start();
    \Elementor\Icons_Manager::render_icon( $load_more_icon, [ 'aria-hidden' => 'true', 'class' => '' ], 'i' );
    $load_more_icon = ob_get_clean();
    $show_divider_el = (bool)$widget->get_setting('show_divider_el', '');
    $grid_class = trim('pxl-grid-inner row '.$masonry);
    $grid_sizer = ($masonry || $filter === 'enable') ? "col-xxl-{$column_xxl} col-xl-{$column_xl} col-lg-{$column_lg} col-md-{$column_md} col-sm-{$column_sm} col-{$column_xs}" : null;
    $load_more = array(
        'tax'             => $tax,
        'post_type'       => $post_type,   
        'layout'          => $layout,
        'startPage'       => $paged,
        'maxPages'        => $max,
        'total'           => $total,
        'filter'          => $filter,
        'filter_type'     => $filter_type,
        'perpage'         => $limit,
        'nextLink'        => $next_link,
        'source'          => $source,
        'orderby'         => $orderby,
        'order'           => $order,
        'limit'           => $limit,
        'post_ids'        => $post_ids,
        'column_xxl'      => $column_xxl,
        'column_xl'       => $column_xl,
        'column_lg'       => $column_lg,
        'column_md'       => $column_md,
        'column_sm'       => $column_sm,
        'column_xs'       => $column_xs,
        'pagination'      => $pagination, 
        'anim'            => $anim,
        'anim_delay'      => $anim_delay,
        'checked_anim'    => $checked_anim,
        'img_dimension'   => $img_dimension,
        'title_tag'       => $title_tag,
        'title_hover_style' => $title_hover_style,
        'featured_hover_style' => $featured_hover_style,
        'show_date'       => $show_date,
        'show_author'     => $show_author
    );
    $wrap_attrs = [
        'id'               => $html_id,
        'class'            => trim('pxl-grid pxl-post-grid pxl-layout-post pxl-layout-post1 '.$layout_style),
        'data-start-page'  => $paged,
        'data-max-pages'   => $max,
        'data-total'       => $total,
        'data-perpage'     => $limit,
        'data-next-link'   => $next_link,
        'data-loadmore'    => !empty($pagination) ? json_encode($load_more) : null,
    ];
    $widget->add_render_attribute( 'wrapper', $wrap_attrs );

    $grid_args = [
        'select_post_by'       => $select_post_by,
        'filter'               => $filter,
        'filter_type'          => $filter_type,
        'load_more_style'      => $load_more_style,
        'load_more_text'       => $load_more_text,
        'load_more_icon'       => $load_more_icon,
        'grid_class'           => $grid_class,
        'load_more'            => $load_more,
        'grid_sizer'           => $grid_sizer,
        'pagination'           => $pagination,
        'posts'                => $posts,
        'query'                => $query,
        'next_link'            => $next_link,
        'categories'           => $categories,
        'divider_el'           => $show_divider_el ? 'has-divider' : null,
    ]; 
?>
    <div <?php pxl_print_html($widget->get_render_attribute_string( 'wrapper' )) ?>>
        <?php mouno_render_post_grid($grid_args); ?>
        <span class="pxl-grid-loader"></span>
    </div>
<?php else: 
   $effect                 = $widget->get_setting('effect', 'slide');
   $autoplay               = $widget->get_setting('autoplay', false);
   $disable_on_interaction = $widget->get_setting('disable_on_interaction', false);
   $delay                  = $widget->get_setting('delay', 5000);
   $loop                   = $widget->get_setting('loop', false);
   $speed                  = $widget->get_setting('speed', 500);
   $space_between          = $widget->get_setting('space_between', 40);
   $pagination             = $widget->get_setting('swiper_pagination', '');
   $navigation             = $widget->get_setting('swiper_navigation', false);
   $slides_per_view        = $widget->get_setting('slides_per_view', 'auto');
   $slides_per_view_xs     = $widget->get_setting('slides_per_view_xs', 1);
   $slides_per_view_sm     = $widget->get_setting('slides_per_view_sm', 1);
   $slides_per_view_md     = $widget->get_setting('slides_per_view_md', 1);
   $slides_per_view_lg     = $widget->get_setting('slides_per_view_lg', 1);
   $slides_per_view_xl     = $widget->get_setting('slides_per_view_xl', 1);
   $slides_per_view_xxl    = $widget->get_setting('slides_per_view_xxl', 1);

   if($slides_per_view_xxl == 1 && $slides_per_view_xl == 1 && $slides_per_view_lg == 1 && $slides_per_view_md == 1 && $slides_per_view_sm == 1 && $slides_per_view_xs == 1){
    switch($layout_style) {
        case 'layout-post-style2':
        case 'layout-post-style1':
            $slides_per_view_xs  = 1;
            $slides_per_view_sm  = 1;
            $slides_per_view_md  = 2;
            $slides_per_view_lg  = 2;
            $slides_per_view_xl  = 2;
            $slides_per_view_xxl = 2;
            break;
        default : 
            $slides_per_view_xs  = 1;
            $slides_per_view_sm  = 2;
            $slides_per_view_md  = 2;
            $slides_per_view_lg  = 3;
            $slides_per_view_xl  = 3;
            $slides_per_view_xxl = 3;
            break;
    }
}
   $swiperParams           = [
       'effect'                 => $effect, 
       'direction'              => 'horizontal', 
       'autoplay'               => (bool)$autoplay,
       'disable_on_interaction' => (bool)$disable_on_interaction,
       'delay'                  => $delay,
       'loop'                   => (bool)$loop,
       'speed'                  => $speed,
       'space_between'          => $space_between,
       'pagination'             => $pagination,
       'navigation'             => (bool)$navigation,
       'slides_per_view'        => $slides_per_view,
       'slides_per_view_xs'     => (int)$slides_per_view_xs,
       'slides_per_view_sm'     => (int)$slides_per_view_sm,
       'slides_per_view_md'     => (int)$slides_per_view_md,
       'slides_per_view_lg'     => (int)$slides_per_view_lg,
       'slides_per_view_xl'     => (int)$slides_per_view_xl,
       'slides_per_view_xxl'    => (int)$slides_per_view_xxl,
   ];

   $swiperParams = json_encode($swiperParams);
   $nav_btn_icon_prev  = $widget->get_setting('nav_btn_icon_prev', []);
   $nav_btn_icon_next  = $widget->get_setting('nav_btn_icon_next', []);
   $nav_id = $widget->get_setting('nav_id', '');
   $nav_hidden_class = !empty($nav_id) ? 'swiper-navigation-hidden' : null;
   $nav_btn_style = $widget->get_setting('nav_btn_style', 'swiper-button-default');
    ?>
    <div class="pxl-swiper pxl-post-carousel pxl-layout-post pxl-layout-post1 <?php echo esc_attr($layout_style); ?>">
        <div class="swiper-container" data-swiper = "<?php echo esc_attr($swiperParams); ?>">
            <div class="swiper-wrapper">
                <?php foreach($posts as $key => $post) : 
                    $thumbnail = mouno_get_image_by_size([
                        'img_dimension' => $img_dimension ,
                        'attr' => [
                            'class' => 'pxl-image-featured',
                        ],
                    ], $post->ID);
                    $author_id = get_post_field ('post_author', $post->ID);    
                ?>
                    <div class="swiper-slide <?php echo esc_attr($anim); ?>"
                    <?php if($checked_anim == true): ?> data-wow-delay="<?php echo esc_attr(($key * $anim_delay).'ms'); ?>" <?php endif; ?>>
                        <div class="pxl-post-item hover-parent">
                            <span class="pxl-post-featured <?php echo esc_attr($featured_hover_style); ?>">
                                <a href="<?php echo esc_url(get_permalink($post->ID)); ?>" class="pxl-featured-link">
                                    <?php echo wp_kses_post($thumbnail); ?>
                                </a>
                            </span>
                            <div class="pxl-post-content ">
                                <?php if($show_date == true) : ?>
                                    <div class="pxl-post-date"><?php echo get_the_date('d M Y', $post->ID); ?></div>
                                <?php endif; ?>
                                <<?php echo esc_attr($title_tag); ?> class="pxl-post-title <?php echo esc_attr($title_hover_style); ?>"
                                <?php if($title_hover_style == 'hover-3d-cube-flip') : ?> data-text="<?php echo esc_attr(get_the_title($post->ID)); ?>" <?php endif; ?>>
                                    <span class="pxl-title-text">
                                        <?php echo esc_html(get_the_title($post->ID)); ?>
                                    </span>
                                </<?php echo esc_attr($title_tag); ?>>
                                <?php if($show_author == true) : ?>
                                    <span class="pxl-post-author">
                                        <a href="<?php echo esc_url(get_author_posts_url($author_id)); ?>" class="pxl-author-link">
                                            <?php echo esc_attr('BY '.get_the_author_meta('display_name', $author_id)); ?>
                                        </a>
                                    </span>
                                <?php endif; ?>
                                <a href="<?php echo esc_url(get_permalink($post->ID)); ?>" class="pxl-box-link"></a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php if(!empty($pagination)) : ?>
            <div class="swiper-pagination"></div>
        <?php endif; ?>
        <?php if($navigation) : ?>
            <div class="swiper-navigation <?php echo esc_attr($nav_hidden_class); ?>" 
            <?php if(!empty($nav_id)) : ?> data-navigation-id="<?php echo esc_attr($nav_id); ?>" <?php endif; ?>>
                <div class="pxl-swiper-button swiper-button-prev <?php echo esc_attr($nav_btn_style); ?>">
                    <span class="pxl-icon icon-prev">
                        <?php \Elementor\Icons_Manager::render_icon( $nav_btn_icon_prev, [ 'aria-hidden' => 'true', 'class' => 'pxl-button-icon' ], 'i' ); ?>
                    </span>
                </div>
                <div class="pxl-swiper-button swiper-button-next <?php echo esc_attr($nav_btn_style); ?>">
                    <span class="pxl-icon icon-next">
                        <?php \Elementor\Icons_Manager::render_icon( $nav_btn_icon_next, [ 'aria-hidden' => 'true', 'class' => 'pxl-button-icon' ], 'i' ); ?>
                    </span>
                </div>
            </div>
        <?php endif; ?>
    </div>
<?php endif; ?>