<?php 
    $entrance_anim = $widget->get_setting('entrance_anim', '');
    $counter_style = $widget->get_setting('counter_style', '');
?>

<div class="pxl-counter-wrapper pxl-counter-wrapper1 <?php echo esc_attr($counter_style.' '.$entrance_anim); ?>">
    <div class="pxl-counter-number ">
        <?php if($settings['number_effect'] === 'effect-draw') : ?>
            <svg class="dynamic-svg" xmlns="http://www.w3.org/2000/svg">
                <text class="visibility-hidden" x="0" y="50%" dominant-baseline="central" text-anchor="center" >
                    <?php if(!empty($settings['number_prefix'])) : ?><tspan class="pxl-number-prefix"><?php pxl_print_html($settings['number_prefix']); ?></tspan><?php endif; ?> <tspan class="pxl-number-value"><?php echo esc_html($settings['ending_number']); ?></tspan><?php if(!empty($settings['number_suffix'])) : ?><tspan class="pxl-number-suffix"><?php pxl_print_html($settings['number_suffix']); ?></tspan><?php endif; ?>
                </text>
            </svg>
        <?php else : ?>
            <?php 
                $widget->add_render_attribute( 'counter', [
                    'class' => 'pxl-number-value '.$settings['number_effect'].'',
                    'data-duration' => 1200,
                    'data-startnumber' => $settings['starting_number'],
                    'data-endnumber' => $settings['ending_number'],
                    'data-to-value' => $settings['ending_number'],
                    'data-delimiter' => $settings['thousand_separator_char'],
                ]); 
            ?>   
            <?php if(!empty($settings['number_prefix'])) : ?>
                <span class="pxl-number-prefix"><?php pxl_print_html($settings['number_prefix']); ?></span>
            <?php endif; ?> 
            <span <?php pxl_print_html($widget->get_render_attribute_string( 'counter' )); ?>><?php echo esc_html($settings['starting_number']); ?></span>
            <?php if(!empty($settings['number_suffix'])) : ?>
                <span class="pxl-number-suffix"><?php pxl_print_html($settings['number_suffix']); ?></span>
            <?php endif; ?> 
        <?php endif; ?>
    </div>
    <?php if(!empty($settings['show_title'])) : ?>
        <<?php echo esc_attr($settings['title_tag']); ?> class="pxl-counter-title">
            <span class="pxl-title-text"><?php pxl_print_html($settings['title']); ?></span>
        </<?php echo esc_attr($settings['title_tag']); ?>>
    <?php endif; ?>
</div>