<?php
$html_id = pxl_get_element_id($settings);
$post_type = $widget->get_setting('post_type', 'portfolio');
$tax = [$post_type.'-category'];

$layout = $widget->get_setting('layout_'.$post_type, 'portfolio-1');
$select_post_by = $widget->get_setting('select_post_by', '');
$post_ids = ($select_post_by === 'post_selected') ? $widget->get_setting('source_'.$post_type.'_post_ids', '') : [];
$source = ($select_post_by === 'term_selected') ? $widget->get_setting('source_'.$post_type , '') : [];
$orderby = $widget->get_setting('orderby', 'date');
$order = $widget->get_setting('order', 'desc');
$limit = $widget->get_setting('limit', 6);
extract(pxl_get_posts_of_grid( 
    $post_type, 
    [
        'source' => $source, 
        'orderby' => $orderby, 
        'order' => $order, 
        'limit' => $limit, 
        'post_ids' => $post_ids
    ],
));

if( count($posts) <= 0) : ?>
    <div class="pxl-no-post-grid"><?php echo esc_html__( 'No Post Found', 'mouno' ); ?></div>
    <?php return;
endif;

$filter = $widget->get_setting('filter', 'false');
$filter_type = $widget->get_setting('filter_type', 'normal');

$anim = $widget->get_setting('entrance_anim', '');
$anim_delay = $widget->get_setting('anim_delay', 0);
$checked_anim = (!empty($anim) && $anim_delay != 0) || false;

$title_tag = $widget->get_setting('title_tag', 'h3');
$img_dimension = $widget->get_setting('img_dimension', 'custom');
if($img_dimension === 'custom') {
    $custom_img_dimension = $widget->get_setting('custom_img_dimension', []);
    $img_dimension = !empty($custom_img_dimension['width']) || !empty($custom_img_dimension['height']) ? $custom_img_dimension : ['width' => 919, 'height' => 632];
}

$show_index = (bool)$widget->get_setting('show_index', '');
$show_order = (bool)$widget->get_setting('show_order', '');
$show_category = (bool)$widget->get_setting('show_category', '');
$show_excerpt = (bool)$widget->get_setting('show_excerpt' , '');
$num_words = $widget->get_setting('num_words' , 20);
$show_btn = (bool)$widget->get_setting('show_btn' , '');
$btn_text = $widget->get_setting('btn_text' , 'Read More');
$featured_hover_style = $widget->get_setting('featured_hover_style' , 'hover-image-default');
$title_hover_style = $widget->get_setting('title_hover_style', 'hover-text-default');
$displacement_img     = $widget->get_setting('displacement_img', ['url' => '']);

if($settings['layout_type'] === 'grid') :
    $pagination = $widget->get_setting('grid_pagination', '');
    $load_more_style = $widget->get_setting('load_more_style', 'load-more-button-default');
    $load_more_text = $widget->get_setting('load_more_text', 'Load More');
    $load_more_icon = $widget->get_setting('load_more_icon', []);
    ob_start();
    \Elementor\Icons_Manager::render_icon( $load_more_icon, [ 'aria-hidden' => 'true', 'class' => '' ], 'i' );
    $load_more_icon = ob_get_clean();
    $show_divider_el = (bool)$widget->get_setting('show_divider_el', '');
    $grid_class = trim('pxl-grid-inner row');    
    $load_more = array(
        'tax'             => $tax,
        'post_type'       => $post_type,   
        'layout'          => $layout,
        'startPage'       => $paged,
        'maxPages'        => $max,
        'total'           => $total,
        'filter'          => $filter,
        'filter_type'     => $filter_type,
        'perpage'         => $limit,
        'nextLink'        => $next_link,
        'source'          => $source,
        'orderby'         => $orderby,
        'order'           => $order,
        'limit'           => $limit,
        'post_ids'        => $post_ids,
        'pagination'      => $pagination,
        'anim'             => $anim,
        'anim_delay'       => $anim_delay,
        'checked_anim'     => $checked_anim,
        'title_tag'       => $title_tag,
        'img_dimension'   => $img_dimension,
        'show_order'      => $show_order,
        'show_index'      => $show_index,
        'show_category'   => $show_category,
        'show_excerpt'    => $show_excerpt,
        'num_words'       => $num_words,
        'show_btn'        => $show_btn,
        'btn_text'        => $btn_text,
        'featured_hover_style' => $featured_hover_style,
        'title_hover_style' => $title_hover_style,
        'displacement_url'     => $displacement_img['url'],
    );
    $wrap_attrs = [
        'id'               => $html_id,
        'class'            => 'pxl-grid pxl-portfolio-grid pxl-layout-portfolio pxl-layout-portfolio2',
        'data-start-page'  => $paged,
        'data-max-pages'   => $max,
        'data-total'       => $total,
        'data-perpage'     => $limit,
        'data-next-link'   => $next_link,
        'data-loadmore'    => !empty($pagination) ? json_encode($load_more) : null,
    ];
    $widget->add_render_attribute( 'wrapper', $wrap_attrs );

    $grid_args = [
        'select_post_by'       => $select_post_by,
        'filter'               => $filter,
        'filter_type'          => $filter_type,
        'load_more_style'      => $load_more_style,
        'load_more_text'       => $load_more_text,
        'load_more_icon'       => $load_more_icon,
        'grid_class'           => $grid_class,
        'load_more'            => $load_more,
        'grid_sizer'           => null,
        'pagination'           => $pagination,
        'posts'                => $posts,
        'query'                => $query,
        'next_link'            => $next_link,
        'categories'           => $categories,
        'divider_el'           => $show_divider_el ? 'has-divider' : null,
    ];    
?>
    <div <?php pxl_print_html($widget->get_render_attribute_string( 'wrapper' )) ?>>
        <?php mouno_render_post_grid($grid_args); ?>
        <span class="pxl-grid-loader"></span>
    </div>
<?php else: ?>
    <div class="pxl-notification">
        <?php echo esc_html('This '); ?>
    </div>
<?php endif; ?>