<?php
$html_id = pxl_get_element_id($settings);
$post_type = $widget->get_setting('post_type', 'portfolio');
$tax = [$post_type.'-category'];

$layout = $widget->get_setting('layout_'.$post_type, 'portfolio-1');
$select_post_by = $widget->get_setting('select_post_by', '');
$post_ids = ($select_post_by === 'post_selected') ? $widget->get_setting('source_'.$post_type.'_post_ids', '') : [];
$source = ($select_post_by === 'term_selected') ? $widget->get_setting('source_'.$post_type , '') : [];
$orderby = $widget->get_setting('orderby', 'date');
$order = $widget->get_setting('order', 'desc');
$limit = $widget->get_setting('limit', 6);
extract(pxl_get_posts_of_grid( 
    $post_type, 
    [
        'source' => $source, 
        'orderby' => $orderby, 
        'order' => $order, 
        'limit' => $limit, 
        'post_ids' => $post_ids
    ],
));

if( count($posts) <= 0) : ?>
    <div class="pxl-no-post-grid"><?php echo esc_html__( 'No Post Found', 'mouno' ); ?></div>
    <?php return;
endif;

$filter = $widget->get_setting('filter', 'disable');
$filter_type = $widget->get_setting('filter_type', 'normal');

$anim = $widget->get_setting('entrance_anim', '');
$anim_delay = $widget->get_setting('anim_delay', 0);
$checked_anim = (!empty($anim) && $anim_delay != 0) || false;

$title_tag = $widget->get_setting('title_tag', 'h5');
$img_dimension = $widget->get_setting('img_dimension', 'custom');
if($img_dimension === 'custom') {
    $custom_img_dimension = $widget->get_setting('custom_img_dimension', []);
    $img_dimension = !empty($custom_img_dimension['width']) || !empty($custom_img_dimension['height']) ? $custom_img_dimension : ['width' => 1193, 'height' => 587];
}

$show_category = (bool)$widget->get_setting('show_category', '');
$layout_style = $widget->get_setting('layout1_style', '');
$featured_hover_style = $widget->get_setting('featured_hover_style' , 'hover-image-default');
$title_hover_style    = $widget->get_setting('title_hover_style', 'hover-text-default');
$displacement_img     = $widget->get_setting('displacement_img', ['url' => '']);
$box_content_follow_cursor     = !empty($settings['box_content_follow_cursor']) ? 'follow-cursor' : null;

if($settings['layout_type'] === 'grid') :
    $column_xxl = $settings['column_xxl'] == '5' ? 'pxl-xxl5' : 12 / intval($widget->get_setting('column_xxl', 2));
    $column_xl  = $settings['column_xl'] == '5' ? 'pxl-xl5' : 12 / intval($widget->get_setting('column_xl', 2));
    $column_lg  = 12 / intval($widget->get_setting('column_lg', 2));
    $column_md  = 12 / intval($widget->get_setting('column_md', 2));
    $column_sm  = 12 / intval($widget->get_setting('column_sm', 2));
    $column_xs  = 12 / intval($widget->get_setting('column_xs', 1));
    $pagination = $widget->get_setting('grid_pagination', '');
    $load_more_style = $widget->get_setting('load_more_style', 'load-more-button-default');
    $load_more_text = $widget->get_setting('load_more_text', 'Load More');
    $load_more_icon = $widget->get_setting('load_more_icon', []);
    ob_start();
    \Elementor\Icons_Manager::render_icon( $load_more_icon, [ 'aria-hidden' => 'true', 'class' => '' ], 'i' );
    $load_more_icon = ob_get_clean();
    $show_divider_el = (bool)$widget->get_setting('show_divider_el', '');

    $masonry    = $widget->get_setting('grid_masonry', '');
    $masonry_class = (!empty($masonry) || $filter === 'enable')  ? 'pxl-grid-masonry' : null;
    $masonry_items = $widget->get_setting('masonry_items', []);

    $grid_class = trim('pxl-grid-inner row '.$masonry_class);
    if($masonry !== 'fitRows' && $filter === 'enable') {
        $masonry = 'masonry';
        $grid_sizer = "col-xxl-{$column_xxl} col-xl-{$column_xl} col-lg-{$column_lg} col-md-{$column_md} col-sm-{$column_sm} col-{$column_xs}";
    }elseif($masonry === 'fitRows') {
        $grid_sizer = null;
    }
    $load_more = array(
        'tax'             => $tax,
        'post_type'       => $post_type,   
        'layout'          => $layout,
        'startPage'       => $paged,
        'maxPages'        => $max,
        'total'           => $total,
        'filter'          => $filter,
        'filter_type'     => $filter_type,
        'perpage'         => $limit,
        'nextLink'        => $next_link,
        'source'          => $source,
        'orderby'         => $orderby,
        'order'           => $order,
        'limit'           => $limit,
        'post_ids'        => $post_ids,
        'column_xxl'      => $column_xxl,
        'column_xl'       => $column_xl,
        'column_lg'       => $column_lg,
        'column_md'       => $column_md,
        'column_sm'       => $column_sm,
        'column_xs'       => $column_xs,
        'pagination'      => $pagination, 
        'anim'            => $anim,
        'anim_delay'      => $anim_delay,
        'checked_anim'    => $checked_anim,
        'featured_hover_style' => $featured_hover_style,
        'title_hover_style'    => $title_hover_style,
        'displacement_url'     => $displacement_img['url'],
        'show_category'   => $show_category,
        'img_dimension'   => $img_dimension,
        'title_tag'       => $title_tag,
        'box_content_follow_cursor' => $box_content_follow_cursor,
        'masonry'         => $masonry,
        'masonry_items'  => $masonry_items,
    );
    $wrap_attrs = [
        'id'               => $html_id,
        'class'            => 'pxl-grid pxl-portfolio-grid pxl-layout-portfolio pxl-layout-portfolio5',
        'data-start-page'  => $paged,
        'data-max-pages'   => $max,
        'data-total'       => $total,
        'data-perpage'     => $limit,
        'data-next-link'   => $next_link,
        'data-loadmore'    => !empty($pagination) ? json_encode($load_more) : null,
    ];
    if(!empty($masonry)) {
        $wrap_attrs['data-masonry-layout']= $masonry;
    }
    $widget->add_render_attribute( 'wrapper', $wrap_attrs );
    $grid_args = [
        'select_post_by'       => $select_post_by,
        'filter'               => $filter,
        'filter_type'          => $filter_type,
        'load_more_style'      => $load_more_style,
        'load_more_text'       => $load_more_text,
        'load_more_icon'       => $load_more_icon,
        'grid_class'           => $grid_class,
        'load_more'            => $load_more,
        'grid_sizer'           => $grid_sizer,
        'pagination'           => $pagination,
        'posts'                => $posts,
        'query'                => $query,
        'next_link'            => $next_link,
        'categories'           => $categories,
        'divider_el'           => $show_divider_el ? 'has-divider' : null,
    ]; 
?>
    <div <?php pxl_print_html($widget->get_render_attribute_string('wrapper')) ?>>
        <?php mouno_render_post_grid($grid_args); ?>
        <span class="pxl-grid-loader"></span>
    </div>
<?php else: ?>
    <div class="pxl-notification">
        <span><?php echo esc_html__("This layout doesn's support carousel!", 'mouno'); ?></span>
    </div>
<?php endif;