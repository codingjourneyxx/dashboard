<?php
    $img_dimension = $widget->get_setting('img_dimension', 'full');
    $custom_img_dimension = $widget->get_setting('custom_img_dimension', ['width' => 0, 'height' => 0]);
    $img_hover_effect = $widget->get_setting('img_hover_effect', '');
    $img = $widget->get_setting('img', []);
    $scrolling_effect = $widget->get_setting('scrolling_effect', '');
    $anim_effect = $widget->get_setting('anim_effect', '');

    if($scrolling_effect === 'parallax') {
        $parallax_params = [
            'x' => $widget->get_setting('parallax_x', 0),
            'y' => $widget->get_setting('parallax_y', 0),
            'scale' => $widget->get_setting('parallax_scale', 0),
            'rotate' => $widget->get_setting('parallax_rotate', 0),
            'opacity' => $widget->get_setting('parallax_opacity', 0),
        ];
        $parallax_params = json_encode($parallax_params);
    }

    $thumbnail = mouno_get_image_by_size([
        'img_id' => $img['id'],
        'img_dimension' => ($img_dimension !== 'custom') ? $img_dimension : $custom_img_dimension,
        'attr' => [
            'class' => 'pxl-image '.$img_hover_effect,
        ]
    ]);
    $entrance_anim = $widget->get_setting('entrance_anim', '');
?>
<div class="pxl-image-wrapper <?php echo esc_attr($entrance_anim); ?>">
    <span class="pxl-image-item <?php echo esc_attr($anim_effect); ?>" <?php if(isset($parallax_params)) : ?> data-parallax="<?php echo esc_attr($parallax_params); ?>" <?php endif; ?>>
        <?php pxl_print_html($thumbnail); ?>
    </span>
</div>