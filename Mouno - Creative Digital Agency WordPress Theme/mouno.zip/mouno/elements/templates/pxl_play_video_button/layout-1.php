<div class="pxl-play-video-button-wrapper">
    <a <?php pxl_print_html(mouno_render_link_attributes($settings['video_link'])); ?> class="btn pxl-play-video-button pxl-action-popup <?php echo esc_attr($settings['btn_style']); ?>">
        <?php \Elementor\Icons_Manager::render_icon( $settings['btn_icon'], [ 'aria-hidden' => 'true', 'class' => '' ], 'i' ); ?>
    </a>
</div>