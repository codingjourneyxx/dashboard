<?php 
$index = $widget->get_setting('index', '0');
$title = $widget->get_setting('title', 'Heading Title');
$desc  = $widget->get_setting('desc', 'Lorem ipsum dolor amet consectet adipiscing elit, sed eiusmod tempor incididunt ut labore et.');
?>
<div class="pxl-index-box-wrapper">
    <div class="pxl-index-box-number">
        <span class="pxl-index"><?php echo esc_html($index); ?></span>
    </div>
    <div class="pxl-index-box-content">
        <h4 class="pxl-index-box-title">
            <span class="pxl-title-text">
                <?php echo esc_html($title); ?>
            </span>
        </h4>
        <p class="pxl-index-box-description">
            <?php echo esc_html($desc); ?>
        </p>
    </div>
</div>