
<?php
    $is_items = (isset($settings['items']) && !empty($settings['items']) && count($settings['items'])) || false;
?>

<?php if($is_items) : ?> 
    <div class="pxl-progress-bar pxl-progress-bar1">
        <div class="pxl-item--container">
            <div class="pxl-item--inner">
                <ul class="pxl-item--list">
                    <?php foreach($settings['items'] as $item): ?>
                        <?php 
                            $percent = !empty($item['percent']['size']) ? $item['percent']['size'].'%' : '50%';
                        ?>
                        <div class="pxl-item--single" style="--pxl-width: <?php echo esc_attr($percent); ?>">
                            <div class="pxl-item--info">
                                <div class="pxl-item--title">
                                    <?php echo esc_html($item['title']); ?>
                                </div>
                                <span class="pxl-item--percent"><?php echo esc_html($percent); ?></span>
                            </div>
                            <div class="pxl-item--track">
                                <span class="pxl-item--fill wow growWidth"></span>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </ul>
            </div>
        </div>
    </div>
<?php endif; ?>