<div class="pxl-heading-wrapper">
	<?php if($settings['view'] !== 'only-title') : ?>
		<?php 
			$subtitle = $widget->parse_text_editor( $settings['subtitle'] ?? '' );
			$subtitle_style  = $widget->get_setting( 'subtitle_style', '');
			$subtitle_gsap_stagger = $widget->get_setting('subtitle_gsap_stagger', 0);
			$subtitle_gsap_duration = $widget->get_setting('subtitle_gsap_duration', 1);
			$subtitle_gsap_delay = $widget->get_setting('subtitle_gsap_delay', 0);
			$subtitle_entrance_anim = $widget->get_setting('subtitle_entrance_anim', '');
			$subtitle_text_entrance_anim = $widget->get_setting('subtitle_text_entrance_anim', '');
			$subtitle_anim_works_in = $widget->get_setting('subtitle_anim_works_in', '');

			if(is_singular('portfolio') && $subtitle_style === 'heading-subtitle-portfolio') {
				ob_start();
				the_terms(get_the_ID(), 'portfolio-category', '', ' ');
				$subtitle = ob_get_clean();
			}

		?>
		<div class="<?php echo esc_attr('pxl-heading-subtitle '.$subtitle_style.' '.$subtitle_entrance_anim.' '.$subtitle_text_entrance_anim.' '.$subtitle_anim_works_in); ?>"
		<?php 
			if(isset($subtitle_text_entrance_anim) && !empty($subtitle_text_entrance_anim)) {
				$gsap_params = [
					'stagger' => $subtitle_gsap_stagger,
					'duration' => $subtitle_gsap_duration,
					'delay' => $subtitle_gsap_delay,
				];
				$gsap_params = json_encode($gsap_params);
				echo 'data-gsap="'.esc_attr($gsap_params).'"';
			}
		?>>
			<div class="pxl-subtitle-text">
				<?php pxl_print_html($subtitle); ?>
			</div>
		</div>
	<?php endif; ?>

	<?php if($settings['view'] !== 'only-subtitle') : ?>
		<?php 
			$title = $widget->parse_text_editor( $settings['title'] ?? '' ); 
			$title_gsap_stagger = $widget->get_setting('title_gsap_stagger', 0);
			$title_gsap_duration = $widget->get_setting('title_gsap_duration', 1);
			$title_gsap_delay = $widget->get_setting('title_gsap_delay', 0);
			$title_entrance_anim = $widget->get_setting('title_entrance_anim', '');
			$title_text_entrance_anim = $widget->get_setting('title_text_entrance_anim', '');
			$title_anim_works_in = $widget->get_setting('title_anim_works_in', '');
			$underline_anim = ($settings['title_style'] === 'heading-title-underline') ? 'wow textUnderlineSlide' : null;
		?>
		<<?php echo esc_attr($settings['title_tag']); ?> class="<?php echo esc_attr('pxl-heading-title '.$settings['title_style'].' '.$title_entrance_anim.' '.$title_text_entrance_anim.' '.$title_anim_works_in); ?>"
			<?php 
				if(isset($title_text_entrance_anim) && !empty($title_text_entrance_anim)) {
					$gsap_params = [
						'stagger' => $title_gsap_stagger,
						'duration' => $title_gsap_duration,
						'delay' => $title_gsap_delay,
					];
					$gsap_params = json_encode($gsap_params);
					echo 'data-gsap="'.esc_attr($gsap_params).'"';
				}
			?>
		>
			<span class="pxl-title-text <?php echo esc_attr($underline_anim); ?>" >
				<?php pxl_print_html($title); ?>
			</span>
		</<?php echo esc_attr($settings['title_tag']); ?>>
	<?php endif; ?>
</div>
