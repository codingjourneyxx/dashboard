<?php 
    $post_id = get_the_ID();
    $title_tag = $widget->get_setting('title_tag', 'h2');
    $custom_title = (bool)$widget->get_setting('custom_title', '');
    $custom_title_text = $widget->get_setting('custom_title_text', '');
    $page_title_custom = mouno()->get_page_opt('page_title_custom', '');
    $title = !empty($page_title_custom) ? $page_title_custom : get_the_title($post_id);
    if($custom_title) {
        $title = $custom_title_text;
    }
    $title = $widget->parse_text_editor( $title ); 
    $num_of_text_highlight = $widget->get_setting('num_of_text_highlight', 0);
    if($num_of_text_highlight != 0) {
        $title_split = explode(' ', $title);
        $i = 0;
        $title = '';
        while($i < count($title_split)) {
            if($num_of_text_highlight == $i) {
                $title .= '<span class="pxl-text-highlight">';
            }
            $title .= $title_split[$i].' ';
            $i++;
        }
        if($num_of_text_highlight < count($title_split)) {
            $title .= '</span>';
        }
    }
?>

<div class="pxl-post-title-wrapper">
    <<?php echo esc_attr($title_tag); ?> class="pxl-post-title-item">
        <span class="pxl-post-title"><?php pxl_print_html($title); ?></span>
    </<?php echo esc_attr($title_tag); ?>>
</div>