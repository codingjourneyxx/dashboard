<div class="pxl-circular-text-wrapper">
  <div class="pxl-circular-text-item">
    <?php echo esc_html($settings['text']); ?>
  </div>
  <span class="pxl-circular-text-icon">
    <?php if(isset($settings['_icon'])) : ?>
      <?php \Elementor\Icons_Manager::render_icon( $settings['_icon'], [ 'aria-hidden' => 'true', 'class' => '' ], 'i' ); ?>
    <?php elseif(isset($settings['img'])): ?>
      <?php 
          $get_img = pxl_get_image_by_size([
            'attach_id'  => $settings['img']['id'],
            'thumb_size' => 'full',
          ]);
          $img = $get_img ? $get_img['thumbnail'] : '<img src="' . $settings['img']['url'] . '">';
          pxl_print_html($img);
      ?>
    <?php endif; ?>
  </span>
</div>