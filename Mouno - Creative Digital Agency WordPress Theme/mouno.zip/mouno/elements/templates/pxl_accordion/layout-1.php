<?php
    $is_accordion = isset($settings['accordion']) && !empty($settings['accordion']) && count($settings['accordion']) || false;
    $anim = $widget->get_setting('entrance_anim', '');
?>
<?php if($is_accordion) : ?>
    <div class="pxl-accordion-wrapper <?php echo esc_attr($settings['layout1_style'].' '.$anim); ?>">
        <?php foreach($settings['accordion'] as $key => $accordion) : ?>
            <?php 
                $content = $widget->parse_text_editor( $accordion['content'] ?? '' );   
                $index = $key + 1;
                $active = !empty($settings['active']) && $settings['active'] === ($index) ? 'active' : ''; 
            ?>
            <div class="pxl-accordion-item <?php echo esc_attr($active); ?>">
                <?php if($settings['layout1_style'] !== 'accordion-style1') : ?>
                    <span class="pxl-accordion-index"><?php echo esc_html('0'.$index); ?></span>    
                <?php endif; ?>
                <div class="pxl-accordion-details">
                    <div class="pxl-accordion-header">
                        <<?php echo esc_attr($settings['title_tag']); ?> class="pxl-accordion-title">
                            <?php echo esc_html($accordion['title']); ?>
                        </<?php echo esc_attr($settings['title_tag']); ?>>
                        <span class="pxl-accordion-action"></span>
                    </div>
                    <div class="pxl-accordion-content ">
                        <?php pxl_print_html($content); ?>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>