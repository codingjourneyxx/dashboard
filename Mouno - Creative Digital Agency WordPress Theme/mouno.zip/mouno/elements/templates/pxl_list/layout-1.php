<?php 
    $is_list = isset($settings['list']) && !empty($settings['list']) && count($settings['list']) || false;
    $anim = $widget->get_setting('entrance_anim', '');
    $anim_delay = $widget->get_setting('anim_delay', ['size' => 0]);
?>
<ul class="pxl-list-wrapper">
    <?php if($is_list) : ?>
        <?php foreach($settings['list'] as $key => $item) : ?>
            <?php 
                $wow_delay = ($anim_delay['size'] !== 0) ? ($key * $anim_delay['size']).'s' : null;      
            ?>
            <li class="pxl-list-item" <?php if(!is_null($wow_delay)) : ?> data-wow-delay="<?php echo esc_attr($wow_delay); ?>" <?php endif; ?>>
                <?php if(!empty($settings['_icon'])) : ?>
                    <?php \Elementor\Icons_Manager::render_icon( $settings['_icon'], [ 'aria-hidden' => 'true', 'class' => '' ], 'i' ); ?>
                <?php endif; ?>
                <span class="pxl-item-text">
                    <?php echo esc_html($item['text']) ?>
                </span>
            </li>
        <?php endforeach; ?>
    <?php endif; ?>
</ul>