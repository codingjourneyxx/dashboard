<?php 
$current_post_id = get_the_ID();
$img_dimension = $widget->get_setting('img_dimension', 'full');
if($img_dimension === 'custom') {
    $custom_img_dimension = $widget->get_setting('custom_img_dimension', []);
    $img_dimension = (!empty($custom_img_dimension['width']) && !empty($custom_img_dimension['height'])) ? $custom_img_dimension : 'full';
}
$thumbnail = mouno_get_image_by_size([
    'img_dimension' => $img_dimension,
    'attr' => [
        'class' => 'pxl-featured-image',
    ]
], $current_post_id);

?>
<div class="pxl-featured-image-wrapper">
    <span class="pxl-featured-image-item">
        <?php pxl_print_html($thumbnail); ?>
    </span>
</div>
