<?php
$html_id = pxl_get_element_id($settings);
$text = $widget->parse_text_editor( $settings['text'] ?? '' );
$gsap_stagger = $widget->get_setting('gsap_stagger', 0);
$gsap_duration = $widget->get_setting('gsap_duration', 1);
$gsap_delay = $widget->get_setting('gsap_delay', 0);
$entrance_anim = $widget->get_setting('entrance_anim', '');
$text_entrance_anim = $widget->get_setting('text_entrance_anim', '');
$anim_works_in = $widget->get_setting('anim_works_in', '');
$gsap_params = [
	'stagger' => $gsap_stagger,
	'duration' => $gsap_duration,
	'delay' => $gsap_delay,
];
$gsap_params = json_encode($gsap_params);
$widget->add_render_attribute( 'attrs', [
	'id' => $html_id,
	'class' => 'pxl-text-editor-wrapper '.$settings['text_style'].' '.$settings['link_style'].' '.$settings['link_hover_style'].' '.$entrance_anim.' '.$text_entrance_anim.' '.$anim_works_in,
]);	
?>
<div <?php pxl_print_html($widget->get_render_attribute_string('attrs')); ?>
	<?php if(!empty($text_entrance_anim)) : ?> data-gsap="<?php echo esc_attr($gsap_params); ?>" <?php endif; ?>>
	<?php pxl_print_html($text); ?>		
</div>