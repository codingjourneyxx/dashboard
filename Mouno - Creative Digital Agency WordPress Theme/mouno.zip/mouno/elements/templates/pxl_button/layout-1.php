<?php
$html_id = pxl_get_element_id($settings);

$parallax_intensity = $widget->get_setting('parallax_intensity', 1.5);
$btn_link_style = $widget->get_setting('btn_link_style', '');
$animation = $widget->get_setting('entrance_anim', '');
$icon_anim = $widget->get_setting('icon_entrance_anim', '');
$text_anim = $widget->get_setting('text_entrance_anim', '');
$color_gradient_class = !empty($settings['is_color_gradient']) ? 'text-gradient' : null;
$attrs = [
    'class' => 'btn '.$settings['btn_action'].' '.$settings['btn_type'].' '.$btn_link_style.' '.$settings['btn_hover_style'].' '.$color_gradient_class,
];
if($settings['btn_hover_style'] === 'hover-parallax-seft') {
    $attrs['data-intensity'] = $parallax_intensity;
}
if(isset($settings['submit_to_id']) && !empty($settings['submit_to_id'])) {
    $attrs['data-submit'] = $settings['submit_to_id'];
}
if($settings['btn_action'] === 'pxl-atc-anchor') {
    $attrs['data-target-offset'] = $settings['anchor_target_offset'] ?? 0;
}
$widget->add_render_attribute( 'attrs', $attrs);

?>
<div class="pxl-button-wrapper <?php echo esc_attr($animation); ?>">
    <a <?php pxl_print_html(mouno_render_link_attributes($settings['btn_link'])); pxl_print_html($widget->get_render_attribute_string('attrs')); ?>>
        <?php if($settings['btn_type'] === 'pxl-btn-split') : ?>
            <span class="pxl-btn-icon icon-duplicated">
                <?php if(!empty($settings['btn_icon']['value'])) : ?>
                    <?php \Elementor\Icons_Manager::render_icon( $settings['btn_icon'], [ 'aria-hidden' => 'true', 'class' => '' ], 'i' ); ?>
                <?php else : ?>
                    <svg xmlns="http://www.w3.org/2000/svg" width="38" height="38" viewBox="0 0 38 38" fill="none">
                        <path d="M26.6745 23.8894L26.5892 12.0397C26.5892 11.5282 26.1914 11.1304 25.6799 11.1304L13.8302 11.0451C13.3187 11.0451 12.9208 11.443 12.9208 11.9545C12.9208 12.466 13.3187 12.8638 13.8302 12.8638L23.4634 12.9491L11.3864 25.0261C11.0454 25.3671 11.0454 25.9354 11.3864 26.2764C11.7274 26.6174 12.3241 26.6458 12.6651 26.3048L24.799 14.171L24.8842 23.9178C24.8842 24.1452 24.9979 24.3725 25.1684 24.543C25.3389 24.7135 25.5662 24.8272 25.822 24.7988C26.2766 24.7988 26.7029 24.3725 26.6745 23.8894Z" fill="currentcolor"/>
                    </svg>
                <?php endif; ?>
            </span>
        <?php endif; ?>
        <?php if(!empty($settings['btn_text'])) : ?>
            <span class="pxl-btn-text <?php echo esc_attr($text_anim); ?>" data-text="<?php echo esc_attr($settings['btn_text']); ?>">
                <?php echo esc_html($settings['btn_text']); ?>
            </span>
        <?php endif; ?>
        <?php if(!empty($settings['btn_icon']['value'])) : ?>
            <span class="pxl-btn-icon icon-main <?php echo esc_attr($icon_anim); ?>">
                <?php \Elementor\Icons_Manager::render_icon( $settings['btn_icon'], [ 'aria-hidden' => 'true', 'class' => '' ], 'i' ); ?>
            </span>
        <?php elseif(empty($settings['btn_icon']['value']) && $settings['btn_type'] === 'pxl-btn-split'): ?>
            <span class="pxl-btn-icon icon-main <?php echo esc_attr($icon_anim); ?>">
                <svg xmlns="http://www.w3.org/2000/svg" width="38" height="38" viewBox="0 0 38 38" fill="none">
                    <path d="M26.6745 23.8894L26.5892 12.0397C26.5892 11.5282 26.1914 11.1304 25.6799 11.1304L13.8302 11.0451C13.3187 11.0451 12.9208 11.443 12.9208 11.9545C12.9208 12.466 13.3187 12.8638 13.8302 12.8638L23.4634 12.9491L11.3864 25.0261C11.0454 25.3671 11.0454 25.9354 11.3864 26.2764C11.7274 26.6174 12.3241 26.6458 12.6651 26.3048L24.799 14.171L24.8842 23.9178C24.8842 24.1452 24.9979 24.3725 25.1684 24.543C25.3389 24.7135 25.5662 24.8272 25.822 24.7988C26.2766 24.7988 26.7029 24.3725 26.6745 23.8894Z" fill="currentcolor"/>
                </svg>
            </span>
        <?php endif; ?>
    </a>
</div>



