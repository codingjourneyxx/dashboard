<?php 
    $tag = !empty($settings['link']['url']) ? 'a' : 'span';
    $gradient_color = (bool)$widget->get_setting('gradient_color', '');
    $gradient_color_class = ($gradient_color) ? 'text-gradient' : null;
    $entrance_anim = $widget->get_setting('entrance_anim', '');
    $icon_hover_anim = !empty($settings['icon_hover_anim']) ? 'elementor-animation-'.$settings['icon_hover_anim'] : null;

    $scrolling_effect = $widget->get_setting('scrolling_effect', '');
    if($scrolling_effect === 'parallax') {
        $parallax_params = [
            'x' => $widget->get_setting('parallax_x', 0),
            'y' => $widget->get_setting('parallax_y', 0),
            'scale' => $widget->get_setting('parallax_scale', 0),
            'rotate' => $widget->get_setting('parallax_rotate', 0),
            'opacity' => $widget->get_setting('parallax_opacity', 0),
        ];
        $parallax_params = json_encode($parallax_params);
    }
    $anim_effect = $widget->get_setting('anim_effect', '');
    $item_class = trim('pxl-icon-item '.$gradient_color_class.' '.$icon_hover_anim.' '.$anim_effect);
?>

<div class="pxl-icon-wrapper <?php echo esc_attr($entrance_anim); ?>">
    <<?php echo esc_attr($tag); ?> <?php pxl_print_html(mouno_render_link_attributes($settings['link'])); ?> class="<?php echo esc_attr($item_class); ?>"
    <?php if(isset($parallax_params)) : ?> data-parallax="<?php echo esc_attr($parallax_params); ?>" <?php endif; ?>>
        <?php \Elementor\Icons_Manager::render_icon( $settings['_icon'], [ 'aria-hidden' => 'true', 'class' => '' ], 'i' ); ?>
    </<?php echo esc_attr($tag); ?>>
</div>