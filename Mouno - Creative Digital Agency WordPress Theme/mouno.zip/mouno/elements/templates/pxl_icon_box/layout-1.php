<?php 
$entrance_anim = $widget->get_setting('entrance_anim', '');
$widget->add_render_attribute( 'wrapper', [
    'class'         => 'pxl-icon-box-wrapper '.$settings['style'].' '.$entrance_anim,
]);

?>

<div <?php pxl_print_html($widget->get_render_attribute_string('wrapper')); ?>>
    <div class="pxl-icon-box-icon">
        <?php if(!empty($settings['link']['url'])) : ?>
            <a <?php mouno_render_link_attributes($settings['link']); ?> class="pxl-icon">
                <?php \Elementor\Icons_Manager::render_icon( $settings['_icon'], [ 'aria-hidden' => 'true', 'class' => '' ], 'i' ); ?>
            </a>
        <?php else : ?>
            <span class="pxl-icon"><?php \Elementor\Icons_Manager::render_icon( $settings['_icon'], [ 'aria-hidden' => 'true', 'class' => '' ], 'i' ); ?></span>
        <?php endif; ?>
    </div>
    <?php if($settings['style'] === 'icon-box-style1') : ?>
        <span class="pxl-icon-box-index"><?php echo esc_html(($settings['index']) < 10 ? '0'.$settings['index'] : $settings['index']); ?></span>
    <?php endif; ?>
    <div class="pxl-icon-box-content">
        <<?php echo esc_attr($settings['title_tag']); ?> class="pxl-icon-box-title">
            <?php if(!empty($settings['link']['url'])) : ?>
                <a <?php mouno_render_link_attributes($settings['link']); ?> class="pxl-title-text">
                    <?php echo esc_html($settings['title']); ?>
                </a>
            <?php else: ?>
                <span class="pxl-title-text"><?php echo esc_html($settings['title']); ?></span>
            <?php endif; ?>
        </<?php echo esc_attr($settings['title_tag']); ?>>
        <p class="pxl-icon-box-description"><?php echo esc_html($settings['desc']); ?></p>
    </div>
    <?php if(!empty($settings['link']['url']) && $settings['style'] === 'icon-box-style1') : ?>
        <a <?php mouno_render_link_attributes($settings['link']); ?> class="pxl-item-link">
            <?php echo esc_html($settings['title']); ?>
        </a>
    <?php endif; ?>
</div>