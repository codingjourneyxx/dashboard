<?php 
$effect                 = $widget->get_setting('effect', 'slide');
$autoplay               = $widget->get_setting('autoplay', false);
$disable_on_interaction = $widget->get_setting('disable_on_interaction', false);
$delay                  = $widget->get_setting('delay', 5000);
$loop                   = $widget->get_setting('loop', false);
$speed                  = $widget->get_setting('speed', 500);
$mousewheel             = (bool)$widget->get_setting('mousewheel', '');
$space_between          = $widget->get_setting('space_between', 0);
$pagination             = $widget->get_setting('swiper_pagination', '');
$navigation             = (bool)$widget->get_setting('swiper_navigation', '');
$slides_per_view        = $widget->get_setting('slides_per_view', 'auto');
$slides_per_view_xs     = $widget->get_setting('slides_per_view_xs', 1);
$slides_per_view_sm     = $widget->get_setting('slides_per_view_sm', 2);
$slides_per_view_md     = $widget->get_setting('slides_per_view_md', 3);
$slides_per_view_lg     = $widget->get_setting('slides_per_view_lg', 4);
$slides_per_view_xl     = $widget->get_setting('slides_per_view_xl', 5);
$slides_per_view_xxl    = $widget->get_setting('slides_per_view_xxl', 5);
$swiperParams           = [
    'effect'                 => $effect, 
    'direction'              => 'horizontal', 
    'autoplay'               => (bool)$autoplay,
    'disable_on_interaction' => (bool)$disable_on_interaction,
    'delay'                  => $delay,
    'loop'                   => (bool)$loop,
    'speed'                  => $speed,
    'mousewheel'             => $mousewheel,
    'space_between'          => $space_between,
    'pagination'             => $pagination,
    'navigation'             => $navigation,
    'slides_per_view'        => $slides_per_view,
    'slides_per_view_xs'     => (int)$slides_per_view_xs,
    'slides_per_view_sm'     => (int)$slides_per_view_sm,
    'slides_per_view_md'     => (int)$slides_per_view_md,
    'slides_per_view_lg'     => (int)$slides_per_view_lg,
    'slides_per_view_xl'     => (int)$slides_per_view_xl,
    'slides_per_view_xxl'    => (int)$slides_per_view_xxl,
];

$swiperParams = json_encode($swiperParams);
$nav_btn_icon_prev  = $widget->get_setting('nav_btn_icon_prev', []);
$nav_btn_icon_next  = $widget->get_setting('nav_btn_icon_next', []);
$nav_id = $widget->get_setting('nav_id', '');
$nav_hidden_class = !empty($nav_id) ? 'swiper-navigation-hidden' : null;
$nav_btn_style = $widget->get_setting('nav_btn_style', 'swiper-button-default');

$items = $widget->get_setting('icons', []);
$hover_anim = !empty($settings['icon_hover_anim']) ? 'elementor-animation-'.$settings['icon_hover_anim'] : '';
$layout_style = $widget->get_setting('layout_style', 'icon-carousel-default');
$anim = $widget->get_setting('entrance_anim', '');
$anim_delay = $widget->get_setting('anim_delay', 0);
$checked_anim = (!empty($anim) && $anim_delay != 0) || false;
$has_divider = $widget->get_setting('has_divider', ''); 
$has_divider_class = !empty($has_divider) ? 'has-divider' : '';
if(!empty($items)) : ?>
    <div class="pxl-swiper pxl-icon-carousel <?php echo esc_attr($layout_style.' '.$has_divider_class); ?>">
        <div class="swiper-container" data-swiper = "<?php echo esc_attr($swiperParams); ?>">
            <div class="swiper-wrapper">
                <?php foreach($items as $key => $item) : 
                    $link_attr = mouno_render_link_attributes($item['icon_link']);
                    $tag = (!is_null($link_attr)) ? 'a' : 'span';
                ?>
                    <div class="swiper-slide <?php echo esc_attr($anim); ?>"
                    <?php if($checked_anim) : ?> data-wow-delay="<?php echo esc_attr(($key*$anim_delay).'ms'); ?>" <?php endif; ?>>
                        <div class="pxl-icon-item <?php echo esc_attr('elementor-repeater-item-'.esc_attr( $item['_id'] ).' '.$hover_anim); ?>">
                            <<?php echo esc_attr($tag); pxl_print_html($link_attr); ?> class="pxl-icon">
                                <?php \Elementor\Icons_Manager::render_icon( $item['_icon'], [ 'aria-hidden' => 'true', 'class' => '' ], 'i' ); ?>
                            </<?php echo esc_attr($tag); ?>>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php if(!empty($pagination)) : ?>
            <div class="swiper-pagination"></div>
        <?php endif; ?>
        <?php if($navigation) : ?>
            <div class="swiper-navigation <?php echo esc_attr($nav_hidden_class); ?>" 
            <?php if(!empty($nav_id)) : ?> data-navigation-id="<?php echo esc_attr($nav_id); ?>" <?php endif; ?>>
                <div class="pxl-swiper-button swiper-button-prev <?php echo esc_attr($nav_btn_style); ?>">
                    <span class="pxl-icon icon-prev">
                        <?php \Elementor\Icons_Manager::render_icon( $nav_btn_icon_prev, [ 'aria-hidden' => 'true', 'class' => 'pxl-button-icon' ], 'i' ); ?>
                    </span>
                </div>
                <div class="pxl-swiper-button swiper-button-next <?php echo esc_attr($nav_btn_style); ?>">
                    <span class="pxl-icon icon-next">
                        <?php \Elementor\Icons_Manager::render_icon( $nav_btn_icon_next, [ 'aria-hidden' => 'true', 'class' => 'pxl-button-icon' ], 'i' ); ?>
                    </span>
                </div>
            </div>
        <?php endif; ?>
    </div>
<?php endif;