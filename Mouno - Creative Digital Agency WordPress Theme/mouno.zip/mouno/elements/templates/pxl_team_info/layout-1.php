<?php 
    $currrent_post_id = get_the_ID();
    $position     = get_post_meta($currrent_post_id, 'team_position', true);
    $email        = get_post_meta($currrent_post_id, 'team_email', true);
    $phone_number = get_post_meta($currrent_post_id, 'team_phone_number', true);
    $address      = get_post_meta($currrent_post_id, 'team_address', true);

    $social_share_content = mouno_get_team_social($currrent_post_id);

    $items = $widget->get_setting('items', []);
    $title_tag = $widget->get_setting('title_tag', 'h3');

?>

<div class="pxl-team-info">
    <div class="pxl-team-header">
        <<?php echo esc_attr($title_tag); ?> class="pxl-team-title">
            <span class="pxl-title-text">
                <?php echo esc_html(get_the_title($currrent_post_id)); ?>
            </span>
        </<?php echo esc_attr($title_tag); ?>>
        <div class="pxl-team-position">
            <?php echo esc_html($position); ?>
        </div>
    </div>
    <div class="pxl-team-metas">
        <div class="pxl-team-email pxl-meta-item">
            <span class="pxl-meta-label">
                <?php echo esc_html__('Email Address', 'mouno'); ?>
            </span>
            <a href="<?php echo esc_attr('mailto:'.$email); ?>" class="pxl-meta-info">
                <?php echo esc_html($email); ?>
            </a>
        </div>
        <div class="pxl-team-phone_number pxl-meta-item">
            <span class="pxl-meta-label">
                <?php echo esc_html__('Phone Number', 'mouno'); ?>
            </span>
            <a href="<?php echo esc_attr('tel:'.$phone_number); ?>" class="pxl-meta-info">
                <?php echo esc_html($phone_number); ?>
            </a>
        </div>
        <div class="pxl-team-address pxl-meta-item">
            <span class="pxl-meta-label">
                <?php echo esc_html__('Address', 'mouno'); ?>
            </span>
            <span class="pxl-meta-info">
                <?php echo esc_html($address); ?>
            </span>
        </div>
        <?php if(!empty($items)) : ?>
            <?php foreach($items as $key => $item) : 
                $item_label = $item['label'] ?? '';
                $item_info  = $item['info'] ?? '';
            ?>
            <div class="pxl-team-add-info pxl-meta-item">
                <span class="pxl-meta-label">
                    <?php echo esc_html($item_label); ?>
                </span>
                <span class="pxl-meta-info">
                    <?php pxl_print_html($item_info); ?>
                </span>
            </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
    <div class="pxl-team-socials">
        <?php pxl_print_html($social_share_content); ?>
    </div>
</div>