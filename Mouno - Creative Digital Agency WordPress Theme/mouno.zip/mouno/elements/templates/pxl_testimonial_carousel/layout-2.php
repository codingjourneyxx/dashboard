<?php 
$items = $widget->get_setting('testimonials', []);
if(!empty($items)) : 
    $effect                 = $widget->get_setting('effect', 'slide');
    $autoplay               = $widget->get_setting('autoplay', false);
    $disable_on_interaction = $widget->get_setting('disable_on_interaction', false);
    $delay                  = $widget->get_setting('delay', 5000);
    $loop                   = $widget->get_setting('loop', false);
    $speed                  = $widget->get_setting('speed', 500);
    $space_between          = $widget->get_setting('space_between', 151);
    $pagination             = $widget->get_setting('swiper_pagination', '');
    $navigation             = $widget->get_setting('swiper_navigation', false);
    $slides_per_view        = $widget->get_setting('slides_per_view', 'auto');
    $slides_per_view_xs     = $widget->get_setting('slides_per_view_xs', 1);
    $slides_per_view_sm     = $widget->get_setting('slides_per_view_sm', 1);
    $slides_per_view_md     = $widget->get_setting('slides_per_view_md', 1);
    $slides_per_view_lg     = $widget->get_setting('slides_per_view_lg', 1);
    $slides_per_view_xl     = $widget->get_setting('slides_per_view_xl', 1);
    $slides_per_view_xxl    = $widget->get_setting('slides_per_view_xxl', 1);
    $swiperParams           = [
        'effect'                 => $effect, 
        'direction'              => 'horizontal', 
        'autoplay'               => (bool)$autoplay,
        'disable_on_interaction' => (bool)$disable_on_interaction,
        'delay'                  => $delay,
        'loop'                   => (bool)$loop,
        'speed'                  => $speed,
        'space_between'          => $space_between,
        'pagination'             => $pagination,
        'navigation'             => (bool)$navigation,
        'slides_per_view'        => $slides_per_view,
        'slides_per_view_xs'     => (int)$slides_per_view_xs,
        'slides_per_view_sm'     => (int)$slides_per_view_sm,
        'slides_per_view_md'     => (int)$slides_per_view_md,
        'slides_per_view_lg'     => (int)$slides_per_view_lg,
        'slides_per_view_xl'     => (int)$slides_per_view_xl,
        'slides_per_view_xxl'    => (int)$slides_per_view_xxl,
    ];

    $swiperParams = json_encode($swiperParams);
    $nav_btn_icon_prev  = $widget->get_setting('nav_btn_icon_prev', []);
    $nav_btn_icon_next  = $widget->get_setting('nav_btn_icon_next', []);
    $nav_id = $widget->get_setting('nav_id', '');
    $nav_hidden_class = !empty($nav_id) ? 'swiper-navigation-hidden' : null;
    $nav_btn_style = $widget->get_setting('nav_btn_style', 'swiper-button-default');

    $anim = $widget->get_setting('entrance_anim', '');
    $anim_delay = $widget->get_setting('anim_delay', 0);
    $checked_anim = (!empty($anim) && $anim_delay != 0) || false;
?>
    <div class="pxl-swiper pxl-testimonial-carousel pxl-testimonial-carousel2">
        <div class="swiper-container" data-swiper = "<?php echo esc_attr($swiperParams); ?>">
            <div class="swiper-wrapper">
                <?php foreach($items as $key => $item) : 
                    $user_image = mouno_get_image_by_size([
                        'img_id'  => $item['img']['id'],
                        'img_dimension' => 'full',
                        'attr' => [
                            'class' => 'pxl-image no-lazyload'
                        ],
                    ]);
                    $user_name  = $item['name'] ?? '';
                    $user_title = $item['title'] ?? '';
                    $content = $item['content'] ?? '';
                ?>
                    <div class="swiper-slide <?php echo esc_attr($anim); ?>"
                    <?php if($checked_anim) : ?> data-wow-delay="<?php echo esc_attr(($key*$anim_delay).'ms'); ?>" <?php endif; ?>>
                        <div class="pxl-testimonial-item">
                            <div class="pxl-testimonial-user">
                                <div class="pxl-user-image">
                                    <?php pxl_print_html($user_image); ?>
                                </div>
                                <div class="pxl-user-content">
                                    <span class="pxl-user-name"><?php echo esc_html($user_name); ?></span>
                                    <span class="pxl-user-title"><?php echo esc_html($user_title); ?></span>
                                </div>
                            </div>
                            <p class="pxl-testimonial-content">
                                <?php echo esc_html($content); ?>
                            </p>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
<?php endif; 
