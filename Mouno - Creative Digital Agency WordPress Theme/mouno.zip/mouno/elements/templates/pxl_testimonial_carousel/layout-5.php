<?php 
$items = $widget->get_setting('testimonials', []);
if(!empty($items)) : 
    $effect                 = $widget->get_setting('effect', 'slide');
    $autoplay               = $widget->get_setting('autoplay', false);
    $disable_on_interaction = $widget->get_setting('disable_on_interaction', false);
    $delay                  = $widget->get_setting('delay', 5000);
    $loop                   = $widget->get_setting('loop', false);
    $speed                  = $widget->get_setting('speed', 500);
    $space_between          = $widget->get_setting('space_between', 30);
    $pagination             = $widget->get_setting('swiper_pagination', '');
    $navigation             = $widget->get_setting('swiper_navigation', false);
    $slides_per_view        = $widget->get_setting('slides_per_view', 'auto');
    $slides_per_view_xs     = $widget->get_setting('slides_per_view_xs', 1);
    $slides_per_view_sm     = $widget->get_setting('slides_per_view_sm', 1);
    $slides_per_view_md     = $widget->get_setting('slides_per_view_md', 2);
    $slides_per_view_lg     = $widget->get_setting('slides_per_view_lg', 2);
    $slides_per_view_xl     = $widget->get_setting('slides_per_view_xl', 3);
    $slides_per_view_xxl    = $widget->get_setting('slides_per_view_xxl', 3);
    $swiperParams           = [
        'effect'                 => $effect, 
        'direction'              => 'horizontal', 
        'autoplay'               => (bool)$autoplay,
        'disable_on_interaction' => (bool)$disable_on_interaction,
        'delay'                  => $delay,
        'loop'                   => (bool)$loop,
        'speed'                  => $speed,
        'space_between'          => $space_between,
        'pagination'             => $pagination,
        'navigation'             => (bool)$navigation,
        'slides_per_view'        => $slides_per_view,
        'slides_per_view_xs'     => (int)$slides_per_view_xs,
        'slides_per_view_sm'     => (int)$slides_per_view_sm,
        'slides_per_view_md'     => (int)$slides_per_view_md,
        'slides_per_view_lg'     => (int)$slides_per_view_lg,
        'slides_per_view_xl'     => (int)$slides_per_view_xl,
        'slides_per_view_xxl'    => (int)$slides_per_view_xxl,
    ];

    $swiperParams = json_encode($swiperParams);
    $nav_btn_icon_prev  = $widget->get_setting('nav_btn_icon_prev', []);
    $nav_btn_icon_next  = $widget->get_setting('nav_btn_icon_next', []);
    $nav_id = $widget->get_setting('nav_id', '');
    $nav_hidden_class = !empty($nav_id) ? 'swiper-navigation-hidden' : null;
    $nav_btn_style = $widget->get_setting('nav_btn_style', 'swiper-button-default');

    $anim = $widget->get_setting('entrance_anim', '');
    $anim_delay = $widget->get_setting('anim_delay', 0);
    $checked_anim = (!empty($anim) && $anim_delay != 0) || false;

    $icon = $widget->get_setting('_icon', []);
?>
    <div class="pxl-swiper pxl-testimonial-carousel pxl-testimonial-carousel5">
        <div class="swiper-container" data-swiper = "<?php echo esc_attr($swiperParams); ?>">
            <div class="swiper-wrapper">
                <?php foreach($items as $key => $item) : 
                    $user_image = mouno_get_image_by_size([
                        'img_id'  => $item['img']['id'],
                        'img_dimension' => 'full',
                        'attr' => [
                            'class' => 'pxl-image no-lazyload'
                        ],
                    ]);
                    $rating = !empty($item['rating']) ? $item['rating'] : 5;

                    $content = $item['content'] ?? '';
                    $name    = $item['name'] ?? '';
                    $title   = $item['title'] ?? '';
                ?>
                    <div class="swiper-slide <?php echo esc_attr($anim); ?>"
                    <?php if($checked_anim) : ?> data-wow-delay="<?php echo esc_attr(($key*$anim_delay).'ms'); ?>" <?php endif; ?>>
                        <div class="pxl-testimonial-item">
                            <span class="pxl-testimonial-icon">
                                <?php \Elementor\Icons_Manager::render_icon( $icon, [ 'aria-hidden' => 'true', 'class' => '' ], 'i' ); ?>
                            </span>    
                            <p class="pxl-testimonial-content">
                                <?php echo esc_html($content); ?>
                            </p>
                            <div class="pxl-testimonial-rating">
                                <span class="pxl-rating-star">
                                    <?php for($i=0; $i<$rating; $i++) : ?>
                                        <svg xmlns="http://www.w3.org/2000/svg" width="21" height="21" viewBox="0 0 21 21" fill="none">
                                            <path d="M9.66076 2.50961L7.3934 7.10683L2.32048 7.84641C1.41076 7.97836 1.04618 9.09989 1.7059 9.74225L5.37604 13.3186L4.50798 18.3707C4.35173 19.2839 5.31354 19.9679 6.1191 19.5409L10.6573 17.1554L15.1955 19.5409C16.001 19.9645 16.9628 19.2839 16.8066 18.3707L15.9385 13.3186L19.6087 9.74225C20.2684 9.09989 19.9038 7.97836 18.9941 7.84641L13.9212 7.10683L11.6538 2.50961C11.2476 1.69016 10.0705 1.67975 9.66076 2.50961Z" fill="currentcolor"/>
                                        </svg>
                                    <?php endfor; ?>
                                </span>
                            </div>
                            <div class="pxl-testimonial-user">
                                <span class="pxl-user-image">
                                    <?php pxl_print_html($user_image); ?>
                                </span>
                                <div class="pxl-user-content">
                                    <span class="pxl-user-name"><?php echo esc_html($name); ?></span>
                                    <span class="pxl-user-title"><?php echo esc_html($title); ?></span>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php if(!empty($pagination)) : ?>
            <div class="swiper-pagination"></div>
        <?php endif; ?>
        <?php if($navigation) : ?>
            <div class="swiper-navigation <?php echo esc_attr($nav_hidden_class); ?>" 
            <?php if(!empty($nav_id)) : ?> data-navigation-id="<?php echo esc_attr($nav_id); ?>" <?php endif; ?>>
                <div class="pxl-swiper-button swiper-button-prev <?php echo esc_attr($nav_btn_style); ?>">
                    <span class="pxl-icon icon-prev">
                        <?php \Elementor\Icons_Manager::render_icon( $nav_btn_icon_prev, [ 'aria-hidden' => 'true', 'class' => 'pxl-button-icon' ], 'i' ); ?>
                    </span>
                </div>
                <div class="pxl-swiper-button swiper-button-next <?php echo esc_attr($nav_btn_style); ?>">
                    <span class="pxl-icon icon-next">
                        <?php \Elementor\Icons_Manager::render_icon( $nav_btn_icon_next, [ 'aria-hidden' => 'true', 'class' => 'pxl-button-icon' ], 'i' ); ?>
                    </span>
                </div>
            </div>
        <?php endif; ?>  
    </div>
<?php endif; ?>
