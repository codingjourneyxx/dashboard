<?php 
$items = $widget->get_setting('testimonials', []);
if(!empty($items)) : 
    $effect                 = $widget->get_setting('effect', 'slide');
    $autoplay               = $widget->get_setting('autoplay', false);
    $disable_on_interaction = $widget->get_setting('disable_on_interaction', false);
    $delay                  = $widget->get_setting('delay', 5000);
    $loop                   = $widget->get_setting('loop', false);
    $speed                  = $widget->get_setting('speed', 500);
    $space_between          = $widget->get_setting('space_between', 151);
    $pagination             = $widget->get_setting('swiper_pagination', '');
    $navigation             = $widget->get_setting('swiper_navigation', false);
    $slides_per_view        = $widget->get_setting('slides_per_view', 'auto');
    $slides_per_view_xs     = $widget->get_setting('slides_per_view_xs', 1);
    $slides_per_view_sm     = $widget->get_setting('slides_per_view_sm', 1);
    $slides_per_view_md     = $widget->get_setting('slides_per_view_md', 1);
    $slides_per_view_lg     = $widget->get_setting('slides_per_view_lg', 1);
    $slides_per_view_xl     = $widget->get_setting('slides_per_view_xl', 1);
    $slides_per_view_xxl    = $widget->get_setting('slides_per_view_xxl', 1);
    $swiperParams           = [
        'effect'                 => $effect, 
        'direction'              => 'horizontal', 
        'autoplay'               => (bool)$autoplay,
        'disable_on_interaction' => (bool)$disable_on_interaction,
        'delay'                  => $delay,
        'loop'                   => (bool)$loop,
        'speed'                  => $speed,
        'space_between'          => $space_between,
        'pagination'             => $pagination,
        'navigation'             => (bool)$navigation,
        'slides_per_view'        => $slides_per_view,
        'slides_per_view_xs'     => (int)$slides_per_view_xs,
        'slides_per_view_sm'     => (int)$slides_per_view_sm,
        'slides_per_view_md'     => (int)$slides_per_view_md,
        'slides_per_view_lg'     => (int)$slides_per_view_lg,
        'slides_per_view_xl'     => (int)$slides_per_view_xl,
        'slides_per_view_xxl'    => (int)$slides_per_view_xxl,
    ];

    $swiperParams = json_encode($swiperParams);
    $nav_btn_icon_prev  = $widget->get_setting('nav_btn_icon_prev', []);
    $nav_btn_icon_next  = $widget->get_setting('nav_btn_icon_next', []);
    $nav_id = $widget->get_setting('nav_id', '');
    $nav_hidden_class = !empty($nav_id) ? 'swiper-navigation-hidden' : null;
    $nav_btn_style = $widget->get_setting('nav_btn_style', 'swiper-button-default');

    $anim = $widget->get_setting('entrance_anim', '');
    $anim_delay = $widget->get_setting('anim_delay', 0);
    $checked_anim = (!empty($anim) && $anim_delay != 0) || false;
?>
    <div class="pxl-swiper pxl-testimonial-carousel pxl-testimonial-carousel3">
        <div class="swiper-container" data-swiper = "<?php echo esc_attr($swiperParams); ?>">
            <div class="swiper-wrapper">
                <?php foreach($items as $key => $item) : ?>
                    <?php 
                        $user_image = mouno_get_image_by_size([
                            'img_id'  => $item['img']['id'],
                            'img_dimension' => 'full',
                            'attr' => [
                                'class' => 'pxl-image no-lazyload'
                            ],
                        ]);
                        $rating = !empty($item['rating']) ? $item['rating'] : 1;
                        $user_name  = $item['name'] ?? '';
                        $user_title = $item['title'] ?? '';
                        $content = $item['content'] ?? '';
                    ?>
                    <div class="swiper-slide <?php echo esc_attr($anim); ?>"
                    <?php if($checked_anim) : ?> data-wow-delay="<?php echo esc_attr(($key*$anim_delay).'ms'); ?>" <?php endif; ?>>
                        <div class="pxl-testimonial-item">
                            <div class="pxl-testimonial-rating">
                                <?php if(is_int($rating)) : 
                                    for($i=0; $i<$rating; $i++) : ?>
                                    <span class="pxl-rating-star">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="17" viewBox="0 0 18 17" fill="none">
                                            <path d="M9.00001 14.27L13.15 16.78C13.91 17.24 14.84 16.56 14.64 15.7L13.54 10.98L17.21 7.80001C17.88 7.22001 17.52 6.12001 16.64 6.05001L11.81 5.64001L9.92001 1.18001C9.58001 0.37001 8.42001 0.37001 8.08001 1.18001L6.19001 5.63001L1.36001 6.04001C0.480012 6.11001 0.120012 7.21001 0.790012 7.79001L4.46001 10.97L3.36001 15.69C3.16001 16.55 4.09001 17.23 4.85001 16.77L9.00001 14.27Z" fill="currentcolor"/>
                                        </svg>
                                    </span>
                                <?php endfor; 
                                endif; ?>
                            </div>
                            <p class="pxl-testimonial-content">
                                <?php echo esc_html($content); ?>
                            </p>
                            <hr class="pxl-testimonial-divider">
                            <div class="pxl-testimonial-user">
                                <div class="pxl-user-image">
                                    <?php pxl_print_html($user_image); ?>
                                </div>
                                <div class="pxl-user-content">
                                    <span class="pxl-user-name"><?php echo esc_html($user_name); ?></span>
                                    <span class="pxl-user-title"><?php echo esc_html($user_title); ?></span>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php if(!empty($pagination)) : ?>
            <div class="swiper-pagination"></div>
        <?php endif; ?>
        <?php if($navigation) : ?>
            <div class="swiper-navigation <?php echo esc_attr($nav_hidden_class); ?>" 
            <?php if(!empty($nav_id)) : ?> data-navigation-id="<?php echo esc_attr($nav_id); ?>" <?php endif; ?>>
                <div class="pxl-swiper-button swiper-button-prev <?php echo esc_attr($nav_btn_style); ?>">
                    <span class="pxl-icon icon-prev">
                        <?php \Elementor\Icons_Manager::render_icon( $nav_btn_icon_prev, [ 'aria-hidden' => 'true', 'class' => 'pxl-button-icon' ], 'i' ); ?>
                    </span>
                </div>
                <div class="pxl-swiper-button swiper-button-next <?php echo esc_attr($nav_btn_style); ?>">
                    <span class="pxl-icon icon-next">
                        <?php \Elementor\Icons_Manager::render_icon( $nav_btn_icon_next, [ 'aria-hidden' => 'true', 'class' => 'pxl-button-icon' ], 'i' ); ?>
                    </span>
                </div>
            </div>
        <?php endif; ?>
    </div>
<?php endif; ?>