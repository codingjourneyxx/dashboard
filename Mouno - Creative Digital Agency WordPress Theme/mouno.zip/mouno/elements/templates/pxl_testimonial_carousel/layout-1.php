<?php 
$items = $widget->get_setting('testimonials', []);
if(!empty($items)) : 
    $effect                 = $widget->get_setting('effect', 'slide');
    $autoplay               = $widget->get_setting('autoplay', false);
    $disable_on_interaction = $widget->get_setting('disable_on_interaction', false);
    $delay                  = $widget->get_setting('delay', 5000);
    $loop                   = $widget->get_setting('loop', false);
    $speed                  = $widget->get_setting('speed', 500);
    $space_between          = $widget->get_setting('space_between', 151);
    $pagination             = $widget->get_setting('swiper_pagination', '');
    $navigation             = $widget->get_setting('swiper_navigation', false);
    $slides_per_view        = $widget->get_setting('slides_per_view', 'auto');
    $slides_per_view_xs     = $widget->get_setting('slides_per_view_xs', 1);
    $slides_per_view_sm     = $widget->get_setting('slides_per_view_sm', 1);
    $slides_per_view_md     = $widget->get_setting('slides_per_view_md', 1);
    $slides_per_view_lg     = $widget->get_setting('slides_per_view_lg', 1);
    $slides_per_view_xl     = $widget->get_setting('slides_per_view_xl', 1);
    $slides_per_view_xxl    = $widget->get_setting('slides_per_view_xxl', 1);
    $swiperParams           = [
        'effect'                 => $effect, 
        'direction'              => 'horizontal', 
        'autoplay'               => (bool)$autoplay,
        'disable_on_interaction' => (bool)$disable_on_interaction,
        'delay'                  => $delay,
        'loop'                   => (bool)$loop,
        'speed'                  => $speed,
        'space_between'          => $space_between,
        'pagination'             => $pagination,
        'navigation'             => (bool)$navigation,
        'slides_per_view'        => $slides_per_view,
        'slides_per_view_xs'     => (int)$slides_per_view_xs,
        'slides_per_view_sm'     => (int)$slides_per_view_sm,
        'slides_per_view_md'     => (int)$slides_per_view_md,
        'slides_per_view_lg'     => (int)$slides_per_view_lg,
        'slides_per_view_xl'     => (int)$slides_per_view_xl,
        'slides_per_view_xxl'    => (int)$slides_per_view_xxl,
    ];

    $swiperParams = json_encode($swiperParams);
    $nav_btn_icon_prev  = $widget->get_setting('nav_btn_icon_prev', []);
    $nav_btn_icon_next  = $widget->get_setting('nav_btn_icon_next', []);
    $nav_id = $widget->get_setting('nav_id', '');
    $nav_hidden_class = !empty($nav_id) ? 'swiper-navigation-hidden' : null;
    $nav_btn_style = $widget->get_setting('nav_btn_style', 'swiper-button-default');

    $anim = $widget->get_setting('entrance_anim', '');
    $anim_delay = $widget->get_setting('anim_delay', 0);
    $checked_anim = (!empty($anim) && $anim_delay != 0) || false;
?>
    <div class="pxl-swiper pxl-testimonial-carousel pxl-layout-testimonial pxl-layout-testimonial pxl-layout-testimonial1">
        <div class="swiper-container" data-swiper = "<?php echo esc_attr($swiperParams); ?>">
            <div class="swiper-wrapper">
                <?php foreach($items as $item) : 
                    $content = $item['content'] ?? '';
                    $name    = $item['name'] ?? '';
                    $title   = $item['title'] ?? '';
                ?>
                    <div class="swiper-slide <?php echo esc_attr($anim); ?>"
                    <?php if($checked_anim) : ?> data-wow-delay="<?php echo esc_attr(($key*$anim_delay).'ms'); ?>" <?php endif; ?>>
                        <div class="pxl-testimonial-item">
                            <p class="pxl-testimonial-content">
                                <?php echo esc_html($content); ?>
                            </p>
                            <div class="pxl-testimonial-user">
                                <span class="pxl-user-name"><?php echo esc_html($name); ?></span>
                                <span class="pxl-user-separator"><?php echo esc_html(', ', 'mouno'); ?></span>
                                <span class="pxl-user-title"><?php echo esc_html($title); ?></span>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php if(!empty($pagination)) : ?>
            <div class="swiper-pagination"></div>
        <?php endif; ?>
        <?php if($navigation) : ?>
            <div class="swiper-navigation <?php echo esc_attr($nav_hidden_class); ?>" 
            <?php if(!empty($nav_id)) : ?> data-navigation-id="<?php echo esc_attr($nav_id); ?>" <?php endif; ?>>
                <div class="pxl-swiper-button swiper-button-prev <?php echo esc_attr($nav_btn_style); ?>">
                    <span class="pxl-icon icon-prev">
                        <?php \Elementor\Icons_Manager::render_icon( $nav_btn_icon_prev, [ 'aria-hidden' => 'true', 'class' => 'pxl-button-icon' ], 'i' ); ?>
                    </span>
                </div>
                <div class="pxl-swiper-button swiper-button-next <?php echo esc_attr($nav_btn_style); ?>">
                    <span class="pxl-icon icon-next">
                        <?php \Elementor\Icons_Manager::render_icon( $nav_btn_icon_next, [ 'aria-hidden' => 'true', 'class' => 'pxl-button-icon' ], 'i' ); ?>
                    </span>
                </div>
            </div>
        <?php endif; ?>  
    </div>
<?php endif; 