<?php
    $text = $widget->parse_text_editor( $settings['text'] ?? '' );
    $anim = $widget->get_setting('entrance_anim', '');
 ?>

<div class="pxl-text-marquee-wrapper <?php echo esc_attr($settings['direction'].' '.$settings['marquee_type'].' '.$anim); ?>">
    <span class="pxl-text-marquee-item main">
        <?php pxl_print_html($text); ?>
    </span>
    <?php if(!empty($settings['duplicate'])) : ?>
        <span class="pxl-text-marquee-item duplicated">
            <?php pxl_print_html($text); ?>
        </span>
    <?php endif; ?>
</div>