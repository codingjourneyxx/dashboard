<?php
$slides = $widget->get_setting('slides', []);
$layers = $widget->get_setting('layers', []);
if(!empty($slides)) : 
    $effect                 = $widget->get_setting('effect', 'fade');
    $autoplay               = $widget->get_setting('autoplay', false);
    $disable_on_interaction = $widget->get_setting('disable_on_interaction', false);
    $delay                  = $widget->get_setting('delay', 5000);
    $loop                   = $widget->get_setting('loop', false);
    $speed                  = $widget->get_setting('speed', 500);
    $mousewheel             = (bool)$widget->get_setting('mousewheel', '');
    $space_between          = $widget->get_setting('space_between', 26);
    $pagination             = $widget->get_setting('swiper_pagination', '');
    $navigation             = $widget->get_setting('swiper_navigation', false);
    $swiperParams           = [
        'effect'                 => $effect, 
        'direction'              => 'horizontal', 
        'autoplay'               => (bool)$autoplay,
        'disable_on_interaction' => (bool)$disable_on_interaction,
        'delay'                  => $delay,
        'loop'                   => (bool)$loop,
        'speed'                  => $speed,
        'mousewheel'             => $mousewheel,
        'space_between'          => 0,
        'pagination'             => $pagination,
        'navigation'             => (bool)$navigation,
        'allow_touch_move'       => false,
        'slides_per_view'        => 'auto',
        'slides_per_view_xs'     => 1,
        'slides_per_view_sm'     => 1,
        'slides_per_view_md'     => 1,
        'slides_per_view_lg'     => 1,
        'slides_per_view_xl'     => 1,
        'slides_per_view_xxl'    => 1,
    ];
    $swiperParams = json_encode($swiperParams);

    $subtitle_anim = $widget->get_setting('subtitle_entrance_anim', '');
    $icon_anim     = $widget->get_setting('icon_entrance_anim', '');
    $desc_anim     = $widget->get_setting('desc_entrance_anim', '');
?>
    <div class="pxl-swiper pxl-slider pxl-slider1">
        <div class="swiper-container" data-swiper = "<?php echo esc_attr($swiperParams); ?>">
            <div class="swiper-wrapper">
                <?php foreach($slides as $key => $slide) : ?>
                    <?php 
                        $title = $widget->parse_text_editor($slide['title'] ?? '');
                        $subtitle = $slide['subtitle'] ?? '';
                        $desc     = $slide['desc'] ?? '';
                        $current_slide = $key + 1;
                        $icon_link = mouno_render_link_attributes($slide['icon_link']);
                        $icon_tag = is_null($icon_link) ? 'span' : 'a';
                    ?>
                    <div class="swiper-slide <?php echo esc_attr('elementor-repeater-item-'.$slide['_id']); ?>">
                        <?php if(!empty($layers)) : ?>
                            <?php foreach($layers as $key => $layer) : ?>
                                <?php
                                    $layer_anim_effect = $layer['layer_anim_effect'] ?? '';
                                    $layer_anim = $layer['layer_entrance_anim'] ?? '';
                                    $layer_img = mouno_get_image_by_size([
                                        'img_id' => $layer['layer_img']['id'],
                                        'img_dimension' => 'full',
                                        'attr' => [
                                            'class' => 'pxl-image '.$layer_anim_effect,
                                        ]
                                    ]);
                                    $show_in_slides = !empty($layer['show_in_slides']) ? explode('-', $layer['show_in_slides']) : [];
                                ?>
                                <?php if(in_array($current_slide, $show_in_slides) || empty($show_in_slides))  : ?>
                                    <span class="pxl-slide-layer <?php echo esc_attr('elementor-repeater-item-'.$layer['_id'].' '.$layer_anim); ?>">
                                        <?php pxl_print_html($layer_img); ?>
                                    </span>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        <?php endif; ?>
                        <div class="pxl-slide-item">
                            <div class="pxl-slide-inner">
                                <div class="pxl-slide-heading">
                                    <div class="pxl-heading-subtitle <?php echo esc_attr($subtitle_anim); ?>">
                                        <?php echo esc_html($subtitle); ?>
                                    </div>
                                    <h1 class="pxl-heading-title">
                                        <span class="pxl-title-text">
                                            <?php pxl_print_html($title); ?>
                                        </span>
                                    </h1>
                                </div>
                                <div class="pxl-slide-content">
                                    <<?php echo esc_attr($icon_tag); pxl_print_html(' '.$icon_link); ?>  class="pxl-slide-icon <?php echo esc_attr($icon_anim); ?>">
                                        <?php \Elementor\Icons_Manager::render_icon( $slide['_icon'], [ 'aria-hidden' => 'true', 'class' => '' ], 'i' ); ?>
                                    </<?php echo esc_attr($icon_tag); ?>>
                                    <p class="pxl-slide-description <?php echo esc_attr($desc_anim); ?>">
                                        <?php echo esc_html($desc); ?>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php if(!empty($pagination)) : ?>
            <div class="swiper-pagination"></div>
        <?php endif; ?>
        <?php if($navigation) : ?>
            <div class="swiper-navigation <?php echo esc_attr($nav_hidden_class); ?>" 
            <?php if(!empty($nav_id)) : ?> data-navigation-id="<?php echo esc_attr($nav_id); ?>" <?php endif; ?>>
                <div class="pxl-swiper-button swiper-button-prev <?php echo esc_attr($nav_btn_style); ?>">
                    <span class="pxl-icon icon-prev">
                        <?php \Elementor\Icons_Manager::render_icon( $nav_btn_icon_prev, [ 'aria-hidden' => 'true', 'class' => 'pxl-button-icon' ], 'i' ); ?>
                    </span>
                </div>
                <div class="pxl-swiper-button swiper-button-next <?php echo esc_attr($nav_btn_style); ?>">
                    <span class="pxl-icon icon-next">
                        <?php \Elementor\Icons_Manager::render_icon( $nav_btn_icon_next, [ 'aria-hidden' => 'true', 'class' => 'pxl-button-icon' ], 'i' ); ?>
                    </span>
                </div>
            </div>
        <?php endif; ?> 
    </div>
<?php endif; ?>
