<?php 
    $is_links = isset($settings['links']) && !empty($settings['links']) && count($settings['links']) || false;
    $anim = $widget->get_setting('entrance_anim', '');
    $anim_delay = $widget->get_setting('anim_delay', 0);
    $checked_anim = (!empty($anim) && $anim_delay !== 0) || false;
?>


<?php if($is_links) : ?>
    <ul class="pxl-links-wrapper">
        <?php foreach($settings['links'] as $key => $link) : ?>
            <li class="pxl-links-item <?php echo esc_attr($anim); ?>"
            <?php if($checked_anim) : ?> data-wow-delay="<?php //echo esc_attr(($key * $anim_delay).'ms'); ?>" <?php endif; ?>>
                <a class="pxl-link <?php echo esc_attr($settings['link_style'].' '.$settings['link_hover_style']); ?>" <?php pxl_print_html(mouno_render_link_attributes($link['link_url'])); ?>>
                    <?php \Elementor\Icons_Manager::render_icon( $link['link_icon'], [ 'aria-hidden' => 'true', 'class' => '' ], 'i' ); ?>
                    <span class="pxl-link-text" >
                        <?php echo esc_html($link['link_text']); ?>
                    </span>
                </a>
            </li>
        <?php endforeach; ?>
    </ul>
<?php endif; ?>