<div class="pxl-image-box pxl-image-box1">
    <div class="pxl-item--inner">
        <div class="canvas"></div>
        <div class="item--image">            
            <img src="https://raw.githubusercontent.com/ivanalbizu/WEBGL-texture-Hover/main/src/img/chair-02.jpg" class="image-front attachment-full" alt="image front" data-sampler="texture0">
            <img src="https://raw.githubusercontent.com/ivanalbizu/WEBGL-texture-Hover/main/src/img/chair-02.jpg" class="image-back attachment-full" alt="image back" data-sampler="texture1">
            <img src="https://raw.githubusercontent.com/ivanalbizu/WEBGL-texture-Hover/main/src/img/displacements/01.jpg" class="map" alt="image displacements" data-sampler="map" crossorigin="anonymous">
        </div>
    </div>
</div>