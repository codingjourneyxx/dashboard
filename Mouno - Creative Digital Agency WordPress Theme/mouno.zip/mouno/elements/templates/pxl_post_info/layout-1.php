<?php 
    $post_id = get_the_ID();
    $post_type = get_post_type();
    $taxonomy_category = $post_type === 'post' ? 'category' : $post_type.'-category';
    $taxonomy_tag = $post_type === 'post' ? 'post_tag' : $post_type.'-tags';

    $show_title = (!empty($settings['show_title'])) || false;
?>

<div class="pxl-post-info-wrapper">
    <?php if(!empty($settings['items'])) : ?>
        <?php foreach($settings['items'] as $item) : ?>
            <?php 
                $info = $item['info']; 
                $item_link = isset($item['link']) ? mouno_render_link_attributes($item['link']) : null;
                $item_tag  = !empty($item_link) ? 'a' : 'span';
            ?>
            <div class="pxl-post-info-item">
                <div class="pxl-info-icon">
                    <?php \Elementor\Icons_Manager::render_icon( $item['_icon'], [ 'aria-hidden' => 'true', 'class' => '' ], 'i' ); ?>
                </div>
                <div class="pxl-info-content">
                    <?php if($show_title) : ?>
                        <span class="pxl-info-title">
                            <?php echo esc_html($item['title']); ?>
                        </span>
                    <?php endif; ?>
                    <span class="pxl-info-meta">
                        <?php if($info === 'category') : ?>
                            <?php the_terms( $post_id, $taxonomy_category, '', ', '); ?>
                        <?php elseif($info === 'date') : ?>
                            <span>
                                <?php echo get_the_date( 'F j, Y', $post_id ); ?>
                            </span>
                        <?php elseif($info === 'author') : ?>
                            <?php  
                                $author_id = get_post_field ('post_author', $post_id);
                            ?>
                            <a href="<?php echo esc_url(get_author_posts_url($author_id)); ?>" class="pxl-author-link">
                                <?php echo esc_attr(get_the_author_meta('display_name', $author_id)); ?>
                            </a>
                        <?php elseif($info === 'tags') : ?>
                            <?php the_terms( $post_id, $taxonomy_tag, '', ', '); ?>
                        <?php else : ?>
                            <<?php echo esc_attr($item_tag); ?> <?php pxl_print_html($item_link); ?>>
                                <?php echo esc_html($info); ?>
                            </<?php echo esc_attr($item_tag); ?>>
                        <?php endif; ?>
                    </span>
                </div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>