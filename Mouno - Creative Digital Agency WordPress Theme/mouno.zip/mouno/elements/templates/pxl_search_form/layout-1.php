<div class="pxl-search-form-wrapper">
	<?php get_search_form(); ?>
</div>