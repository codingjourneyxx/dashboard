<?php 
    $btn_icon_prev = $widget->get_setting('l_icon', []);
    $btn_icon_next = $widget->get_setting('r_icon', []);
    $nav_id = $widget->get_setting('nav_id', pxl_get_element_id($settings));
    $nav_btn_style = $widget->get_setting('nav_btn_style', 'swiper-button-default');
    $entrance_anim = $widget->get_setting('entrance_anim', '');
?>
<div id="<?php echo esc_attr($nav_id); ?>" class="pxl-navigation-carousel swiper-navigation <?php echo esc_attr($entrance_anim); ?>">
    <div class="pxl-swiper-button pxl-swiper-button-prev swiper-button-prev <?php echo esc_attr($nav_btn_style); ?>">
        <span class="pxl-icon icon-prev">
            <?php \Elementor\Icons_Manager::render_icon( $btn_icon_prev, [ 'aria-hidden' => 'true', 'class' => 'pxl-icon' ], 'i' ); ?>
        </span>
    </div>
    <div class="pxl-swiper-button pxl-swiper-button-next swiper-button-next <?php echo esc_attr($nav_btn_style); ?>">
        <span class="pxl-icon icon-next">
            <?php \Elementor\Icons_Manager::render_icon( $btn_icon_next, [ 'aria-hidden' => 'true', 'class' => 'pxl-icon' ], 'i' ); ?>
        </span>
    </div>
</div>
<!--  -->