<?php 
    $hover_styles = $widget->get_setting('btn_hover_styles', []);
    $btn_style = $widget->get_setting('btn_style', 'pxl-cta-button1');
    $anim  = $widget->get_setting('entrance_anim', '');
    $class = 'btn pxl-cta-button '.$btn_style;
    if(!empty($hover_styles)) {
        foreach($hover_styles as $value) {
            $class .= ' '.$value;
        }
    }
    $attrs = [
        'class' => $class,
    ];
    $widget->add_render_attribute( 'attrs', $attrs);


    $hidden_panel_template_id = (int)$widget->get_setting('hidden_panel_template', 0);
    $template_class = '#';
    if($hidden_panel_template_id > 0) {
        if(!has_action( 'pxl_anchor_target_hidden_panel_'.$hidden_panel_template_id)){
            add_action( 'pxl_anchor_target_hidden_panel_'.$hidden_panel_template_id, 'mouno_hook_anchor_hidden_panel' );
        }
        $template_class .= 'hidden-panel-template-'.$hidden_panel_template_id;
    }
?>
<div class="pxl-cta-button-wrapper <?php echo esc_attr($anim); ?>">
    <a <?php pxl_print_html($widget->get_render_attribute_string('attrs')); ?> href="<?php echo esc_attr($template_class); ?>">
        <?php \Elementor\Icons_Manager::render_icon( $settings['btn_icon'], [ 'aria-hidden' => 'true', 'class' => '' ], 'i' ); ?>
    </a>
</div>
