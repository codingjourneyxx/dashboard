<?php
/**
 * @package Case-Themes
 */
get_header(); 
$page_id = mouno()->get_theme_opt('404_page', '');
if(!empty($page_id)) :
    echo Elementor\Plugin::$instance->frontend->get_builder_content_for_display((int)$page_id);
else : ?>
<div class="container">
    <div class="inner">
        <h1></h1>
    </div>
</div>
<?php endif;
get_footer();