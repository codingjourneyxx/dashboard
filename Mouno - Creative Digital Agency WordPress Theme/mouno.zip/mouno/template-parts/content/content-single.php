<?php
/**
 * Template part for displaying posts in loop
 *
 * @package Case-Themes
 */
// $post_tag = mouno()->get_theme_opt( 'post_tag', true );
// $post_navigation = mouno()->get_theme_opt( 'post_navigation', false );
// $post_social_share = mouno()->get_theme_opt( 'post_social_share', false );
// $tags_list = get_the_tag_list();
// $sg_post_title = mouno()->get_theme_opt('sg_post_title', 'default');
// $sg_featured_img_size = mouno()->get_theme_opt('sg_featured_img_size', '960x545');
// $post_video_link = get_post_meta(get_the_ID(), 'post_video_link', true);
?>
<article id="pxl-post-<?php the_ID(); ?>" <?php post_class('pxl-single-post'); ?>>
    <?php 
        $post_id = get_the_ID();
        $thumbnail = mouno_get_image_by_size([
            'img_dimension' => 'full' ,
            'attr' => [
                'class' => 'pxl-post-featured',
            ],
        ], $post_id);
    ?>
    <div class="pxl-post-header">
        <h2 class="pxl-post-title">
            <span class="pxl-title-text">
                <?php the_title(); ?>
            </span>
        </h2>
        <?php mouno()->blog->get_post_metas($post_id); ?>
        <div class="pxl-post-featured">
            <?php echo wp_kses_post($thumbnail); ?>
        </div>
    </div>
    <div class="pxl-post-content clearfix">
        <?php
            the_content();
            wp_link_pages( array(
                'before'      => '<div class="page-links">',
                'after'       => '</div>',
                'link_before' => '<span>',
                'link_after'  => '</span>',
            ) );
        ?>
    </div>
    <div class="pxl-post-group">
        <?php mouno()->blog->get_socials_share(); ?>
        <?php mouno()->blog->get_post_author_info($post_id); ?>
    </div>
</article><!-- #post -->