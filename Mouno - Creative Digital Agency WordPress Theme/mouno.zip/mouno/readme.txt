=== Mouno - CaseThemees ===
Contributors: wordpressdotorg
Requires at least: 6.6.x
Tested up to: 6.4
Requires PHP: 8.0
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==


== Changelog ==