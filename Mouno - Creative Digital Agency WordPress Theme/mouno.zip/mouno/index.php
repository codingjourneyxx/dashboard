<?php
/**
 * @package Case-Themes
 */

get_header();

$sidebar = mouno()->get_sidebar_value('blog'); 
$paragraph = 'Mouno provide best digital product design for firms who are launching new products. We have best 3D artists here to serve best outputs.';
?>
<div class="container">
    <div class="pxl-content-header">
        <div class="pxl-heading-wrapper">
            <div class="pxl-heading-subtitle heading-subtitle-default">
                <span class="pxl-subtitle-text">
                <span class="pxl-text-highlight"><?php echo esc_html__('//', 'mouno') ?></span>
                    <?php echo esc_html__('Latest news', 'mouno'); ?>
                </span>
            </div>
            <h2 class="pxl-heading-title heading-title-default">
                <span class="pxl-title-text">
                    <span class="pxl-text-highlight"><?php echo esc_html__('Amazing Research', 'mouno') ?></span>
                    <?php echo esc_html__('news & blogs', 'mouno'); ?>
                </span>
            </h2>
        </div>
        <p class="pxl-text-paragraph">
            <?php echo esc_html($paragraph, 'mouno'); ?>
        </p>
    </div>
    <div class="inner <?php echo esc_attr($sidebar['sidebar_class']); ?>" >
        <div id="pxl-content-area" class="pxl-content-area">
            <main id="pxl-content-main">
                <?php if ( have_posts() ) {
                    while ( have_posts() ) {
                        the_post();
                        get_template_part( 'template-parts/content/archive/standard' );
                    }
                    mouno()->page->get_pagination();
                } else {
                    get_template_part( 'template-parts/content/content', 'none' );
                } ?>
            </main>
        </div>
        <?php if($sidebar['is_sidebar'] == true) : ?>
            <div id="pxl-sidebar-area" class="pxl-sidebar-area">
                <div class="pxl-sidebar-content">
                    <?php get_sidebar(); ?>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php get_footer();
