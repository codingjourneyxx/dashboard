<?php
/**
 * The Front Page template file.
 *
 * @package RENTIC
 * @since RENTIC 1.0.31
 */

get_header();

// If front-page is a static page
if ( get_option( 'show_on_front' ) == 'page' ) {

	// If Front Page Builder is enabled - display sections
	if ( rentic_is_on( rentic_get_theme_option( 'front_page_enabled', false ) ) ) {

		if ( have_posts() ) {
			the_post();
		}

		$rentic_sections = rentic_array_get_keys_by_value( rentic_get_theme_option( 'front_page_sections' ) );
		if ( is_array( $rentic_sections ) ) {
			foreach ( $rentic_sections as $rentic_section ) {
				get_template_part( apply_filters( 'rentic_filter_get_template_part', 'front-page/section', $rentic_section ), $rentic_section );
			}
		}

		// Else if this page is a blog archive
	} elseif ( is_page_template( 'blog.php' ) ) {
		get_template_part( apply_filters( 'rentic_filter_get_template_part', 'blog' ) );

		// Else - display a native page content
	} else {
		get_template_part( apply_filters( 'rentic_filter_get_template_part', 'page' ) );
	}

	// Else get the template 'index.php' to show posts
} else {
	get_template_part( apply_filters( 'rentic_filter_get_template_part', 'index' ) );
}

get_footer();
