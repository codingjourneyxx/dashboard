<?php
/**
 * The template to display the page title and breadcrumbs
 *
 * @package RENTIC
 * @since RENTIC 1.0
 */

// Page (category, tag, archive, author) title

if ( rentic_need_page_title() ) {
	rentic_sc_layouts_showed( 'title', true );
	rentic_sc_layouts_showed( 'postmeta', true );
	?>
	<div class="top_panel_title sc_layouts_row sc_layouts_row_type_normal">
		<div class="content_wrap">
			<div class="sc_layouts_column sc_layouts_column_align_center">
				<div class="sc_layouts_item">
					<div class="sc_layouts_title sc_align_center">
						<?php
						// Post meta on the single post
						if ( is_single() ) {
							?>
							<div class="sc_layouts_title_meta">
							<?php
								rentic_show_post_meta(
									apply_filters(
										'rentic_filter_post_meta_args', array(
											'components' => join( ',', rentic_array_get_keys_by_value( rentic_get_theme_option( 'meta_parts' ) ) ),
											'counters'   => join( ',', rentic_array_get_keys_by_value( rentic_get_theme_option( 'counters' ) ) ),
											'seo'        => rentic_is_on( rentic_get_theme_option( 'seo_snippets' ) ),
										), 'header', 1
									)
								);
							?>
							</div>
							<?php
						}

						// Blog/Post title
						?>
						<div class="sc_layouts_title_title">
							<?php
							$rentic_blog_title           = rentic_get_blog_title();
							$rentic_blog_title_text      = '';
							$rentic_blog_title_class     = '';
							$rentic_blog_title_link      = '';
							$rentic_blog_title_link_text = '';
							if ( is_array( $rentic_blog_title ) ) {
								$rentic_blog_title_text      = $rentic_blog_title['text'];
								$rentic_blog_title_class     = ! empty( $rentic_blog_title['class'] ) ? ' ' . $rentic_blog_title['class'] : '';
								$rentic_blog_title_link      = ! empty( $rentic_blog_title['link'] ) ? $rentic_blog_title['link'] : '';
								$rentic_blog_title_link_text = ! empty( $rentic_blog_title['link_text'] ) ? $rentic_blog_title['link_text'] : '';
							} else {
								$rentic_blog_title_text = $rentic_blog_title;
							}
							?>
							<h1 class="sc_layouts_title_caption<?php echo esc_attr( $rentic_blog_title_class ); ?>"<?php
								if ( rentic_is_on( rentic_get_theme_option( 'seo_snippets' ) ) ) {
									?> itemprop="headline"<?php
								}
							?>>
								<?php
								$rentic_top_icon = rentic_get_term_image_small();
								if ( ! empty( $rentic_top_icon ) ) {
									$rentic_attr = rentic_getimagesize( $rentic_top_icon );
									?>
									<img src="<?php echo esc_url( $rentic_top_icon ); ?>" alt="<?php esc_attr_e( 'Site icon', 'rentic' ); ?>"
										<?php
										if ( ! empty( $rentic_attr[3] ) ) {
											rentic_show_layout( $rentic_attr[3] );
										}
										?>
									>
									<?php
								}
								echo wp_kses_data( $rentic_blog_title_text );
								?>
							</h1>
							<?php
							if ( ! empty( $rentic_blog_title_link ) && ! empty( $rentic_blog_title_link_text ) ) {
								?>
								<a href="<?php echo esc_url( $rentic_blog_title_link ); ?>" class="theme_button theme_button_small sc_layouts_title_link"><?php echo esc_html( $rentic_blog_title_link_text ); ?></a>
								<?php
							}

							// Category/Tag description
							if ( ! is_paged() && ( is_category() || is_tag() || is_tax() ) ) {
								the_archive_description( '<div class="sc_layouts_title_description">', '</div>' );
							}

							?>
						</div>
						<?php

						// Breadcrumbs
						ob_start();
						do_action( 'rentic_action_breadcrumbs' );
						$rentic_breadcrumbs = ob_get_contents();
						ob_end_clean();
						rentic_show_layout( $rentic_breadcrumbs, '<div class="sc_layouts_title_breadcrumbs">', '</div>' );
						?>
					</div>
				</div>
			</div>
		</div>
	</div>
	<?php
}
