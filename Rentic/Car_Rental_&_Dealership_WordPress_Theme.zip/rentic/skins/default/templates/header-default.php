<?php
/**
 * The template to display default site header
 *
 * @package RENTIC
 * @since RENTIC 1.0
 */

$rentic_header_css   = '';
$rentic_header_image = get_header_image();
$rentic_header_video = rentic_get_header_video();
if ( ! empty( $rentic_header_image ) && rentic_trx_addons_featured_image_override( is_singular() || rentic_storage_isset( 'blog_archive' ) || is_category() ) ) {
	$rentic_header_image = rentic_get_current_mode_image( $rentic_header_image );
}

?><header class="top_panel top_panel_default
	<?php
	echo ! empty( $rentic_header_image ) || ! empty( $rentic_header_video ) ? ' with_bg_image' : ' without_bg_image';
	if ( '' != $rentic_header_video ) {
		echo ' with_bg_video';
	}
	if ( '' != $rentic_header_image ) {
		echo ' ' . esc_attr( rentic_add_inline_css_class( 'background-image: url(' . esc_url( $rentic_header_image ) . ');' ) );
	}
	if ( is_single() && has_post_thumbnail() ) {
		echo ' with_featured_image';
	}
	if ( rentic_is_on( rentic_get_theme_option( 'header_fullheight' ) ) ) {
		echo ' header_fullheight rentic-full-height';
	}
	$rentic_header_scheme = rentic_get_theme_option( 'header_scheme' );
	if ( ! empty( $rentic_header_scheme ) && ! rentic_is_inherit( $rentic_header_scheme  ) ) {
		echo ' scheme_' . esc_attr( $rentic_header_scheme );
	}
	?>
">
	<?php

	// Background video
	if ( ! empty( $rentic_header_video ) ) {
		get_template_part( apply_filters( 'rentic_filter_get_template_part', 'templates/header-video' ) );
	}

	// Main menu
	get_template_part( apply_filters( 'rentic_filter_get_template_part', 'templates/header-navi' ) );

	// Mobile header
	if ( rentic_is_on( rentic_get_theme_option( 'header_mobile_enabled' ) ) ) {
		get_template_part( apply_filters( 'rentic_filter_get_template_part', 'templates/header-mobile' ) );
	}

	// Page title and breadcrumbs area
	if ( ! is_single() ) {
		get_template_part( apply_filters( 'rentic_filter_get_template_part', 'templates/header-title' ) );
	}

	// Header widgets area
	get_template_part( apply_filters( 'rentic_filter_get_template_part', 'templates/header-widgets' ) );
	?>
</header>
