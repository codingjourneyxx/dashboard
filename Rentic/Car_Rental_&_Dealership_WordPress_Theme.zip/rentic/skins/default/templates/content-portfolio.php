<?php
/**
 * The Portfolio template to display the content
 *
 * Used for index/archive/search.
 *
 * @package RENTIC
 * @since RENTIC 1.0
 */

$rentic_template_args = get_query_var( 'rentic_template_args' );
if ( is_array( $rentic_template_args ) ) {
	$rentic_columns    = empty( $rentic_template_args['columns'] ) ? 2 : max( 1, $rentic_template_args['columns'] );
	$rentic_blog_style = array( $rentic_template_args['type'], $rentic_columns );
    $rentic_columns_class = rentic_get_column_class( 1, $rentic_columns, ! empty( $rentic_template_args['columns_tablet']) ? $rentic_template_args['columns_tablet'] : '', ! empty($rentic_template_args['columns_mobile']) ? $rentic_template_args['columns_mobile'] : '' );
} else {
	$rentic_template_args = array();
	$rentic_blog_style = explode( '_', rentic_get_theme_option( 'blog_style' ) );
	$rentic_columns    = empty( $rentic_blog_style[1] ) ? 2 : max( 1, $rentic_blog_style[1] );
    $rentic_columns_class = rentic_get_column_class( 1, $rentic_columns );
}

$rentic_post_format = get_post_format();
$rentic_post_format = empty( $rentic_post_format ) ? 'standard' : str_replace( 'post-format-', '', $rentic_post_format );

?><div class="
<?php
if ( ! empty( $rentic_template_args['slider'] ) ) {
	echo ' slider-slide swiper-slide';
} else {
	echo ( rentic_is_blog_style_use_masonry( $rentic_blog_style[0] ) ? 'masonry_item masonry_item-1_' . esc_attr( $rentic_columns ) : esc_attr( $rentic_columns_class ));
}
?>
"><article id="post-<?php the_ID(); ?>" 
	<?php
	post_class(
		'post_item post_item_container post_format_' . esc_attr( $rentic_post_format )
		. ' post_layout_portfolio'
		. ' post_layout_portfolio_' . esc_attr( $rentic_columns )
		. ( 'portfolio' != $rentic_blog_style[0] ? ' ' . esc_attr( $rentic_blog_style[0] )  . '_' . esc_attr( $rentic_columns ) : '' )
	);
	rentic_add_blog_animation( $rentic_template_args );
	?>
>
<?php

	// Sticky label
	if ( is_sticky() && ! is_paged() ) {
		?><span class="post_label label_sticky"></span><?php
	}

	$rentic_hover   = ! empty( $rentic_template_args['hover'] ) && ! rentic_is_inherit( $rentic_template_args['hover'] )
								? $rentic_template_args['hover']
								: rentic_get_theme_option( 'image_hover' );

	if ( 'dots' == $rentic_hover ) {
		$rentic_post_link = empty( $rentic_template_args['no_links'] )
								? ( ! empty( $rentic_template_args['link'] )
									? $rentic_template_args['link']
									: get_permalink()
									)
								: '';
		$rentic_target    = ! empty( $rentic_post_link ) && rentic_is_external_url( $rentic_post_link ) && function_exists( 'rentic_external_links_target' )
								? rentic_external_links_target()
								: '';
	}
	
	// Meta parts
	$rentic_components = ! empty( $rentic_template_args['meta_parts'] )
							? ( is_array( $rentic_template_args['meta_parts'] )
								? $rentic_template_args['meta_parts']
								: explode( ',', $rentic_template_args['meta_parts'] )
								)
							: rentic_array_get_keys_by_value( rentic_get_theme_option( 'meta_parts' ) );

	// Featured image
	rentic_show_post_featured( apply_filters( 'rentic_filter_args_featured', 
        array(
			'hover'         => $rentic_hover,
			'no_links'      => ! empty( $rentic_template_args['no_links'] ),
			'thumb_size'    => ! empty( $rentic_template_args['thumb_size'] )
								? $rentic_template_args['thumb_size']
								: rentic_get_thumb_size(
									rentic_is_blog_style_use_masonry( $rentic_blog_style[0] )
										? (	strpos( rentic_get_theme_option( 'body_style' ), 'full' ) !== false || $rentic_columns < 3
											? 'masonry-big'
											: 'masonry'
											)
										: (	strpos( rentic_get_theme_option( 'body_style' ), 'full' ) !== false || $rentic_columns < 3
											? 'square'
											: 'square'
											)
								),
			'thumb_bg' => rentic_is_blog_style_use_masonry( $rentic_blog_style[0] ) ? false : true,
			'show_no_image' => true,
			'meta_parts'    => $rentic_components,
			'class'         => 'dots' == $rentic_hover ? 'hover_with_info' : '',
			'post_info'     => 'dots' == $rentic_hover
										? '<div class="post_info"><h5 class="post_title">'
											. ( ! empty( $rentic_post_link )
												? '<a href="' . esc_url( $rentic_post_link ) . '"' . ( ! empty( $target ) ? $target : '' ) . '>'
												: ''
												)
												. esc_html( get_the_title() ) 
											. ( ! empty( $rentic_post_link )
												? '</a>'
												: ''
												)
											. '</h5></div>'
										: '',
            'thumb_ratio'   => 'info' == $rentic_hover ?  '100:102' : '',
        ),
        'content-portfolio',
        $rentic_template_args
    ) );
	?>
</article></div><?php
// Need opening PHP-tag above, because <article> is a inline-block element (used as column)!