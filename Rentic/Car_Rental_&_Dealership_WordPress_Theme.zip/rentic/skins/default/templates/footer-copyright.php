<?php
/**
 * The template to display the copyright info in the footer
 *
 * @package RENTIC
 * @since RENTIC 1.0.10
 */

// Copyright area
?> 
<div class="footer_copyright_wrap
<?php
$rentic_copyright_scheme = rentic_get_theme_option( 'copyright_scheme' );
if ( ! empty( $rentic_copyright_scheme ) && ! rentic_is_inherit( $rentic_copyright_scheme  ) ) {
	echo ' scheme_' . esc_attr( $rentic_copyright_scheme );
}
?>
				">
	<div class="footer_copyright_inner">
		<div class="content_wrap">
			<div class="copyright_text">
			<?php
				$rentic_copyright = rentic_get_theme_option( 'copyright' );
			if ( ! empty( $rentic_copyright ) ) {
				// Replace {{Y}} or {Y} with the current year
				$rentic_copyright = str_replace( array( '{{Y}}', '{Y}' ), date( 'Y' ), $rentic_copyright );
				// Replace {{...}} and ((...)) on the <i>...</i> and <b>...</b>
				$rentic_copyright = rentic_prepare_macros( $rentic_copyright );
				// Display copyright
				echo wp_kses( nl2br( $rentic_copyright ), 'rentic_kses_content' );
			}
			?>
			</div>
		</div>
	</div>
</div>
