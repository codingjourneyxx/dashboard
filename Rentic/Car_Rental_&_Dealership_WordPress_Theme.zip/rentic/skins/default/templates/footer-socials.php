<?php
/**
 * The template to display the socials in the footer
 *
 * @package RENTIC
 * @since RENTIC 1.0.10
 */


// Socials
if ( rentic_is_on( rentic_get_theme_option( 'socials_in_footer' ) ) ) {
	$rentic_output = rentic_get_socials_links();
	if ( '' != $rentic_output ) {
		?>
		<div class="footer_socials_wrap socials_wrap">
			<div class="footer_socials_inner">
				<?php rentic_show_layout( $rentic_output ); ?>
			</div>
		</div>
		<?php
	}
}
