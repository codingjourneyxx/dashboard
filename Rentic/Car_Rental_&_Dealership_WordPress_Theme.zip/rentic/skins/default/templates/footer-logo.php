<?php
/**
 * The template to display the site logo in the footer
 *
 * @package RENTIC
 * @since RENTIC 1.0.10
 */

// Logo
if ( rentic_is_on( rentic_get_theme_option( 'logo_in_footer' ) ) ) {
	$rentic_logo_image = rentic_get_logo_image( 'footer' );
	$rentic_logo_text  = get_bloginfo( 'name' );
	if ( ! empty( $rentic_logo_image['logo'] ) || ! empty( $rentic_logo_text ) ) {
		?>
		<div class="footer_logo_wrap">
			<div class="footer_logo_inner">
				<?php
				if ( ! empty( $rentic_logo_image['logo'] ) ) {
					$rentic_attr = rentic_getimagesize( $rentic_logo_image['logo'] );
					echo '<a href="' . esc_url( home_url( '/' ) ) . '">'
							. '<img src="' . esc_url( $rentic_logo_image['logo'] ) . '"'
								. ( ! empty( $rentic_logo_image['logo_retina'] ) ? ' srcset="' . esc_url( $rentic_logo_image['logo_retina'] ) . ' 2x"' : '' )
								. ' class="logo_footer_image"'
								. ' alt="' . esc_attr__( 'Site logo', 'rentic' ) . '"'
								. ( ! empty( $rentic_attr[3] ) ? ' ' . wp_kses_data( $rentic_attr[3] ) : '' )
							. '>'
						. '</a>';
				} elseif ( ! empty( $rentic_logo_text ) ) {
					echo '<h1 class="logo_footer_text">'
							. '<a href="' . esc_url( home_url( '/' ) ) . '">'
								. esc_html( $rentic_logo_text )
							. '</a>'
						. '</h1>';
				}
				?>
			</div>
		</div>
		<?php
	}
}
