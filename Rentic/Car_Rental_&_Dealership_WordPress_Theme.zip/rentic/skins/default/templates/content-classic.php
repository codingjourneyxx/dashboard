<?php
/**
 * The Classic template to display the content
 *
 * Used for index/archive/search.
 *
 * @package RENTIC
 * @since RENTIC 1.0
 */

$rentic_template_args = get_query_var( 'rentic_template_args' );

if ( is_array( $rentic_template_args ) ) {
	$rentic_columns    = empty( $rentic_template_args['columns'] ) ? 2 : max( 1, $rentic_template_args['columns'] );
	$rentic_blog_style = array( $rentic_template_args['type'], $rentic_columns );
    $rentic_columns_class = rentic_get_column_class( 1, $rentic_columns, ! empty( $rentic_template_args['columns_tablet']) ? $rentic_template_args['columns_tablet'] : '', ! empty($rentic_template_args['columns_mobile']) ? $rentic_template_args['columns_mobile'] : '' );
} else {
	$rentic_template_args = array();
	$rentic_blog_style = explode( '_', rentic_get_theme_option( 'blog_style' ) );
	$rentic_columns    = empty( $rentic_blog_style[1] ) ? 2 : max( 1, $rentic_blog_style[1] );
    $rentic_columns_class = rentic_get_column_class( 1, $rentic_columns );
}
$rentic_expanded   = ! rentic_sidebar_present() && rentic_get_theme_option( 'expand_content' ) == 'expand';

$rentic_post_format = get_post_format();
$rentic_post_format = empty( $rentic_post_format ) ? 'standard' : str_replace( 'post-format-', '', $rentic_post_format );

?><div class="<?php
	if ( ! empty( $rentic_template_args['slider'] ) ) {
		echo ' slider-slide swiper-slide';
	} else {
		echo ( rentic_is_blog_style_use_masonry( $rentic_blog_style[0] ) ? 'masonry_item masonry_item-1_' . esc_attr( $rentic_columns ) : esc_attr( $rentic_columns_class ) );
	}
?>"><article id="post-<?php the_ID(); ?>" data-post-id="<?php the_ID(); ?>"
	<?php
	post_class(
		'post_item post_item_container post_format_' . esc_attr( $rentic_post_format )
				. ' post_layout_classic post_layout_classic_' . esc_attr( $rentic_columns )
				. ' post_layout_' . esc_attr( $rentic_blog_style[0] )
				. ' post_layout_' . esc_attr( $rentic_blog_style[0] ) . '_' . esc_attr( $rentic_columns )
	);
	rentic_add_blog_animation( $rentic_template_args );
	?>
>
	<?php

	// Sticky label
	if ( is_sticky() && ! is_paged() ) {
		?>
		<span class="post_label label_sticky"></span>
		<?php
	}

	// Featured image
	$rentic_hover      = ! empty( $rentic_template_args['hover'] ) && ! rentic_is_inherit( $rentic_template_args['hover'] )
							? $rentic_template_args['hover']
							: rentic_get_theme_option( 'image_hover' );

	$rentic_components = ! empty( $rentic_template_args['meta_parts'] )
							? ( is_array( $rentic_template_args['meta_parts'] )
								? $rentic_template_args['meta_parts']
								: explode( ',', $rentic_template_args['meta_parts'] )
								)
							: rentic_array_get_keys_by_value( rentic_get_theme_option( 'meta_parts' ) );

	rentic_show_post_featured( apply_filters( 'rentic_filter_args_featured',
		array(
			'thumb_size' => ! empty( $rentic_template_args['thumb_size'] )
				? $rentic_template_args['thumb_size']
				: rentic_get_thumb_size(
					'classic' == $rentic_blog_style[0]
						? ( strpos( rentic_get_theme_option( 'body_style' ), 'full' ) !== false
								? ( $rentic_columns > 2 ? 'big' : 'huge' )
								: ( $rentic_columns > 2
									? ( $rentic_expanded ? 'square' : 'square' )
									: ($rentic_columns > 1 ? 'square' : ( $rentic_expanded ? 'huge' : 'big' ))
									)
							)
						: ( strpos( rentic_get_theme_option( 'body_style' ), 'full' ) !== false
								? ( $rentic_columns > 2 ? 'masonry-big' : 'full' )
								: ($rentic_columns === 1 ? ( $rentic_expanded ? 'huge' : 'big' ) : ( $rentic_columns <= 2 && $rentic_expanded ? 'masonry-big' : 'masonry' ))
							)
			),
			'hover'      => $rentic_hover,
			'meta_parts' => $rentic_components,
			'no_links'   => ! empty( $rentic_template_args['no_links'] ),
        ),
        'content-classic',
        $rentic_template_args
    ) );

	// Title and post meta
	$rentic_show_title = get_the_title() != '';
	$rentic_show_meta  = count( $rentic_components ) > 0 && ! in_array( $rentic_hover, array( 'border', 'pull', 'slide', 'fade', 'info' ) );

	if ( $rentic_show_title ) {
		?>
		<div class="post_header entry-header">
			<?php

			// Post meta
			if ( apply_filters( 'rentic_filter_show_blog_meta', $rentic_show_meta, $rentic_components, 'classic' ) ) {
				if ( count( $rentic_components ) > 0 ) {
					do_action( 'rentic_action_before_post_meta' );
					rentic_show_post_meta(
						apply_filters(
							'rentic_filter_post_meta_args', array(
							'components' => join( ',', $rentic_components ),
							'seo'        => false,
							'echo'       => true,
						), $rentic_blog_style[0], $rentic_columns
						)
					);
					do_action( 'rentic_action_after_post_meta' );
				}
			}

			// Post title
			if ( apply_filters( 'rentic_filter_show_blog_title', true, 'classic' ) ) {
				do_action( 'rentic_action_before_post_title' );
				if ( empty( $rentic_template_args['no_links'] ) ) {
					the_title( sprintf( '<h4 class="post_title entry-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h4>' );
				} else {
					the_title( '<h4 class="post_title entry-title">', '</h4>' );
				}
				do_action( 'rentic_action_after_post_title' );
			}

			if( !in_array( $rentic_post_format, array( 'quote', 'aside', 'link', 'status' ) ) ) {
				// More button
				if ( apply_filters( 'rentic_filter_show_blog_readmore', ! $rentic_show_title || ! empty( $rentic_template_args['more_button'] ), 'classic' ) ) {
					if ( empty( $rentic_template_args['no_links'] ) ) {
						do_action( 'rentic_action_before_post_readmore' );
						rentic_show_post_more_link( $rentic_template_args, '<div class="more-wrap">', '</div>' );
						do_action( 'rentic_action_after_post_readmore' );
					}
				}
			}
			?>
		</div><!-- .entry-header -->
		<?php
	}

	// Post content
	if( in_array( $rentic_post_format, array( 'quote', 'aside', 'link', 'status' ) ) ) {
		ob_start();
		if (apply_filters('rentic_filter_show_blog_excerpt', empty($rentic_template_args['hide_excerpt']) && rentic_get_theme_option('excerpt_length') > 0, 'classic')) {
			rentic_show_post_content($rentic_template_args, '<div class="post_content_inner">', '</div>');
		}
		// More button
		if(! empty( $rentic_template_args['more_button'] )) {
			if ( empty( $rentic_template_args['no_links'] ) ) {
				do_action( 'rentic_action_before_post_readmore' );
				rentic_show_post_more_link( $rentic_template_args, '<div class="more-wrap">', '</div>' );
				do_action( 'rentic_action_after_post_readmore' );
			}
		}
		$rentic_content = ob_get_contents();
		ob_end_clean();
		rentic_show_layout($rentic_content, '<div class="post_content entry-content">', '</div><!-- .entry-content -->');
	}
	?>

</article></div><?php
// Need opening PHP-tag above, because <div> is a inline-block element (used as column)!
