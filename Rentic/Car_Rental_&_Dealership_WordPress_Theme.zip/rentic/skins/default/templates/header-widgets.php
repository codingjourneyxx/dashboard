<?php
/**
 * The template to display the widgets area in the header
 *
 * @package RENTIC
 * @since RENTIC 1.0
 */

// Header sidebar
$rentic_header_name    = rentic_get_theme_option( 'header_widgets' );
$rentic_header_present = ! rentic_is_off( $rentic_header_name ) && is_active_sidebar( $rentic_header_name );
if ( $rentic_header_present ) {
	rentic_storage_set( 'current_sidebar', 'header' );
	$rentic_header_wide = rentic_get_theme_option( 'header_wide' );
	ob_start();
	if ( is_active_sidebar( $rentic_header_name ) ) {
		dynamic_sidebar( $rentic_header_name );
	}
	$rentic_widgets_output = ob_get_contents();
	ob_end_clean();
	if ( ! empty( $rentic_widgets_output ) ) {
		$rentic_widgets_output = preg_replace( "/<\/aside>[\r\n\s]*<aside/", '</aside><aside', $rentic_widgets_output );
		$rentic_need_columns   = strpos( $rentic_widgets_output, 'columns_wrap' ) === false;
		if ( $rentic_need_columns ) {
			$rentic_columns = max( 0, (int) rentic_get_theme_option( 'header_columns' ) );
			if ( 0 == $rentic_columns ) {
				$rentic_columns = min( 6, max( 1, rentic_tags_count( $rentic_widgets_output, 'aside' ) ) );
			}
			if ( $rentic_columns > 1 ) {
				$rentic_widgets_output = preg_replace( '/<aside([^>]*)class="widget/', '<aside$1class="column-1_' . esc_attr( $rentic_columns ) . ' widget', $rentic_widgets_output );
			} else {
				$rentic_need_columns = false;
			}
		}
		?>
		<div class="header_widgets_wrap widget_area<?php echo ! empty( $rentic_header_wide ) ? ' header_fullwidth' : ' header_boxed'; ?>">
			<?php do_action( 'rentic_action_before_sidebar_wrap', 'header' ); ?>
			<div class="header_widgets_inner widget_area_inner">
				<?php
				if ( ! $rentic_header_wide ) {
					?>
					<div class="content_wrap">
					<?php
				}
				if ( $rentic_need_columns ) {
					?>
					<div class="columns_wrap">
					<?php
				}
				do_action( 'rentic_action_before_sidebar', 'header' );
				rentic_show_layout( $rentic_widgets_output );
				do_action( 'rentic_action_after_sidebar', 'header' );
				if ( $rentic_need_columns ) {
					?>
					</div>	<!-- /.columns_wrap -->
					<?php
				}
				if ( ! $rentic_header_wide ) {
					?>
					</div>	<!-- /.content_wrap -->
					<?php
				}
				?>
			</div>	<!-- /.header_widgets_inner -->
			<?php do_action( 'rentic_action_after_sidebar_wrap', 'header' ); ?>
		</div>	<!-- /.header_widgets_wrap -->
		<?php
	}
}
