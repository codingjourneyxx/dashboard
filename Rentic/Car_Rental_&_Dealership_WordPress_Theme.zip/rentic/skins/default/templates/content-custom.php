<?php
/**
 * The custom template to display the content
 *
 * Used for index/archive/search.
 *
 * @package RENTIC
 * @since RENTIC 1.0.50
 */

$rentic_template_args = get_query_var( 'rentic_template_args' );
if ( is_array( $rentic_template_args ) ) {
	$rentic_columns    = empty( $rentic_template_args['columns'] ) ? 2 : max( 1, $rentic_template_args['columns'] );
	$rentic_blog_style = array( $rentic_template_args['type'], $rentic_columns );
} else {
	$rentic_template_args = array();
	$rentic_blog_style = explode( '_', rentic_get_theme_option( 'blog_style' ) );
	$rentic_columns    = empty( $rentic_blog_style[1] ) ? 2 : max( 1, $rentic_blog_style[1] );
}
$rentic_blog_id       = rentic_get_custom_blog_id( join( '_', $rentic_blog_style ) );
$rentic_blog_style[0] = str_replace( 'blog-custom-', '', $rentic_blog_style[0] );
$rentic_expanded      = ! rentic_sidebar_present() && rentic_get_theme_option( 'expand_content' ) == 'expand';
$rentic_components    = ! empty( $rentic_template_args['meta_parts'] )
							? ( is_array( $rentic_template_args['meta_parts'] )
								? join( ',', $rentic_template_args['meta_parts'] )
								: $rentic_template_args['meta_parts']
								)
							: rentic_array_get_keys_by_value( rentic_get_theme_option( 'meta_parts' ) );
$rentic_post_format   = get_post_format();
$rentic_post_format   = empty( $rentic_post_format ) ? 'standard' : str_replace( 'post-format-', '', $rentic_post_format );

$rentic_blog_meta     = rentic_get_custom_layout_meta( $rentic_blog_id );
$rentic_custom_style  = ! empty( $rentic_blog_meta['scripts_required'] ) ? $rentic_blog_meta['scripts_required'] : 'none';

if ( ! empty( $rentic_template_args['slider'] ) || $rentic_columns > 1 || ! rentic_is_off( $rentic_custom_style ) ) {
	?><div class="
		<?php
		if ( ! empty( $rentic_template_args['slider'] ) ) {
			echo 'slider-slide swiper-slide';
		} else {
			echo esc_attr( ( rentic_is_off( $rentic_custom_style ) ? 'column' : sprintf( '%1$s_item %1$s_item', $rentic_custom_style ) ) . "-1_{$rentic_columns}" );
		}
		?>
	">
	<?php
}
?>
<article id="post-<?php the_ID(); ?>" data-post-id="<?php the_ID(); ?>"
	<?php
	post_class(
			'post_item post_item_container post_format_' . esc_attr( $rentic_post_format )
					. ' post_layout_custom post_layout_custom_' . esc_attr( $rentic_columns )
					. ' post_layout_' . esc_attr( $rentic_blog_style[0] )
					. ' post_layout_' . esc_attr( $rentic_blog_style[0] ) . '_' . esc_attr( $rentic_columns )
					. ( ! rentic_is_off( $rentic_custom_style )
						? ' post_layout_' . esc_attr( $rentic_custom_style )
							. ' post_layout_' . esc_attr( $rentic_custom_style ) . '_' . esc_attr( $rentic_columns )
						: ''
						)
		);
	rentic_add_blog_animation( $rentic_template_args );
	?>
>
	<?php
	// Sticky label
	if ( is_sticky() && ! is_paged() ) {
		?>
		<span class="post_label label_sticky"></span>
		<?php
	}
	// Custom layout
	do_action( 'rentic_action_show_layout', $rentic_blog_id, get_the_ID() );
	?>
</article><?php
if ( ! empty( $rentic_template_args['slider'] ) || $rentic_columns > 1 || ! rentic_is_off( $rentic_custom_style ) ) {
	?></div><?php
	// Need opening PHP-tag above just after </div>, because <div> is a inline-block element (used as column)!
}
