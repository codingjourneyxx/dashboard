<?php
/**
 * The template to display custom header from the ThemeREX Addons Layouts
 *
 * @package RENTIC
 * @since RENTIC 1.0.06
 */

$rentic_header_css   = '';
$rentic_header_image = get_header_image();
$rentic_header_video = rentic_get_header_video();
if ( ! empty( $rentic_header_image ) && rentic_trx_addons_featured_image_override( is_singular() || rentic_storage_isset( 'blog_archive' ) || is_category() ) ) {
	$rentic_header_image = rentic_get_current_mode_image( $rentic_header_image );
}

$rentic_header_id = rentic_get_custom_header_id();
$rentic_header_meta = get_post_meta( $rentic_header_id, 'trx_addons_options', true );
if ( ! empty( $rentic_header_meta['margin'] ) ) {
	rentic_add_inline_css( sprintf( '.page_content_wrap{padding-top:%s}', esc_attr( rentic_prepare_css_value( $rentic_header_meta['margin'] ) ) ) );
}

?><header class="top_panel top_panel_custom top_panel_custom_<?php echo esc_attr( $rentic_header_id ); ?> top_panel_custom_<?php echo esc_attr( sanitize_title( get_the_title( $rentic_header_id ) ) ); ?>
				<?php
				echo ! empty( $rentic_header_image ) || ! empty( $rentic_header_video )
					? ' with_bg_image'
					: ' without_bg_image';
				if ( '' != $rentic_header_video ) {
					echo ' with_bg_video';
				}
				if ( '' != $rentic_header_image ) {
					echo ' ' . esc_attr( rentic_add_inline_css_class( 'background-image: url(' . esc_url( $rentic_header_image ) . ');' ) );
				}
				if ( is_single() && has_post_thumbnail() ) {
					echo ' with_featured_image';
				}
				if ( rentic_is_on( rentic_get_theme_option( 'header_fullheight' ) ) ) {
					echo ' header_fullheight rentic-full-height';
				}
				$rentic_header_scheme = rentic_get_theme_option( 'header_scheme' );
				if ( ! empty( $rentic_header_scheme ) && ! rentic_is_inherit( $rentic_header_scheme  ) ) {
					echo ' scheme_' . esc_attr( $rentic_header_scheme );
				}
				?>
">
	<?php

	// Background video
	if ( ! empty( $rentic_header_video ) ) {
		get_template_part( apply_filters( 'rentic_filter_get_template_part', 'templates/header-video' ) );
	}

	// Custom header's layout
	do_action( 'rentic_action_show_layout', $rentic_header_id );

	// Header widgets area
	get_template_part( apply_filters( 'rentic_filter_get_template_part', 'templates/header-widgets' ) );

	?>
</header>
