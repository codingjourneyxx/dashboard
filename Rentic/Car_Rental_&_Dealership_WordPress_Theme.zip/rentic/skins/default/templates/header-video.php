<?php
/**
 * The template to display the background video in the header
 *
 * @package RENTIC
 * @since RENTIC 1.0.14
 */
$rentic_header_video = rentic_get_header_video();
$rentic_embed_video  = '';
if ( ! empty( $rentic_header_video ) && ! rentic_is_from_uploads( $rentic_header_video ) ) {
	if ( rentic_is_youtube_url( $rentic_header_video ) && preg_match( '/[=\/]([^=\/]*)$/', $rentic_header_video, $matches ) && ! empty( $matches[1] ) ) {
		?><div id="background_video" data-youtube-code="<?php echo esc_attr( $matches[1] ); ?>"></div>
		<?php
	} else {
		?>
		<div id="background_video"><?php rentic_show_layout( rentic_get_embed_video( $rentic_header_video ) ); ?></div>
		<?php
	}
}
