<?php
/**
 * 'Band' template to display the content
 *
 * Used for index/archive/search.
 *
 * @package RENTIC
 * @since RENTIC 1.71.0
 */

$rentic_template_args = get_query_var( 'rentic_template_args' );
if ( ! is_array( $rentic_template_args ) ) {
	$rentic_template_args = array(
								'type'    => 'band',
								'columns' => 1
								);
}

$rentic_columns       = 1;

$rentic_expanded      = ! rentic_sidebar_present() && rentic_get_theme_option( 'expand_content' ) == 'expand';

$rentic_post_format   = get_post_format();
$rentic_post_format   = empty( $rentic_post_format ) ? 'standard' : str_replace( 'post-format-', '', $rentic_post_format );

if ( is_array( $rentic_template_args ) ) {
	$rentic_columns    = empty( $rentic_template_args['columns'] ) ? 1 : max( 1, $rentic_template_args['columns'] );
	$rentic_blog_style = array( $rentic_template_args['type'], $rentic_columns );
	if ( ! empty( $rentic_template_args['slider'] ) ) {
		?><div class="slider-slide swiper-slide">
		<?php
	} elseif ( $rentic_columns > 1 ) {
	    $rentic_columns_class = rentic_get_column_class( 1, $rentic_columns, ! empty( $rentic_template_args['columns_tablet']) ? $rentic_template_args['columns_tablet'] : '', ! empty($rentic_template_args['columns_mobile']) ? $rentic_template_args['columns_mobile'] : '' );
				?><div class="<?php echo esc_attr( $rentic_columns_class ); ?>"><?php
	}
}
?>
<article id="post-<?php the_ID(); ?>" data-post-id="<?php the_ID(); ?>"
	<?php
	post_class( 'post_item post_item_container post_layout_band post_format_' . esc_attr( $rentic_post_format ) );
	rentic_add_blog_animation( $rentic_template_args );
	?>
>
	<?php

	// Sticky label
	if ( is_sticky() && ! is_paged() ) {
		?>
		<span class="post_label label_sticky"></span>
		<?php
	}

	// Featured image
	$rentic_hover      = ! empty( $rentic_template_args['hover'] ) && ! rentic_is_inherit( $rentic_template_args['hover'] )
							? $rentic_template_args['hover']
							: rentic_get_theme_option( 'image_hover' );
	$rentic_components = ! empty( $rentic_template_args['meta_parts'] )
							? ( is_array( $rentic_template_args['meta_parts'] )
								? $rentic_template_args['meta_parts']
								: array_map( 'trim', explode( ',', $rentic_template_args['meta_parts'] ) )
								)
							: rentic_array_get_keys_by_value( rentic_get_theme_option( 'meta_parts' ) );
	rentic_show_post_featured( apply_filters( 'rentic_filter_args_featured',
		array(
			'no_links'   => ! empty( $rentic_template_args['no_links'] ),
			'hover'      => $rentic_hover,
			'meta_parts' => $rentic_components,
			'thumb_bg'   => true,
			'thumb_ratio'   => '1:1',
			'thumb_size' => ! empty( $rentic_template_args['thumb_size'] )
								? $rentic_template_args['thumb_size']
								: rentic_get_thumb_size( 
								in_array( $rentic_post_format, array( 'gallery', 'audio', 'video' ) )
									? ( strpos( rentic_get_theme_option( 'body_style' ), 'full' ) !== false
										? 'full'
										: ( $rentic_expanded 
											? 'big' 
											: 'medium-square'
											)
										)
									: 'masonry-big'
								)
		),
		'content-band',
		$rentic_template_args
	) );

	?><div class="post_content_wrap"><?php

		// Title and post meta
		$rentic_show_title = get_the_title() != '';
		$rentic_show_meta  = count( $rentic_components ) > 0 && ! in_array( $rentic_hover, array( 'border', 'pull', 'slide', 'fade', 'info' ) );
		if ( $rentic_show_title ) {
			?>
			<div class="post_header entry-header">
				<?php
				// Categories
				if ( apply_filters( 'rentic_filter_show_blog_categories', $rentic_show_meta && in_array( 'categories', $rentic_components ), array( 'categories' ), 'band' ) ) {
					do_action( 'rentic_action_before_post_category' );
					?>
					<div class="post_category">
						<?php
						rentic_show_post_meta( apply_filters(
															'rentic_filter_post_meta_args',
															array(
																'components' => 'categories',
																'seo'        => false,
																'echo'       => true,
																'cat_sep'    => false,
																),
															'hover_' . $rentic_hover, 1
															)
											);
						?>
					</div>
					<?php
					$rentic_components = rentic_array_delete_by_value( $rentic_components, 'categories' );
					do_action( 'rentic_action_after_post_category' );
				}
				// Post title
				if ( apply_filters( 'rentic_filter_show_blog_title', true, 'band' ) ) {
					do_action( 'rentic_action_before_post_title' );
					if ( empty( $rentic_template_args['no_links'] ) ) {
						the_title( sprintf( '<h4 class="post_title entry-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h4>' );
					} else {
						the_title( '<h4 class="post_title entry-title">', '</h4>' );
					}
					do_action( 'rentic_action_after_post_title' );
				}
				?>
			</div><!-- .post_header -->
			<?php
		}

		// Post content
		if ( ! isset( $rentic_template_args['excerpt_length'] ) && ! in_array( $rentic_post_format, array( 'gallery', 'audio', 'video' ) ) ) {
			$rentic_template_args['excerpt_length'] = 13;
		}
		if ( apply_filters( 'rentic_filter_show_blog_excerpt', empty( $rentic_template_args['hide_excerpt'] ) && rentic_get_theme_option( 'excerpt_length' ) > 0, 'band' ) ) {
			?>
			<div class="post_content entry-content">
				<?php
				// Post content area
				rentic_show_post_content( $rentic_template_args, '<div class="post_content_inner">', '</div>' );
				?>
			</div><!-- .entry-content -->
			<?php
		}
		// Post meta
		if ( apply_filters( 'rentic_filter_show_blog_meta', $rentic_show_meta, $rentic_components, 'band' ) ) {
			if ( count( $rentic_components ) > 0 ) {
				do_action( 'rentic_action_before_post_meta' );
				rentic_show_post_meta(
					apply_filters(
						'rentic_filter_post_meta_args', array(
							'components' => join( ',', $rentic_components ),
							'seo'        => false,
							'echo'       => true,
						), 'band', 1
					)
				);
				do_action( 'rentic_action_after_post_meta' );
			}
		}
		// More button
		if ( apply_filters( 'rentic_filter_show_blog_readmore', ! $rentic_show_title || ! empty( $rentic_template_args['more_button'] ), 'band' ) ) {
			if ( empty( $rentic_template_args['no_links'] ) ) {
				do_action( 'rentic_action_before_post_readmore' );
				rentic_show_post_more_link( $rentic_template_args, '<div class="more-wrap">', '</div>' );
				do_action( 'rentic_action_after_post_readmore' );
			}
		}
		?>
	</div>
</article>
<?php

if ( is_array( $rentic_template_args ) ) {
	if ( ! empty( $rentic_template_args['slider'] ) || $rentic_columns > 1 ) {
		?>
		</div>
		<?php
	}
}