<div class="front_page_section front_page_section_features<?php
	$rentic_scheme = rentic_get_theme_option( 'front_page_features_scheme' );
	if ( ! empty( $rentic_scheme ) && ! rentic_is_inherit( $rentic_scheme ) ) {
		echo ' scheme_' . esc_attr( $rentic_scheme );
	}
	echo ' front_page_section_paddings_' . esc_attr( rentic_get_theme_option( 'front_page_features_paddings' ) );
	if ( rentic_get_theme_option( 'front_page_features_stack' ) ) {
		echo ' sc_stack_section_on';
	}
?>"
		<?php
		$rentic_css      = '';
		$rentic_bg_image = rentic_get_theme_option( 'front_page_features_bg_image' );
		if ( ! empty( $rentic_bg_image ) ) {
			$rentic_css .= 'background-image: url(' . esc_url( rentic_get_attachment_url( $rentic_bg_image ) ) . ');';
		}
		if ( ! empty( $rentic_css ) ) {
			echo ' style="' . esc_attr( $rentic_css ) . '"';
		}
		?>
>
<?php
	// Add anchor
	$rentic_anchor_icon = rentic_get_theme_option( 'front_page_features_anchor_icon' );
	$rentic_anchor_text = rentic_get_theme_option( 'front_page_features_anchor_text' );
if ( ( ! empty( $rentic_anchor_icon ) || ! empty( $rentic_anchor_text ) ) && shortcode_exists( 'trx_sc_anchor' ) ) {
	echo do_shortcode(
		'[trx_sc_anchor id="front_page_section_features"'
									. ( ! empty( $rentic_anchor_icon ) ? ' icon="' . esc_attr( $rentic_anchor_icon ) . '"' : '' )
									. ( ! empty( $rentic_anchor_text ) ? ' title="' . esc_attr( $rentic_anchor_text ) . '"' : '' )
									. ']'
	);
}
?>
	<div class="front_page_section_inner front_page_section_features_inner
	<?php
	if ( rentic_get_theme_option( 'front_page_features_fullheight' ) ) {
		echo ' rentic-full-height sc_layouts_flex sc_layouts_columns_middle';
	}
	?>
			"
			<?php
			$rentic_css      = '';
			$rentic_bg_mask  = rentic_get_theme_option( 'front_page_features_bg_mask' );
			$rentic_bg_color_type = rentic_get_theme_option( 'front_page_features_bg_color_type' );
			if ( 'custom' == $rentic_bg_color_type ) {
				$rentic_bg_color = rentic_get_theme_option( 'front_page_features_bg_color' );
			} elseif ( 'scheme_bg_color' == $rentic_bg_color_type ) {
				$rentic_bg_color = rentic_get_scheme_color( 'bg_color', $rentic_scheme );
			} else {
				$rentic_bg_color = '';
			}
			if ( ! empty( $rentic_bg_color ) && $rentic_bg_mask > 0 ) {
				$rentic_css .= 'background-color: ' . esc_attr(
					1 == $rentic_bg_mask ? $rentic_bg_color : rentic_hex2rgba( $rentic_bg_color, $rentic_bg_mask )
				) . ';';
			}
			if ( ! empty( $rentic_css ) ) {
				echo ' style="' . esc_attr( $rentic_css ) . '"';
			}
			?>
	>
		<div class="front_page_section_content_wrap front_page_section_features_content_wrap content_wrap">
			<?php
			// Caption
			$rentic_caption = rentic_get_theme_option( 'front_page_features_caption' );
			if ( ! empty( $rentic_caption ) || ( current_user_can( 'edit_theme_options' ) && is_customize_preview() ) ) {
				?>
				<h2 class="front_page_section_caption front_page_section_features_caption front_page_block_<?php echo ! empty( $rentic_caption ) ? 'filled' : 'empty'; ?>"><?php echo wp_kses( $rentic_caption, 'rentic_kses_content' ); ?></h2>
				<?php
			}

			// Description (text)
			$rentic_description = rentic_get_theme_option( 'front_page_features_description' );
			if ( ! empty( $rentic_description ) || ( current_user_can( 'edit_theme_options' ) && is_customize_preview() ) ) {
				?>
				<div class="front_page_section_description front_page_section_features_description front_page_block_<?php echo ! empty( $rentic_description ) ? 'filled' : 'empty'; ?>"><?php echo wp_kses( wpautop( $rentic_description ), 'rentic_kses_content' ); ?></div>
				<?php
			}

			// Content (widgets)
			?>
			<div class="front_page_section_output front_page_section_features_output">
				<?php
				if ( is_active_sidebar( 'front_page_features_widgets' ) ) {
					dynamic_sidebar( 'front_page_features_widgets' );
				} elseif ( current_user_can( 'edit_theme_options' ) ) {
					if ( ! rentic_exists_trx_addons() ) {
						rentic_customizer_need_trx_addons_message();
					} else {
						rentic_customizer_need_widgets_message( 'front_page_features_caption', 'ThemeREX Addons - Services' );
					}
				}
				?>
			</div>
		</div>
	</div>
</div>
