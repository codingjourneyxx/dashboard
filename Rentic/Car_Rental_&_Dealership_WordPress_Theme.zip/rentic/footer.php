<?php
/**
 * The Footer: widgets area, logo, footer menu and socials
 *
 * @package RENTIC
 * @since RENTIC 1.0
 */

							do_action( 'rentic_action_page_content_end_text' );
							
							// Widgets area below the content
							rentic_create_widgets_area( 'widgets_below_content' );
						
							do_action( 'rentic_action_page_content_end' );
							?>
						</div>
						<?php
						
						do_action( 'rentic_action_after_page_content' );

						// Show main sidebar
						get_sidebar();

						do_action( 'rentic_action_content_wrap_end' );
						?>
					</div>
					<?php

					do_action( 'rentic_action_after_content_wrap' );

					// Widgets area below the page and related posts below the page
					$rentic_body_style = rentic_get_theme_option( 'body_style' );
					$rentic_widgets_name = rentic_get_theme_option( 'widgets_below_page', 'hide' );
					$rentic_show_widgets = ! rentic_is_off( $rentic_widgets_name ) && is_active_sidebar( $rentic_widgets_name );
					$rentic_show_related = rentic_is_single() && rentic_get_theme_option( 'related_position', 'below_content' ) == 'below_page';
					if ( $rentic_show_widgets || $rentic_show_related ) {
						if ( 'fullscreen' != $rentic_body_style ) {
							?>
							<div class="content_wrap">
							<?php
						}
						// Show related posts before footer
						if ( $rentic_show_related ) {
							do_action( 'rentic_action_related_posts' );
						}

						// Widgets area below page content
						if ( $rentic_show_widgets ) {
							rentic_create_widgets_area( 'widgets_below_page' );
						}
						if ( 'fullscreen' != $rentic_body_style ) {
							?>
							</div>
							<?php
						}
					}
					do_action( 'rentic_action_page_content_wrap_end' );
					?>
			</div>
			<?php
			do_action( 'rentic_action_after_page_content_wrap' );

			// Don't display the footer elements while actions 'full_post_loading' and 'prev_post_loading'
			if ( ( ! rentic_is_singular( 'post' ) && ! rentic_is_singular( 'attachment' ) ) || ! in_array ( rentic_get_value_gp( 'action' ), array( 'full_post_loading', 'prev_post_loading' ) ) ) {
				
				// Skip link anchor to fast access to the footer from keyboard
				?>
				<span id="footer_skip_link_anchor" class="rentic_skip_link_anchor"></span>
				<?php

				do_action( 'rentic_action_before_footer' );

				// Footer
				$rentic_footer_type = rentic_get_theme_option( 'footer_type' );
				if ( 'custom' == $rentic_footer_type && ! rentic_is_layouts_available() ) {
					$rentic_footer_type = 'default';
				}
				get_template_part( apply_filters( 'rentic_filter_get_template_part', "templates/footer-" . sanitize_file_name( $rentic_footer_type ) ) );

				do_action( 'rentic_action_after_footer' );

			}
			?>

			<?php do_action( 'rentic_action_page_wrap_end' ); ?>

		</div>

		<?php do_action( 'rentic_action_after_page_wrap' ); ?>

	</div>

	<?php do_action( 'rentic_action_after_body' ); ?>

	<?php wp_footer(); ?>

</body>
</html>