<?php
/**
 * The Sidebar containing the main widget areas.
 *
 * @package RENTIC
 * @since RENTIC 1.0
 */

if ( rentic_sidebar_present() ) {
	
	$rentic_sidebar_type = rentic_get_theme_option( 'sidebar_type' );
	if ( 'custom' == $rentic_sidebar_type && ! rentic_is_layouts_available() ) {
		$rentic_sidebar_type = 'default';
	}
	
	// Catch output to the buffer
	ob_start();
	if ( 'default' == $rentic_sidebar_type ) {
		// Default sidebar with widgets
		$rentic_sidebar_name = rentic_get_theme_option( 'sidebar_widgets' );
		rentic_storage_set( 'current_sidebar', 'sidebar' );
		if ( is_active_sidebar( $rentic_sidebar_name ) ) {
			dynamic_sidebar( $rentic_sidebar_name );
		}
	} else {
		// Custom sidebar from Layouts Builder
		$rentic_sidebar_id = rentic_get_custom_sidebar_id();
		do_action( 'rentic_action_show_layout', $rentic_sidebar_id );
	}
	$rentic_out = trim( ob_get_contents() );
	ob_end_clean();
	
	// If any html is present - display it
	if ( ! empty( $rentic_out ) ) {
		$rentic_sidebar_position    = rentic_get_theme_option( 'sidebar_position' );
		$rentic_sidebar_position_ss = rentic_get_theme_option( 'sidebar_position_ss', 'below' );
		?>
		<div class="sidebar widget_area
			<?php
			echo ' ' . esc_attr( $rentic_sidebar_position );
			echo ' sidebar_' . esc_attr( $rentic_sidebar_position_ss );
			echo ' sidebar_' . esc_attr( $rentic_sidebar_type );

			$rentic_sidebar_scheme = apply_filters( 'rentic_filter_sidebar_scheme', rentic_get_theme_option( 'sidebar_scheme', 'inherit' ) );
			if ( ! empty( $rentic_sidebar_scheme ) && ! rentic_is_inherit( $rentic_sidebar_scheme ) && 'custom' != $rentic_sidebar_type ) {
				echo ' scheme_' . esc_attr( $rentic_sidebar_scheme );
			}
			?>
		" role="complementary">
			<?php

			// Skip link anchor to fast access to the sidebar from keyboard
			?>
			<span id="sidebar_skip_link_anchor" class="rentic_skip_link_anchor"></span>
			<?php

			do_action( 'rentic_action_before_sidebar_wrap', 'sidebar' );

			// Button to show/hide sidebar on mobile
			if ( in_array( $rentic_sidebar_position_ss, array( 'above', 'float' ) ) ) {
				$rentic_title = apply_filters( 'rentic_filter_sidebar_control_title', 'float' == $rentic_sidebar_position_ss ? esc_html__( 'Show Sidebar', 'rentic' ) : '' );
				$rentic_text  = apply_filters( 'rentic_filter_sidebar_control_text', 'above' == $rentic_sidebar_position_ss ? esc_html__( 'Show Sidebar', 'rentic' ) : '' );
				?>
				<a href="#" role="button" class="sidebar_control" title="<?php echo esc_attr( $rentic_title ); ?>"><?php echo esc_html( $rentic_text ); ?></a>
				<?php
			}
			?>
			<div class="sidebar_inner">
				<?php
				do_action( 'rentic_action_before_sidebar', 'sidebar' );
				rentic_show_layout( preg_replace( "/<\/aside>[\r\n\s]*<aside/", '</aside><aside', $rentic_out ) );
				do_action( 'rentic_action_after_sidebar', 'sidebar' );
				?>
			</div>
			<?php

			do_action( 'rentic_action_after_sidebar_wrap', 'sidebar' );

			?>
		</div>
		<div class="clearfix"></div>
		<?php
	}
}
