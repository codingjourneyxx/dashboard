<?php

/**
 * Displays the scroll to top button
 *
 * @package vamtam/execor
 */
?>

<div id="scroll-to-top" class="vamtam-scroll-to-top">
    <div id="scroll-to-top-text"><?php esc_html_e( 'top', 'execor' ) ?></div>
</div>


