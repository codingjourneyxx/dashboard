<div class="author vamtam-meta-author">
	<?php VamtamTemplates::the_author_posts_link_with_icon()?>
</div>