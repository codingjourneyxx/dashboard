<?php
/**
 * Theme footer
 *
 * The template for displaying the footer.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 */

defined( 'ABSPATH' ) || exit;
?>

<?php keystone_content_bottom(); ?>
</div><!-- #content -->
<?php
	keystone_content_after();
	keystone_footer_before();
	keystone_footer();
	keystone_footer_after();
?>
</div><!-- #page -->

<?php
	keystone_body_bottom();
	wp_footer();
?>

</body>
</html>
