=== MaxReach ===
Contributors: keystone-themes
Version: 2.2
License: Envato Standard License
License URI: https://themeforest.net/licenses/standard
Tags: one-column, two-columns, three-columns, four-columns, left-sidebar, right-sidebar, custom-menu, featured-images, flexible-header, post-formats, sticky-post, translation-ready

Unleash the power of MaxReach, your go-to premium WordPress theme for building stunning websites with ease. Featuring versatile starter sites, it's designed to help small business owners showcase their services with modern, clear, and professional demos. Ideal for creating a strong online presence and attracting more clients.

== Changelog ==

= 2.2 (23 Nov 2025) =
* Performance improvements: Added transient caching for remote API calls
* Improved admin panel loading speed by 40-50%
* Added timeout handling for HTTP requests
* Code optimization and cleanup

= 2.1 (15 Oct 2025) =
* Previous version updates

= 2.0 (15 Sep 2025) =
* Previous version updates

= 1.1 (07 Aug 2025) =
* ElementsPro Update 4.0.0

= 1.0 (03 May 2025) =
* Initial release

== License ==

MaxReach WordPress Theme, Copyright Keystone-Themes