<?php
/**
 * Functions file
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 */

defined( 'ABSPATH' ) || exit;

require_once( get_template_directory() . '/inc/init.php' );
