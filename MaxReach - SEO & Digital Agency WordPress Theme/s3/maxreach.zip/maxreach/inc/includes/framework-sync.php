<?php

// Set framework constants
define( 'KEYSTONE_THEME_THUMBNAIL', KEYSTONE_THEME_URI . 'assets/img/thumbnail.svg' );

// Core brand colors
define( 'KEYSTONE_ELEMENTOR_PRIMARY_COLOR',   '#000000' ); // Primary
define( 'KEYSTONE_ELEMENTOR_SECONDARY_COLOR', '#212023' ); // Secondary
define( 'KEYSTONE_ELEMENTOR_HEADLINE_COLOR',  '#1e293b' ); // Headline
define( 'KEYSTONE_ELEMENTOR_TEXT_COLOR',      '#334155' ); // Text
define( 'KEYSTONE_ELEMENTOR_ACCENT_COLOR',    '#ff0909' ); // Accent

// Backgrounds
define( 'KEYSTONE_ELEMENTOR_LIGHT_COLOR',      '#fbfbfb' ); // Light Background
define( 'KEYSTONE_ELEMENTOR_DARK_LIGHT_COLOR', '#e5e7eb' ); // Dark Light Background

// Utility colors
define( 'KEYSTONE_ELEMENTOR_BORDER_COLOR', '#d1d5db' ); // Border
define( 'KEYSTONE_ELEMENTOR_BLACK_COLOR',  '#000000' ); // Black
define( 'KEYSTONE_ELEMENTOR_WHITE_COLOR',  '#ffffff' ); // White

define( 'KEYSTONE_ELEMENTOR_PRIMARY_FONT_FAMILY', 'Be Vietnam Pro' );
define( 'KEYSTONE_ELEMENTOR_PRIMARY_FONT_WEIGHT', '600' );

define( 'KEYSTONE_ELEMENTOR_SECONDARY_FONT_FAMILY', 'Be Vietnam Pro' );
define( 'KEYSTONE_ELEMENTOR_SECONDARY_FONT_WEIGHT', '600' );

define( 'KEYSTONE_ELEMENTOR_TEXT_FONT_FAMILY', 'Be Vietnam Pro' );
define( 'KEYSTONE_ELEMENTOR_TEXT_FONT_WEIGHT', '400' );

define( 'KEYSTONE_ELEMENTOR_ACCENT_FONT_FAMILY', 'Be Vietnam Pro' );
define( 'KEYSTONE_ELEMENTOR_ACCENT_FONT_WEIGHT', '600' );

define( 'KEYSTONE_THEMEFOREST_THEME_LINK', 'https://themeforest.net/user/keystone_themes/portfolio' );

update_option( 'KEYSTONE_API_PRODUCT_ID', '82250B6E' );


