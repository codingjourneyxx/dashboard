<?php

// Add wrapper for shop ordering bar
add_action('woocommerce_before_shop_loop', function () {
	echo '<div class="shop-before-loop">';
}, 12);

add_action('woocommerce_before_shop_loop', function () {
	echo '</div>';
}, 31);

// Add wrapper for product image
add_action('woocommerce_before_shop_loop_item_title', function () {
	echo '<div class="woo-entry-image">';
}, 5);

add_action('woocommerce_before_shop_loop_item_title', function () {
	echo '</div>';
}, 12);

// Add wrapper for add to cart button
add_action('woocommerce_after_shop_loop_item', function () {
	echo '<div class="woo-action-wrapper">';
}, 6);

add_action('woocommerce_after_shop_loop_item', function () {
	echo '</div>';
}, 20);

// Ensure WooCommerce buttons use Elementor Site Settings by adding Elementor button class
add_filter('woocommerce_loop_add_to_cart_link', function ($html, $product, $args) {
	// Append elementor-button class to loop add-to-cart links
	return preg_replace('/class=("|\')(.*?)("|\')/i', 'class=$1$2 elementor-button$3', $html, 1);
}, 10, 3);

add_filter('woocommerce_button_proceed_to_checkout', function ($button_html) {
	// Proceed to checkout button
	return preg_replace('/class=("|\')(.*?)("|\')/i', 'class=$1$2 elementor-button$3', $button_html, 1);
});

add_filter('woocommerce_widget_shopping_cart_buttons', function ($buttons_html) {
	// Mini-cart buttons
	return preg_replace('/class=("|\')(.*?)("|\')/i', 'class=$1$2 elementor-button$3', $buttons_html);
}, 10, 1);

// Move product rating above title
remove_action( 'woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_rating', 5 );
add_action( 'woocommerce_before_shop_loop_item_title', 'woocommerce_template_loop_rating', 20 );

// Breadcrumbs settings
remove_action( 'woocommerce_before_main_content', 'woocommerce_breadcrumb', 20, 0 );
add_action( 'woocommerce_single_product_summary', 'woocommerce_breadcrumb', 2 );
