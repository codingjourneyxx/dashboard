<?php
/**
 * Page title bar
 */

defined( 'ABSPATH' ) || exit;

$keystone_title_switch = true;
if ( class_exists( '\KeyStone\Plugin' ) ) {
	$keystone_title_switch = keystone_get_option( 'title_bar_switch' );
}
$elementor_title_switch = apply_filters( 'elementor_page_title_switch', true );
if ( $keystone_title_switch == false || $elementor_title_switch == false ) {
	return;
}
?>
<?php keystone_page_header_before(); ?>
<header id="page-header" <?php keystone_page_header_class(); ?>>
	<div class="keystone-container e-con">
		<?php
			keystone_page_header_top();
			keystone_page_header_content();
			keystone_page_header_bottom();
		?>
	</div>
</header>
<?php keystone_page_header_after(); ?>