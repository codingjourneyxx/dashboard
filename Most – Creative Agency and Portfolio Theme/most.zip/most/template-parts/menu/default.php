<nav class="main-header__nav js-main-header__nav main-header__default" id="main-header-nav" aria-labelledby="primary-menu">
    <?php if ( has_nav_menu( 'primary-menu' ) ) {  most_primary_menu(); } ?>
</nav>
<div class="menuTrigger"></div>