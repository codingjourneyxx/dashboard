<?php
/**
 * Show the excerpt (Default).
 *
 * @package WordPress
 * @since Most 1.0
 */

get_template_part( 'template-parts/excerpt/excerpt', 'image' );