
<?php

/**
 * @author: MadSparrow
 * @version: 1.0.0
 */

?>

<div class="woocommerce-content-loop-header">

	<?php
		do_action( 'most_woocommerce_result_count' );
		do_action( 'most_woocommerce_catalog_ordering' );
	?>

</div>