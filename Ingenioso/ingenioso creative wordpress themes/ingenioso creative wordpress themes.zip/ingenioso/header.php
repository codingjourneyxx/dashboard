<?php
/**
 * The Header: Logo and main menu
 *
 * @package INGENIOSO
 * @since INGENIOSO 1.0
 */
?><!DOCTYPE html>
<html <?php language_attributes(); ?> class="no-js<?php
	// Class scheme_xxx need in the <html> as context for the <body>!
	echo ' scheme_' . esc_attr( ingenioso_get_theme_option( 'color_scheme' ) );
?>">

<head>
	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>

	<?php
	if ( function_exists( 'wp_body_open' ) ) {
		wp_body_open();
	} else {
		do_action( 'wp_body_open' );
	}
	do_action( 'ingenioso_action_before_body' );
	?>

	<div class="<?php echo esc_attr( apply_filters( 'ingenioso_filter_body_wrap_class', 'body_wrap' ) ); ?>" <?php do_action('ingenioso_action_body_wrap_attributes'); ?>>

		<?php do_action( 'ingenioso_action_before_page_wrap' ); ?>

		<div class="<?php echo esc_attr( apply_filters( 'ingenioso_filter_page_wrap_class', 'page_wrap' ) ); ?>" <?php do_action('ingenioso_action_page_wrap_attributes'); ?>>

			<?php do_action( 'ingenioso_action_page_wrap_start' ); ?>

			<?php
			$ingenioso_full_post_loading = ( ingenioso_is_singular( 'post' ) || ingenioso_is_singular( 'attachment' ) ) && ingenioso_get_value_gp( 'action' ) == 'full_post_loading';
			$ingenioso_prev_post_loading = ( ingenioso_is_singular( 'post' ) || ingenioso_is_singular( 'attachment' ) ) && ingenioso_get_value_gp( 'action' ) == 'prev_post_loading';

			// Don't display the header elements while actions 'full_post_loading' and 'prev_post_loading'
			if ( ! $ingenioso_full_post_loading && ! $ingenioso_prev_post_loading ) {

				// Short links to fast access to the content, sidebar and footer from the keyboard
				?>
				<a class="ingenioso_skip_link skip_to_content_link" href="#content_skip_link_anchor" tabindex="<?php echo esc_attr( apply_filters( 'ingenioso_filter_skip_links_tabindex', 1 ) ); ?>"><?php esc_html_e( "Skip to content", 'ingenioso' ); ?></a>
				<?php if ( ingenioso_sidebar_present() ) { ?>
				<a class="ingenioso_skip_link skip_to_sidebar_link" href="#sidebar_skip_link_anchor" tabindex="<?php echo esc_attr( apply_filters( 'ingenioso_filter_skip_links_tabindex', 1 ) ); ?>"><?php esc_html_e( "Skip to sidebar", 'ingenioso' ); ?></a>
				<?php } ?>
				<a class="ingenioso_skip_link skip_to_footer_link" href="#footer_skip_link_anchor" tabindex="<?php echo esc_attr( apply_filters( 'ingenioso_filter_skip_links_tabindex', 1 ) ); ?>"><?php esc_html_e( "Skip to footer", 'ingenioso' ); ?></a>

				<?php
				do_action( 'ingenioso_action_before_header' );

				// Header
				$ingenioso_header_type = ingenioso_get_theme_option( 'header_type' );
				if ( 'custom' == $ingenioso_header_type && ! ingenioso_is_layouts_available() ) {
					$ingenioso_header_type = 'default';
				}
				get_template_part( apply_filters( 'ingenioso_filter_get_template_part', "templates/header-" . sanitize_file_name( $ingenioso_header_type ) ) );

				// Side menu
				if ( in_array( ingenioso_get_theme_option( 'menu_side', 'none' ), array( 'left', 'right' ) ) ) {
					get_template_part( apply_filters( 'ingenioso_filter_get_template_part', 'templates/header-navi-side' ) );
				}

				// Mobile menu
				if ( apply_filters( 'ingenioso_filter_use_navi_mobile', true ) ) {
					get_template_part( apply_filters( 'ingenioso_filter_get_template_part', 'templates/header-navi-mobile' ) );
				}

				do_action( 'ingenioso_action_after_header' );

			}
			?>

			<?php do_action( 'ingenioso_action_before_page_content_wrap' ); ?>

			<div class="page_content_wrap<?php
				if ( ingenioso_is_off( ingenioso_get_theme_option( 'remove_margins' ) ) ) {
					if ( empty( $ingenioso_header_type ) ) {
						$ingenioso_header_type = ingenioso_get_theme_option( 'header_type' );
					}
					if ( 'custom' == $ingenioso_header_type && ingenioso_is_layouts_available() ) {
						$ingenioso_header_id = ingenioso_get_custom_header_id();
						if ( $ingenioso_header_id > 0 ) {
							$ingenioso_header_meta = ingenioso_get_custom_layout_meta( $ingenioso_header_id );
							if ( ! empty( $ingenioso_header_meta['margin'] ) ) {
								?> page_content_wrap_custom_header_margin<?php
							}
						}
					}
					$ingenioso_footer_type = ingenioso_get_theme_option( 'footer_type' );
					if ( 'custom' == $ingenioso_footer_type && ingenioso_is_layouts_available() ) {
						$ingenioso_footer_id = ingenioso_get_custom_footer_id();
						if ( $ingenioso_footer_id ) {
							$ingenioso_footer_meta = ingenioso_get_custom_layout_meta( $ingenioso_footer_id );
							if ( ! empty( $ingenioso_footer_meta['margin'] ) ) {
								?> page_content_wrap_custom_footer_margin<?php
							}
						}
					}
				}
				do_action( 'ingenioso_action_page_content_wrap_class', $ingenioso_prev_post_loading );
				?>"<?php
				if ( apply_filters( 'ingenioso_filter_is_prev_post_loading', $ingenioso_prev_post_loading ) ) {
					?> data-single-style="<?php echo esc_attr( ingenioso_get_theme_option( 'single_style' ) ); ?>"<?php
				}
				do_action( 'ingenioso_action_page_content_wrap_data', $ingenioso_prev_post_loading );
			?>>
				<?php
				do_action( 'ingenioso_action_page_content_wrap', $ingenioso_full_post_loading || $ingenioso_prev_post_loading );

				// Single posts banner
				if ( apply_filters( 'ingenioso_filter_single_post_header', ingenioso_is_singular( 'post' ) || ingenioso_is_singular( 'attachment' ) ) ) {
					if ( $ingenioso_prev_post_loading ) {
						if ( ingenioso_get_theme_option( 'posts_navigation_scroll_which_block', 'article' ) != 'article' ) {
							do_action( 'ingenioso_action_between_posts' );
						}
					}
					// Single post thumbnail and title
					$ingenioso_path = apply_filters( 'ingenioso_filter_get_template_part', 'templates/single-styles/' . ingenioso_get_theme_option( 'single_style' ) );
					if ( ingenioso_get_file_dir( $ingenioso_path . '.php' ) != '' ) {
						get_template_part( $ingenioso_path );
					}
				}

				// Widgets area above page
				$ingenioso_body_style   = ingenioso_get_theme_option( 'body_style' );
				$ingenioso_widgets_name = ingenioso_get_theme_option( 'widgets_above_page', 'hide' );
				$ingenioso_show_widgets = ! ingenioso_is_off( $ingenioso_widgets_name ) && is_active_sidebar( $ingenioso_widgets_name );
				if ( $ingenioso_show_widgets ) {
					if ( 'fullscreen' != $ingenioso_body_style ) {
						?>
						<div class="content_wrap">
							<?php
					}
					ingenioso_create_widgets_area( 'widgets_above_page' );
					if ( 'fullscreen' != $ingenioso_body_style ) {
						?>
						</div>
						<?php
					}
				}

				// Content area
				do_action( 'ingenioso_action_before_content_wrap' );
				?>
				<div class="content_wrap<?php echo 'fullscreen' == $ingenioso_body_style ? '_fullscreen' : ''; ?>">

					<?php do_action( 'ingenioso_action_content_wrap_start' ); ?>

					<div class="content">
						<?php
						do_action( 'ingenioso_action_page_content_start' );

						// Skip link anchor to fast access to the content from keyboard
						?>
						<a id="content_skip_link_anchor" class="ingenioso_skip_link_anchor" href="#"></a>
						<?php
						// Single posts banner between prev/next posts
						if ( ( ingenioso_is_singular( 'post' ) || ingenioso_is_singular( 'attachment' ) )
							&& $ingenioso_prev_post_loading 
							&& ingenioso_get_theme_option( 'posts_navigation_scroll_which_block', 'article' ) == 'article'
						) {
							do_action( 'ingenioso_action_between_posts' );
						}

						// Widgets area above content
						ingenioso_create_widgets_area( 'widgets_above_content' );

						do_action( 'ingenioso_action_page_content_start_text' );
