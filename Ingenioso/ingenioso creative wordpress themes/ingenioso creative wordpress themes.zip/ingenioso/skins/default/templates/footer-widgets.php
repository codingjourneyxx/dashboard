<?php
/**
 * The template to display the widgets area in the footer
 *
 * @package INGENIOSO
 * @since INGENIOSO 1.0.10
 */

// Footer sidebar
$ingenioso_footer_name    = ingenioso_get_theme_option( 'footer_widgets' );
$ingenioso_footer_present = ! ingenioso_is_off( $ingenioso_footer_name ) && is_active_sidebar( $ingenioso_footer_name );
if ( $ingenioso_footer_present ) {
	ingenioso_storage_set( 'current_sidebar', 'footer' );
	$ingenioso_footer_wide = ingenioso_get_theme_option( 'footer_wide' );
	ob_start();
	if ( is_active_sidebar( $ingenioso_footer_name ) ) {
		dynamic_sidebar( $ingenioso_footer_name );
	}
	$ingenioso_out = trim( ob_get_contents() );
	ob_end_clean();
	if ( ! empty( $ingenioso_out ) ) {
		$ingenioso_out          = preg_replace( "/<\\/aside>[\r\n\s]*<aside/", '</aside><aside', $ingenioso_out );
		$ingenioso_need_columns = true;   //or check: strpos($ingenioso_out, 'columns_wrap')===false;
		if ( $ingenioso_need_columns ) {
			$ingenioso_columns = max( 0, (int) ingenioso_get_theme_option( 'footer_columns' ) );			
			if ( 0 == $ingenioso_columns ) {
				$ingenioso_columns = min( 4, max( 1, ingenioso_tags_count( $ingenioso_out, 'aside' ) ) );
			}
			if ( $ingenioso_columns > 1 ) {
				$ingenioso_out = preg_replace( '/<aside([^>]*)class="widget/', '<aside$1class="column-1_' . esc_attr( $ingenioso_columns ) . ' widget', $ingenioso_out );
			} else {
				$ingenioso_need_columns = false;
			}
		}
		?>
		<div class="footer_widgets_wrap widget_area<?php echo ! empty( $ingenioso_footer_wide ) ? ' footer_fullwidth' : ''; ?> sc_layouts_row sc_layouts_row_type_normal">
			<?php do_action( 'ingenioso_action_before_sidebar_wrap', 'footer' ); ?>
			<div class="footer_widgets_inner widget_area_inner">
				<?php
				if ( ! $ingenioso_footer_wide ) {
					?>
					<div class="content_wrap">
					<?php
				}
				if ( $ingenioso_need_columns ) {
					?>
					<div class="columns_wrap">
					<?php
				}
				do_action( 'ingenioso_action_before_sidebar', 'footer' );
				ingenioso_show_layout( $ingenioso_out );
				do_action( 'ingenioso_action_after_sidebar', 'footer' );
				if ( $ingenioso_need_columns ) {
					?>
					</div><!-- /.columns_wrap -->
					<?php
				}
				if ( ! $ingenioso_footer_wide ) {
					?>
					</div><!-- /.content_wrap -->
					<?php
				}
				?>
			</div><!-- /.footer_widgets_inner -->
			<?php do_action( 'ingenioso_action_after_sidebar_wrap', 'footer' ); ?>
		</div><!-- /.footer_widgets_wrap -->
		<?php
	}
}
