<?php
/**
 * The template to display the socials in the footer
 *
 * @package INGENIOSO
 * @since INGENIOSO 1.0.10
 */


// Socials
if ( ingenioso_is_on( ingenioso_get_theme_option( 'socials_in_footer' ) ) ) {
	$ingenioso_output = ingenioso_get_socials_links();
	if ( '' != $ingenioso_output ) {
		?>
		<div class="footer_socials_wrap socials_wrap">
			<div class="footer_socials_inner">
				<?php ingenioso_show_layout( $ingenioso_output ); ?>
			</div>
		</div>
		<?php
	}
}
