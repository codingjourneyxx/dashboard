<?php
/**
 * The template to display the logo or the site name and the slogan in the Header
 *
 * @package INGENIOSO
 * @since INGENIOSO 1.0
 */

$ingenioso_args = get_query_var( 'ingenioso_logo_args' );

// Site logo
$ingenioso_logo_type   = isset( $ingenioso_args['type'] ) ? $ingenioso_args['type'] : '';
$ingenioso_logo_image  = ingenioso_get_logo_image( $ingenioso_logo_type );
$ingenioso_logo_text   = ingenioso_is_on( ingenioso_get_theme_option( 'logo_text' ) ) ? get_bloginfo( 'name' ) : '';
$ingenioso_logo_slogan = get_bloginfo( 'description', 'display' );
if ( ! empty( $ingenioso_logo_image['logo'] ) || ! empty( $ingenioso_logo_text ) ) {
	?><a class="sc_layouts_logo" href="<?php echo esc_url( home_url( '/' ) ); ?>">
		<?php
		if ( ! empty( $ingenioso_logo_image['logo'] ) ) {
			if ( empty( $ingenioso_logo_type ) && function_exists( 'the_custom_logo' ) && is_numeric($ingenioso_logo_image['logo']) && (int) $ingenioso_logo_image['logo'] > 0 ) {
				the_custom_logo();
			} else {
				$ingenioso_attr = ingenioso_getimagesize( $ingenioso_logo_image['logo'] );
				echo '<img src="' . esc_url( $ingenioso_logo_image['logo'] ) . '"'
						. ( ! empty( $ingenioso_logo_image['logo_retina'] ) ? ' srcset="' . esc_url( $ingenioso_logo_image['logo_retina'] ) . ' 2x"' : '' )
						. ' alt="' . esc_attr( $ingenioso_logo_text ) . '"'
						. ( ! empty( $ingenioso_attr[3] ) ? ' ' . wp_kses_data( $ingenioso_attr[3] ) : '' )
						. '>';
			}
		} else {
			ingenioso_show_layout( ingenioso_prepare_macros( $ingenioso_logo_text ), '<span class="logo_text">', '</span>' );
			ingenioso_show_layout( ingenioso_prepare_macros( $ingenioso_logo_slogan ), '<span class="logo_slogan">', '</span>' );
		}
		?>
	</a>
	<?php
}
