<?php
/**
 * The template 'Style 1' to displaying related posts
 *
 * @package INGENIOSO
 * @since INGENIOSO 1.0
 */

$ingenioso_link        = get_permalink();
$ingenioso_post_format = get_post_format();
$ingenioso_post_format = empty( $ingenioso_post_format ) ? 'standard' : str_replace( 'post-format-', '', $ingenioso_post_format );
?><div id="post-<?php the_ID(); ?>" <?php post_class( 'related_item post_format_' . esc_attr( $ingenioso_post_format ) ); ?> data-post-id="<?php the_ID(); ?>">
	<?php
	ingenioso_show_post_featured(
		array(
			'thumb_size'    => apply_filters( 'ingenioso_filter_related_thumb_size', ingenioso_get_thumb_size( (int) ingenioso_get_theme_option( 'related_posts' ) == 1 ? 'huge' : 'big' ) ),
			'post_info'     => '<div class="post_header entry-header">'
									. '<div class="post_categories">' . wp_kses( ingenioso_get_post_categories( '' ), 'ingenioso_kses_content' ) . '</div>'
									. '<h6 class="post_title entry-title"><a href="' . esc_url( $ingenioso_link ) . '">'
										. wp_kses_data( '' == get_the_title() ? esc_html__( '- No title -', 'ingenioso' ) : get_the_title() )
									. '</a></h6>'
									. ( in_array( get_post_type(), array( 'post', 'attachment' ) )
											? '<div class="post_meta"><a href="' . esc_url( $ingenioso_link ) . '" class="post_meta_item post_date">' . wp_kses_data( ingenioso_get_date() ) . '</a></div>'
											: '' )
								. '</div>',
		)
	);
	?>
</div>
