<?php
/**
 * The template to display default site footer
 *
 * @package INGENIOSO
 * @since INGENIOSO 1.0.10
 */

$ingenioso_footer_id = ingenioso_get_custom_footer_id();
$ingenioso_footer_meta = get_post_meta( $ingenioso_footer_id, 'trx_addons_options', true );
if ( ! empty( $ingenioso_footer_meta['margin'] ) ) {
	ingenioso_add_inline_css( sprintf( '.page_content_wrap{padding-bottom:%s}', esc_attr( ingenioso_prepare_css_value( $ingenioso_footer_meta['margin'] ) ) ) );
}
?>
<footer class="footer_wrap footer_custom footer_custom_<?php echo esc_attr( $ingenioso_footer_id ); ?> footer_custom_<?php echo esc_attr( sanitize_title( get_the_title( $ingenioso_footer_id ) ) ); ?>
						<?php
						$ingenioso_footer_scheme = ingenioso_get_theme_option( 'footer_scheme' );
						if ( ! empty( $ingenioso_footer_scheme ) && ! ingenioso_is_inherit( $ingenioso_footer_scheme  ) ) {
							echo ' scheme_' . esc_attr( $ingenioso_footer_scheme );
						}
						?>
						">
	<?php
	// Custom footer's layout
	do_action( 'ingenioso_action_show_layout', $ingenioso_footer_id );
	?>
</footer><!-- /.footer_wrap -->
