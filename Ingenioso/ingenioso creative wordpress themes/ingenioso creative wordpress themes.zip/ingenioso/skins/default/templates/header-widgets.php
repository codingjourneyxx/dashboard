<?php
/**
 * The template to display the widgets area in the header
 *
 * @package INGENIOSO
 * @since INGENIOSO 1.0
 */

// Header sidebar
$ingenioso_header_name    = ingenioso_get_theme_option( 'header_widgets' );
$ingenioso_header_present = ! ingenioso_is_off( $ingenioso_header_name ) && is_active_sidebar( $ingenioso_header_name );
if ( $ingenioso_header_present ) {
	ingenioso_storage_set( 'current_sidebar', 'header' );
	$ingenioso_header_wide = ingenioso_get_theme_option( 'header_wide' );
	ob_start();
	if ( is_active_sidebar( $ingenioso_header_name ) ) {
		dynamic_sidebar( $ingenioso_header_name );
	}
	$ingenioso_widgets_output = ob_get_contents();
	ob_end_clean();
	if ( ! empty( $ingenioso_widgets_output ) ) {
		$ingenioso_widgets_output = preg_replace( "/<\/aside>[\r\n\s]*<aside/", '</aside><aside', $ingenioso_widgets_output );
		$ingenioso_need_columns   = strpos( $ingenioso_widgets_output, 'columns_wrap' ) === false;
		if ( $ingenioso_need_columns ) {
			$ingenioso_columns = max( 0, (int) ingenioso_get_theme_option( 'header_columns' ) );
			if ( 0 == $ingenioso_columns ) {
				$ingenioso_columns = min( 6, max( 1, ingenioso_tags_count( $ingenioso_widgets_output, 'aside' ) ) );
			}
			if ( $ingenioso_columns > 1 ) {
				$ingenioso_widgets_output = preg_replace( '/<aside([^>]*)class="widget/', '<aside$1class="column-1_' . esc_attr( $ingenioso_columns ) . ' widget', $ingenioso_widgets_output );
			} else {
				$ingenioso_need_columns = false;
			}
		}
		?>
		<div class="header_widgets_wrap widget_area<?php echo ! empty( $ingenioso_header_wide ) ? ' header_fullwidth' : ' header_boxed'; ?>">
			<?php do_action( 'ingenioso_action_before_sidebar_wrap', 'header' ); ?>
			<div class="header_widgets_inner widget_area_inner">
				<?php
				if ( ! $ingenioso_header_wide ) {
					?>
					<div class="content_wrap">
					<?php
				}
				if ( $ingenioso_need_columns ) {
					?>
					<div class="columns_wrap">
					<?php
				}
				do_action( 'ingenioso_action_before_sidebar', 'header' );
				ingenioso_show_layout( $ingenioso_widgets_output );
				do_action( 'ingenioso_action_after_sidebar', 'header' );
				if ( $ingenioso_need_columns ) {
					?>
					</div>	<!-- /.columns_wrap -->
					<?php
				}
				if ( ! $ingenioso_header_wide ) {
					?>
					</div>	<!-- /.content_wrap -->
					<?php
				}
				?>
			</div>	<!-- /.header_widgets_inner -->
			<?php do_action( 'ingenioso_action_after_sidebar_wrap', 'header' ); ?>
		</div>	<!-- /.header_widgets_wrap -->
		<?php
	}
}
