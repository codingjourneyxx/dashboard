<?php
/**
 * The Portfolio template to display the content
 *
 * Used for index/archive/search.
 *
 * @package INGENIOSO
 * @since INGENIOSO 1.0
 */

$ingenioso_template_args = get_query_var( 'ingenioso_template_args' );
if ( is_array( $ingenioso_template_args ) ) {
	$ingenioso_columns    = empty( $ingenioso_template_args['columns'] ) ? 2 : max( 1, $ingenioso_template_args['columns'] );
	$ingenioso_blog_style = array( $ingenioso_template_args['type'], $ingenioso_columns );
    $ingenioso_columns_class = ingenioso_get_column_class( 1, $ingenioso_columns, ! empty( $ingenioso_template_args['columns_tablet']) ? $ingenioso_template_args['columns_tablet'] : '', ! empty($ingenioso_template_args['columns_mobile']) ? $ingenioso_template_args['columns_mobile'] : '' );
} else {
	$ingenioso_template_args = array();
	$ingenioso_blog_style = explode( '_', ingenioso_get_theme_option( 'blog_style' ) );
	$ingenioso_columns    = empty( $ingenioso_blog_style[1] ) ? 2 : max( 1, $ingenioso_blog_style[1] );
    $ingenioso_columns_class = ingenioso_get_column_class( 1, $ingenioso_columns );
}

$ingenioso_post_format = get_post_format();
$ingenioso_post_format = empty( $ingenioso_post_format ) ? 'standard' : str_replace( 'post-format-', '', $ingenioso_post_format );

?><div class="
<?php
if ( ! empty( $ingenioso_template_args['slider'] ) ) {
	echo ' slider-slide swiper-slide';
} else {
	echo ( ingenioso_is_blog_style_use_masonry( $ingenioso_blog_style[0] ) ? 'masonry_item masonry_item-1_' . esc_attr( $ingenioso_columns ) : esc_attr( $ingenioso_columns_class ));
}
?>
"><article id="post-<?php the_ID(); ?>" 
	<?php
	post_class(
		'post_item post_item_container post_format_' . esc_attr( $ingenioso_post_format )
		. ' post_layout_portfolio'
		. ' post_layout_portfolio_' . esc_attr( $ingenioso_columns )
		. ( 'portfolio' != $ingenioso_blog_style[0] ? ' ' . esc_attr( $ingenioso_blog_style[0] )  . '_' . esc_attr( $ingenioso_columns ) : '' )
	);
	ingenioso_add_blog_animation( $ingenioso_template_args );
	?>
>
<?php

	// Sticky label
	if ( is_sticky() && ! is_paged() ) {
		?>
		<span class="post_label label_sticky"></span>
		<?php
	}

	$ingenioso_hover   = ! empty( $ingenioso_template_args['hover'] ) && ! ingenioso_is_inherit( $ingenioso_template_args['hover'] )
								? $ingenioso_template_args['hover']
								: ingenioso_get_theme_option( 'image_hover' );

	if ( 'dots' == $ingenioso_hover ) {
		$ingenioso_post_link = empty( $ingenioso_template_args['no_links'] )
								? ( ! empty( $ingenioso_template_args['link'] )
									? $ingenioso_template_args['link']
									: get_permalink()
									)
								: '';
		$ingenioso_target    = ! empty( $ingenioso_post_link ) && ingenioso_is_external_url( $ingenioso_post_link )
								? ' target="_blank" rel="nofollow"'
								: '';
	}
	
	// Meta parts
	$ingenioso_components = ! empty( $ingenioso_template_args['meta_parts'] )
							? ( is_array( $ingenioso_template_args['meta_parts'] )
								? $ingenioso_template_args['meta_parts']
								: explode( ',', $ingenioso_template_args['meta_parts'] )
								)
							: ingenioso_array_get_keys_by_value( ingenioso_get_theme_option( 'meta_parts' ) );

	// Featured image
	ingenioso_show_post_featured( apply_filters( 'ingenioso_filter_args_featured',
        array(
			'hover'         => $ingenioso_hover,
			'no_links'      => ! empty( $ingenioso_template_args['no_links'] ),
			'thumb_size'    => ! empty( $ingenioso_template_args['thumb_size'] )
								? $ingenioso_template_args['thumb_size']
								: ingenioso_get_thumb_size(
									ingenioso_is_blog_style_use_masonry( $ingenioso_blog_style[0] )
										? (	strpos( ingenioso_get_theme_option( 'body_style' ), 'full' ) !== false || $ingenioso_columns < 3
											? 'masonry-big'
											: 'masonry'
											)
										: (	strpos( ingenioso_get_theme_option( 'body_style' ), 'full' ) !== false || $ingenioso_columns < 3
											? 'square'
											: 'square'
											)
								),
			'thumb_bg' => ingenioso_is_blog_style_use_masonry( $ingenioso_blog_style[0] ) ? false : true,
			'show_no_image' => true,
			'meta_parts'    => $ingenioso_components,
			'class'         => 'dots' == $ingenioso_hover ? 'hover_with_info' : '',
			'post_info'     => 'dots' == $ingenioso_hover
										? '<div class="post_info"><h5 class="post_title">'
											. ( ! empty( $ingenioso_post_link )
												? '<a href="' . esc_url( $ingenioso_post_link ) . '"' . ( ! empty( $target ) ? $target : '' ) . '>'
												: ''
												)
												. esc_html( get_the_title() ) 
											. ( ! empty( $ingenioso_post_link )
												? '</a>'
												: ''
												)
											. '</h5></div>'
										: '',
            'thumb_ratio'   => 'info' == $ingenioso_hover ?  '100:102' : '',
        ),
        'content-portfolio',
        $ingenioso_template_args
    ) );
	?>
</article></div><?php
// Need opening PHP-tag above, because <article> is a inline-block element (used as column)!