<?php
/**
 * The Classic template to display the content
 *
 * Used for index/archive/search.
 *
 * @package INGENIOSO
 * @since INGENIOSO 1.0
 */

$ingenioso_template_args = get_query_var( 'ingenioso_template_args' );

if ( is_array( $ingenioso_template_args ) ) {
	$ingenioso_columns    = empty( $ingenioso_template_args['columns'] ) ? 2 : max( 1, $ingenioso_template_args['columns'] );
	$ingenioso_blog_style = array( $ingenioso_template_args['type'], $ingenioso_columns );
    $ingenioso_columns_class = ingenioso_get_column_class( 1, $ingenioso_columns, ! empty( $ingenioso_template_args['columns_tablet']) ? $ingenioso_template_args['columns_tablet'] : '', ! empty($ingenioso_template_args['columns_mobile']) ? $ingenioso_template_args['columns_mobile'] : '' );
} else {
	$ingenioso_template_args = array();
	$ingenioso_blog_style = explode( '_', ingenioso_get_theme_option( 'blog_style' ) );
	$ingenioso_columns    = empty( $ingenioso_blog_style[1] ) ? 2 : max( 1, $ingenioso_blog_style[1] );
    $ingenioso_columns_class = ingenioso_get_column_class( 1, $ingenioso_columns );
}
$ingenioso_expanded   = ! ingenioso_sidebar_present() && ingenioso_get_theme_option( 'expand_content' ) == 'expand';

$ingenioso_post_format = get_post_format();
$ingenioso_post_format = empty( $ingenioso_post_format ) ? 'standard' : str_replace( 'post-format-', '', $ingenioso_post_format );

?><div class="<?php
	if ( ! empty( $ingenioso_template_args['slider'] ) ) {
		echo ' slider-slide swiper-slide';
	} else {
		echo ( ingenioso_is_blog_style_use_masonry( $ingenioso_blog_style[0] ) ? 'masonry_item masonry_item-1_' . esc_attr( $ingenioso_columns ) : esc_attr( $ingenioso_columns_class ) );
	}
?>"><article id="post-<?php the_ID(); ?>" data-post-id="<?php the_ID(); ?>"
	<?php
	post_class(
		'post_item post_item_container post_format_' . esc_attr( $ingenioso_post_format )
				. ' post_layout_classic post_layout_classic_' . esc_attr( $ingenioso_columns )
				. ' post_layout_' . esc_attr( $ingenioso_blog_style[0] )
				. ' post_layout_' . esc_attr( $ingenioso_blog_style[0] ) . '_' . esc_attr( $ingenioso_columns )
	);
	ingenioso_add_blog_animation( $ingenioso_template_args );
	?>
>
	<?php

	// Sticky label
	if ( is_sticky() && ! is_paged() ) {
		?>
		<span class="post_label label_sticky"></span>
		<?php
	}

	// Featured image
	$ingenioso_hover      = ! empty( $ingenioso_template_args['hover'] ) && ! ingenioso_is_inherit( $ingenioso_template_args['hover'] )
							? $ingenioso_template_args['hover']
							: ingenioso_get_theme_option( 'image_hover' );

	$ingenioso_components = ! empty( $ingenioso_template_args['meta_parts'] )
							? ( is_array( $ingenioso_template_args['meta_parts'] )
								? $ingenioso_template_args['meta_parts']
								: explode( ',', $ingenioso_template_args['meta_parts'] )
								)
							: ingenioso_array_get_keys_by_value( ingenioso_get_theme_option( 'meta_parts' ) );

	ingenioso_show_post_featured( apply_filters( 'ingenioso_filter_args_featured',
		array(
			'thumb_size' => ! empty( $ingenioso_template_args['thumb_size'] )
				? $ingenioso_template_args['thumb_size']
				: ingenioso_get_thumb_size(
					'classic' == $ingenioso_blog_style[0]
						? ( strpos( ingenioso_get_theme_option( 'body_style' ), 'full' ) !== false
								? ( $ingenioso_columns > 2 ? 'big' : 'huge' )
								: ( $ingenioso_columns > 2
									? ( $ingenioso_expanded ? 'square' : 'square' )
									: ($ingenioso_columns > 1 ? 'square' : ( $ingenioso_expanded ? 'huge' : 'big' ))
									)
							)
						: ( strpos( ingenioso_get_theme_option( 'body_style' ), 'full' ) !== false
								? ( $ingenioso_columns > 2 ? 'masonry-big' : 'full' )
								: ($ingenioso_columns === 1 ? ( $ingenioso_expanded ? 'huge' : 'big' ) : ( $ingenioso_columns <= 2 && $ingenioso_expanded ? 'masonry-big' : 'masonry' ))
							)
			),
			'hover'      => $ingenioso_hover,
			'meta_parts' => $ingenioso_components,
			'no_links'   => ! empty( $ingenioso_template_args['no_links'] ),
        ),
        'content-classic',
        $ingenioso_template_args
    ) );

	// Title and post meta
	$ingenioso_show_title = get_the_title() != '';
	$ingenioso_show_meta  = count( $ingenioso_components ) > 0 && ! in_array( $ingenioso_hover, array( 'border', 'pull', 'slide', 'fade', 'info' ) );

	if ( $ingenioso_show_title ) {
		?>
		<div class="post_header entry-header">
			<?php

			// Post meta
			if ( apply_filters( 'ingenioso_filter_show_blog_meta', $ingenioso_show_meta, $ingenioso_components, 'classic' ) ) {
				if ( count( $ingenioso_components ) > 0 ) {
					do_action( 'ingenioso_action_before_post_meta' );
					ingenioso_show_post_meta(
						apply_filters(
							'ingenioso_filter_post_meta_args', array(
							'components' => join( ',', $ingenioso_components ),
							'seo'        => false,
							'echo'       => true,
						), $ingenioso_blog_style[0], $ingenioso_columns
						)
					);
					do_action( 'ingenioso_action_after_post_meta' );
				}
			}

			// Post title
			if ( apply_filters( 'ingenioso_filter_show_blog_title', true, 'classic' ) ) {
				do_action( 'ingenioso_action_before_post_title' );
				if ( empty( $ingenioso_template_args['no_links'] ) ) {
					the_title( sprintf( '<h4 class="post_title entry-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h4>' );
				} else {
					the_title( '<h4 class="post_title entry-title">', '</h4>' );
				}
				do_action( 'ingenioso_action_after_post_title' );
			}

			if( !in_array( $ingenioso_post_format, array( 'quote', 'aside', 'link', 'status' ) ) ) {
				// More button
				if ( apply_filters( 'ingenioso_filter_show_blog_readmore', ! $ingenioso_show_title || ! empty( $ingenioso_template_args['more_button'] ), 'classic' ) ) {
					if ( empty( $ingenioso_template_args['no_links'] ) ) {
						do_action( 'ingenioso_action_before_post_readmore' );
						ingenioso_show_post_more_link( $ingenioso_template_args, '<div class="more-wrap">', '</div>' );
						do_action( 'ingenioso_action_after_post_readmore' );
					}
				}
			}
			?>
		</div><!-- .entry-header -->
		<?php
	}

	// Post content
	if( in_array( $ingenioso_post_format, array( 'quote', 'aside', 'link', 'status' ) ) ) {
		ob_start();
		if (apply_filters('ingenioso_filter_show_blog_excerpt', empty($ingenioso_template_args['hide_excerpt']) && ingenioso_get_theme_option('excerpt_length') > 0, 'classic')) {
			ingenioso_show_post_content($ingenioso_template_args, '<div class="post_content_inner">', '</div>');
		}
		// More button
		if(! empty( $ingenioso_template_args['more_button'] )) {
			if ( empty( $ingenioso_template_args['no_links'] ) ) {
				do_action( 'ingenioso_action_before_post_readmore' );
				ingenioso_show_post_more_link( $ingenioso_template_args, '<div class="more-wrap">', '</div>' );
				do_action( 'ingenioso_action_after_post_readmore' );
			}
		}
		$ingenioso_content = ob_get_contents();
		ob_end_clean();
		ingenioso_show_layout($ingenioso_content, '<div class="post_content entry-content">', '</div><!-- .entry-content -->');
	}
	?>

</article></div><?php
// Need opening PHP-tag above, because <div> is a inline-block element (used as column)!
