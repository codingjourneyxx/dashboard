<?php
/**
 * The custom template to display the content
 *
 * Used for index/archive/search.
 *
 * @package INGENIOSO
 * @since INGENIOSO 1.0.50
 */

$ingenioso_template_args = get_query_var( 'ingenioso_template_args' );
if ( is_array( $ingenioso_template_args ) ) {
	$ingenioso_columns    = empty( $ingenioso_template_args['columns'] ) ? 2 : max( 1, $ingenioso_template_args['columns'] );
	$ingenioso_blog_style = array( $ingenioso_template_args['type'], $ingenioso_columns );
} else {
	$ingenioso_template_args = array();
	$ingenioso_blog_style = explode( '_', ingenioso_get_theme_option( 'blog_style' ) );
	$ingenioso_columns    = empty( $ingenioso_blog_style[1] ) ? 2 : max( 1, $ingenioso_blog_style[1] );
}
$ingenioso_blog_id       = ingenioso_get_custom_blog_id( join( '_', $ingenioso_blog_style ) );
$ingenioso_blog_style[0] = str_replace( 'blog-custom-', '', $ingenioso_blog_style[0] );
$ingenioso_expanded      = ! ingenioso_sidebar_present() && ingenioso_get_theme_option( 'expand_content' ) == 'expand';
$ingenioso_components    = ! empty( $ingenioso_template_args['meta_parts'] )
							? ( is_array( $ingenioso_template_args['meta_parts'] )
								? join( ',', $ingenioso_template_args['meta_parts'] )
								: $ingenioso_template_args['meta_parts']
								)
							: ingenioso_array_get_keys_by_value( ingenioso_get_theme_option( 'meta_parts' ) );
$ingenioso_post_format   = get_post_format();
$ingenioso_post_format   = empty( $ingenioso_post_format ) ? 'standard' : str_replace( 'post-format-', '', $ingenioso_post_format );

$ingenioso_blog_meta     = ingenioso_get_custom_layout_meta( $ingenioso_blog_id );
$ingenioso_custom_style  = ! empty( $ingenioso_blog_meta['scripts_required'] ) ? $ingenioso_blog_meta['scripts_required'] : 'none';

if ( ! empty( $ingenioso_template_args['slider'] ) || $ingenioso_columns > 1 || ! ingenioso_is_off( $ingenioso_custom_style ) ) {
	?><div class="
		<?php
		if ( ! empty( $ingenioso_template_args['slider'] ) ) {
			echo 'slider-slide swiper-slide';
		} else {
			echo esc_attr( ( ingenioso_is_off( $ingenioso_custom_style ) ? 'column' : sprintf( '%1$s_item %1$s_item', $ingenioso_custom_style ) ) . "-1_{$ingenioso_columns}" );
		}
		?>
	">
	<?php
}
?>
<article id="post-<?php the_ID(); ?>" data-post-id="<?php the_ID(); ?>"
	<?php
	post_class(
			'post_item post_item_container post_format_' . esc_attr( $ingenioso_post_format )
					. ' post_layout_custom post_layout_custom_' . esc_attr( $ingenioso_columns )
					. ' post_layout_' . esc_attr( $ingenioso_blog_style[0] )
					. ' post_layout_' . esc_attr( $ingenioso_blog_style[0] ) . '_' . esc_attr( $ingenioso_columns )
					. ( ! ingenioso_is_off( $ingenioso_custom_style )
						? ' post_layout_' . esc_attr( $ingenioso_custom_style )
							. ' post_layout_' . esc_attr( $ingenioso_custom_style ) . '_' . esc_attr( $ingenioso_columns )
						: ''
						)
		);
	ingenioso_add_blog_animation( $ingenioso_template_args );
	?>
>
	<?php
	// Sticky label
	if ( is_sticky() && ! is_paged() ) {
		?>
		<span class="post_label label_sticky"></span>
		<?php
	}
	// Custom layout
	do_action( 'ingenioso_action_show_layout', $ingenioso_blog_id, get_the_ID() );
	?>
</article><?php
if ( ! empty( $ingenioso_template_args['slider'] ) || $ingenioso_columns > 1 || ! ingenioso_is_off( $ingenioso_custom_style ) ) {
	?></div><?php
	// Need opening PHP-tag above just after </div>, because <div> is a inline-block element (used as column)!
}
