<?php
/**
 * Required plugins
 *
 * @package INGENIOSO
 * @since INGENIOSO 1.76.0
 */

// THEME-SUPPORTED PLUGINS
// If plugin not need - remove its settings from next array
//----------------------------------------------------------
$ingenioso_theme_required_plugins_groups = array(
	'core'          => esc_html__( 'Core', 'ingenioso' ),
	'page_builders' => esc_html__( 'Page Builders', 'ingenioso' ),
	'ecommerce'     => esc_html__( 'E-Commerce & Donations', 'ingenioso' ),
	'socials'       => esc_html__( 'Socials and Communities', 'ingenioso' ),
	'events'        => esc_html__( 'Events and Appointments', 'ingenioso' ),
	'content'       => esc_html__( 'Content', 'ingenioso' ),
	'other'         => esc_html__( 'Other', 'ingenioso' ),
);
$ingenioso_theme_required_plugins        = array(
	'trx_addons'                 => array(
		'title'       => esc_html__( 'ThemeREX Addons', 'ingenioso' ),
		'description' => esc_html__( "Will allow you to install recommended plugins, demo content, and improve the theme's functionality overall with multiple theme options", 'ingenioso' ),
		'required'    => true,
		'logo'        => 'trx_addons.png',
		'group'       => $ingenioso_theme_required_plugins_groups['core'],
	),
	'elementor'                  => array(
		'title'       => esc_html__( 'Elementor', 'ingenioso' ),
		'description' => esc_html__( "Is a beautiful PageBuilder, even the free version of which allows you to create great pages using a variety of modules.", 'ingenioso' ),
		'required'    => false,
		'logo'        => 'elementor.png',
		'group'       => $ingenioso_theme_required_plugins_groups['page_builders'],
	),
	'gutenberg'                  => array(
		'title'       => esc_html__( 'Gutenberg', 'ingenioso' ),
		'description' => esc_html__( "It's a posts editor coming in place of the classic TinyMCE. Can be installed and used in parallel with Elementor", 'ingenioso' ),
		'required'    => false,
		'install'     => false,          // Do not offer installation of the plugin in the Theme Dashboard and TGMPA
		'logo'        => 'gutenberg.png',
		'group'       => $ingenioso_theme_required_plugins_groups['page_builders'],
	),
	'js_composer'                => array(
		'title'       => esc_html__( 'WPBakery PageBuilder', 'ingenioso' ),
		'description' => esc_html__( "Popular PageBuilder which allows you to create excellent pages", 'ingenioso' ),
		'required'    => false,
		'install'     => false,          // Do not offer installation of the plugin in the Theme Dashboard and TGMPA
		'logo'        => 'js_composer.jpg',
		'group'       => $ingenioso_theme_required_plugins_groups['page_builders'],
	),
	'woocommerce'                => array(
		'title'       => esc_html__( 'WooCommerce', 'ingenioso' ),
		'description' => esc_html__( "Connect the store to your website and start selling now", 'ingenioso' ),
		'required'    => false,
		'install'     => false,
		'logo'        => 'woocommerce.png',
		'group'       => $ingenioso_theme_required_plugins_groups['ecommerce'],
	),
	'elegro-payment'             => array(
		'title'       => esc_html__( 'Elegro Crypto Payment', 'ingenioso' ),
		'description' => esc_html__( "Extends WooCommerce Payment Gateways with an elegro Crypto Payment", 'ingenioso' ),
		'required'    => false,
		'install'     => false, // TRX_addons has marked the "Elegro Crypto Payment" plugin as obsolete and no longer recommends it for installation, even if it had been previously recommended by the theme
		'logo'        => 'elegro-payment.png',
		'group'       => $ingenioso_theme_required_plugins_groups['ecommerce'],
	),
	'instagram-feed'             => array(
		'title'       => esc_html__( 'Instagram Feed', 'ingenioso' ),
		'description' => esc_html__( "Displays the latest photos from your profile on Instagram", 'ingenioso' ),
		'required'    => false,
		'logo'        => 'instagram-feed.png',
		'group'       => $ingenioso_theme_required_plugins_groups['socials'],
	),
	'mailchimp-for-wp'           => array(
		'title'       => esc_html__( 'MailChimp for WP', 'ingenioso' ),
		'description' => esc_html__( "Allows visitors to subscribe to newsletters", 'ingenioso' ),
		'required'    => false,
		'logo'        => 'mailchimp-for-wp.png',
		'group'       => $ingenioso_theme_required_plugins_groups['socials'],
	),
	'booked'                     => array(
		'title'       => esc_html__( 'Booked Appointments', 'ingenioso' ),
		'description' => '',
		'required'    => false,
		'install'     => false,
		'logo'        => 'booked.png',
		'group'       => $ingenioso_theme_required_plugins_groups['events'],
	),
	'quickcal'                     => array(
		'title'       => esc_html__( 'QuickCal', 'ingenioso' ),
		'description' => '',
		'required'    => false,
		'install'     => false,
		'logo'        => 'quickcal.png',
		'group'       => $ingenioso_theme_required_plugins_groups['events'],
	),
	'the-events-calendar'        => array(
		'title'       => esc_html__( 'The Events Calendar', 'ingenioso' ),
		'description' => '',
		'required'    => false,
		'install'     => false,
		'logo'        => 'the-events-calendar.png',
		'group'       => $ingenioso_theme_required_plugins_groups['events'],
	),
	'contact-form-7'             => array(
		'title'       => esc_html__( 'Contact Form 7', 'ingenioso' ),
		'description' => esc_html__( "CF7 allows you to create an unlimited number of contact forms", 'ingenioso' ),
		'required'    => false,
		'logo'        => 'contact-form-7.png',
		'group'       => $ingenioso_theme_required_plugins_groups['content'],
	),

	'latepoint'                  => array(
		'title'       => esc_html__( 'LatePoint', 'ingenioso' ),
		'description' => '',
		'required'    => false,
		'install'     => false,
		'logo'        => ingenioso_get_file_url( 'plugins/latepoint/latepoint.png' ),
		'group'       => $ingenioso_theme_required_plugins_groups['events'],
	),
	'advanced-popups'                  => array(
		'title'       => esc_html__( 'Advanced Popups', 'ingenioso' ),
		'description' => '',
		'required'    => false,
		'logo'        => ingenioso_get_file_url( 'plugins/advanced-popups/advanced-popups.jpg' ),
		'group'       => $ingenioso_theme_required_plugins_groups['content'],
	),
	'devvn-image-hotspot'                  => array(
		'title'       => esc_html__( 'Image Hotspot by DevVN', 'ingenioso' ),
		'description' => '',
		'required'    => false,
		'install'     => false,
		'logo'        => ingenioso_get_file_url( 'plugins/devvn-image-hotspot/devvn-image-hotspot.png' ),
		'group'       => $ingenioso_theme_required_plugins_groups['content'],
	),
	'ti-woocommerce-wishlist'                  => array(
		'title'       => esc_html__( 'TI WooCommerce Wishlist', 'ingenioso' ),
		'description' => '',
		'required'    => false,
		'install'     => false,
		'logo'        => ingenioso_get_file_url( 'plugins/ti-woocommerce-wishlist/ti-woocommerce-wishlist.png' ),
		'group'       => $ingenioso_theme_required_plugins_groups['ecommerce'],
	),
	'woo-smart-quick-view'                  => array(
		'title'       => esc_html__( 'WPC Smart Quick View for WooCommerce', 'ingenioso' ),
		'description' => '',
		'required'    => false,
		'install'     => false,
		'logo'        => ingenioso_get_file_url( 'plugins/woo-smart-quick-view/woo-smart-quick-view.png' ),
		'group'       => $ingenioso_theme_required_plugins_groups['ecommerce'],
	),
	'twenty20'                  => array(
		'title'       => esc_html__( 'Twenty20 Image Before-After', 'ingenioso' ),
		'description' => '',
		'required'    => false,
		'install'     => false,
		'logo'        => ingenioso_get_file_url( 'plugins/twenty20/twenty20.png' ),
		'group'       => $ingenioso_theme_required_plugins_groups['content'],
	),
	'essential-grid'             => array(
		'title'       => esc_html__( 'Essential Grid', 'ingenioso' ),
		'description' => '',
		'required'    => false,
		'install'     => false,
		'logo'        => 'essential-grid.png',
		'group'       => $ingenioso_theme_required_plugins_groups['content'],
	),
	'revslider'                  => array(
		'title'       => esc_html__( 'Revolution Slider', 'ingenioso' ),
		'description' => '',
		'required'    => false,
		'logo'        => 'revslider.png',
		'group'       => $ingenioso_theme_required_plugins_groups['content'],
	),
	'sitepress-multilingual-cms' => array(
		'title'       => esc_html__( 'WPML - Sitepress Multilingual CMS', 'ingenioso' ),
		'description' => esc_html__( "Allows you to make your website multilingual", 'ingenioso' ),
		'required'    => false,
		'install'     => false,      // Do not offer installation of the plugin in the Theme Dashboard and TGMPA
		'logo'        => 'sitepress-multilingual-cms.png',
		'group'       => $ingenioso_theme_required_plugins_groups['content'],
	),
	'wp-gdpr-compliance'         => array(
		'title'       => esc_html__( 'Cookie Information', 'ingenioso' ),
		'description' => esc_html__( "Allow visitors to decide for themselves what personal data they want to store on your site", 'ingenioso' ),
		'required'    => false,
		'install'     => false,
		'logo'        => 'wp-gdpr-compliance.png',
		'group'       => $ingenioso_theme_required_plugins_groups['other'],
	),
	'gdpr-framework'         => array(
		'title'       => esc_html__( 'The GDPR Framework', 'ingenioso' ),
		'description' => esc_html__( "Tools to help make your website GDPR-compliant. Fully documented, extendable and developer-friendly.", 'ingenioso' ),
		'required'    => false,
		'install'     => false,
		'logo'        => 'gdpr-framework.png',
		'group'       => $ingenioso_theme_required_plugins_groups['other'],
	),
	'trx_updater'                => array(
		'title'       => esc_html__( 'ThemeREX Updater', 'ingenioso' ),
		'description' => esc_html__( "Update theme and theme-specific plugins from developer's upgrade server.", 'ingenioso' ),
		'required'    => false,
		'logo'        => 'trx_updater.png',
		'group'       => $ingenioso_theme_required_plugins_groups['other'],
	),
);

if ( INGENIOSO_THEME_FREE ) {
	unset( $ingenioso_theme_required_plugins['js_composer'] );
	unset( $ingenioso_theme_required_plugins['booked'] );
	unset( $ingenioso_theme_required_plugins['quickcal'] );
	unset( $ingenioso_theme_required_plugins['the-events-calendar'] );
	unset( $ingenioso_theme_required_plugins['calculated-fields-form'] );
	unset( $ingenioso_theme_required_plugins['essential-grid'] );
	unset( $ingenioso_theme_required_plugins['revslider'] );
	unset( $ingenioso_theme_required_plugins['sitepress-multilingual-cms'] );
	unset( $ingenioso_theme_required_plugins['trx_updater'] );
	unset( $ingenioso_theme_required_plugins['trx_popup'] );
}

// Add plugins list to the global storage
ingenioso_storage_set( 'required_plugins', $ingenioso_theme_required_plugins );
