<?php
/* TI WooCommerce Wishlist support functions
------------------------------------------------------------------------------- */

// Theme init priorities:
// 9 - register other filters (for installer, etc.)
if (!function_exists('ingenioso_wishlist_theme_setup9')) {
	add_action( 'after_setup_theme', 'ingenioso_wishlist_theme_setup9', 9 );
	function ingenioso_wishlist_theme_setup9() {
		if (is_admin()) {
			add_filter( 'ingenioso_filter_tgmpa_required_plugins',		'ingenioso_wishlist_tgmpa_required_plugins' );
		}
	}
}

// Filter to add in the required plugins list
if ( !function_exists( 'ingenioso_wishlist_tgmpa_required_plugins' ) ) {
	function ingenioso_wishlist_tgmpa_required_plugins($list=array()) {
		if (ingenioso_storage_isset('required_plugins', 'ti-woocommerce-wishlist') && ingenioso_storage_get_array( 'required_plugins', 'ti-woocommerce-wishlist', 'install' ) !== false) {
			$list[] = array(
				'name' 		=> ingenioso_storage_get_array('required_plugins', 'ti-woocommerce-wishlist', 'title'),
				'slug' 		=> 'ti-woocommerce-wishlist',
				'required' 	=> false
			);
		}
		return $list;
	}
}

// Check if plugin installed and activated
if ( !function_exists( 'ingenioso_exists_wishlist' ) ) {
	function ingenioso_exists_wishlist() {
		return function_exists('activation_tinv_wishlist');
	}
}


// One-click import support
//------------------------------------------------------------------------

// Check plugin in the required plugins
if ( !function_exists( 'ingenioso_wishlist_importer_required_plugins' ) ) {
    if (is_admin()) add_filter( 'trx_addons_filter_importer_required_plugins',	'ingenioso_wishlist_importer_required_plugins', 10, 2 );
    function ingenioso_wishlist_importer_required_plugins($not_installed='', $list='') {
        if (strpos($list, 'ti-woocommerce-wishlist')!==false && !ingenioso_exists_wishlist() )
            $not_installed .= '<br>' . esc_html__('WooCommerce Wishlist', 'ingenioso');
        return $not_installed;
    }
}

// Set plugin's specific importer options
if ( !function_exists( 'ingenioso_wishlist_importer_set_options' ) ) {
    if (is_admin()) add_filter( 'trx_addons_filter_importer_options',	'ingenioso_wishlist_importer_set_options' );
    function ingenioso_wishlist_importer_set_options($options=array()) {
        if ( ingenioso_exists_wishlist() && in_array('ti-woocommerce-wishlist', $options['required_plugins']) ) {
            $options['additional_options'][] = 'tinvwl-%';
        }
        return $options;
    }
}


?>