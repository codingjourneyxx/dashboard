<?php
$ingenioso_woocommerce_sc = ingenioso_get_theme_option( 'front_page_woocommerce_products' );
if ( ! empty( $ingenioso_woocommerce_sc ) ) {
	?><div class="front_page_section front_page_section_woocommerce<?php
		$ingenioso_scheme = ingenioso_get_theme_option( 'front_page_woocommerce_scheme' );
		if ( ! empty( $ingenioso_scheme ) && ! ingenioso_is_inherit( $ingenioso_scheme ) ) {
			echo ' scheme_' . esc_attr( $ingenioso_scheme );
		}
		echo ' front_page_section_paddings_' . esc_attr( ingenioso_get_theme_option( 'front_page_woocommerce_paddings' ) );
		if ( ingenioso_get_theme_option( 'front_page_woocommerce_stack' ) ) {
			echo ' sc_stack_section_on';
		}
	?>"
			<?php
			$ingenioso_css      = '';
			$ingenioso_bg_image = ingenioso_get_theme_option( 'front_page_woocommerce_bg_image' );
			if ( ! empty( $ingenioso_bg_image ) ) {
				$ingenioso_css .= 'background-image: url(' . esc_url( ingenioso_get_attachment_url( $ingenioso_bg_image ) ) . ');';
			}
			if ( ! empty( $ingenioso_css ) ) {
				echo ' style="' . esc_attr( $ingenioso_css ) . '"';
			}
			?>
	>
	<?php
		// Add anchor
		$ingenioso_anchor_icon = ingenioso_get_theme_option( 'front_page_woocommerce_anchor_icon' );
		$ingenioso_anchor_text = ingenioso_get_theme_option( 'front_page_woocommerce_anchor_text' );
		if ( ( ! empty( $ingenioso_anchor_icon ) || ! empty( $ingenioso_anchor_text ) ) && shortcode_exists( 'trx_sc_anchor' ) ) {
			echo do_shortcode(
				'[trx_sc_anchor id="front_page_section_woocommerce"'
											. ( ! empty( $ingenioso_anchor_icon ) ? ' icon="' . esc_attr( $ingenioso_anchor_icon ) . '"' : '' )
											. ( ! empty( $ingenioso_anchor_text ) ? ' title="' . esc_attr( $ingenioso_anchor_text ) . '"' : '' )
											. ']'
			);
		}
	?>
		<div class="front_page_section_inner front_page_section_woocommerce_inner
			<?php
			if ( ingenioso_get_theme_option( 'front_page_woocommerce_fullheight' ) ) {
				echo ' ingenioso-full-height sc_layouts_flex sc_layouts_columns_middle';
			}
			?>
				"
				<?php
				$ingenioso_css      = '';
				$ingenioso_bg_mask  = ingenioso_get_theme_option( 'front_page_woocommerce_bg_mask' );
				$ingenioso_bg_color_type = ingenioso_get_theme_option( 'front_page_woocommerce_bg_color_type' );
				if ( 'custom' == $ingenioso_bg_color_type ) {
					$ingenioso_bg_color = ingenioso_get_theme_option( 'front_page_woocommerce_bg_color' );
				} elseif ( 'scheme_bg_color' == $ingenioso_bg_color_type ) {
					$ingenioso_bg_color = ingenioso_get_scheme_color( 'bg_color', $ingenioso_scheme );
				} else {
					$ingenioso_bg_color = '';
				}
				if ( ! empty( $ingenioso_bg_color ) && $ingenioso_bg_mask > 0 ) {
					$ingenioso_css .= 'background-color: ' . esc_attr(
						1 == $ingenioso_bg_mask ? $ingenioso_bg_color : ingenioso_hex2rgba( $ingenioso_bg_color, $ingenioso_bg_mask )
					) . ';';
				}
				if ( ! empty( $ingenioso_css ) ) {
					echo ' style="' . esc_attr( $ingenioso_css ) . '"';
				}
				?>
		>
			<div class="front_page_section_content_wrap front_page_section_woocommerce_content_wrap content_wrap woocommerce">
				<?php
				// Content wrap with title and description
				$ingenioso_caption     = ingenioso_get_theme_option( 'front_page_woocommerce_caption' );
				$ingenioso_description = ingenioso_get_theme_option( 'front_page_woocommerce_description' );
				if ( ! empty( $ingenioso_caption ) || ! empty( $ingenioso_description ) || ( current_user_can( 'edit_theme_options' ) && is_customize_preview() ) ) {
					// Caption
					if ( ! empty( $ingenioso_caption ) || ( current_user_can( 'edit_theme_options' ) && is_customize_preview() ) ) {
						?>
						<h2 class="front_page_section_caption front_page_section_woocommerce_caption front_page_block_<?php echo ! empty( $ingenioso_caption ) ? 'filled' : 'empty'; ?>">
						<?php
							echo wp_kses( $ingenioso_caption, 'ingenioso_kses_content' );
						?>
						</h2>
						<?php
					}

					// Description (text)
					if ( ! empty( $ingenioso_description ) || ( current_user_can( 'edit_theme_options' ) && is_customize_preview() ) ) {
						?>
						<div class="front_page_section_description front_page_section_woocommerce_description front_page_block_<?php echo ! empty( $ingenioso_description ) ? 'filled' : 'empty'; ?>">
						<?php
							echo wp_kses( wpautop( $ingenioso_description ), 'ingenioso_kses_content' );
						?>
						</div>
						<?php
					}
				}

				// Content (widgets)
				?>
				<div class="front_page_section_output front_page_section_woocommerce_output list_products shop_mode_thumbs">
					<?php
					if ( 'products' == $ingenioso_woocommerce_sc ) {
						$ingenioso_woocommerce_sc_ids      = ingenioso_get_theme_option( 'front_page_woocommerce_products_per_page' );
						$ingenioso_woocommerce_sc_per_page = count( explode( ',', $ingenioso_woocommerce_sc_ids ) );
					} else {
						$ingenioso_woocommerce_sc_per_page = max( 1, (int) ingenioso_get_theme_option( 'front_page_woocommerce_products_per_page' ) );
					}
					$ingenioso_woocommerce_sc_columns = max( 1, min( $ingenioso_woocommerce_sc_per_page, (int) ingenioso_get_theme_option( 'front_page_woocommerce_products_columns' ) ) );
					echo do_shortcode(
						"[{$ingenioso_woocommerce_sc}"
										. ( 'products' == $ingenioso_woocommerce_sc
												? ' ids="' . esc_attr( $ingenioso_woocommerce_sc_ids ) . '"'
												: '' )
										. ( 'product_category' == $ingenioso_woocommerce_sc
												? ' category="' . esc_attr( ingenioso_get_theme_option( 'front_page_woocommerce_products_categories' ) ) . '"'
												: '' )
										. ( 'best_selling_products' != $ingenioso_woocommerce_sc
												? ' orderby="' . esc_attr( ingenioso_get_theme_option( 'front_page_woocommerce_products_orderby' ) ) . '"'
													. ' order="' . esc_attr( ingenioso_get_theme_option( 'front_page_woocommerce_products_order' ) ) . '"'
												: '' )
										. ' per_page="' . esc_attr( $ingenioso_woocommerce_sc_per_page ) . '"'
										. ' columns="' . esc_attr( $ingenioso_woocommerce_sc_columns ) . '"'
						. ']'
					);
					?>
				</div>
			</div>
		</div>
	</div>
	<?php
}
