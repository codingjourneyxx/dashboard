<?php
/* Elegro Crypto Payment support functions
------------------------------------------------------------------------------- */

// Theme init priorities:
// 9 - register other filters (for installer, etc.)
if ( ! function_exists( 'ingenioso_elegro_payment_theme_setup9' ) ) {
	add_action( 'after_setup_theme', 'ingenioso_elegro_payment_theme_setup9', 9 );
	function ingenioso_elegro_payment_theme_setup9() {
		if ( ingenioso_exists_elegro_payment() ) {
			add_action( 'wp_enqueue_scripts', 'ingenioso_elegro_payment_frontend_scripts', 1100 );
			add_action( 'trx_addons_action_load_scripts_front_elegro_payment', 'ingenioso_elegro_payment_frontend_scripts', 10, 1 );
			add_filter( 'ingenioso_filter_merge_styles', 'ingenioso_elegro_payment_merge_styles' );
		}
		if ( is_admin() ) {
			add_filter( 'ingenioso_filter_tgmpa_required_plugins', 'ingenioso_elegro_payment_tgmpa_required_plugins' );
		}
	}
}

// Filter to add in the required plugins list
if ( ! function_exists( 'ingenioso_elegro_payment_tgmpa_required_plugins' ) ) {
	//Handler of the add_filter('ingenioso_filter_tgmpa_required_plugins',	'ingenioso_elegro_payment_tgmpa_required_plugins');
	function ingenioso_elegro_payment_tgmpa_required_plugins( $list = array() ) {
		if ( ingenioso_storage_isset( 'required_plugins', 'woocommerce' ) && ingenioso_storage_isset( 'required_plugins', 'elegro-payment' ) && ingenioso_storage_get_array( 'required_plugins', 'elegro-payment', 'install' ) !== false ) {
			$list[] = array(
				'name'     => ingenioso_storage_get_array( 'required_plugins', 'elegro-payment', 'title' ),
				'slug'     => 'elegro-payment',
				'required' => false,
			);
		}
		return $list;
	}
}

// Check if this plugin installed and activated
if ( ! function_exists( 'ingenioso_exists_elegro_payment' ) ) {
	function ingenioso_exists_elegro_payment() {
		return class_exists( 'WC_Elegro_Payment' );
	}
}


// Enqueue styles for frontend
if ( ! function_exists( 'ingenioso_elegro_payment_frontend_scripts' ) ) {
	//Handler of the add_action( 'wp_enqueue_scripts', 'ingenioso_elegro_payment_frontend_scripts', 1100 );
	//Handler of the add_action( 'trx_addons_action_load_scripts_front_elegro_payment', 'ingenioso_elegro_payment_frontend_scripts', 10, 1 );
	function ingenioso_elegro_payment_frontend_scripts( $force = false ) {
		ingenioso_enqueue_optimized( 'elegro_payment', $force, array(
			'css' => array(
				'ingenioso-elegro-payment' => array( 'src' => 'plugins/elegro-payment/elegro-payment.css' ),
			)
		) );
	}
}

// Merge custom styles
if ( ! function_exists( 'ingenioso_elegro_payment_merge_styles' ) ) {
	//Handler of the add_filter('ingenioso_filter_merge_styles', 'ingenioso_elegro_payment_merge_styles');
	function ingenioso_elegro_payment_merge_styles( $list ) {
		$list[ 'plugins/elegro-payment/elegro-payment.css' ] = false;
		return $list;
	}
}
