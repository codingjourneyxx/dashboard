<?php
/**
 * Default template for footer
 *
 * @package minterio
 */

?>

<div class="container">
	<div class="bottom-footer">
		<div class="text-center">
			<p><?php echo esc_html__( '&copy; 2021. All rights reserved', 'minterio' ); ?></p>
		</div>
		<div class="clearfix"></div>
	</div><!--bottom-footer end-->
</div>