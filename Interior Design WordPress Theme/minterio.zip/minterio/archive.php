<?php
/**
 * The template for displaying archive pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package minterio
 */

get_header();
?>
	
	<?php $post_id = get_the_ID(); ?>

	<section class="pager-section pager-section-post no-bg style2">
		<div class="container">
			<div class="pager-info">
				<?php minterio_breadcrumbs( $post_id ); ?>
				<h2><?php echo wp_kses_post( get_the_archive_title() ); ?></h2>
			</div>
			<div class="clearfix"></div>
		</div>
	</section><!--pager-section end-->

	<?php get_template_part( 'template-parts/archive-list' ); ?>
	
<?php
get_footer();