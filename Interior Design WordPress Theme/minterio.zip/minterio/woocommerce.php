<?php
/**
 * The template for displaying woocommerce pages.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package minterio
 */

get_header();
?>

<?php
get_template_part( 'woocommerce/woo-template' );
?>

<?php
get_footer();
