<?php
/**
 * The template for displaying all pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package minterio
 */

get_header();
?>

	<?php
	while ( have_posts() ) : the_post();

	$post_id = get_the_ID();

	?>

	<section class="pager-section pager-section-post no-bg style2">
		<div class="container">
			<div class="pager-info">
				<?php minterio_breadcrumbs( $post_id ); ?>
			</div>
			<div class="clearfix"></div>
		</div>
	</section><!--pager-section end-->

	<section class="page-content pt-0">
		<div class="container">
			<div class="blog-single">
				<div class="row">
					<div class="col-md-12">
						<div class="blog-post single">
							<div class="blog-info">
								<h1 class="blog-title"><?php the_title(); ?></h1>

								<!-- content -->
								<?php get_template_part( 'template-parts/content', 'page' ); ?>
								<!-- /content -->

								<!-- post nav -->
								<?php
								wp_link_pages( array(
									'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'minterio' ),
									'after'  => '</div>',
								) );
								?>
								<!-- /post nav -->
							</div>

							<?php minterio_entry_footer(); ?>

							<?php if ( comments_open() || get_comments_number() ) : ?>
							<!-- Comments -->
							<div class="comments-post">
								<?php
									// If comments are open or we have at least one comment, load up the comment template.
									comments_template();
								?>
							</div>
							<?php endif; ?>

						</div><!--blog-post single end-->
					</div>
				</div>
			</div><!--blog-single end-->
		</div>
	</section><!--page-content end-->

	<?php endwhile; ?>

<?php
get_footer();
