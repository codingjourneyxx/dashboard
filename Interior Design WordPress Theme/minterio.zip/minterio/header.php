<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package minterio
 */

?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<!-- Meta Data -->
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<link rel="profile" href="https://gmpg.org/xfn/11">

	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
	<?php wp_body_open(); ?>

	<?php
		$disable_preloader = get_field( 'disable_preloader', 'option' );
		$header_layout = get_field( 'header_layout', 'option' );

		$header_classes = 'header-bg';

		if ( get_page_template_slug() == 'template-layout-builder.php' && ! is_singular( 'portfolio' ) && ! is_singular( 'post' ) ) {
			$header_classes = 0;
		}
	?>

	<?php if ( ! $disable_preloader ) : ?>
	<div class="page-loading">
		<div class="thecube">
			<div class="cube c1"></div>
			<div class="cube c2"></div>
			<div class="cube c4"></div>
			<div class="cube c3"></div>
		</div>
	</div><!--page-loading end-->
	<?php endif; ?>

	<div class="wrapper <?php if ( $header_classes ) : echo esc_attr( $header_classes ); endif; ?>">

		<header class="header <?php if ( $header_classes ) : echo esc_attr( $header_classes ); endif; ?>">
			<div class="container">
				<?php
			    if ( ! $header_layout ) :
			    	get_template_part( 'template-elements/header', 'default' );
				elseif ( !\Elementor\Plugin::$instance->preview->is_preview_mode() ) :
			        get_template_part( 'template-elements/header', 'builder' );
			    endif; ?>
			</div>
		</header><!--header end-->

		<div class="header-search d-flex flex-wrap justify-content-center align-items-center w-100">
        <span class="search-close-btn"><i class="fas fa-times"></i></span>
        <form method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>">
            <input type="search" name="s" placeholder="<?php echo esc_attr__( 'Search', 'minterio' ); ?>">
        </form>
    </div><!--header-search end-->

		<div class="responsive-mobile-menu"></div><!--responsive-mobile-menu end-->
