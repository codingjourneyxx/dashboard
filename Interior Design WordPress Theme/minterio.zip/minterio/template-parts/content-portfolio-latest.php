<?php
/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package minterio
 */

?>

<?php

/* post content */

$image = get_the_post_thumbnail_url( get_the_ID(), 'minterio_900xAuto' );
$title = get_the_title();
$subtitle = get_field( 'subname' );
$href = get_the_permalink();

?>

<div class="project-item">
	<?php if ( $image ) : ?>
	<a href="<?php echo esc_url( $href ); ?>"><img src="<?php echo esc_url( $image ); ?>" alt="<?php echo esc_attr( $title ); ?>" /></a>
	<?php endif; ?>
	<?php if ( $title || $subtitle ) : ?>
	<div class="project-info">
		<?php if ( $title ) : ?>
		<h3><a href="<?php echo esc_url( $href ); ?>"><?php echo esc_html( $title ); ?></a></h3>
		<?php endif; ?>
		<?php if ( $subtitle ) : ?>
		<span><?php echo esc_html( $subtitle ); ?></span>
		<?php endif; ?>
	</div><!--project-info end-->
	<?php endif; ?>
</div><!--project-item end-->