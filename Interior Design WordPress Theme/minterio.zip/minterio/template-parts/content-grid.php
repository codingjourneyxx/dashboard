<?php
/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package minterio
 */

?>

<?php

//options
$blog_categories = get_field( 'blog_categories', 'option' );
$blog_excerpt = get_field( 'blog_excerpt', 'option' );

//content
$image = get_the_post_thumbnail_url( get_the_ID(), 'minterio_900xAuto' );
$categories_list = false;

if ( $blog_categories ) :
	$categories_list = get_the_category( get_the_ID() );
endif;

$col_class = 'col-lg-4 col-md-6 col-sm-6 col-12';

$columns = get_query_var( 'columns' );

if ( $columns == 'columns-1' ) :
	$col_class = 'col-lg-12 col-md-12 col-sm-12 col-12';
	$image = get_the_post_thumbnail_url( get_the_ID(), 'minterio_1920xAuto' );
elseif ( $columns == 'columns-2' ) :
	$col_class = 'col-lg-6 col-md-6 col-sm-6 col-12';
endif;

?>

<div class="<?php echo esc_attr( $col_class ); ?>">
	<div id="post-<?php the_ID(); ?>" <?php post_class( 'blog-post' ); ?>>
		<div class="blog-thumbnail">
			<?php if ( $image ) : ?>
			<img src="<?php echo esc_url( $image ); ?>" alt="<?php echo esc_attr( get_the_title() ); ?>" />
			<?php endif; ?>
			<?php if ( $categories_list ) :
				echo '<span class="category">';
				$total = count( $categories_list );
				$i = 0; foreach ( $categories_list as $category ) { $i++;
					if ( $total != $i ) {
						echo esc_html( $category->cat_name ) . ', ';
					} else {
						echo esc_html( $category->cat_name );
					}
				}
				echo '</span>';
			endif; ?>
		</div>
		<div class="blog-info">
			<?php if ( ! empty( get_the_title() ) ) :
				echo '<span>' . esc_html( get_the_date() ) . '</span>';
			else :
				echo '<span><a class="date" href="' . esc_url( get_the_permalink() ) . '">' . esc_html( get_the_date() ) . '</a></span>';
			endif; ?>
			<h2 class="blog-title">
				<a href="<?php echo esc_url( get_permalink() ); ?>"><?php the_title(); ?></a>
			</h2>
			<?php if ( ! $blog_excerpt ) : ?>
			<?php the_excerpt(); ?>
			<?php endif; ?>
		</div>
	</div><!-- #post-<?php the_ID(); ?> -->
</div>