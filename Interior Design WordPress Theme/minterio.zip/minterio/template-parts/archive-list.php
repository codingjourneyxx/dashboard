<?php
/**
 * Template part for displaying archive list
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package minterio
 */

?>

<?php

$layout = get_field( 'blog_layout', 'option' );

?>

<section class="page-content pt-0">
    <div class="container">
        <div class="row">
            <?php if ( is_active_sidebar( 'sidebar-1' ) ) : ?>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3 col-sidebar">
                <?php get_sidebar(); ?>
            </div>
            <?php endif; ?>

            <?php if ( is_active_sidebar( 'sidebar-1' ) ) : ?>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-9 col-content">
            <?php else : ?>
            <div class="col-md-12">
            <?php endif; ?>

                <?php if ( have_posts() ) : ?>
                <div class="blog-posts blog-page">
                    <div class="row">
                        <?php
                            while ( have_posts() ) : the_post();
                                get_template_part( 'template-parts/content' );
                            endwhile;
                        ?>
                    </div>
                </div>
                <div class="pagination-minterio">
                    <?php
                        echo paginate_links( array(
                            'prev_text'     => esc_html__( 'Prev', 'minterio' ),
                            'next_text'     => esc_html__( 'Next', 'minterio' ),
                        ) );
                    ?>
                </div>
                <?php else :
                    get_template_part( 'template-parts/content', 'none' );
                endif; ?>

            </div>
        </div>
    </div>
</section>
