<?php
/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package minterio
 */

?>

<?php

/* post content */
$current_categories = get_the_terms( get_the_ID(), 'portfolio_categories' );
$categories_string = '';
$categories_slugs_string = '';
if ( $current_categories && ! is_wp_error( $current_categories ) ) {
	$arr_keys = array_keys( $current_categories );
	$last_key = end( $arr_keys );
	foreach ( $current_categories as $key => $value ) {
		if ( $key == $last_key ) {
			$categories_string .= $value->name . ' ';
		} else {
			$categories_string .= $value->name . ', ';
		}
		$categories_slugs_string .= 'sorting-' . $value->slug . ' ';
	}
}

$image = get_the_post_thumbnail_url( get_the_ID(), 'minterio_900xAuto' );
$title = get_the_title();
$subtitle = get_field( 'subname' );
$href = get_the_permalink();
$layout = get_query_var( 'layout' );

if ( $layout == 'columns-4' ) {
	$cols = 'col-lg-3 col-md-3 col-sm-6';
} elseif ( $layout == 'columns-2' ) {
	$cols = 'col-lg-6 col-md-6 col-sm-6';
} else {
	$cols = 'col-lg-4 col-md-4 col-sm-6';
}

?>
<div class="<?php echo esc_attr( $cols ); ?> <?php echo esc_attr( $categories_slugs_string ); ?>">
	<div class="project-item">
		<?php if ( $image ) : ?>
		<a href="<?php echo esc_url( $href ); ?>"><img src="<?php echo esc_url( $image ); ?>" alt="<?php echo esc_attr( $title ); ?>" /></a>
		<?php endif; ?>
		<?php if ( $title || $subtitle ) : ?>
		<div class="project-info">
			<?php if ( $title ) : ?>
			<h3><a href="<?php echo esc_url( $href ); ?>"><?php echo esc_html( $title ); ?></a></h3>
			<?php endif; ?>
			<?php if ( $subtitle ) : ?>
			<span><?php echo esc_html( $subtitle ); ?></span>
			<?php endif; ?>
		</div><!--project-info end-->
		<?php endif; ?>
	</div><!--project-item end-->
</div>