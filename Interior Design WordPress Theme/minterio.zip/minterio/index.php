<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package minterio
 */

get_header();
?>

	<?php

	/*get options*/
	$blog_title = get_field( 'blog_title', 'option' );
	
	if( empty( $blog_title ) ) {
		$blog_title = esc_html__( 'Latest Posts', 'minterio' );
	}

	?>

	<section class="pager-section pager-section-post no-bg style2">
		<div class="container">
			<div class="pager-info">
				<h2><?php echo wp_kses_post( $blog_title ); ?></h2>
			</div>
			<div class="clearfix"></div>
		</div>
	</section><!--pager-section end-->

	<?php get_template_part( 'template-parts/archive-list' ); ?>

<?php
get_footer();