<?php
/**
 * The search form markup
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package minterio
 */

?>

<form role="search" method="get" class="search-form" action="<?php echo esc_url( home_url( '/' ) ); ?>">
	<label>
		<span class="screen-reader-text"><?php echo esc_html__( 'Search for:', 'minterio' ) ?></span>
		<input type="search" class="search-field" placeholder="<?php echo esc_attr__( 'Search …', 'minterio' ); ?>" value="<?php echo esc_attr( get_search_query() ); ?>" name="s" title="<?php echo esc_attr__( 'Search for:', 'minterio' ); ?>" />
	</label>
	<button type="submit" class="search-submit"><?php echo esc_html__( 'Search', 'minterio' ); ?></button>
</form>
