<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package minterio
 */

?>

<?php

$hide_footer = get_field( 'hide_footer' );
$footer_layout = get_field( 'footer_layout', 'option' );

?>
		<?php if ( ! $hide_footer ) : ?>
		<footer>
			
			<?php 
			if ( ! $footer_layout ) :
				get_template_part( 'template-elements/footer', 'default' );
			elseif ( !\Elementor\Plugin::$instance->preview->is_preview_mode() ) :
				get_template_part( 'template-elements/footer', 'builder' );
			endif; ?>

		</footer><!--footer end-->
		<?php endif; ?>
	</div><!--wrapper end-->
	
	<?php wp_footer(); ?>

</body>
</html>