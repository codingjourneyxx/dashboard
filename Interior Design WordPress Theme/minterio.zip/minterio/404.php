<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @link https://codex.wordpress.org/Creating_an_Error_404_Page
 *
 * @package minterio
 */

get_header();
?>

<?php

$image = get_field( 'p404_image', 'option' );
$bg_image = get_field( 'p404_bg_image', 'option' );
$title = get_field( 'p404_title', 'option' );
$content = get_field( 'p404_content', 'option' );

if ( ! $title ) {
	$title =  esc_html__( 'Something has happened...', 'minterio' );
}
if ( ! $content ) {
	$content = '<p>' . esc_html__( 'This page is missing or you assembled the link incorrectly. Try again or come back', 'minterio' ) . '</p>';
}

?>

<section class="error-page"<?php if ( $bg_image ) : ?> style="background-image: url(<?php echo esc_url( $bg_image['sizes']['minterio_1920xAuto'] ); ?>);"<?php endif; ?>>
	<div class="container">
		<div class="error-content">
			<div class="col-xl-6">
				<div class="error-text">
					<?php if ( $image ) : ?>
					<img src="<?php echo esc_url( $image['sizes']['minterio_1920xAuto'] ); ?>" alt="<?php echo esc_attr__( '404', 'minterio' ); ?>" />
					<?php else : ?>
					<div class="error-text__num"><?php echo esc_html__( '404', 'minterio' ); ?></div>
					<?php endif; ?>
					<?php if ( $title ) : ?>
					<h2><?php echo wp_kses_post( $title ); ?></h2>
					<?php endif; ?>
					<?php if ( $content ) : ?>
					<?php echo wp_kses_post( $content ); ?>
					<?php endif; ?>
					<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="lnk-default">
						<i class="la la-arrow-left"></i>
						<?php echo esc_html__( 'Go Home', 'minterio' ); ?>
						<span></span>
					</a>
				</div><!--error-text end-->
			</div>
		</div><!--error-content end-->
	</div>
</section><!--error-page end-->

<?php
get_footer();
