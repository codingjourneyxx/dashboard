<?php
/**
 * Custom template tags for this theme
 *
 * Eventually, some of the functionality here could be replaced by core features.
 *
 * @package minterio
 */

if ( ! function_exists( 'minterio_get_categories' ) ) {
	/**
	 * Displays Categories
	 */
	function minterio_get_categories( $taxonomy, $order_by = 'DESC' ) {
		$args = array(
			'type'			=> 'post',
			'child_of'		=> 0,
			'parent'		=> '',
			'orderby'		=> 'name',
			'order'			=> $order_by,
			'hide_empty'	=> 1,
			'hierarchical'	=> 1,
			'taxonomy'		=> $taxonomy,
			'pad_counts'	=> false 
		);

		return get_categories( $args );
	}
}

if ( ! function_exists( 'minterio_post_details' ) ) :
	/**
	 * Displays post details: date, author, categories.
	 */
	function minterio_post_details() {
		if ( is_singular() ) :
			$categories_list = get_the_category_list( esc_html__( ', ', 'minterio' ) );
			
			if ( $categories_list ) :
				printf( esc_html__( '%1$s / ', 'minterio' ), $categories_list );
			endif;

			echo esc_html( get_the_date() ) . esc_html__( ' / by ', 'minterio' ) . '<a href="' . esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ) . '">' . esc_html( get_the_author() ) . '</a>';

			
		endif; // End is_singular().
	}
endif;

if ( ! function_exists( 'minterio_post_author' ) ) :
	/**
	 * Displays post details: date, author, categories.
	 */
	function minterio_post_author() {
		if ( is_singular() ) :
			echo esc_html__( 'by ', 'minterio' ) . '<a href="' . esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ) . '">' . esc_html( get_the_author() ) . '</a>';
		endif; // End is_singular().
	}
endif;

if ( ! function_exists( 'minterio_post_navigation' ) ) :
	/**
	 * Displays an optional next link.
	 */
	function minterio_post_navigation() {
		if ( is_singular() ) :
			
			$next_post = get_adjacent_post( false, '', true );
			$prev_post = get_adjacent_post( false, '', false );
			
			?>
			
			<div class="pagination-minterio">
				<nav aria-label="Page navigation example">
					<ul class="pagination">
						<?php if ( is_a( $prev_post, 'WP_Post' ) ) : ?>
				    	<li class="page-item">
				    		<a class="page-link prev" href="<?php echo esc_url( get_permalink( $prev_post->ID ) ); ?>">
				    			<i class="fa fa-angle-left"></i>
				    			<?php echo esc_html__( 'Previous', 'minterio' ); ?>
				    		</a>
				    	</li>
				    	<?php endif; ?>
				    	<?php if ( is_a( $next_post, 'WP_Post' ) ) : ?>
				    	<li class="page-item">
				    		<a class="page-link next" href="<?php echo esc_url( get_permalink( $next_post->ID ) ); ?>">
				    			<?php echo esc_html__( 'Next', 'minterio' ); ?>
				    			<i class="fa fa-angle-right"></i>
				    		</a>
				    	</li>
				    	<?php endif; ?>
				  	</ul>
				</nav>
			</div><!--pagination-minterio end-->
			
		<?php
		endif; // End is_singular().
	}
endif;

if ( ! function_exists( 'minterio_post_social' ) ) :
	/**
	 * Prints HTML with meta information for the categories, tags and comments.
	 */
	function minterio_post_social() {
		$social_share = get_field( 'social_share', 'options' );

		// Hide category and tag text for pages.
		if ( $social_share ) { ?>

			<ul class="social-share social-links without-bg">
				<?php foreach ( $social_share as $social ) : ?>
				<li>
					<a class="share-btn share-btn-<?php echo esc_attr( $social['value'] ); ?>">
						<?php if ( $social['value'] == 'facebook' ) : ?>
						<i class="fab fa-facebook-f"></i>
						<?php endif; ?>
						<?php if ( $social['value'] == 'twitter' ) : ?>
						<i class="fab fa-twitter"></i>
						<?php endif; ?>
						<?php if ( $social['value'] == 'tumblr' ) : ?>
						<i class="fab fa-tumblr"></i>
						<?php endif; ?>
						<?php if ( $social['value'] == 'linkedin' ) : ?>
						<i class="fab fa-linkedin"></i>
						<?php endif; ?>
						<?php if ( $social['value'] == 'reddit' ) : ?>
						<i class="fab fa-reddit-alien" aria-hidden="true"></i>
						<?php endif; ?>
						<?php if ( $social['value'] == 'pinterest' ) : ?>
						<i class="fab fa-pinterest-p"></i>
						<?php endif; ?>
						<?php if ( $social['value'] == 'whatsapp' ) : ?>
						<i class="fab fa-whatsapp"></i>
						<?php endif; ?>
					</a>
				</li>
				<?php endforeach; ?>
			</ul>

		<?php }
	}
endif;

if ( ! function_exists( 'minterio_entry_footer' ) ) :
	/**
	 * Prints HTML with meta information for the categories, tags and comments.
	 */
	function minterio_entry_footer() {
		// Hide category and tag text for pages.
		if ( 'post' === get_post_type() ) {
			/* translators: used between list items, there is a space after the comma */
			$tags_list = get_the_tag_list( '', esc_html_x( '', 'list item separator', 'minterio' ) );
			if ( $tags_list ) {
				/* translators: 1: list of tags. */
				echo '<div class="tags_list">' . '<span>' . esc_html__( 'Tags:', 'minterio' ) . '</span>' . $tags_list . '</div>';
			}
		}

		edit_post_link(
			sprintf(
				wp_kses(
					/* translators: %s: Name of current post. Only visible to screen readers */
					__( 'Edit <span class="screen-reader-text">%s</span>', 'minterio' ),
					array(
						'span' => array(
							'class' => array(),
						),
					)
				),
				get_the_title()
			),
			'<span class="edit-link">',
			'</span>'
		);
	}
endif;

if ( ! function_exists( 'minterio_comment' ) ) {
	/**
	 * Displays post comments.
	 */
	function minterio_comment( $comment, $args, $depth ) {
		?>
			<!-- Item Comment -->
			<li <?php comment_class( 'comment-item' ); ?> id="li-comment-<?php comment_ID(); ?>">
				<div id="comment-<?php comment_ID(); ?>" class="comment comment-box">
					<?php
						$avatar_size = 64;
						if ( '0' != $comment->comment_parent ){
							$avatar_size = 64;
						}
						echo get_avatar( $comment, $avatar_size );
					?>
					<div class="comment-box__body">
						<div class="content-caption post-content description">
							<h5 class="comment-box__details"><?php comment_author_link(); ?> <span><?php comment_date(); ?></span></h5>
							<?php comment_text(); ?>
						</div>
					</div>
					<div class="comment-footer">
						<?php comment_reply_link( array_merge( $args, array( 'depth' => $depth, 'max_depth' => $args['max_depth'] ) ) ); ?>
					</div>
				</div>
		<?php
	}
}