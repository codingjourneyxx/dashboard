<?php
/**
 * One Click Demo Import Configurations
 *
 * @package minterio
 */

if ( class_exists( 'MinterioPlugin' ) && class_exists( 'ACF' ) && class_exists( 'OCDI_Plugin' ) ) {

function minterio_ocdi_import_files() {
    return array(
        array(
            'import_file_name'             => esc_attr__( 'Default', 'minterio' ),
            'categories'                   => array( esc_attr__( 'Main', 'minterio' ) ),
            'import_file_url'            => MINTERIO_EXTRA_PLUGINS_DIRECTORY . 'normal/ocdi-import/demo/01/content.xml',
            'preview_url'                  => 'https://1.envato.market/c/1790164/275988/4415?u=https://themeforest.net/item/minterio-interior-design-wordpress-theme/full_screen_preview/34326502',
            'import_preview_image_url'     => MINTERIO_EXTRA_PLUGINS_DIRECTORY . 'normal/ocdi-import/demo/01/preview.jpg',
        ),
    );
}
add_filter( 'pt-ocdi/import_files', 'minterio_ocdi_import_files' );

function minterio_ocdi_after_import_setup( $selected_import ) {

    $front_page_id = get_page_by_title( 'Home' );
    $main_menu = get_term_by( 'name', 'Main Menu', 'nav_menu' );

    set_theme_mod( 'nav_menu_locations', array(
        'primary' => $main_menu->term_id,
    ) );

    update_option( 'show_on_front', 'page' );
    update_option( 'page_on_front', $front_page_id->ID );
    update_option( 'posts_per_page', 6 );

    $ocdi_fields_static = array(
        'options_header_layout' => 1,
        '_options_header_layout' => 'field_6047f336daec0',
        'options_footer_layout' => 1,
        '_options_footer_layout' => 'field_6047f44e06120',
        'options_blog_title' => '',
        '_options_blog_title' => 'field_5e5e39b87f0e0',
        'options_post_page' => 397,
        '_options_post_page' => 'field_5d29eb446dca9',
        'options_blog_categories' => 1,
        '_options_blog_categories' => 'field_5b81b6d930cb9',
        'options_blog_excerpt' => 0,
        '_options_blog_excerpt' => 'field_5b81b7ca30cba',
        'options_social_share' => 'a:5:{i:0;s:8:"facebook";i:1;s:7:"twitter";i:2;s:8:"linkedin";i:3;s:6:"reddit";i:4;s:9:"pinterest";}',
        '_options_social_share' => 'field_5c610c399cf20',
        'options_portfolio_page' => '',
        '_options_portfolio_page' => 'field_5d29e1a48ac41',
        'options_p404_content' => 'The page you\'re looking for doesn\'t exist or has been moved.',
        '_options_p404_content' => 'field_5d180feb59b80',
        'options_bg_image' => 667,
        '_options_bg_image' => 'field_5d2a5bab8dc53',
        'options_disable_preloader' => 0,
        '_options_disable_preloader' => 'field_5e7d27a0e322a',
        'options_shop_sidebar' => 'left',
        '_options_shop_sidebar' => 'field_611458e3400f9',
        'options_shop_bg' => 424,
        '_options_shop_bg' => 'field_61145ad02915c',
        'options_shop_desc_main' => 'In our store you can buy the missing item in the room',
        '_options_shop_desc_main' => 'field_61145cf2d7a24',
        'options_shop_desc_cat' => 'Select the appropriate option',
        '_options_shop_desc_cat' => 'field_61145d11d7a25',
        'options_header_template' => 427,
        '_options_header_template' => 'field_6047f4160611f',
        'options_footer_template' => 471,
        '_options_footer_template' => 'field_6047f46706121',
        'options_p404_title' => 'Something has happened...',
        '_options_p404_title' => 'field_6143a27dadffb',
        'options_p404_image' => 667,
        '_options_p404_image' => 'field_6143aa772487a',
        'options_p404_bg_image' => 671,
        '_options_p404_bg_image' => 'field_5d2a5bab8dc53',
    );
    $ocdi_fields_to_change = array();

    if( 'Default' === $selected_import['import_file_name'] ) {
        $ocdi_fields_to_change = array(
            'options_base_bg_color' => '',
            '_options_base_bg_color' => 'field_5b68d509665d9',
            'options_text_color' => '',
            '_options_text_color' => 'field_60672b1d6115f',
            'options_theme_color' => '',
            '_options_theme_color' => 'field_60672bee61163',
            'options_base_font_size' => '',
            '_options_base_font_size' => 'field_60672c8261165',
            'options_heading_font_size' => '',
            '_options_heading_font_size' => 'field_60672cef61168',
            'options_text_font_family' => 0,
            '_options_text_font_family' => 'field_5b68d188906fd',
            'options_primary_font_family' => 0,
            '_options_primary_font_family' => 'field_5b68cfc4906fc',
            'options_menu_font_size' => '',
            '_options_menu_font_size' => 'field_60672e186116c',
            'options_menu_color' => '',
            '_options_menu_color' => 'field_6143ab7dbeaca',
            'options_preloader_color' => '',
            '_options_preloader_color' => 'field_608c707f85717',
        );
    }

    global $wpdb;
    foreach ( array_merge( $ocdi_fields_static, $ocdi_fields_to_change ) as $field => $value ) {
        if ( $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $wpdb->options WHERE option_name = %s", $field ) ) == 0 ) {
            $wpdb->query( $wpdb->prepare( "INSERT INTO $wpdb->options ( option_name, option_value, autoload ) VALUES (%s, %s, 'no')", $field, $value ) );
        } else {
            $wpdb->query( $wpdb->prepare( "UPDATE $wpdb->options SET option_value = %s WHERE option_name = %s", $value, $field ) );
        }
    }

}
add_action( 'pt-ocdi/after_import', 'minterio_ocdi_after_import_setup' );

}
