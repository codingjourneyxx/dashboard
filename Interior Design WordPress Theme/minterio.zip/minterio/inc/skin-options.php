<?php
/**
 * Skin
**/

if ( ! function_exists( 'minterio_skin' ) ) {
function minterio_skin() {
	$bg_color = get_field( 'base_bg_color', 'options' );
	$theme_color = get_field( 'theme_color', 'options' );
	$btn_color = get_field( 'btn_color', 'options' );
	$ad_btn_color = get_field( 'ad_btn_color', 'options' );
	$heading_color = get_field( 'heading_color', 'options' );
	$text_color = get_field( 'text_color', 'options' );
  $menu_color = get_field( 'menu_color', 'options' );
  $preloader_color = get_field( 'preloader_color', 'options' );
  $disable_preloader = get_field( 'disable_preloader', 'options' );

	$heading_font_family = get_field( 'heading_font_family', 'options' );
	$text_font_family = get_field( 'text_font_family', 'options' );

	$heading_font_size = get_field( 'heading_font_size', 'options' );
	$text_font_size = get_field( 'base_font_size', 'options' );
	$menu_font_size = get_field( 'menu_font_size', 'options' );
?>

<style>

  <?php if ( $theme_color ) : ?>
  /* Theme Color */
  .responsive-mobile-menu,
  .lnk-default,
  .banner-slide:before,
  .play-btn,
  .sub-title:before,
  .team-head,
  .slick-prev:hover,
  .slick-next:hover,
  .slick-dots li.slick-active button,
  .blog-post .category,
  .cart-count,
  .banner-slider .slick-prev:hover,
  .banner-slider .slick-next:hover,
  nav ul ul,
  .pger-imgs:before,
  .dott,
  .paginated li a:hover,
  .widget_search form .search-submit,
  .tags-list li a:hover,
  .ui-slider-horizontal .ui-slider-range,
  .add-to-cart:hover,
  .status,
  input:checked + .slider,
  .btn-default,
  .cart-btn-circle:hover,
  .contact_info,
  .search-close-btn:hover,
  .thecube .cube:before,
  .failed,
  .text-info,
  .widget .wc-block-product-search form button,
  .yith-wcwl-items-count,
  .woocommerce #respond input#submit,
  .woocommerce a.button,
  .woocommerce button.button,
  .woocommerce input.button,
  .woocommerce-js #respond input#submit,
  .woocommerce-js a.button,
  .woocommerce-js button.button,
  .woocommerce-js input.button,
  .woocommerce-mini-cart__buttons #respond input#submit,
  .woocommerce-mini-cart__buttons a.button,
  .woocommerce-mini-cart__buttons button.button,
  .woocommerce-mini-cart__buttons input.button,
  #add_payment_method .wc-proceed-to-checkout a.checkout-button,
  .woocommerce-cart .wc-proceed-to-checkout a.checkout-button,
  .woocommerce-checkout .wc-proceed-to-checkout a.checkout-button,
  .woocommerce #respond input#submit.alt,
  .woocommerce a.button.alt,
  .woocommerce button.button.alt,
  .woocommerce input.button.alt,
  .breadcrumb li:before,
  .widget_search form .search-submit, .widget .wc-block-product-search form button, .wp-block-search .wp-block-search__button,
  .wp-block-search .wp-block-search__button,
  .status, .woocommerce span.onsale,
  .form-submit button,
  .woocommerce .widget_price_filter .ui-slider .ui-slider-range,
  .woocommerce .catalog-product-page div.product .woocommerce-tabs ul.tabs li.active a:after,
  .comment-form button, .comment-form .form-submit input[type="submit"], .woocommerce #respond input#submit,
  .comment-form .form-submit input[type="submit"]:hover, .woocommerce #respond input#submit:hover,
  .wp-block-button__link,
  .woocommerce .products .product .button.add_to_cart_button.added,
  .woocommerce-js .products .product .button.add_to_cart_button.added,
  .woocommerce .products .product .button.add_to_cart_button.added,
  .woocommerce-js .products .product .button.add_to_cart_button.added,
  button.single_add_to_cart_button,
  .pg-title-head:before,
  .woocommerce #respond input#submit:hover, 
  .woocommerce a.button:hover, 
  .woocommerce button.button:hover, 
  .woocommerce input.button:hover, 
  .woocommerce-js #respond input#submit:hover, 
  .woocommerce-js a.button:hover, 
  .woocommerce-js button.button:hover, 
  .woocommerce-js input.button:hover, 
  .woocommerce-mini-cart__buttons #respond input#submit:hover, 
  .woocommerce-mini-cart__buttons a.button:hover, 
  .woocommerce-mini-cart__buttons button.button:hover, 
  .woocommerce-mini-cart__buttons input.button:hover, 
  .catalog-product-page .btn-default:hover, 
  #add_payment_method .wc-proceed-to-checkout a.checkout-button:hover, 
  .woocommerce-cart .wc-proceed-to-checkout a.checkout-button:hover, 
  .woocommerce-checkout .wc-proceed-to-checkout a.checkout-button:hover, 
  .woocommerce-checkout .wc-proceed-to-checkout a.checkout-button:hover, 
  .woocommerce #respond input#submit.alt:hover, 
  .woocommerce a.button.alt:hover, 
  .woocommerce button.button.alt:hover, 
  .woocommerce input.button.al:hover,
  .sub-title.white:before {
    background-color: <?php echo esc_attr( $theme_color ); ?>;
  }
	.contact-head-info > a:before,
	.lnk-default2:before,
	.team:before,
	.prc-sorw ul:before,
	.pagination-minterio .page-numbers.next:before,
	.pagination-minterio .page-numbers.prev:before,
	.pagination-minterio .page-link.next:before,
	.pagination-minterio .page-link.prev:before,
	.woocommerce nav.woocommerce-pagination ul li .next:before,
	.woocommerce nav.woocommerce-pagination ul li .prev:before {
		background-color: <?php echo esc_attr( $theme_color ); ?>;
		opacity: 0.5;
	}
	.pro-head strong {
		color: <?php echo esc_attr( $theme_color ); ?>;
	}
	.team:hover:before,
	.pro-head strong {
		opacity: 0.5;
	}
  header nav ul li a:hover,
  .contact-head-info > a,
  .banner-content > h2 span b,
  .lnk-default2,
  .lnk-default2:hover,
  .p-num,
  .rating li,
  .blog-title a:hover,
  .contact-head-info > a:hover,
  header nav ul li a.active,
  .award-col > h2,
  .wid-post-info > h3:hover,
  .wid-post-info > h3:hover a,
  .arch-list li a:hover,
  .tags_list li a:hover,
  .pagination-minterio .page-link:hover,
  input#amount,
  .view-details:hover,
  .shop-info > h3:hover a,
  .add-cart,
  .cart-btn-circle,
  .catg-controls li a:hover,
  .social-links.without-bg li a,
  .option-set li a.selected,
  .arch-list li a:hover, .sidebar .widget ul li a:hover,
  .product_price,
  .product_meta a,
  .product_meta a:hover,
  .woocommerce .widget_price_filter .price_slider_amount .price_label,
  .woocommerce .catalog-product-page div.product .woocommerce-tabs ul.tabs li.active a,
  .wp-calendar-nav-prev a, .wp-calendar-nav-next a,
  .wp-block-calendar tfoot a,
  .tags-links a,
  .sidebar .tagcloud a,
  .wp-block-tag-cloud a,
  .tags_list a,
  .pagination-minterio a.page-numbers:hover,
  .pagination-minterio a.page-link:hover,
  .page-links a:hover,
  .page-links span:hover,
  .woocommerce nav.woocommerce-pagination ul li a:hover,
  .pagination-minterio .page-numbers.next,
  .pagination-minterio .page-numbers.prev,
  .pagination-minterio .page-link.next,
  .pagination-minterio .page-link.prev,
  .woocommerce nav.woocommerce-pagination ul li .next,
  .woocommerce nav.woocommerce-pagination ul li .prev,
  .comment-reply-link,
  .post-password-form input[type="submit"],
  .catalog-product-info .yith-wcwl-wishlistaddedbrowse:before, .catalog-product-info .yith-wcwl-wishlistexistsbrowse:before,
  .shop-thumbnail .yith-wcwl-add-to-wishlist a,
  .woocommerce-info::before,
  .blog-post.single .blog-info span a,
  .woocommerce .woocommerce-error .button,
  .woocommerce .woocommerce-info .button,
  .woocommerce .woocommerce-message .button,
  .woocommerce-page .woocommerce-error .button,
  .woocommerce-page .woocommerce-info .button,
  .woocommerce-page .woocommerce-message .button,
  .woocommerce .woocommerce-error .button:hover,
  .woocommerce .woocommerce-info .button:hover,
  .woocommerce .woocommerce-message .button:hover,
  .woocommerce-page .woocommerce-error .button:hover,
  .woocommerce-page .woocommerce-info .button:hover,
  .woocommerce-page .woocommerce-message .button:hover,
  .woocommerce-grouped-product-list-item__price ins, .woocommerce-grouped-product-list-item__price bdi {
    color: <?php echo esc_attr( $theme_color ); ?>;
  }
  .social-links.without-bg li a svg,
  .social-links.without-bg li a svg path {
    fill: <?php echo esc_attr( $theme_color ); ?>;
  }
  .proz-minterio:after,
  .dott:before,
  .ui-slider-horizontal .ui-slider-handle,
  .form-control:focus,
  .woocommerce #respond input#submit,
  .woocommerce a.button,
  .woocommerce button.button,
  .woocommerce input.button,
  .woocommerce-js #respond input#submit,
  .woocommerce-js a.button,
  .woocommerce-js button.button,
  .woocommerce-js input.button,
  .woocommerce-mini-cart__buttons #respond input#submit,
  .woocommerce-mini-cart__buttons a.button,
  .woocommerce-mini-cart__buttons button.button,
  .woocommerce-mini-cart__buttons input.button,
  #add_payment_method .wc-proceed-to-checkout a.checkout-button,
  .woocommerce-cart .wc-proceed-to-checkout a.checkout-button,
  .woocommerce-checkout .wc-proceed-to-checkout a.checkout-button,
  .woocommerce #respond input#submit.alt,
  .woocommerce a.button.alt,
  .woocommerce button.button.alt,
  .woocommerce input.button.alt,
  .woocommerce .widget_price_filter .ui-slider .ui-slider-handle,
  .tags-links a,
  .sidebar .tagcloud a,
  .wp-block-tag-cloud a,
  .tags_list a,
  .blog-post.sticky,
  .wp-block-button__link,
  .is-style-outline .wp-block-button__link,
  .post-password-form input[type="submit"],
  .woocommerce .woocommerce-error .button:hover,
  .woocommerce .woocommerce-info .button:hover,
  .woocommerce .woocommerce-message .button:hover,
  .woocommerce-page .woocommerce-error .button:hover,
  .woocommerce-page .woocommerce-info .button:hover,
  .woocommerce-page .woocommerce-message .button:hover,
	.option-set li a.selected {
    border-color: <?php echo esc_attr( $theme_color ); ?>;
  }
  <?php endif; ?>

	<?php if ( $bg_color ) : ?>
	/* BG Color */
	body {
		background-color: <?php echo esc_attr( $bg_color ); ?>;
	}
	<?php endif; ?>

	<?php if ( $heading_color ) : ?>
	/* Heading Color */
	h1, h2, h3, h4, h5, h6, .sub-title, .section__comments .m-title, .related h2, .upsells h2, .woocommerce div.product .woocommerce-tabs .panel h2 {
		color: <?php echo esc_attr( $heading_color ); ?>;
	}
	<?php endif; ?>

	<?php if ( $text_color ) : ?>
	/* Text Color */
	body,
  .banner-content > p,
  .bzn-csd > span,
  .about-text > .description,
  .proz-minterio > p,
  .project-text > .description,
  .testi-slide > .description,
  .blog-info > p,
  .pager-info > span,
  .pg-title-head > span,
  .our-history .description,
  .section-title.style2 .description, .section-title.style2 > p,
  .post-info .description,
  .svs-info p,
  .svss-info p,
  .prc-sorw ul li,
  .catalog-product-info p,
  .woocommerce div.product .woocommerce-tabs .panel p,
  .product_meta > span,
  .contact-head p,
  .section-title > .description,
  .portfolio-details-info p,
  .calendar_wrap table caption,
  .wp-block-calendar table caption,
  .post-content p,
  .post-content,
  .comment-box__body {
		color: <?php echo esc_attr( $text_color ); ?>;
	}
	<?php endif; ?>

  <?php if ( $menu_color ) : ?>
	/* Menu Color */
	.header-menu ul li a {
		color: <?php echo esc_attr( $menu_color ); ?>;
	}
	<?php endif; ?>

	<?php if ( $text_font_size ) : ?>
	/* Text Font Size */
	body,
  .abt-txt > span,
  .proz-minterio > p,
  .project-info > span,
  .testi-slide > .description,
  .blog-info > span,
  .blog-info > p,
  .post-info > span,
  .post-info .description,
  .svs-info p,
  .svss-info p,
  .post-content,
  .comment .comment-box__details {
		font-size: <?php echo esc_attr( $text_font_size ); ?>px;
	}
	<?php endif; ?>

  <?php if ( $menu_font_size ) : ?>
	/* Menu Font Size */
	.header-menu ul li a {
		font-size: <?php echo esc_attr( $menu_font_size ); ?>px;
	}
	<?php endif; ?>

	<?php if ( $heading_font_size ) : ?>
	/* heading_font_size */
	.blog-title {
		font-size: <?php echo esc_attr( $heading_font_size ); ?>px;
	}
	<?php endif; ?>

  <?php if ( $text_font_family ) : ?>
	/* Base Font Family */
	body {
		font-family: '<?php echo esc_attr( $text_font_family['font_name'] ); ?>';
	}
	<?php endif; ?>

	<?php if ( $heading_font_family ) : ?>
	/* Primary Font Family */
	h1, h2, h3, h4, h5, h6, .sub-title, .section__comments .m-title, .related h2, .upsells h2, .woocommerce div.product .woocommerce-tabs .panel h2 {
		font-family: '<?php echo esc_attr( $heading_font_family['font_name'] ); ?>';
	}
	<?php endif; ?>

  <?php if ( $preloader_color ) : ?>
	/* Preloader Color */
	.thecube .cube:before {
		background: <?php echo esc_attr( $preloader_color ); ?>;
	}
	<?php endif; ?>

  <?php if ( $disable_preloader ) : ?>
	/* Preloader */
	.page-loading {
		display: none !important;
	}
	<?php endif; ?>

	<?php if ( $btn_color ) : ?>
	/* Btn Color */
	.lnk-default, a.lnk-default, .lnk-default:hover, a.lnk-default:hover {
		background-color: <?php echo esc_attr( $btn_color ); ?>;
	}
	<?php endif; ?>

	<?php if ( $ad_btn_color ) : ?>
	/* Ad Btn Color */
	.lnk-default2, a.lnk-default2, .lnk-default2:hover, a.lnk-default2:hover, .lnk-default2 i {
		color: <?php echo esc_attr( $ad_btn_color ); ?>;
	}
	/* Ad Btn Color */
	.lnk-default2:before {
		background-color: <?php echo esc_attr( $ad_btn_color ); ?>;
		opacity: 0.5;
	}
	<?php endif; ?>

</style>

<?php
}
}
add_action( 'wp_head', 'minterio_skin', 10 );
