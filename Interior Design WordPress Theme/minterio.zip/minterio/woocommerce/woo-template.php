<?php
/**
 * The template for displaying main shop page
 *
 * @link https://docs.woocommerce.com/document/template-structure/
 *
 * @package minterio
 */

get_header();
?>

<?php

$shop_sidebar = get_field( 'shop_sidebar', 'option' );

if ( ! $shop_sidebar ) {
	$shop_sidebar = 'hide';
}

$args = array(
	'delimiter'   => '',
	'wrap_before' => '<ul class="breadcrumb">',
	'wrap_after'  => '</ul>',
	'before'      => '<li>',
	'after'       => '</li>',
	'home'        => esc_html__( 'Home', 'minterio' ),
);

$page_class = 'shop-catalog';

$shop_bg = get_field( 'shop_bg', 'option' );
$shop_bg_url = '';

if ( $shop_bg ) {
	$shop_bg_url = wp_get_attachment_image_url( $shop_bg, 'minterio_900x900' );
}

$short_desc = get_field( 'shop_desc_cat', 'option' );

if ( is_shop() ) {
	$short_desc = get_field( 'shop_desc_main', 'option' );
	//$page_class = 'shop-page';
}

if ( is_product() ) {
	$page_class = 'catalog-product-page';
}

?>

<section class="pager-section no-bg style2">
	<div class="container">
		<div class="pager-info">
			<?php woocommerce_breadcrumb( $args ); ?>
			<!--breadcrumb end-->

			<?php if ( ! is_product() ) : ?>
			<div class="pg-title-head">
				<h2><?php woocommerce_page_title(); ?></h2>
				<?php if ( $short_desc ) : ?>
				<span><?php echo wp_kses_post( $short_desc ); ?></span>
				<?php endif; ?>
			</div>
			<?php endif; ?>
		</div>

		<?php if ( $shop_bg && ! is_product() ) : ?>
		<div class="pger-imgs no-seduo w-auto">
			<div class="abt-imgz">
				<img src="<?php echo esc_url( $shop_bg_url ); ?>" alt="<?php echo esc_attr( 'Shop', 'minterio' ); ?>">
			</div>
		</div><!--pger-imgs end-->
		<?php endif; ?>

		<div class="clearfix"></div>
	</div>
</section><!--pager-section end-->

<section class="page-content pt-0">
	<div class="container">
		<div class="row">
			<?php if ( 'left' == $shop_sidebar && ! is_product() ) : ?>
			<div class="col-lg-3">
				<?php if ( is_active_sidebar( 'shop-sidebar' ) ) : ?>
				<div id="sidebar" class="widget-area content-sidebar sidebar p-0" role="complementary">
		        	<?php dynamic_sidebar( 'shop-sidebar' ); ?>
		        </div>
			    <?php endif; ?>
			</div>
			<?php endif; ?>

			<div class="<?php if ( 'hide' != $shop_sidebar && ! is_product() ) : ?>col-lg-9<?php else : ?>col-lg-12<?php endif; ?>">
				<div class="<?php echo esc_attr( $page_class ); ?>">
					<?php woocommerce_content(); ?>
				</div><!--shop-catalog end-->
			</div>

			<?php if ( 'right' == $shop_sidebar && ! is_product() ) : ?>
			<div class="col-lg-3">
				<?php if ( is_active_sidebar( 'shop-sidebar' ) ) : ?>
				<div id="sidebar" class="widget-area content-sidebar sidebar p-0" role="complementary">
		        	<?php dynamic_sidebar( 'shop-sidebar' ); ?>
		        </div>
			    <?php endif; ?>
			</div>
			<?php endif; ?>
		</div>
	</div>
</section><!--page-content end-->

<?php
get_footer();
