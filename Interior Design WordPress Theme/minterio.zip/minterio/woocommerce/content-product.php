<?php
/**
 * The template for displaying product content within loops
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/content-product.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 9.4.0
 */

defined( 'ABSPATH' ) || exit;

global $product;

// Check if the product is a valid WooCommerce product and ensure its visibility before proceeding.
if ( ! is_a( $product, WC_Product::class ) || ! $product->is_visible() ) {
	return;
}

$link = apply_filters( 'woocommerce_loop_product_link', get_the_permalink(), $product );
$title_class = apply_filters( 'woocommerce_product_loop_title_classes', 'woocommerce-loop-product__title' );
$title = get_the_title();
$image_size = apply_filters( 'single_product_archive_thumbnail_size', 'woocommerce_thumbnail' );
$image = $product->get_image( $image_size );
$category = '';
$terms = get_the_terms( $product->get_id(), 'product_cat' );
if ( $terms && ! is_wp_error( $terms ) ) {
    if ( ! empty( $terms ) ) {
        $category = $terms[0]->name;
    }
}

?>

<div <?php wc_product_class( 'col-lg-4 col-md-4 col-sm-6', $product ); ?>>
	<div class="shop-col">

		<div class="catalog-head">
			<div class="shop-thumbnail">
				<?php echo wp_kses_post( $image ); ?>

				<?php if ( class_exists( 'YITH_WCWL' ) ) : echo do_shortcode( '[yith_wcwl_add_to_wishlist product_id="' . $product->get_id() . '"]' ); endif; ?>

				<?php
				/**
				 * Hook: woocommerce_before_shop_loop_item_title.
				 *
				 * @hooked woocommerce_show_product_loop_sale_flash - 10
				 * @hooked woocommerce_template_loop_product_thumbnail - 10
				 */
				do_action( 'woocommerce_before_shop_loop_item_title' );
				?>
			</div>
			<div class="shop-hd">
				<div class="shop-hd-info">
					<a href="<?php echo esc_url( $link ); ?>" class="view-details"><?php echo esc_html__( 'view details', 'minterio' ); ?></a>
					<?php
					/**
					 * Hook: woocommerce_after_shop_loop_item_title.
					 *
					 * @hooked woocommerce_template_loop_rating - 5
					 * @hooked woocommerce_template_loop_price - 10
					 */
					do_action( 'woocommerce_after_shop_loop_item_title' );

					/**
					 * Hook: woocommerce_after_shop_loop_item.
					 *
					 * @hooked woocommerce_template_loop_product_link_close - 5
					 * @hooked woocommerce_template_loop_add_to_cart - 10
					 */
					do_action( 'woocommerce_after_shop_loop_item' );
					?>
				</div>
			</div>
		</div>
		<div class="shop-info">
			<?php if ( $category ) : ?>
			<span><?php echo esc_html( $category ); ?></span>
			<?php endif; ?>

			<?php
			/**
			 * Hook: woocommerce_before_shop_loop_item.
			 *
			 * @hooked woocommerce_template_loop_product_link_open - 10
			 */
			do_action( 'woocommerce_before_shop_loop_item' );
			?>

			<h3 class="<?php echo esc_attr( $title_class ); ?>">
				<a href="<?php echo esc_url( $link ); ?>"><?php echo esc_html( $title ); ?></a>
			</h3>

			<?php
			/**
			 * Hook: woocommerce_shop_loop_item_title.
			 *
			 * @hooked woocommerce_template_loop_product_title - 10
			 */
			do_action( 'woocommerce_shop_loop_item_title' );
			?>
		</div>

	</div>
</div>
