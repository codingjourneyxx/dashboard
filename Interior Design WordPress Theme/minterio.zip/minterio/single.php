<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package minterio
 */

get_header();
?>

	<?php while ( have_posts() ) : the_post(); ?>

	<?php

	$post_id = get_the_ID();

	//content
	$image = get_the_post_thumbnail_url( get_the_ID(), 'minterio_1920xauto' );
	
	//social share
	$social_share = get_field( 'social_share', 'options' );

	?>

	<section class="pager-section pager-section-post no-bg style2">
		<div class="container">
			<div class="pager-info">
				<?php minterio_breadcrumbs( $post_id ); ?>
			</div>
			<div class="clearfix"></div>
		</div>
	</section><!--pager-section end-->

	<section class="page-content pt-0">
		<div class="container">
			<div class="blog-single">
				<div class="row">
					<?php if ( is_active_sidebar( 'sidebar-1' ) ) : ?>
					<div class="col-lg-3">
						<?php get_sidebar(); ?>
					</div>
					<div class="col-lg-9">
					<?php else : ?>
					<div class="col-md-12">
					<?php endif; ?>
						<div class="blog-post single">
							<?php if ( $image ) : ?>
							<div class="blog-thumbnail">
								<img src="<?php echo esc_url( $image ); ?>" alt="<?php esc_attr( get_the_title() ); ?>" />
							</div>
							<?php endif; ?>
							<div class="blog-info">
								<span><?php minterio_post_details(); ?></span>
								<h1 class="blog-title"><?php the_title(); ?></h1>
								
								<!-- content -->
								<?php get_template_part( 'template-parts/content', 'single' ); ?>
								<!-- /content -->

								<!-- post nav -->
								<?php 
								wp_link_pages( array(
									'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'minterio' ),
									'after'  => '</div>',
								) );
								?>
								<!-- /post nav -->
							</div>

							<!-- Post Footer -->
							<?php minterio_entry_footer(); ?>

							<!-- Social Share -->
							<?php minterio_post_social(); ?>

							<!-- Nav -->
							<?php minterio_post_navigation(); ?>

							<?php if ( comments_open() || get_comments_number() ) : ?>
							<!-- Comments -->
							<div class="comments-post">
								<?php
									// If comments are open or we have at least one comment, load up the comment template.
									comments_template();
								?>
							</div>
							<?php endif; ?>

						</div><!--blog-post single end-->
					</div>
				</div>
			</div><!--blog-single end-->
		</div>
	</section><!--page-content end-->

	<?php endwhile; ?>

<?php
get_footer();