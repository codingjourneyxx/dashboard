<?php
/**
 * The template for displaying all posts
 *
 * @package minterio
 */

get_template_part( 'index' );

?>